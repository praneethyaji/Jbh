package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOfrStopRqm;

@RepositoryRestResource
public interface TOfrStopRqmRepository extends JpaRepository<TOfrStopRqm, Integer>{

	TOfrStopRqm findByOrderId(final Integer orderId);
	
}
