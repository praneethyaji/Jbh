package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.Activity;

@RepositoryRestResource
public interface TActivityRepository extends JpaRepository<Activity, Integer> {

	@Query(value = "SELECT A.SRCE_ID, A.SEQ_NO_N, A.ATY_TY_ID, A.PROG_STT_C, A.ACL_STRT_D, A.ACL_STRT_H, A.ACL_CMP_D, A.ACL_CMP_H, A.REC_STT_F from ALI.TACTIVITY A, ALI.TSUBTASK1 B WHERE A.SRCE_ID=:sourceId AND A.SRCE_ID=B.STSK_ID AND A.ATY_TY_ID='ARRIVE' WITH UR ", nativeQuery = true)
	Activity fetchArrivalCallActivityDetails(@Param("sourceId") Integer sourceId);
	
	Activity findBySrceIdAndAtyTyId(final Integer srceId, final String atyTyId);
	
	@Query(value = "SELECT * FROM ALI.TACTIVITY A WHERE A.ATY_TY_ID like '%LOAD%' AND A.REC_STT_F = 'A' AND A.SRCE_ID = :srceId WITH UR", nativeQuery = true)
	Activity fetchBySrceIdForLoad(@Param("srceId") Integer srceId);
	
	@Query(value = "SELECT * FROM ALI.TACTIVITY A WHERE A.ATY_TY_ID like '%UNLD%' AND A.REC_STT_F = 'A' AND A.SRCE_ID = :srceId WITH UR", nativeQuery = true)
	Activity fetchBySrceIdForUnload(@Param("srceId") Integer srceId);
	
	@Query(value = "SELECT * FROM ALI.TACTIVITY A WHERE A.ATY_TY_ID like '%CNT%' AND A.REC_STT_F = 'A' AND A.SRCE_ID = :srceId WITH UR", nativeQuery = true)
	Activity fetchBySrceIdForCount(@Param("srceId") Integer srceId);

}
