package com.jbhunt.loadplannig.integration.backfill.utils;

import org.springframework.stereotype.Service;

import com.google.common.collect.ComparisonChain;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersBuffer;
import com.jbhunt.biz.refNumber.vo.DeletedReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.LineItemVO;
import com.jbhunt.biz.refNumber.vo.ReferenceNumberDetailsVO;
import com.jbhunt.biz.refNumber.vo.UpdatedReferenceNumberVO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor	
public class ReferenceBufferHelper {
	
	 public ReferenceNumbersBuffer assignNewValues(ReferenceNumbersBuffer referenceNumber, ReferenceNumberDetailsVO detailVO,
	            int refNbrUpdIndex, String action) {
	        log.debug(" mg7:setNewValues::");
	        
	        ReferenceNumbersBuffer referenceNumbers=referenceNumber;
	        
	        referenceNumbers.setNumber(detailVO.getReferenceNumber(), refNbrUpdIndex);
	        referenceNumbers.setType(detailVO.getReferenceNumberType(), refNbrUpdIndex);
	        referenceNumbers.setCustomerCode(detailVO.getCustomerCode(), refNbrUpdIndex);
	        referenceNumbers.setDepartment(detailVO.getDepartment() == null ? "" : detailVO.getDepartment(), refNbrUpdIndex);
	        referenceNumbers.setSiteID(detailVO.getSiteID() == null ? 0 : detailVO.getSiteID(), refNbrUpdIndex);
	        referenceNumbers.setAddressID(detailVO.getAddressID() == null ? 0 : detailVO.getAddressID(), refNbrUpdIndex);
	        referenceNumbers.setSequence(detailVO.getSequence() == null ? 0 : detailVO.getSequence(), refNbrUpdIndex);
	        referenceNumbers.setLevel(detailVO.getLevel(), refNbrUpdIndex);
	        referenceNumbers.setWeight(detailVO.getWeight(), refNbrUpdIndex);
	        referenceNumbers.setProductDescr(detailVO.getProductDescr(), refNbrUpdIndex);
	        Integer volume = detailVO.getVolume();
	        int finalVolume = (volume == null) ? 0 : volume;
	        referenceNumbers.setVolume(finalVolume, refNbrUpdIndex);
	        Integer quantity = detailVO.getQuantity();
	        short quan = (quantity == null) ? 0 : quantity.shortValue();
	        referenceNumbers.setQuantity(quan, refNbrUpdIndex);
	        referenceNumbers.setAction(action, refNbrUpdIndex);
	        // Project 37134 - jisaca3 - Setting new fields.
	        Integer refNumI = detailVO.getReferenceNumberI();
	        int referenceNumberI = (refNumI == null) ? 0 : refNumI.intValue();
	        referenceNumbers.setReferenceNumberI(referenceNumberI, refNbrUpdIndex);
	        Integer parRefNumI = detailVO.getParentReferenceNumberI();
	        int parentReferenceNumberI = (parRefNumI == null) ? 0 : parRefNumI.intValue();
	        referenceNumbers.setParentReferenceNumberI(parentReferenceNumberI, refNbrUpdIndex);
	        referenceNumbers= setLineItemsDetails(detailVO, refNbrUpdIndex, referenceNumbers);
	        
	        return referenceNumbers;
	    }

	    private ReferenceNumbersBuffer setLineItemsDetails(ReferenceNumberDetailsVO detailVO, int refNbrUpdIndex,
	            ReferenceNumbersBuffer referenceNumbers) {
	        
	        LineItemVO lineItemVO = detailVO.getLineItemVO();
	        if (lineItemVO != null) {
	            referenceNumbers.setStopLineItemI(lineItemVO.getStopLineItemI()!=null?lineItemVO.getStopLineItemI():0, refNbrUpdIndex);
	            referenceNumbers.setLineItemHazF(lineItemVO.getHazF(), refNbrUpdIndex);
	            referenceNumbers.setLineItemActCls(lineItemVO.getActCls(), refNbrUpdIndex);
	            referenceNumbers.setLineItemRateCls(lineItemVO.getRateCls(), refNbrUpdIndex);
	            referenceNumbers.setLineItemCarrCls(lineItemVO.getCarrCls(), refNbrUpdIndex);
	            referenceNumbers.setLineItemLength(lineItemVO.getLength(), refNbrUpdIndex);
	            referenceNumbers.setLineItemWidth(lineItemVO.getWidth(), refNbrUpdIndex);
	            referenceNumbers.setLineItemHeight(lineItemVO.getHeight(), refNbrUpdIndex);
	            referenceNumbers.setLineItemQtyTyp(lineItemVO.getQtyTyp(), refNbrUpdIndex);
	            referenceNumbers.setLineItemNmfcItemNumber(lineItemVO.getNmfcItemNumber(), refNbrUpdIndex);
	            referenceNumbers.setLineItemNmfcItemSubC(lineItemVO.getNmfcItemSubC(), refNbrUpdIndex);
	            referenceNumbers.setLineItemHandlingUnit(lineItemVO.getHandlingUnit(), refNbrUpdIndex);
	            referenceNumbers.setLineItemHandlingQuantity(lineItemVO.getHandlingQuantity(), refNbrUpdIndex);
	        }
	        return referenceNumbers;
	    }

	    public boolean validateForInsert(ReferenceNumberDetailsVO detailVO) {
	        log.debug("validateForInsert: " + detailVO.getReferenceNumberType());
	        return detailVO.getReferenceNumberType() != null && !"".equalsIgnoreCase(detailVO.getReferenceNumberType());
	    }

	   /* public ReferenceNumbersBuffer setAsOldValues(ReferenceNumbersBuffer referenceNumber, ReferenceNumberDetailsVO detailVO, int offset) {
	        log.debug(" mg7:setAsOldValues::");
	        
	        ReferenceNumbersBuffer referenceNumbers=referenceNumber;
	        
	        referenceNumbers.setOldNumber(detailVO.getReferenceNumber(), offset);
	        referenceNumbers.setOldType(detailVO.getReferenceNumberType(), offset);
	        referenceNumbers.setOldCustomerCode(detailVO.getCustomerCode(), offset);
	        referenceNumbers.setOldDepartment(detailVO.getDepartment(), offset);
	        referenceNumbers.setOldSiteID(detailVO.getSiteID(), offset);
	        referenceNumbers.setOldAddressID(detailVO.getAddressID(), offset);
	        referenceNumbers.setOldSequence(detailVO.getSequence(), offset);
	        return referenceNumbers;
	    }*/

	    public int fetchReferenceNumberIndexLTL(ReferenceNumbersBuffer referenceNumbers, ReferenceNumberDetailsVO detailVO) {
	        int returnValue = -1;
	        for (int i = 0; i < ReferenceNumbersBuffer.MAX_REF_NBR_COUNT; i++) {
	            log.debug("a****" + referenceNumbers.getType(i) + "*" + referenceNumbers.getReferenceNumberI(i) + "*"
	                    + referenceNumbers.getStopLineItemI(i));
	            log.debug("b****" + detailVO.getReferenceNumberType() + "*" + detailVO.getReferenceNumberI() + "*"
	                    + detailVO.getLineItemVO().getStopLineItemI());

	            ComparisonChain comparison = ComparisonChain.start();

	            int result = comparison.compare(referenceNumbers.getType(i), detailVO.getReferenceNumberType())
	                    .compare(referenceNumbers.getReferenceNumberI(i), detailVO.getReferenceNumberI().intValue())
	                    .compare(referenceNumbers.getStopLineItemI(i),
	                            detailVO.getLineItemVO().getStopLineItemI().intValue())
	                    .result();

	            if (result == 0) {

	                returnValue = i;
	                return returnValue;
	            }
	        }
	        return returnValue;
	    }

	    public boolean validate(ReferenceNumberDetailsVO detailVO) {
	        return detailVO.getReferenceNumberType() != null && !"".equalsIgnoreCase(detailVO.getReferenceNumberType())
	                && detailVO.getReferenceNumber() != null && !"".equalsIgnoreCase(detailVO.getReferenceNumber());
	    }

	    public int fetchOldReferenceNumberIndex(ReferenceNumbersBuffer referenceNumbers, UpdatedReferenceNumberVO detailVO) {
	        int returnValue = -1;
	        ComparisonChain comparison = ComparisonChain.start();
	        for (int i = 0; i < ReferenceNumbersBuffer.MAX_REF_NBR_COUNT; i++) {
	            int result = comparison.compare(referenceNumbers.getOldType(i).trim(), detailVO.getOldReferenceNumberType().trim().toUpperCase())
	                    .compare(referenceNumbers.getOldNumber(i), detailVO.getOldReferenceNumber())
	                    .compare(referenceNumbers.getOldSequence(i), detailVO.getOldSequence())
	                    .compare(referenceNumbers.getOldCustomerCode(i), detailVO.getOldCustomerCode())
	                    .compare(referenceNumbers.getOldSiteID(i), detailVO.getOldSiteID())
	                    .compare(referenceNumbers.getOldAddressID(i), detailVO.getOldAddressID())
	                    .compare(referenceNumbers.getOldDepartment(i).trim(), detailVO.getOldDepartment()).result();
	            if (result == 0) {
	                returnValue = i;
	                return returnValue;
	            }
	        }
	        return returnValue;
	    }

	    public int fetchReferenceNumberIndex(ReferenceNumbersBuffer referenceNumbers, DeletedReferenceNumberVO detailVO) {
	        int returnValue = -1;
	        ComparisonChain comparison = ComparisonChain.start();
	        for (int i = 0; i < ReferenceNumbersBuffer.MAX_REF_NBR_COUNT; i++) {

	            int result = comparison.compare(referenceNumbers.getType(i), detailVO.getReferenceNumberType())
	                    .compare(referenceNumbers.getNumber(i), detailVO.getReferenceNumber())
	                    .compare(referenceNumbers.getSequence(i), detailVO.getSequence().intValue())
	                    .compare(referenceNumbers.getCustomerCode(i), detailVO.getCustomerCode())
	                    .compare(referenceNumbers.getSiteID(i), detailVO.getSiteID().intValue())
	                    .compare(referenceNumbers.getAddressID(i), detailVO.getAddressID().intValue())
	                    .compare(referenceNumbers.getDepartment(i), detailVO.getDepartment()).result();

	            if (result == 0) {
	                returnValue = i;
	                return returnValue;
	            }

	        }

	        return returnValue;
	    }

}
