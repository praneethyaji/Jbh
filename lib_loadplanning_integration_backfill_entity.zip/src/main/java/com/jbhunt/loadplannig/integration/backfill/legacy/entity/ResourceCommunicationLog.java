package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "RSC_CMN_LOG", schema = "ALI")
public class ResourceCommunicationLog implements Serializable {

	private static final long serialVersionUID = 2221979065082873858L;

	@Id
	@Column(name = "RSC_CMN_LOG_I")
	private Integer resourceCommunicationLogId;

	@Column(name = "LGC_CLL_SEQ_NBR")
	private Short legacySequenceNumber;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "JOB_I", referencedColumnName = "JOB_I")
	private TDspJobXrf tDspJobXrf;

	@Column(name = "ORD_I")
	private Integer orderId;

	@Column(name = "CLL_TKR_INI")
	private String callTakerInit;

	@Column(name = "OPR_C_1")
	private String driverCode1;

	@Column(name = "USR_SGN_ON_C")
	private String userSignOn;

	@Column(name = "LST_UPD_UID")
	private String lastUpdatedUserId;

	@Column(name = "SRC_NM")
	private String sourceName;

	@Column(name = "CLL_SUB_TYP")
	private String callSubtype;

	@Column(name = "CLL_SEQ_NBR")
	private Short callSequenceNumber;

}
