package com.jbhunt.loadplannig.integration.backfill.configuration;

import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.properties.MainframeEndpointProperties;
import com.lmc341i.lmc341.LMC341Port;
import com.lmc342i.lmc342.LMC342Port;
import com.lmc345i.lmc345.LMC345Port;
import com.lmc359i.lmc359.LMC359Port;
import com.lmc360i.lmc360.LMC360Port;
import com.lmc361i.lmc361.LMC361Port;
import com.lmc362i.lmc362.LMC362Port;
import com.lmc363i.lmc363.LMC363Port;
import com.lmc364i.lmc364.LMC364Port;
import com.lmc365i.lmc365.LMC365Port;
import com.lmc366i.lmc366.LMC366Port;
import com.lmc367i.lmc367.LMC367Port;
import com.oec076i.oec076.OEC076Port;
import com.oec145i.oec145.OEC145Port;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Configuration
@AllArgsConstructor
@Slf4j
public class MainframePortConfiguration {
	private final PIDCredentials pidCredentials;
	private final MainframeEndpointProperties mainFrameEndPoints;

	@Bean
	public LMC341Port lMC341Port() {

		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC341Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc341URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		return (LMC341Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public LMC342Port lMC342Port() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC342Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc342URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		return (LMC342Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public LMC345Port lMC345Port() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC345Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc345URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		return (LMC345Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public LMC360Port lMC360Port() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC360Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc360URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		return (LMC360Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public LMC359Port lMC359Port() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC359Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc359URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		return (LMC359Port) jaxWsProxyFactoryBean.create();

	}

	@Bean
	public LMC361Port lMC361Port() {
		log.info("Creating lmc361");
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC361Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc361URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		log.info("Finalizing creating LMC361");

		return (LMC361Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public LMC362Port lMC362Port() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC362Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc362URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		log.info("Finalizing creating LMC362");

		return (LMC362Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public LMC366Port lMC366Port() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC366Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc366URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		return (LMC366Port) jaxWsProxyFactoryBean.create();

	}

	@Bean
	public LMC363Port lMC363Port() {
		log.info("Creating lmc362");
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC363Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc363URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		log.info("Finalizing creating LMC363");

		return (LMC363Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public OEC145Port oEC145Port() {
		log.info("Creating oec145");
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(OEC145Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getOec145URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		log.info("Finalizing creating OEC145");

		return (OEC145Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public OEC076Port oEC076Port() {
		log.info("Creating oEC076");
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(OEC076Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getOec076URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		log.info("Finalizing creating OEC076");

		return (OEC076Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public LoggingOutInterceptor loggingOutInterceptor() {
		return new LoggingOutInterceptor();
	}

	@Bean
	public LoggingInInterceptor loggingInInterceptor() {
		return new LoggingInInterceptor();
	}

	@Bean
	public LMC364Port lMC364Port() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC364Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc364URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		return (LMC364Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public LMC365Port lMC365Port() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC365Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc365URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		return (LMC365Port) jaxWsProxyFactoryBean.create();
	}

	@Bean
	public LMC367Port lMC367Port() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		jaxWsProxyFactoryBean.setServiceClass(LMC367Port.class);
		jaxWsProxyFactoryBean.setAddress(mainFrameEndPoints.getLmc367URL());

		jaxWsProxyFactoryBean.setPassword(pidCredentials.getPassword());
		jaxWsProxyFactoryBean.setUsername(pidCredentials.getUsername());
		jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor());
		jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor());
		jaxWsProxyFactoryBean.getInFaultInterceptors().add(loggingInInterceptor());
		return (LMC367Port) jaxWsProxyFactoryBean.create();
	}

}