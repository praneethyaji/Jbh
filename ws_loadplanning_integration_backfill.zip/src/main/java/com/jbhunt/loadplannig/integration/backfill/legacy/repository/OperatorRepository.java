package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOperator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

@RepositoryRestResource
public interface OperatorRepository extends JpaRepository<TOperator, Integer> {

	@Query(value = "SELECT OPR_ID,OPR_CD, CHAR(LST_UPDT_TMSTP_S) as LST_UPDT_TMSTP_S from ALI.TOPERATOR where OPR_CD =:alphaId  WITH UR", nativeQuery = true)
	TOperator findLstUpdatedTimeByAlphaId(@Param("alphaId") String alphaId);

	@Query(value = "SELECT A.OPR_CD, B.EQP_UNIT_ID, B.EQP_ID FROM ALI.TOPERATOR A, ALI.TOPER_POWER_ASSOC B " +
			"WHERE A.OPR_ID = B.OPR_ID AND B.REC_STT_F = 'A' AND B.EQP_ID = (:eqpId) WITH UR ", nativeQuery = true)
	List<Object[]> getDriverDetailsByEqpId(@Param("eqpId") int eqpId);
	
}
