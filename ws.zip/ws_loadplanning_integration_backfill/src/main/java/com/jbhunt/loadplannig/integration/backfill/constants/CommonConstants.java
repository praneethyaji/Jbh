package com.jbhunt.loadplannig.integration.backfill.constants;


public final class CommonConstants {


	private CommonConstants() {
	}

	public static final String FREE_COMMENTS = "FREE DRIVER FROM %s NEXT SYSTEM";
	public static final String PID_APPLICATION_DOMAIN = "loadplanning";
	public static final String PID_RESOURCE_PROPERTIES = "default";
	public static final String ASSIGN_ACTION = "assign";
	public static final String UNASSIGN_ACTION = "unassign";
	public static final String TRACTOR_RQD_FLAG = "Y";
	public static final String FREE_CALL_TYPE = "F";
	public static final String ARRIVAL_CALL_TYPE="A";
	public static final String LOADED_CALL_TYPE = " L";
	public static final String UNLOADED_CALL_TYPE = " U";
	public static final String DRIVER_UNLOADED = "DrvrUnLd";
	public static final String END_HUB_MIL_RANDOM ="54321";
	public static final String DIRVER_PREPLAN_UPDATE = "U";
	public static final String DIRVER_PREPLAN_DELETE = "D";
	public static final String SPACE_1 = " ";
	public static final String SPACE_10 = "          ";
	public static final String SPACE_8 = "        ";
	public static final String EMPTY_SPACE="";
	public static final String DATA_STATE_B ="B";
	public static final String DATA_STATE_A ="A";
	public static final String USER_ID = "JCNT571";
	public static final int ZERO=0;
	public static final String DATE_FORMAT = "MM/dd/yyyy";
	public static final String TIME_FORMAT = "HH:mm";


	public static final String BOL = "BOL" ;
	public static final String PRO_NBR="PRO NBR";
	public static final String SEAL= "SEAL";
	public static final String PO_NBR= "PO NBR";

	public static final String DRIVER_COUNT_FREIGHT = "DrvrCntFrg";
	public static final String DRIVER_LOAD = "DrvrLoad";

	public static final String TRACTOR_AND_DRIVER_SAVEPLAN = "U";
	public static final String TRACTOR_AND_DRIVER_CANCELL = "D";
	public static final String TRACTOR_AND_RIVER_SENDPLAN_ORDER_SAVE = "A";
	public static final String TRACTOR_AND_RIVER_SENDPLAN_ORDER_UPDATE = "U";
	public static final String TRACTOR_PRG_CALLING = "MULTIPP";

	public static final String DRIVER_RSV_ACTION_UPDATED = "A";
	public static final String DRIVER_RSV_ACTION_DELETED = "D";
	public static final String CALLING_PROGRAM_NAME_LMC341 = "LMC341";
	public static final String ORDER_SEGMENT_FFP_ACTION = "N";
	public static final String PLAN_BY_DRIVER = "D";
	public static final String ARRIVAL_CHECKCALL_EVENT_SUBTYPE = "ARRIVAL_CHECK_CALL";
	public static final String FLEXIBLE_APPT_CHANGE_REASON_CODE = "27";
	public static final String EARLY_ARRIVAL_FAILURE_REASON_CODE = "A2";
	public static final String AUTO_APPLY_REASON_CODE_CONTACT = "AUTO-APPLIED";
	public static final String SORRY_FOR_DELAY="SRY FOR  DELAY";
	public static final String JBHUNT_CARRIER_ALPHA_CODE= "HJBT";
	public static final String INCLUDES_BILLING="Y";
	public static final String EARLY_ARRIVAL_FAILURE_DESCRIPTION = "EARLY ARRIVAL FAILURE";
	public static final String LATE_ARRIVAL_FAILURE_DESCRIPTION = "LATE ARRIVAL FAILURE";
	public static final String LATE_ARRIVAL_DESCRIPTION = "FLEXIBLE APPOINTMENT";
	public static final String CATEGORY_OPERATIONS = "OPERATIONS";
	public static final String CATEGORY_OTHER = "OTHER";
	public static final String EARLY_ARRIVAL_TIME_DEVIATION = "Early Arrival";
	public static final int CHECK_CALL_VAR_MIN_LENGTH= 290;
	public static final String MF_DEFAULT_VAL_STRING = " ";
	public static final String TEN_ZEROS= "0000000000";

	public static final String ZERO_STRING = "0";

	public static final long MF_DEFAULT_VAL_INT = 0;

	public static final String DCS = "HJBT JBDCS";

	public static final String JBVAN = "HJBT JBVAN";

	public static final String DB2_RESOURCE_URL = "jbhunt.general.datasource.com.jbhunt.datasource.JBHDB2P";


	public static final long NET_APP_IN = 534;
	public static final String BOX_LOC_INT = "BOXLOCINT";
	public static final String OPERATION = "U";

	public static final String CROSS_REF_URL = "https://masterdatacrossreferenceservices-dev.jbhunt.com/masterdatacrossreferenceservices";

	public static final String MF_DEV_LMC359_URL = "http://devpjes2.jbhunt.com:3180/OCBACKFILL/LMC359CALL";

	public static final String MF_DEV_LMC363_URL = "http://devpjes2.jbhunt.com:3180/OCBACKFILL/LMC363call";

	public static final String MF_DEV_LMC342_URL = "http://devpjes2.jbhunt.com:3180/OCBACKFILL/LMC342CALL";

	public static final String FAIL = "Fail";

	public static final String TRACTOR_PREPLAN_ACTION = "U";

	public static final String TRACTOR_PREPLAN_ORDER_ACTION = "A";

	public static final String BOBTAIL = "Bobtail";

	public static final String DEADHEAD = "DeadHead";

	public static final String PKUP_EQUI = "PickupEqui";

	public static final String DROP_EQUI = "DropEqui";

	public static final String TRADE_IN = "Trade- in";

	public static final String TRACTOR = "Tractor";

	public static final String OWO_CREATE = "C";

	public static final String OWO_UPDATE = "U";

	public static final String OWO_CREATE_RESPONSE = "CREATED";

	public static final String OWO_UPDATE_RESPONSE = "UPDATED";

	public static final String BTAILNOPAY = "BTAILNOPAY";

	public static final String DHNOPAY = "DHNOPAY";


	public static final String DROPTRLR = "DROPTRLR";

	public static final String PKUPTRLR = "PKUPTRLR";

	public static final String OWO_DISPATCH = "S";

	public static final String TRAILING_EQUIP = "Trailing Equipment";

	public static final String CHASIS_PLAN_TYPE1 = "Chassis PlanType 1";

	public static final String APPEND_ZERO_PREFIX = "APPEND_ZERO_PREFIX";
	public static final String STRING_Y = "Y";
	public static final String STRING_N = "N";

	public static final String REPOSITION = "Reposition";

	public static final String DRVR_REFUSED = "40";

	public static final int SINGLE_STOP = 1;

	public static final String PROGRAM_LMC361 = "LMC361";

	public static final String STRING_1 = "1";

	public static final String STRING_U = "U";

	public static final String STRING_B="B";

	public static final String STRING_J = "J";

	public static final String STRING_D = "D";

	public static final String STRING_W = "W";

	public static final String STRING_T = "T";

	public static final String STRING_L = "L";

	public static final String STRING_I = "I";

	public static final String STRING_C = "C";

	public static final String CALLTYPE_CO="CO";

	public static final String CHECK_CALL_PICKUP = "PK";

	public static final String CHECK_CALL_DROP = "S";

	public static final String TRAILER = "TRAILER"; 
	
	public static final String AVAILABLE = "Available";
	
	public static final String PLANNED = "Planned";
	
	public static final String DISPATCHED = "Dispatched";
	
	public static final String STANDARD_PLAN = "StndrdPlan";
	
	public static final String SUBEVENTTYPE_COMMENTCALL="COMMENTCALL";
	
	public static final String CHECK_CALL_DEADHEAD = "DH";
	
	public static final String CHECK_CALL_BOBTAIL = "B";
	
	public static final String SERVICE_CALL_LMC223 = "LMC223";
	
	public static final String STRING_A = "A";
	
	public static final String EQUIPNMENT_NOT_FOUND  = "Equipment details not found.";
	
	public static final String CHASSIS  = "CHASSIS";
	
	public static final String CONTAINER  = "CONTAINER";
	
	public static final String ISBOTHPAIRED  = "ISBOTHPAIRED";
	
	public static final String ISDRIVERALREADYPAIRED  = "ISDRIVERALREADYPAIRED";
	
	public static final String ISTRUCKALREADYPAIRED  = "ISTRUCKALREADYPAIRED";
	
	public static final String SUBEVENTTYPE_TCALL ="TERMINATECALL";
	
	public static final String CALLTYPE_TC="TC";
	
	public static final String STOP_REASONCODE="Terminate";
	
	public static final String NO_EQUIPMENT_DETAILS = "Equipment details not available in the topic posted";
	
	public static final String DEFAULT_COMMENT =  "Default Comment";
}

