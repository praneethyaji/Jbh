package com.jbhunt.loadplannig.integration.backfill.utils;

import lombok.Data;

@Data
public class EquipmentResponse {

	private Integer equipmentId;

	private String equipmentNumber;
	
}
