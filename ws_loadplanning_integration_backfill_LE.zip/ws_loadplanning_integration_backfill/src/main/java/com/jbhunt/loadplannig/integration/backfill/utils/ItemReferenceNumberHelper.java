package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanReferenceNumberDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopHandlingUnitAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopItemDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopItemHandlingUnitReferenceNumberAssociationDTO;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ItemReferenceNumberHelper {
	
	public OperationalPlanStopItemDTO getStopItemIfTiedToReferenceNumber(OperationalPlanReferenceNumberDTO referenceNumberDTO, OperationalPlanStopDTO stopDTO) {
		OperationalPlanStopItemDTO stopItem = null;
        for (OperationalPlanStopHandlingUnitAssociationDTO stopHandlingUnitAssociationDTO : stopDTO.getOperationalPlanStopHandlingUnitAssociations()) {
                Optional<List<OperationalPlanStopItemHandlingUnitReferenceNumberAssociationDTO>> stopItemReferenceNumberAssociations =
                        Optional.ofNullable(stopHandlingUnitAssociationDTO.getOperationalPlanStopItemHandlingUnit().getOperationalPlanStopItemHandlingUnitReferenceNumberAssociations());
                if (stopItemReferenceNumberAssociations.isPresent()) {
                    for (OperationalPlanStopItemHandlingUnitReferenceNumberAssociationDTO stopItemReferenceNumberAssociation :
                            stopItemReferenceNumberAssociations.get()) {
                        if (stopItemReferenceNumberAssociation.getOperationalPlanStopItemHandlingUnitReferenceNumberAssociationID()
                                .equals(referenceNumberDTO.getOperationalPlanReferenceNumberId())) {
                        	stopItem = stopHandlingUnitAssociationDTO.getOperationalPlanStopItemHandlingUnit().getOperationalPlanStopItems().get(0);
                        }
                    }
                }
            }
        return stopItem;
    }
	
	 /*public OperationalPlanStopItemDTO getStopItemByID(OperationalPlanStopDTO stopDTO, Integer stopItemID) {
		 OperationalPlanStopItemDTO stopItem = null;
		 for (OperationalPlanStopHandlingUnitAssociationDTO stopHandlingUnitAssociationDTO : stopDTO.getOperationalPlanStopHandlingUnitAssociations()) {
	                for (OperationalPlanStopItemDTO stopItemDTO : stopHandlingUnitAssociationDTO.getOperationalPlanStopItemHandlingUnit().getOperationalPlanStopItems()) {
	                    if (stopItemDTO.getOperationalPlanStopItemId() == stopItemID) {
	                        stopItem = stopItemDTO;
	                    }
	                }
	            }
	        return stopItem;
	    }*/
	 
	 
	/*public List<OperationalPlanStopItemHandlingUnitReferenceNumberAssociationDTO> getReferenceNumberAssociationsForItemChg(
			OperationalPlanStopDTO stopDTO, Integer stopItemID) {
		List<OperationalPlanStopItemHandlingUnitReferenceNumberAssociationDTO> referenceNumberAssociationList = Collections
				.emptyList();
		for (OperationalPlanStopHandlingUnitAssociationDTO stopHandlingUnitAssociationDTO : stopDTO
				.getOperationalPlanStopHandlingUnitAssociations()) {
			referenceNumberAssociationList = stopHandlingUnitAssociationDTO.getOperationalPlanStopItemHandlingUnit()
					.getOperationalPlanStopItemHandlingUnitReferenceNumberAssociations();
			break;
		}

		return referenceNumberAssociationList;
	}*/
	
	
	/*public List<OperationalPlanReferenceNumberDTO> getReferenceNumberDTOsForStopReferenceNumbers(OperationalPlanStopDTO stopDTO, List<OperationalPlanReferenceNumberDTO> stopReferenceNumbers) {
        ArrayList<OperationalPlanReferenceNumberDTO> referenceNumberDTOS = new ArrayList<>();
        for (OperationalPlanReferenceNumberDTO referenceNumberDTO : stopDTO.getOperationalPlanReferenceNumbers()) {
            for (OperationalPlanReferenceNumberDTO stopReferenceNumber : stopReferenceNumbers) {
                if (referenceNumberDTO.getOperationalPlanReferenceNumberId().equals(stopReferenceNumber.getOperationalPlanReferenceNumberId())) {
                    referenceNumberDTOS.add(referenceNumberDTO);
                }
            }
        }
        return referenceNumberDTOS;
    }*/
	       

}
