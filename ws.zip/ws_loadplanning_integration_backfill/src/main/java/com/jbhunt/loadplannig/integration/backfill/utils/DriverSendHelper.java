package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.Reservation;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOperator;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.RsvrscRepository;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea.Lmc341InputArea;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea.Lmc341InputArea.Lmc341DrRscPpTable;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea.Lmc341InputArea.Lmc341DrRscPpTable.Lmc341DrStpTable;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class DriverSendHelper {

	private final RsvrscRepository rsvrscRepository;

	public Lmc341DrRscPpTable createDriverRsvPreplanBuffer(Integer nextOrderId, Integer nextLoadId,
			String nextLoadnumber, String taskTimeStamp, List<Lmc341DrStpTable> stpDetails, Integer orderId,
			String orderNumber, String assingOrCancell, String tCallLocation, final boolean isOWO) {

		Lmc341DrRscPpTable rscppTable = new Lmc341DrRscPpTable();
		rscppTable.setLmc341DrFiller(CommonConstants.EMPTY_SPACE);
		rscppTable.setLmc341DrOrdNbr(orderNumber);
		rscppTable.setLmc341DrPkupDelvSw(CommonConstants.EMPTY_SPACE);

		if (!assingOrCancell.equalsIgnoreCase("D")) { 
			rscppTable.setLmc341DrRscRsvI(CommonConstants.ZERO);
			rscppTable.setLmc341DrRscRsvTs(CommonConstants.EMPTY_SPACE);
			rscppTable.setLmc341DrRsvActionSw(CommonConstants.DRIVER_RSV_ACTION_UPDATED);
			rscppTable.setLmc341DrStpCnt(stpDetails.size());
			rscppTable.getLmc341DrStpTable().addAll(stpDetails);
		} else {
			log.info("task id " + orderId);
			Reservation rscDriverDetails = Optional.ofNullable(rsvrscRepository.getrsvDetailsofDriver(orderId))
					.orElseThrow(
							() -> new JBHuntRuntimeException("Reservation doesn't exit for the corresponding Order."));
			rscppTable.setLmc341DrRscRsvI(rscDriverDetails.getReservationId());
			rscppTable.setLmc341DrRscRsvTs(rscDriverDetails.getLastUpdateTimeStamp());
			rscppTable.setLmc341DrRsvActionSw(CommonConstants.DRIVER_RSV_ACTION_DELETED);
			rscppTable.setLmc341DrStpCnt(CommonConstants.ZERO);
		}
		rscppTable.setLmc341DrRsvSeqNbr(1);
		rscppTable.setLmc341DrTaskId(orderId);
		rscppTable.setLmc341DrNextOrdI(nextOrderId);
		if(isOWO) {
			rscppTable.setLmc341DrNextOwoI(nextOrderId);
		} else {
			rscppTable.setLmc341DrNextOwoI(CommonConstants.ZERO);
		}
		rscppTable.setLmc341DrNextLdI(nextLoadId);
		rscppTable.setLmc341DrNextLdNum(nextLoadnumber); // TODO
		rscppTable.setLmc341DrTaskTs(taskTimeStamp);

		rscppTable.setLmc341DrTcallAptD(CommonConstants.SPACE_10);
		rscppTable.setLmc341DrTcallAptH(CommonConstants.SPACE_8);
		rscppTable.setLmc341DrTcallCtyC(CommonConstants.SPACE_10);
		if (tCallLocation != null) {
			rscppTable.setLmc341DrTcallLoc(tCallLocation);
		} else {
			rscppTable.setLmc341DrTcallLoc(CommonConstants.SPACE_10);
		}
		rscppTable.setLmc341DrTcallMiles(CommonConstants.ZERO);
		rscppTable.setLmc341DrvrSchedStartD(CommonConstants.SPACE_10);
		rscppTable.setLmc341DrvrSchedStartH(CommonConstants.SPACE_8);
		rscppTable.setLmc341OrdSegFppInd(CommonConstants.ORDER_SEGMENT_FFP_ACTION);
		log.info("ending DriverRsvPrePlan");
		return rscppTable;
	}


	public Lmc341InputArea createInputAreaBuffer(TOperator operatiorDetails, String userId, String assingOrCancell,
			Integer countOfOrders, String planTypeCode) {
		log.info("task time stamp after convert" + operatiorDetails.getLastUpdateTimeStamp());
		log.info("driver id " + operatiorDetails.getDriverid());
		Lmc341InputArea inputArea = new Lmc341InputArea();
		inputArea.setLmc341ActionTypeSw(CommonConstants.PLAN_BY_DRIVER);
		inputArea.setLmc341CallingPgm(CommonConstants.CALLING_PROGRAM_NAME_LMC341);
		inputArea.setLmc341DrDriverCode(operatiorDetails.getDriverid());
		inputArea.setLmc341DrTourF(planTypeCode);
		inputArea.setLmc341DrPpActionSw(assingOrCancell);
		inputArea.setLmc341DrRscPpCnt(countOfOrders);
		inputArea.setLmc341Filler(CommonConstants.EMPTY_SPACE);
		inputArea.setLmc341DrOprLstUpdS(operatiorDetails.getLastUpdateTimeStamp());
		inputArea.setLmc341DrInputFiller(CommonConstants.EMPTY_SPACE);
		inputArea.setLmc341DrRemainFiller(CommonConstants.EMPTY_SPACE);
		inputArea.setLmc341Userid(userId);
		return inputArea;
	}

	public List<Lmc341DrStpTable> createStopBuffer(List<TSubtask1> subTaskDetails) {
		List<Lmc341DrStpTable> stpDetailsList = new ArrayList<>();
		Lmc341DrStpTable stpDetails;
		String cityId;
		log.info("stop count is " + subTaskDetails.size());
		for (TSubtask1 subTask : subTaskDetails) {
			stpDetails = new Lmc341DrStpTable();
			stpDetails.setLmc341DrAptBtime(subTask.getCurrentAppointmnetBegHour());
			stpDetails.setLmc341DrAptDate(subTask.getCurrentAppointmnetBegDate());
			stpDetails.setLmc341DrAptEtime(subTask.getCurrentApointmentEndHour());
			stpDetails.setLmc341DrBsstId(subTask.getBusinessId());
			cityId = subTask.getCityId().substring(2) + subTask.getCityId().substring(0, 2);
			stpDetails.setLmc341DrCityC(cityId.replaceAll("\\s+", ""));
			log.info("after converted custcityid is test1" + cityId.replaceAll("\\s+", ""));
			stpDetails.setLmc341DrCustC(subTask.getCustomerCode());
			stpDetails.setLmc341DrRqTyId(subTask.getRequestTyId());
			stpDetails.setLmc341DrSbtskId(subTask.getSubTaskID());
			stpDetails.setLmc341DrSegMile(CommonConstants.ZERO);
			stpDetailsList.add(stpDetails);
		}
		return stpDetailsList;

	}

}
