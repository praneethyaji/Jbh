package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;



@Entity
@Data
@Table(name = "PREPLAN_LOG", schema = "ALI")
public class PreplanLog {
	
	@Id
	@Column(name = "PPL_LOG_I")
	private Integer preplanLogId;
	
	
	@Column(name = "TSK_I")
	private Integer taskId;
	
	
	@Column(name = "EQP_I")
	private Integer equipmentId;
	
	@Column(name="LST_UPD_S")
	private String lastUpateTimestamp;
	
	
	

}
