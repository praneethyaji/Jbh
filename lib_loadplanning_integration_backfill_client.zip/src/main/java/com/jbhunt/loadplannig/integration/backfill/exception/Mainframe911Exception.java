package com.jbhunt.loadplannig.integration.backfill.exception;

public class Mainframe911Exception extends RuntimeException {
    public Mainframe911Exception(String message){
        super(message);
    }
}
