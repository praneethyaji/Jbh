package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@Entity
@Table(name="VEQUIPMENT_LSE", schema = "ALI")
public class VEquipmentLse implements Serializable {
    @Id
    @Column(name="EQP_ID")
    private Integer equipmentId;

    @Column(name="EQP_TY_ID")
    private String equipmentTyId;

    @Column(name="EQP_UNIT_PREFIX_ID")
    private String equipmentUnitPrefixId;

    @Column(name="DIV_ID")
    private String divisionId;

    @Column(name= "LST_CON_D")
    private String listConD;

    @Column(name= "LST_CON_BSST_ID")
    private String listConBsstId;

    @Column(name= "REC_STT_F")
    private String recSttF;

    @Column(name = "CUR_PLX_I")
    private String curPlxI;

    @Column(name = "CUR_PLX_TYP_C")
    private String curPlxTypC;

    @Column(name = "STT_C")
    private String sttC;

    @Column(name = "EQP_UNIT_ID")
    private  String equipment;

    @Column(name = "UNT_STT_C")
    private String unitSttC;

    @Column(name = "MJR_CLS_C")
    private String majorClassC;

    @Column(name= "SUB_CLS_C")
    private String subClsC;

    @Column(name ="LST_ORD_NBR_CH")
    private String listOrderNumberCh;
}
