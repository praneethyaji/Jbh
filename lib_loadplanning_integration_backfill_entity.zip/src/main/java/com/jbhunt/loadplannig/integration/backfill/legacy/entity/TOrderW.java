
package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TORDER_W", schema = "ALI")
public class TOrderW implements Serializable {

	private static final long serialVersionUID = 3931372509084744183L;

	@Id
	@Column(name = "ORD_I")
	private Integer lagacyOrderId;  

	@Column(name = "ORD_NBR_CH")
	private String lagacyOrderNumber;

	@Column(name = "CRT_S")
	private String orderCreatedTimeStamp;

	@Column(name = "LST_UPD_S")
	private String lastUpdateTimeStamp;

}
