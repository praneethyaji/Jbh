package com.jbhunt.loadplannig.integration.backfill.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.config.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import com.jbhunt.loadplannig.integration.backfill.utils.OEC145MapperHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.OEC145MapperServiceHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.OEC145MapperUtil;
import com.jbhunt.loadplannig.integration.backfill.utils.OrderUpdateMapperHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.OrderUpdatePrePlanBufferHelper;
import com.oec145i.oec145.OEC145Port;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InCommentsLine;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InLoadSyncData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InReconBuffer13;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InReconBuffer13.Oee5InRcdEnterDate;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InReconBuffer13.Oee5InRcdRcdDate;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InReconBuffer13.Oee5InRcdRcdTime;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InRqmntsLine;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InputBuffer1;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData;
import com.response.oec145i.oec145.ProgramInterface.Oee5OutputChannelData;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class OEC145MapperService {
	
    private final OEC145Port oec145Port;
    private final OEC145MapperUtil oec145MapperUtil;
    private final OEC145MapperHelper oEC145MapperHelper;
    private final OEC145MapperServiceHelper oEC145MapperServiceHelper;
    private final OrderUpdatePrePlanBufferHelper orderUpdatePrePlanBufferHelper;
    private final OrderUpdateMapperHelper orderUpdateMapperHelper;
	
	
	private List<Oee5InCommentsLine> mapCommentBuffer(Oe76OutputChannelData orderDetails) {
        List<Oee5InCommentsLine> commentBuffer = new ArrayList<>();

        orderDetails.getOe76OutCommentsBuffer10().forEach(x -> {
            Oee5InCommentsLine oee5InCommentsLine = new Oee5InCommentsLine();

            oee5InCommentsLine.setOee5InCommentsCmm(x.getOe76OutCommentsCmm());
            oee5InCommentsLine.setOee5InCommentsCmmTypC(x.getOe76OutCommentsCmmTypC());
            oee5InCommentsLine.setOee5InCommentsJbhsoacS(x.getOe76OutCommentsJbhsoacS().trim());
            oee5InCommentsLine.setOee5InCommentsSeqNbr(x.getOe76OutCommentsSeqNbr());
            commentBuffer.add(oee5InCommentsLine);
        });
        return commentBuffer;
    }

    private Oee5InReconBuffer13 mapReConsignmentBuffer() {
        Oee5InReconBuffer13 oee5InReconsignmentBuffer13 = new Oee5InReconBuffer13();
        Oee5InRcdEnterDate oee5InRcdEnterDate = new Oee5InRcdEnterDate();
        oee5InReconsignmentBuffer13.setOee5InRcdEnterDate(oee5InRcdEnterDate);
        oee5InReconsignmentBuffer13.setOee5InRcdFee(BigDecimal.ZERO);
        oee5InReconsignmentBuffer13.setOee5InRcdFeeActTypC("waiveFee");
        Oee5InRcdRcdDate oee5InRcdRcdDate = new Oee5InRcdRcdDate();
        oee5InRcdRcdDate.setOee5InRcdRcdDd(1);
        oee5InRcdRcdDate.setOee5InRcdRcdMm(8);
        oee5InRcdRcdDate.setOee5InRcdRcdYy(17);
        oee5InReconsignmentBuffer13.setOee5InRcdRcdDate(oee5InRcdRcdDate);
        Oee5InRcdRcdTime oee5InRcdRcdTime = new Oee5InRcdRcdTime();
        oee5InRcdRcdTime.setOee5InRcdRcdHour(6);
        oee5InRcdRcdTime.setOee5InRcdRcdMin(12);
        oee5InReconsignmentBuffer13.setOee5InRcdRcdTime(oee5InRcdRcdTime);
        return oee5InReconsignmentBuffer13;

    }

    private List<Oee5InRqmntsLine> mapRequirementsBuffer(Oe76OutputChannelData orderDetails,
            Oee5InputBuffer1 inputBuffer) {
        List<Oee5InRqmntsLine> requirementsBuffer = new ArrayList<>();
        orderDetails.getOe76OutRqmntsBuffer14().forEach(x -> {
            Oee5InRqmntsLine oee5InRqmntsLine = new Oee5InRqmntsLine();
            oee5InRqmntsLine.setOee5InRqmntsOfrStpSeqNbr(x.getOe76OutRqmntsOfrStpSeq());
            oee5InRqmntsLine.setOee5InRqmntsRqmClsC(x.getOe76OutRqmntsRqmClsC());
            oee5InRqmntsLine.setOee5InRqmntsRqmClsTypC(x.getOe76OutRqmntsRqmClsTypC());
            requirementsBuffer.add(oee5InRqmntsLine);
        });
        inputBuffer.setOee5InputNbrOfRqmnts(!requirementsBuffer.isEmpty() ? (short) requirementsBuffer.size() : 0);
        return requirementsBuffer;
    }
    
    
    public Oee5InputChannelData getInputChannelDataForOec145(Oe76OutputChannelData orderDetails, OrderLoadSync loadDetails)
            throws JBHuntRuntimeException {
    	
        Oee5InputChannelData oee5InputChannelData = new Oee5InputChannelData();
        oee5InputChannelData.setOee5InCommentsBuffer3(this.mapCommentBuffer(orderDetails));
        List<Oee5InLoadSyncData> inLoadSyncDatas = new ArrayList<>();
        inLoadSyncDatas.add(orderUpdateMapperHelper.mapLoadSyncBuffer(loadDetails));
        oee5InputChannelData.setOee5InLoadSyncBuffer12(inLoadSyncDatas);
        oee5InputChannelData.setOee5InNonstpBuffer4(oEC145MapperHelper.mapNonStopBuffer(orderDetails));
        oee5InputChannelData.setOee5InOrdBuffer2(oec145MapperUtil.mapOrderBuffer2(orderDetails));
        oee5InputChannelData
                .setOee5InOthOrdBuffer9(oEC145MapperServiceHelper.mapOtherOrderBuffer(orderDetails));
        oee5InputChannelData.setOee5InStpBuffer5(
                oEC145MapperHelper.mapStopBuffer(orderDetails));
        oee5InputChannelData.setOee5InOthOrdBuffer7(orderUpdatePrePlanBufferHelper.mapPrePlanBuffer());
        oee5InputChannelData.getOee5InOthOrdBuffer7().setOee5InPplanCmntC(orderDetails.getOe76OutOtherBuffer19().getOe76OutPplanCmntC()!=null?orderDetails.getOe76OutOtherBuffer19().getOe76OutPplanCmntC().trim():"");
        Oee5InputBuffer1 inputBuffer = orderUpdateMapperHelper.mapInputBuffer(orderDetails);
        oee5InputChannelData.setOee5InRateBuffer8(orderUpdateMapperHelper.mapRateBuffer());
        oee5InputChannelData.setOee5InReconBuffer13(this.mapReConsignmentBuffer());
        oee5InputChannelData.setOee5InRqmntsBuffer6(this.mapRequirementsBuffer(orderDetails, inputBuffer));
        oee5InputChannelData.setOee5InTrlgEqpBuffer11(orderUpdateMapperHelper.mapTrailingEquipmentBuffer(orderDetails));
        oee5InputChannelData.setOee5InputBuffer1(inputBuffer);
        oee5InputChannelData.getOee5InOthOrdBuffer7().setOee5InPplanCmntC("");
        return oee5InputChannelData;
    }

    public Oee5OutputChannelData callOEC145UpdateService(Oee5InputChannelData input) throws JBHuntRuntimeException {
        Oee5OutputChannelData output = null;
       
        try {
            output = oec145Port.oec145Operation(input);
        } catch (Exception e) {
            log.error("Error while callOEC145UpdateService" + e);
            if (e.getMessage().contains("404")) {
                throw new ResourceNotFoundException(e.getMessage(), null);
            } else {
                throw new JBHuntRuntimeException(e.getLocalizedMessage());
            }
        }
        return output;
    }

}
