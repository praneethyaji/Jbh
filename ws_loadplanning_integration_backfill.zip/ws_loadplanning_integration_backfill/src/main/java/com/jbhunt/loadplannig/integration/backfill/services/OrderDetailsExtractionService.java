package com.jbhunt.loadplannig.integration.backfill.services;

import org.springframework.stereotype.Service;

import com.request.oec076i.oec076.ProgramInterface.Oe76InputChannelData.Oe76InHeadingBuffer1;
import com.request.oec076i.oec076.ProgramInterface.Oe76InputChannelData.Oe76InXmlStringBuffer16;
import com.request.oec076i.oec076.ProgramInterface.Oe76InputChannelData.Oe76InputBuffer2;

@Service
public class OrderDetailsExtractionService {

	/*public Oe76InXmlStringBuffer16 createXmlSecurity(String securityString) {

		Oe76InXmlStringBuffer16 inXmlStringBuffer16 = new Oe76InXmlStringBuffer16();

		if (null == securityString || "".equalsIgnoreCase(securityString.trim())) {
			inXmlStringBuffer16.setOe76InXmlString(String.format("%-10000s", ""));

		} else {
			inXmlStringBuffer16.setOe76InXmlString(String.format("%-10000s", securityString));
			inXmlStringBuffer16.setOe76InXmlStringLen(securityString.length());
		}

		inXmlStringBuffer16.setOe76InXmlFiller(String.format("%-20000s", ""));

		return inXmlStringBuffer16;
	}*/

	/*public Oe76InHeadingBuffer1 createHeader(String callMode) {
		Oe76InHeadingBuffer1 headingBuff = new Oe76InHeadingBuffer1();
		headingBuff.setOe76InFunction(callMode);
		headingBuff.setOe76InProgramToStart("PROGRAM");
		return headingBuff;
	}

	public Oe76InputBuffer2 createInputBuffer2(String callMode, String prgId, String userId, Integer orderId) {
		Oe76InputBuffer2 inpbuff = new Oe76InputBuffer2();
		inpbuff.setOe76InputFunction(callMode);
		inpbuff.setOe76InputPcPrgId(prgId);
		inpbuff.setOe76InputUsrC(userId);
		inpbuff.setOe76InputOrdTy(" ");
		inpbuff.setOe76InputOverrideFlag("");
		inpbuff.setOe76InputOvrdCount((short) 0);
		if (orderId != null) {
			inpbuff.setOe76InputOrdI(orderId);
		}

		return inpbuff;
	}*/

}
