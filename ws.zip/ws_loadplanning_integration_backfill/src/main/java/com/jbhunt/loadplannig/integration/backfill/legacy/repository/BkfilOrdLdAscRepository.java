package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.BkfilOrdLdAsc;


@Repository
@Transactional
public interface BkfilOrdLdAscRepository extends JpaRepository<BkfilOrdLdAsc, Integer>, QueryDslPredicateExecutor<BkfilOrdLdAsc> {
	
	@Query(value = "Select NEXT_LD_I FROM ALI.BKFIL_ORD_LD_ASC  WHERE NEXT_ORD_I=:newOrderId fetch first 1 rows only WITH UR ", nativeQuery = true)
    Integer getNextLoadIdbyNewOrderId(@Param("newOrderId") Integer newOrderId);
	
	@Query(value = "Select NEXT_LD_I FROM ALI.BKFIL_ORD_LD_ASC  WHERE NEXT_OWO_I=:owoId fetch first 1 rows only WITH UR ", nativeQuery = true)
    Integer getNextLoadIdbyOwoId(@Param("owoId") Integer owoId);
	
	 @Query(value = "Select NEXT_ORD_I FROM ALI.BKFIL_ORD_LD_ASC  WHERE NEXT_LD_I=:operationalPlanId WITH UR ", nativeQuery = true)
	    List<Integer> getNewOrderIdByOperationalPlanId(@Param("operationalPlanId") Integer operationalPlanId);
}


