package com.jbhunt.loadplannig.integration.backfill.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CheckcallElement {
    private String fieldName;
    private String type;
    private short length;
}
