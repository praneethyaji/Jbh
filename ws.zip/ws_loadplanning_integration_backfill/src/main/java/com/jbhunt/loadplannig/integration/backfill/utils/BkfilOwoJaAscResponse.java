package com.jbhunt.loadplannig.integration.backfill.utils;

import lombok.Data;

@Data
public class BkfilOwoJaAscResponse {

	private int ordI;

	private String ordNbrch;

	private int nxtOWOI;

	private String nxtOWONo;

}
