package com.jbhunt.loadplannig.integration.backfill.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.Reservation;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TPndJobAsn;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TpndJobAsnRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.DriverAssignmentDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.personnel.people.dto.PeopleDetailsDTO;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable.Wo42OrdStopInfo;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class TractorAndDriverSendplanHelper {

	private final EquipmentRepository equipmentRepository;
	private final TpndJobAsnRepository tpndJobAsnRepository;
	private final OrderLoadRepository orderLoadRepository;

	public List<Wo42OrdStopInfo> populateStopDetails(List<TSubtask1> listSubTasks) {

		List<Wo42OrdStopInfo> listOfStopDetails = new ArrayList<>();
		for (TSubtask1 subTask : listSubTasks) {
			Wo42OrdStopInfo stopDetails = new Wo42OrdStopInfo();

			stopDetails.setWo42StpAptD(CommonConstants.EMPTY_SPACE);
			stopDetails.setWo42StpAptH1(CommonConstants.EMPTY_SPACE);
			stopDetails.setWo42StpAptH2(CommonConstants.EMPTY_SPACE);
			stopDetails.setWo42StpBsstI(subTask.getBusinessId());
			String cityId = subTask.getCityId().substring(2) + subTask.getCityId().substring(0, 2);
			stopDetails.setWo42StpCity(cityId.replaceAll("\\s+", ""));
			stopDetails.setWo42StpCusC(CommonConstants.EMPTY_SPACE);
			stopDetails.setWo42StpPrfSeqN(subTask.getPreferanceSequenceNumber());
			stopDetails.setWo42StpReqTy(subTask.getRequestTyId());
			stopDetails.setWo42StpSegMil(CommonConstants.ZERO);
			stopDetails.setWo42StpStskI(subTask.getSubTaskID());
			listOfStopDetails.add(stopDetails);
		}
		return listOfStopDetails;
	}

	public Wo42OrdDtlTable populateOrderDetails(Integer nextOrderId, Integer nextLoadId, Integer legacyOrderId,
			List<Wo42OrdStopInfo> subTaskDetails, String actionFlag, String orderLevalActionFlag,
			String timestampOfTask, Reservation reservationDetails, ResourceAssignmentPlanDTO resourceAssignmentPlanDTO,
			Integer seqNumber, String tCallLocationCode, boolean isOldplanOrder,
			List<Integer> oldPlannedOrdersDetailsForUpdate, String legacyOrderNumber, boolean isOWO,
			EquipmentDetailsDTO equipmentDetails) {

		final Optional<DriverAssignmentDTO> driverAaaignment = Optional
				.ofNullable(resourceAssignmentPlanDTO.getDriverAssignment());
		final String driverId = driverAaaignment.isPresent() ? driverAaaignment.get().getDriverId() : "";
		Wo42OrdDtlTable ordDtlTable = new Wo42OrdDtlTable();
		log.info("action flag " + orderLevalActionFlag);
		ordDtlTable.setWo42OrdAction(orderLevalActionFlag);
		ordDtlTable.setWo42OrdDivId(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdEtaChgSw("Y");
		boolean isGoingtoUpdateOldOrder = oldPlannedOrdersDetailsForUpdate.contains(nextOrderId);
		if (isOldplanOrder && !isGoingtoUpdateOldOrder) {
			log.info("oldorder" + legacyOrderNumber);
			TPndJobAsn tpndJobAsn = tpndJobAsnRepository.findTPNJobDetailsByTaskId(legacyOrderId);
			ordDtlTable.setWo42OrdEtaDate(tpndJobAsn.getEstimateTimeAppointmentDate());
			ordDtlTable.setWo42OrdEtaTime(tpndJobAsn.getEstimateTimeAppointmentHours());
		} else {
			LocalDateTime localDateTime= null;
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH.mm.ss");

			TPndJobAsn tpndJobAsn =tpndJobAsnRepository
					.getMaxEtaDateAndTimeByEqpUnitId(equipmentDetails.getEquipmentNumber());
			if (tpndJobAsn!=null){
				String etaDateAndTime = tpndJobAsn.getEstimateTimeAppointmentDate().trim() + " " + tpndJobAsn.getEstimateTimeAppointmentHours().trim();
				localDateTime = LocalDateTime.parse(etaDateAndTime, formatter).plusDays(3);
			}else{
				localDateTime = LocalDateTime.now().plusDays(3);
			}

			final String orgDate = formatter.format(localDateTime).substring(0, 10);
			final String orgTime = formatter.format(localDateTime).substring(11, 19);
			ordDtlTable.setWo42OrdEtaDate(orgDate);
			ordDtlTable.setWo42OrdEtaTime(orgTime);
		}

		ordDtlTable.setWo42OrdEtcChgSw("N");
		ordDtlTable.setWo42OrdEtcDate(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdEtcTime(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdNbrStops(subTaskDetails.size());
		ordDtlTable.setWo42OrdOpzAction(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdOpzGroup(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdOpzLdRslI(CommonConstants.ZERO);
		ordDtlTable.setWo42OrdOpzOrdPnlVal(CommonConstants.ZERO);
		ordDtlTable.setWo42OrdOrdI(legacyOrderId);
		ordDtlTable.setWo42OrdOrdLstUpdS("");
		ordDtlTable.setWo42OrdOrdNbr(legacyOrderNumber);
		ordDtlTable.setWo42NextLdI(nextLoadId);
		if (isOWO) {
			ordDtlTable.setWo42NextOwoI(nextOrderId);
		} else {
			ordDtlTable.setWo42NextOwoI(0);
		}
		ordDtlTable.setWo42NextLdNum("L" + nextLoadId);
		ordDtlTable.setWo42NextOrdI(nextOrderId);
		ordDtlTable.setWo42OrdOrdPpSw("N");
		ordDtlTable.setWo42OrdPkupDelvSw(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdProgSttC(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdReqTyC(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdResvLstUpdS("");
		if (Objects.nonNull(reservationDetails)) {
			ordDtlTable
					.setWo42OrdResvLstUpdS(Optional.ofNullable(reservationDetails.getLastUpdateTimeStamp()).orElse(""));
		}
		ordDtlTable.setWo42OrdSegFppInd(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdSeqNbr(seqNumber);
		subTaskDetails.forEach(ordDtlTable.getWo42OrdStopInfo()::add);
		ordDtlTable.setWo42OrdTaskLstUpdS(Optional.ofNullable(timestampOfTask).orElse(""));
		ordDtlTable.setWo42OrdTcallAptD(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdTcallAptH(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdTcallCtyC(CommonConstants.EMPTY_SPACE);
		if (tCallLocationCode != null) {
			ordDtlTable.setWo42OrdTcallLoc(tCallLocationCode);
		} else {
			ordDtlTable.setWo42OrdTcallLoc(CommonConstants.EMPTY_SPACE);
		}
		ordDtlTable.setWo42OrdTcallLoc(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdTcallMiles(CommonConstants.ZERO);
		ordDtlTable.setWo42OrdTourCnt(CommonConstants.ZERO);
		ordDtlTable.setWo42OrdTourI(CommonConstants.ZERO);
		ordDtlTable.setWo42OrdTpndLstUpdS("");
		if (actionFlag.equalsIgnoreCase("D") && !StringUtils.isEmpty(driverId)
				|| "U".equalsIgnoreCase(orderLevalActionFlag)) {
			TPndJobAsn tpndJobAsn = Optional.ofNullable(tpndJobAsnRepository.findTPNJobDetailsByTaskId(legacyOrderId))
					.orElseThrow(
							() -> new JBHuntRuntimeException("LegacyOrderId is not found in TPND_JOB_ASN Table. "));
			ordDtlTable.setWo42OrdTpndLstUpdS(tpndJobAsn.getLasUpdateTimeStamp());
		}
		ordDtlTable.setWo42OrdTranMode(CommonConstants.EMPTY_SPACE);
		ordDtlTable.setWo42OrdTransferSw(CommonConstants.EMPTY_SPACE);
		return ordDtlTable;
	}

	public Wo42ComRequiredData populateWo42ComJavaSentVariables(List<Wo42OrdDtlTable> ordDtlTableList,
			String assingOrCancell, EquipmentDetailsDTO eqpDetails, PeopleDetailsDTO driverDetails, String userId,
			String planTypeCode) {
		Wo42ComRequiredData requiredData = new Wo42ComRequiredData();
		requiredData.setWo42ActionSw(assingOrCancell);
		requiredData.setWo42CallingPgm(CommonConstants.TRACTOR_PRG_CALLING);
		final Optional<TEquipment> lastDispDetails = Optional
				.ofNullable(equipmentRepository.getLastDispatchOrderDetails(eqpDetails.getEquipmentNumber()));
		requiredData.setWo42DspEtaChgSw("N");
		requiredData.setWo42DspEtaDate(
				lastDispDetails.isPresent() ? lastDispDetails.get().getCurrentEstimateTimeArrivelDate() : "");
		requiredData.setWo42DspEtaTime(
				lastDispDetails.isPresent() ? lastDispDetails.get().getCurrentEstimateTimeArrivelHour() : "");
		final Integer lastDspOrderID = lastDispDetails.isPresent()
				? orderLoadRepository.getOrderIDByOrderNumber(lastDispDetails.get().getLastDispatchOrderNumber())
				: 0;
		log.info("lastdspID " + lastDspOrderID);
		requiredData.setWo42DspOrdI(lastDspOrderID);
		String lastDspNumber = lastDispDetails.isPresent() ? lastDispDetails.get().getLastDispatchOrderNumber() : "";
		requiredData.setWo42DspOrdNbr(lastDspNumber.trim());
		requiredData.setWo42FirstXfrOrdI(CommonConstants.ZERO);
		requiredData.setWo42OrdDtlCnt(ordDtlTableList.size());
		ordDtlTableList.forEach(requiredData.getWo42OrdDtlTable()::add);
		requiredData
				.setWo42TpndMaxLstUpdS(Optional
						.ofNullable(tpndJobAsnRepository
								.getTPNstupdatedTimestampbyEqpUnitId(eqpDetails.getEquipmentNumber(), lastDspOrderID))
						.orElse(""));
		requiredData.setWo42TractorDriver(
				Optional.ofNullable(driverDetails).map(PeopleDetailsDTO::getAlphaCode).orElse(""));
		List<Integer> eqpuipmentIds = equipmentRepository.fetchEquipmentId(eqpDetails.getEquipmentNumber());
		requiredData.setWo42TractorEqpI(eqpuipmentIds.stream().findFirst().orElse(0));
		requiredData.setWo42TourF(planTypeCode);
		requiredData.setWo42TractorNbr(eqpDetails.getEquipmentNumber());
		requiredData.setWo42Userid(userId);
		requiredData.setWo42XfrDspNbr(CommonConstants.ZERO);
		requiredData.setWo42XfrFuelChg(CommonConstants.ZERO);
		requiredData.setWo42XfrStopoffChg(CommonConstants.ZERO);
		requiredData.setWo42XfrTransitChg(CommonConstants.ZERO);
		return requiredData;
	}

}
