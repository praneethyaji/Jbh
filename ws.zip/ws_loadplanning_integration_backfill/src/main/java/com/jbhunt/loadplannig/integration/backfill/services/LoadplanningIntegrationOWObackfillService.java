package com.jbhunt.loadplannig.integration.backfill.services;

import static com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants.MF_DEFAULT_VAL_STRING;

import java.lang.reflect.InvocationTargetException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.enums.CommentType;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.enums.JAStatusType;
import com.jbhunt.loadplannig.integration.backfill.enums.OWOStatusType;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.BkfilOwoJaAscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.CityRepository;
//import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderCommentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.SubTaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TpndJobAsnRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.BkfilOwoJaAscResponse;
import com.jbhunt.loadplannig.integration.backfill.utils.CommonUtils;
import com.jbhunt.loadplannig.integration.backfill.utils.EquipmentResponse;
import com.jbhunt.loadplannig.integration.backfill.utils.LMC342Helper;
import com.jbhunt.loadplanning.owo.dto.CarrierESDTO;
import com.jbhunt.loadplanning.owo.dto.OperationalWorkOrderCommentDTO;
import com.jbhunt.loadplanning.owo.dto.OperationalWorkOrderDTO;
import com.jbhunt.loadplanning.owo.dto.OperationalWorkOrderStopDTO;
import com.jbhunt.loadplanning.owo.dto.ResourceESDTO;
import com.jbhunt.loadplanning.owo.dto.TractorESDTO;
import com.jbhunt.loadplanning.owo.dto.event.OperationalWorkOrderEvent;
import com.jbhunt.loadplanning.owo.dto.event.OperationalWorkOrderEventSubType;
import com.jbhunt.masterdata.account.dto.CrossReferenceDTO;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.crossreference.client.CrossreferenceClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
//import com.jbhunt.masterdata.location.client.LocationClient;
import com.lmc342i.lmc342.LMC342Port;
import com.lmc359i.lmc359.LMC359Port;
import com.request.lmc359i.lmc359.ProgramInterface;
import com.request.lmc359i.lmc359.ProgramInterface.Wo59InputData.Wo59InData.Wo59ApptRsn;
import com.request.lmc359i.lmc359.ProgramInterface.Wo59InputData.Wo59InData.Wo59ApptRsn2;
import com.request.lmc359i.lmc359.ProgramInterface.Wo59InputData.Wo59InData.Wo59UpdateFields;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class LoadplanningIntegrationOWObackfillService {

	private final CrossreferenceClient crossreferenceClient;
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final BkfilOwoJaAscRepository bkfilOwoJaAscRepository;
	private final CityRepository cityRepository;
	private final TpndJobAsnRepository pndJobAsnRepository;
	private final MasterdataAssetClient masterdataAssetClient;

	private SubTaskRepository subTaskRepository;
	private TaskRepository taskRepository;
	private LMC342Helper lmc342Helper;
	private LMC342Port lMC342Port;
	private LMC359Port lmc359Port;

	public BkfilOwoJaAscResponse findOrdDetailsBynxtOwoNum(String nxtOwoNum) {

		BkfilOwoJaAscResponse bkfilResponse = new BkfilOwoJaAscResponse();
		List<Object[]> bkfilObjArrList = bkfilOwoJaAscRepository.findOrdIBynxtOwoNum(nxtOwoNum);
		bkfilObjArrList.forEach(bkfilObjArr -> {
			bkfilResponse.setNxtOWOI((int) bkfilObjArr[0]);
			bkfilResponse.setNxtOWONo((String) bkfilObjArr[1]);
			bkfilResponse.setOrdNbrch((String) bkfilObjArr[2]);
			bkfilResponse.setOrdI((int) bkfilObjArr[3]);
		});
		return bkfilResponse;
	}

	public String getCityStateForCustomerCode(String cusCode) {
		List<Object[]> cityStateObjArrList = cityRepository.getCityStateForCustomerCode(cusCode);
		return cityStateObjArrList.stream().findFirst().map(objects -> StringUtils.trim((String) objects[5]))
				.orElseThrow(() -> new JBHuntRuntimeException("City details not found."));
	}

	public City getCityStateCodeByCityID(Integer cityID) {
		return Optional.ofNullable(crossreferenceClient.fetchBridgeTableDetailList("City", "CityID", cityID))
				.flatMap(crossReferenceDTOs -> crossReferenceDTOs.stream().findFirst()
						.map(CrossReferenceDTO::getCciEntityFirstColumnValue).map(cityRepository::findByPnt))
				.orElseThrow(() -> new JBHuntRuntimeException("City details not found."));
	}

	public String getOperationByStatus(OperationalWorkOrderEvent operationalWorkOrderEvent) {
		String operation = "U";
		operation = OWOStatusType.getOperationByStatus(
				operationalWorkOrderEvent.getOperationalWorkOrderDTOs().get(0).getStatus()) == null ? operation
						: OWOStatusType.getOperationByStatus(
								operationalWorkOrderEvent.getOperationalWorkOrderDTOs().get(0).getStatus());
		log.info("Action Flag >>>>>>>>>>>>>>>>>>>>>> {}", operation);
		return operation;
	}

	public void saveOrUpdateOWO(OperationalWorkOrderEvent operationalWorkOrderEvent, String operation)
			throws Exception {
		log.info("Entering createOWO in ws >>>>>>>>>>>>>>>>>>>>>>> ");
		operationalWorkOrderEvent.getOperationalWorkOrderDTOs().stream().forEach(operationWorkOrder -> {
			String eventType = "";
			if(StringUtils.equals(operation, "S")) {
				eventType = "DISPATCHED";
			}else if(StringUtils.equals(operation, "D")) {
				eventType = "CANCELED";
			}else if(StringUtils.equals(operation, "J")) {
				eventType = "COMPLETED";
			}
			else {
				eventType = operationalWorkOrderEvent.getOperationalWorkOrderEventSubTypes().get(0).name();
			}
			backFillEventTrackingRepository.saveBackTrackingDetails(operationWorkOrder, EventStatusEnum.PENDING.name(), eventType);
			try {
				populateLMC359(operationWorkOrder, operation + "::" + eventType);
				backFillEventTrackingRepository.updateBackTrackingDetails(operationWorkOrder,
						EventStatusEnum.COMPLETED.name(), "");
			} catch (Throwable t) {
				log.error("exception while doing OWO:", t);
				String errorMesage = ExceptionUtils.getRootCauseMessage(t);
				if (errorMesage != null && errorMesage.length() > 500) {
					errorMesage = errorMesage.substring(0, 500);
				}
				backFillEventTrackingRepository.updateBackTrackingDetails(operationWorkOrder,
						EventStatusEnum.FAILED.name(), errorMesage);
			}
		});
	}
	
	public ProgramInterface.Wo59InputData.Wo59InData initDefaultValues() {
		ProgramInterface.Wo59InputData.Wo59InData lmc359child = CommonUtils.getObjectWithDefaultStringValues(
				ProgramInterface.Wo59InputData.Wo59InData.class, CommonConstants.MF_DEFAULT_VAL_STRING);

		Wo59ApptRsn wo59ApptRsn = CommonUtils.getObjectWithDefaultStringValues(
				ProgramInterface.Wo59InputData.Wo59InData.Wo59ApptRsn.class, CommonConstants.MF_DEFAULT_VAL_STRING);
		wo59ApptRsn.setWo59ApptRsnCatC("DRIVER");
		wo59ApptRsn.setWo59ApptRsnChgC(CommonConstants.DRVR_REFUSED);

		Wo59ApptRsn2 wo59ApptRsn2 = CommonUtils.getObjectWithDefaultStringValues(
				ProgramInterface.Wo59InputData.Wo59InData.Wo59ApptRsn2.class, CommonConstants.MF_DEFAULT_VAL_STRING);
		wo59ApptRsn2.setWo59ApptRsnCatC2("DRIVER");
		wo59ApptRsn2.setWo59ApptRsnChgC2(CommonConstants.DRVR_REFUSED);

		lmc359child.setWo59ApptRsn(wo59ApptRsn);
		lmc359child.setWo59ApptRsn2(wo59ApptRsn2);
		lmc359child.setWo59UpdateFields(CommonUtils.getObjectWithDefaultStringValues(
				ProgramInterface.Wo59InputData.Wo59InData.Wo59UpdateFields.class,
				CommonConstants.MF_DEFAULT_VAL_STRING));
		lmc359child.setWo59Transit("T");
		lmc359child.setWo59WarningFields(CommonUtils.getObjectWithDefaultStringValues(
				ProgramInterface.Wo59InputData.Wo59InData.Wo59WarningFields.class,
				CommonConstants.MF_DEFAULT_VAL_STRING));
		return lmc359child;
	}

	public EquipmentDetailsDTO checkAndPopulateEquip(ProgramInterface.Wo59InputData.Wo59InData lmc359child,
			String equipmentId, EquipmentResponse equipResponse) {
		return Optional.ofNullable(equipmentId).filter(StringUtils::isNotEmpty).map(Integer::valueOf)
				.map(equipmentID -> {
					try {
						return masterdataAssetClient.getEquipmentDetails(Arrays.asList(equipmentID));
					} catch (URISyntaxException e) {
						throw new JBHuntRuntimeException(e);
					}
				}).filter(CollectionUtils::isNotEmpty).map(v -> v.get(0)).map(v -> {
					lmc359child.setWo59AsgnPwr(v.getEquipmentNumber());
					equipResponse.setEquipmentId(v.getLegacyEquipmentId());
					equipResponse.setEquipmentNumber(v.getEquipmentNumber());
					return v;
				}).orElseGet(() -> {
					return null;
				});
	}

	public String enrichParam(String param, String funcType) {
		if (StringUtils.equals(funcType, CommonConstants.APPEND_ZERO_PREFIX)) {
			return "0" + param;
		} else if (StringUtils.equals(funcType, "FETCH_FIRST_PHRASE")) {
			return param.split(" ")[0];
		}
		return " ";
	}

	public Wo59UpdateFields checkInputsAndSetFlags(OperationalWorkOrderDTO operationWorkOrder, BkfilOwoJaAscResponse bkfilOwoJaAscResponse,
			Wo59UpdateFields wo59UpdateFields, String updateParam) {
		
		List<Object[]> jaInfoDetails = taskRepository.findOrdDetailsByOrdNbrCh(bkfilOwoJaAscResponse.getOrdNbrch());
		
		if(StringUtils.equals(updateParam, OperationalWorkOrderEventSubType.COMMENT.name())) {
			wo59UpdateFields.setWo59CommentsAddSw(CommonConstants.STRING_Y);
		}
		
		jaInfoDetails.forEach(jaInfo -> {

			if (StringUtils.isNotEmpty(operationWorkOrder.getOperationalGroupCode()) && (!((String) jaInfo[11]).contains(operationWorkOrder.getOperationalGroupCode()))) {
				wo59UpdateFields.setWo59AsgnFltChgSw(CommonConstants.STRING_Y);
			}

			if (!(((String) jaInfo[16]).contains(operationWorkOrder.getFinanceBusinessUnitCode()))) {
				wo59UpdateFields.setWo59BusDivChgSw(CommonConstants.STRING_Y);
			}

		});

		operationWorkOrder.getOperationalWorkOrderStops().forEach(operationalWorkOrderStopDTO -> {

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

			OffsetDateTime offsetApptStartTimeStamp = OffsetDateTime.parse(operationalWorkOrderStopDTO
					.getOperationalWorkOrderStopAppointment().getAppointmentStartTimestamp());
			OffsetDateTime offsetApptEndTimeStamp = OffsetDateTime.parse(operationalWorkOrderStopDTO.getOperationalWorkOrderStopAppointment()
					.getAppointmentEndTimestamp());

			String[] dateTimeBegStr = offsetApptStartTimeStamp.format(formatter).split("T");
			String[] dateTimeEndStr = offsetApptEndTimeStamp.format(formatter).split("T");
			
			if (operationalWorkOrderStopDTO.getStopSequenceNumber() == 1) {
				setFlagforOrigination(operationalWorkOrderStopDTO, jaInfoDetails.get(0), wo59UpdateFields,
						dateTimeBegStr, dateTimeEndStr);
			}

			if (operationalWorkOrderStopDTO.getStopSequenceNumber() == 2) {
				Object[] jaInfoObj = jaInfoDetails.size() > 1 ? jaInfoDetails.get(1) : jaInfoDetails.get(0);
				setFlagforDestination(operationalWorkOrderStopDTO, jaInfoObj, wo59UpdateFields,
						dateTimeBegStr, dateTimeEndStr);
			}
		});

		return wo59UpdateFields;
	}

	private void setFlagforOrigination(OperationalWorkOrderStopDTO operationalWorkOrderStopDTO, Object[] jaInfo,
			Wo59UpdateFields wo59UpdateFields, String[] dateTimeBegStr, String[] dateTimeEndStr) {

		String pickup_drop = CommonUtils
				.getLegacyActivityByStopReasonCode(operationalWorkOrderStopDTO.getOperationalWorkOrderStopReasonCode());

		log.info("dateTimeBegStr >>>>>>>>" + dateTimeBegStr);

		if (!StringUtils.equals(((String) jaInfo[5]).trim(), CommonUtils.getLegacyActivityByStopReasonCode(
				operationalWorkOrderStopDTO.getOperationalWorkOrderStopReasonCode()))) {
			wo59UpdateFields.setWo59ActivityChgSw(CommonConstants.STRING_Y);
			if (!((StringUtils.equals(pickup_drop, CommonConstants.PKUPTRLR))
					|| StringUtils.equals(pickup_drop, CommonConstants.DROPTRLR))) {
				wo59UpdateFields.setWo59Activity2ChgSw(CommonConstants.STRING_Y);
			}
		}

		if (!StringUtils.equals(((String) jaInfo[3]).trim(),
				operationalWorkOrderStopDTO.getLocation().getLocationCode())) {
			wo59UpdateFields.setWo59BusOrgChgSw(CommonConstants.STRING_Y);
			if (!((StringUtils.equals(pickup_drop, CommonConstants.PKUPTRLR))
					|| StringUtils.equals(pickup_drop, CommonConstants.DROPTRLR))) {
				wo59UpdateFields.setWo59BusDstChgSw(CommonConstants.STRING_Y);
			}

		}

		if ((!StringUtils.equals((String) jaInfo[9], dateTimeBegStr[0]))
				|| (!StringUtils.equals((String) jaInfo[10],
						dateTimeBegStr[1].replace(":", ".").substring(0, dateTimeBegStr[1].length() - 1)))
				|| (!StringUtils.equals((String) jaInfo[13], dateTimeEndStr[0]))
				|| (!StringUtils.equals((String) jaInfo[14],
						dateTimeEndStr[1].replace(":", ".").substring(0, dateTimeEndStr[1].length() - 1)))) {
			wo59UpdateFields.setWo59OrgApptChgSw(CommonConstants.STRING_Y);
			if (!((StringUtils.equals(pickup_drop, CommonConstants.PKUPTRLR))
					|| StringUtils.equals(pickup_drop, CommonConstants.DROPTRLR))) {
				wo59UpdateFields.setWo59DstApptChgSw(CommonConstants.STRING_Y);
			}
		}

	}

	private void setFlagforDestination(OperationalWorkOrderStopDTO operationalWorkOrderStopDTO, Object[] jaInfo,
			Wo59UpdateFields wo59UpdateFields, String[] dateTimeBegStr, String[] dateTimeEndStr) {

		String pickup_drop = CommonUtils.getLegacyActivityByStopReasonCode(operationalWorkOrderStopDTO.getOperationalWorkOrderStopReasonCode());
		
		if (!StringUtils.equals(((String) jaInfo[5]).trim(),
				CommonUtils.getLegacyActivityByStopReasonCode(operationalWorkOrderStopDTO.getOperationalWorkOrderStopReasonCode()))) {
			wo59UpdateFields.setWo59Activity2ChgSw(CommonConstants.STRING_Y);
			if(!((StringUtils.equals(pickup_drop, CommonConstants.PKUPTRLR)) || StringUtils.equals(pickup_drop, CommonConstants.DROPTRLR))) {
			wo59UpdateFields.setWo59ActivityChgSw(CommonConstants.STRING_Y);
			}
		}

		if (!StringUtils.equals(((String) jaInfo[3]).trim(), operationalWorkOrderStopDTO.getLocation().getLocationCode())) {
			wo59UpdateFields.setWo59BusDstChgSw(CommonConstants.STRING_Y);
			if(!((StringUtils.equals(pickup_drop, CommonConstants.PKUPTRLR)) || StringUtils.equals(pickup_drop, CommonConstants.DROPTRLR))) {
			wo59UpdateFields.setWo59BusOrgChgSw(CommonConstants.STRING_Y);
			}
		}
		
		if ((!StringUtils.equals((String) jaInfo[9], dateTimeBegStr[0]))
				|| (!StringUtils.equals((String) jaInfo[10],
						dateTimeBegStr[1].replace(":", ".").substring(0, dateTimeBegStr[1].length() - 1)))
				|| (!StringUtils.equals((String) jaInfo[13], dateTimeEndStr[0]))
				|| (!StringUtils.equals((String) jaInfo[14],
						dateTimeEndStr[1].replace(":", ".").substring(0, dateTimeEndStr[1].length() - 1)))) {
			wo59UpdateFields.setWo59DstApptChgSw(CommonConstants.STRING_Y);
			if(!((StringUtils.equals(pickup_drop, CommonConstants.PKUPTRLR)) || StringUtils.equals(pickup_drop, CommonConstants.DROPTRLR))) {
			wo59UpdateFields.setWo59OrgApptChgSw(CommonConstants.STRING_Y);
			}
		}
	}

	public void populateLMC359(OperationalWorkOrderDTO operationWorkOrder, String function) throws Exception{
		EquipmentResponse equipResponse = new EquipmentResponse();

		String operation = function.split("::")[0];
		String updateParam = function.split("::")[1];
		
		String equipId = Optional.ofNullable(operationWorkOrder).map(OperationalWorkOrderDTO::getResourceESDTO)
				.map(ResourceESDTO::getTractor).map(TractorESDTO::getPowerEquipmentID).orElse(StringUtils.EMPTY);

		ProgramInterface.Wo59InputData finalInputLMC359 = new ProgramInterface.Wo59InputData();

		ProgramInterface.Wo59InputData.Wo59InData lmc359child = initDefaultValues();
		lmc359child.setWo59NextOwoI(operationWorkOrder.getOperationalWorkOrderID());
		lmc359child.setWo59NextOwoNum(operationWorkOrder.getOperationalWorkOrderNumber());

		String financeBusinessUnitCode=Optional.ofNullable(operationWorkOrder.getFinanceBusinessUnitCode()).orElseThrow(()->new JBHuntRuntimeException("Business Unit is not present in the contract"));
		lmc359child.setWo59BusDiv(getBusDiv(financeBusinessUnitCode.trim()));

		BkfilOwoJaAscResponse bkfilOwoJaAscResponse = findOrdDetailsBynxtOwoNum(
				operationWorkOrder.getOperationalWorkOrderNumber());

		if (StringUtils.isNotEmpty(bkfilOwoJaAscResponse.getOrdNbrch())) {
			lmc359child.setWo59JobNbr(bkfilOwoJaAscResponse.getOrdNbrch());
			if(CommonConstants.OWO_UPDATE.equalsIgnoreCase(operation)) {
				lmc359child.setWo59UpdateFields(checkInputsAndSetFlags(operationWorkOrder, bkfilOwoJaAscResponse, lmc359child.getWo59UpdateFields(), updateParam));
			}
		}

		if (!CommonConstants.OWO_DISPATCH.equalsIgnoreCase(operation)) {
			checkAndPopulateEquip(lmc359child, equipId, equipResponse);
		}
		
		lmc359child.setWo59FunctionType(operation);
		
		lmc359child.setWo59AsgnFlt(operationWorkOrder.getOperationalGroupCode().trim().
				equalsIgnoreCase("DCS")?CommonConstants.DCS:operationWorkOrder.getOperationalGroupCode());
		
		lmc359child.setWo59Copies(
				enrichParam(String.valueOf(operationWorkOrder.getCopies()), CommonConstants.APPEND_ZERO_PREFIX));
		checkAndPopulateEquip(lmc359child, equipId, equipResponse);

		Optional.ofNullable(Optional.ofNullable(operationWorkOrder).map(OperationalWorkOrderDTO::getResourceESDTO)
				.map(ResourceESDTO::getCarrier).map(CarrierESDTO::getCarrierID).orElse(StringUtils.EMPTY))
				.ifPresent(carrier -> lmc359child.setWo59AsgnCarr(carrier));
		lmc359child.setWo59JaStat(JAStatusType.getCode(operationWorkOrder.getStatus()));

		operationWorkOrder.getOperationalWorkOrderStops().stream().forEach(oprWorkStop -> {
			try {
				updateOperationalWorkOrderStop(operationWorkOrder, lmc359child, oprWorkStop, operation);
			} catch (ParseException e1) {
				log.error("Error while updating workorder >>>>> " + e1);
			}
		});

		if ((operationWorkOrder.getOperationalWorkOrderStops().size() == CommonConstants.SINGLE_STOP && (CommonConstants.OWO_CREATE.equalsIgnoreCase(operation) || CommonConstants.OWO_UPDATE.equalsIgnoreCase(operation))) 
				&& !(StringUtils
				.equals(operationWorkOrder.getOperationalWorkOrderStops().get(0)
						.getOperationalWorkOrderStopReasonCode(), CommonConstants.DROP_EQUI)
				|| StringUtils.equals(operationWorkOrder.getOperationalWorkOrderStops().get(0)
						.getOperationalWorkOrderStopReasonCode(), CommonConstants.PKUP_EQUI))) {
			OperationalWorkOrderStopDTO operationalWorkOrderStopDTO = new OperationalWorkOrderStopDTO();
			try {
				BeanUtils.copyProperties(operationalWorkOrderStopDTO,
						operationWorkOrder.getOperationalWorkOrderStops().get(0));
				if (operationWorkOrder.getOperationalWorkOrderStops().get(0).getStopSequenceNumber() == 1) {
					operationalWorkOrderStopDTO.setStopSequenceNumber(2);
				} else {
					operationalWorkOrderStopDTO.setStopSequenceNumber(1);
				}
				if((operationWorkOrder.getOperationalWorkOrderStops().size() == CommonConstants.SINGLE_STOP && CommonConstants.OWO_UPDATE.equalsIgnoreCase(operation)) && !(StringUtils
						.equals(operationWorkOrder.getOperationalWorkOrderStops().get(0)
								.getOperationalWorkOrderStopReasonCode(), CommonConstants.DROP_EQUI)
						|| StringUtils.equals(operationWorkOrder.getOperationalWorkOrderStops().get(0)
								.getOperationalWorkOrderStopReasonCode(), CommonConstants.PKUP_EQUI))) {
					lmc359child.getWo59UpdateFields().setWo59BusOrgChgSw(CommonConstants.STRING_Y);
					lmc359child.getWo59UpdateFields().setWo59BusDstChgSw(CommonConstants.STRING_Y);
				}
				updateOperationalWorkOrderStop(operationWorkOrder, lmc359child, operationalWorkOrderStopDTO, operation);
			} catch (IllegalAccessException | InvocationTargetException | ParseException e) {
				log.error("Error While copying from one Stop to Other {}", e);
			}
		}

		lmc359child.setWo59UserId(operationWorkOrder.getLastUpdateUserID());
		List<ProgramInterface.Wo59InputData.Wo59InData.Wo59CommentGrp> comGrpList = lmc359child.getWo59CommentGrp();

		if (CollectionUtils.isNotEmpty(operationWorkOrder.getOperationalWorkOrderComments())) {
			
			List<OperationalWorkOrderCommentDTO> updatedComment =  new ArrayList<>();
			updatedComment.add(operationWorkOrder.getOperationalWorkOrderComments().get(operationWorkOrder.getOperationalWorkOrderComments().size() - 1));

			Stream<OperationalWorkOrderCommentDTO> opCommentList = updatedComment.stream();

			if(StringUtils.equals(updateParam, OperationalWorkOrderEventSubType.COMMENT.name())) {
				
				Optional<OperationalWorkOrderCommentDTO> OptionalOperationalWorkOrderCommentDTO = opCommentList.findFirst();
				
				if (OptionalOperationalWorkOrderCommentDTO.isPresent()) {
					OperationalWorkOrderCommentDTO operationalWorkOrderCommentDTO = OptionalOperationalWorkOrderCommentDTO
							.get();
					ProgramInterface.Wo59InputData.Wo59InData.Wo59CommentGrp updateComGrp = new ProgramInterface.Wo59InputData.Wo59InData.Wo59CommentGrp();
					updateComGrp.setWo59ComType(Optional.ofNullable(operationalWorkOrderCommentDTO.getOperationalWorkOrderCommentTypeCode()).map(code -> CommentType
							.getCode(code)).orElse(CommonConstants.STRING_D));
					updateComGrp.setWo59Comments(Optional.ofNullable(operationalWorkOrderCommentDTO.getOperationalWorkorderCommentText()).orElse(CommonConstants.DEFAULT_COMMENT));
					comGrpList.add(updateComGrp);
				}
			}
			else {
				opCommentList.forEach(opComment -> {
					ProgramInterface.Wo59InputData.Wo59InData.Wo59CommentGrp comGrp = new ProgramInterface.Wo59InputData.Wo59InData.Wo59CommentGrp();
					comGrp.setWo59ComType(Optional.ofNullable(opComment.getOperationalWorkOrderCommentTypeCode()).map(code ->CommentType.getCode(code)).orElse(CommonConstants.STRING_D));
					comGrp.setWo59Comments(Optional.ofNullable(opComment.getOperationalWorkorderCommentText()).orElse(CommonConstants.DEFAULT_COMMENT));
					comGrpList.add(comGrp);
				});
			}
		} else {
			ProgramInterface.Wo59InputData.Wo59InData.Wo59CommentGrp comGrp = new ProgramInterface.Wo59InputData.Wo59InData.Wo59CommentGrp();
			comGrp.setWo59ComType(CommonConstants.STRING_D);
			comGrp.setWo59Comments(CommonConstants.DEFAULT_COMMENT);
			comGrpList.add(comGrp);
		}

		finalInputLMC359.setWo59InData(lmc359child);

		ProgramInterface.Wo59InputData.Wo59InHeadingBuffer1 headingBuffer1 = new ProgramInterface.Wo59InputData.Wo59InHeadingBuffer1();
		headingBuffer1.setWo59InCallingProgram("LMC359");
		headingBuffer1.setWo59InProgramToCall("LMC294");
		headingBuffer1.setWo59InFiller(MF_DEFAULT_VAL_STRING);

		finalInputLMC359.setWo59InHeadingBuffer1(headingBuffer1);
		com.response.lmc359i.lmc359.ProgramInterface.Wo59OutputData response = CommonUtils
				.soapCall((i) -> lmc359Port.lmc359Operation(i), finalInputLMC359);
		String outData = response.getWo59OutOutputBuffer1().getWo59OutData();
		String status = response.getWo59OutOutputBuffer1().getWo59ErrorFields().getWo59ErrorFlag();
		if (StringUtils.isNotBlank(status)) {
			throw new JBHuntRuntimeException(CommonUtils.asString(response.getWo59OutOutputBuffer1().getWo59ErrorFields().getWo59ErrorMessage()));
		}
		boolean isCreateOrderTractor = false;
		if (StringUtils.isNotEmpty(equipId)) {
			isCreateOrderTractor = CollectionUtils.isNotEmpty(pndJobAsnRepository
					.fetchPreplanDetByTaskIdAndEqpId(bkfilOwoJaAscResponse.getOrdI(), equipResponse.getEquipmentId()));
		}
		if (StringUtils.isNotEmpty(equipId) && !isCreateOrderTractor && !StringUtils.equals(operation, CommonConstants.OWO_DISPATCH)) {
			callTractorPreplan(operationWorkOrder, equipResponse, outData.substring(3, 10));
		}
	}

	private void updateOperationalWorkOrderStop(OperationalWorkOrderDTO operationWorkOrder,
			ProgramInterface.Wo59InputData.Wo59InData lmc359child, OperationalWorkOrderStopDTO oprWorkStop,
			String operation) throws ParseException {
		String locationCode = oprWorkStop.getLocation().getLocationCode();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");

		OffsetDateTime offsetApptStartTimeStamp = OffsetDateTime.parse(oprWorkStop
				.getOperationalWorkOrderStopAppointment().getAppointmentStartTimestamp());
		OffsetDateTime offsetApptEndTimeStamp = OffsetDateTime.parse(oprWorkStop.getOperationalWorkOrderStopAppointment()
				.getAppointmentEndTimestamp());

		String apptStartTimeStamp = offsetApptStartTimeStamp.format(formatter);
		String apptEndTimeStamp = offsetApptEndTimeStamp.format(formatter);

		String erlyDat[] = apptStartTimeStamp.split(" ")[0].split("-");
		String lteDat[] = apptEndTimeStamp.split(" ")[0].split("-");
		String erlyTme[] = apptStartTimeStamp.split(" ")[1].split(":");
		String lteTme[] = apptEndTimeStamp.split(" ")[1].split(":");
		String busCity = getWo59BusCty(oprWorkStop, locationCode);

		String activity = getWo59Activity(operationWorkOrder, oprWorkStop, lmc359child.getWo59JobNbr(), operation);

		if (CommonConstants.OWO_DISPATCH.equalsIgnoreCase(lmc359child.getWo59FunctionType())) {
			if (oprWorkStop.getOperationalWorkOrderStopReasonCode().equalsIgnoreCase(CommonConstants.BTAILNOPAY)
					|| oprWorkStop.getOperationalWorkOrderStopReasonCode().equalsIgnoreCase(CommonConstants.DHNOPAY)) {
				String financeBusinessUnitCode=Optional.ofNullable(operationWorkOrder.getFinanceBusinessUnitCode()).orElseThrow(()->new JBHuntRuntimeException("Business Unit is not present in the contract"));
				lmc359child.setWo59BusDiv(getBusDiv(financeBusinessUnitCode.trim()));
			}
		} else {
			if (operationWorkOrder.getDriverPayIndicator().equalsIgnoreCase(CommonConstants.STRING_N)) {
				String financeBusinessUnitCode=Optional.ofNullable(operationWorkOrder.getFinanceBusinessUnitCode()).orElseThrow(()->new JBHuntRuntimeException("Business Unit is not present in the contract"));
				lmc359child.setWo59BusDiv(getBusDiv(financeBusinessUnitCode.trim()));
			}
		}

		boolean dhead_btail = (StringUtils.equals(oprWorkStop.getOperationalWorkOrderStopReasonCode(),
				CommonConstants.DEADHEAD)
				|| StringUtils.equals(oprWorkStop.getOperationalWorkOrderStopReasonCode(), CommonConstants.BOBTAIL));

		if (oprWorkStop.getStopSequenceNumber() == 2) {
			Optional.ofNullable(locationCode).filter(StringUtils::isNotEmpty)
					.ifPresent(v -> lmc359child.setWo59BusSite(v));
			lmc359child.setWo59BusCty(busCity);
			if (!dhead_btail) {
				lmc359child.setWo59Activity(activity);
			}
			updateOrigionAppointment(lmc359child, erlyDat, lteDat, erlyTme, lteTme);
		} else {
			Optional.ofNullable(locationCode).filter(StringUtils::isNotEmpty)
					.ifPresent(v -> lmc359child.setWo59BusSite2(v));
			lmc359child.setWo59BusCty2(busCity);
			lmc359child.setWo59Activity2(activity);
			if (dhead_btail) {
				lmc359child.setWo59Activity(activity);
			}
			updateDestinationAppointment(lmc359child, erlyDat, lteDat, erlyTme, lteTme);
		}
	}

	private String getWo59BusCty(OperationalWorkOrderStopDTO oprWorkStop, String locationCode) {
		if (StringUtils.isNotEmpty(locationCode)) {
			return Optional.ofNullable(getCityStateForCustomerCode(locationCode)).map(String::trim)
					.filter(StringUtils::isNotEmpty).orElse("");
		} else if (StringUtils.isNotEmpty(oprWorkStop.getCityId())) {
			return Optional.ofNullable(getCityStateCodeByCityID(Integer.parseInt(oprWorkStop.getCityId())))
					.map(v -> v.getCtyStC()).map(String::trim).orElse("");
		}
		return "";
	}

	private String getWo59Activity(OperationalWorkOrderDTO operationWorkOrder, OperationalWorkOrderStopDTO oprWorkStop,
			String ordNbrCh, String operation) {

		if (StringUtils.equals(oprWorkStop.getOperationalWorkOrderStopReasonCode(), CommonConstants.TRADE_IN)) {
			return Optional
					.ofNullable(CommonUtils
							.getLegacyActivityBySubType(operationWorkOrder.getOperationalWorkOrderSubtypeDescription()))
					.orElse("");
		}

		if (StringUtils.equals(operationWorkOrder.getDriverPayIndicator(), CommonConstants.STRING_N)) {
			return Optional
					.ofNullable(CommonUtils
							.getLegacyActivityByPayableToDriver(oprWorkStop.getOperationalWorkOrderStopReasonCode()))
					.orElse("");
		}

		if (StringUtils.equals(operationWorkOrder.getDriverPayIndicator(), CommonConstants.STRING_N)
				&& operation.equalsIgnoreCase(CommonConstants.OWO_DISPATCH)) {
			List<Object[]> ordActivityList = taskRepository.findOrdDetailsByOrdNbrCh(ordNbrCh);
			if (CollectionUtils.isNotEmpty(ordActivityList)) {
				if (oprWorkStop.getStopSequenceNumber() == 1) {
					return (String) ordActivityList.get(0)[5];
				} else {
					return (String) ordActivityList.get(1)[5];
				}
			}
		}

		return Optional
				.ofNullable(CommonUtils
						.getLegacyActivityByStopReasonCode(oprWorkStop.getOperationalWorkOrderStopReasonCode()))
				.orElse("");
	}

	private void updateOrigionAppointment(ProgramInterface.Wo59InputData.Wo59InData lmc359child, String[] erlyDat,
			String[] lteDat, String[] erlyTme, String[] lteTme) {
		ProgramInterface.Wo59InputData.Wo59InData.Wo59EarlyDt earlyDt = new ProgramInterface.Wo59InputData.Wo59InData.Wo59EarlyDt();
		earlyDt.setWo59EarlyDtMm(erlyDat[0]);
		earlyDt.setWo59EarlyDtDd(erlyDat[1]);
		earlyDt.setWo59EarlyDtCc(erlyDat[2].substring(0, 2));
		earlyDt.setWo59EarlyDtYy(erlyDat[2].substring(2, 4));
		lmc359child.setWo59EarlyDt(earlyDt);

		ProgramInterface.Wo59InputData.Wo59InData.Wo59LateDt lateDt = new ProgramInterface.Wo59InputData.Wo59InData.Wo59LateDt();
		lateDt.setWo59LateDtMm(lteDat[0]);
		lateDt.setWo59LateDtDd(lteDat[1]);
		lateDt.setWo59LateDtCc(lteDat[2].substring(0, 2));
		lateDt.setWo59LateDtYy(lteDat[2].substring(2, 4));
		lmc359child.setWo59LateDt(lateDt);

		ProgramInterface.Wo59InputData.Wo59InData.Wo59EarlyTm earlyTm = new ProgramInterface.Wo59InputData.Wo59InData.Wo59EarlyTm();
		earlyTm.setWo59EarlyTmHh(erlyTme[0]);
		earlyTm.setWo59EarlyTmMm(erlyTme[1]);
		earlyTm.setWo59EarlyTmSs(MF_DEFAULT_VAL_STRING);
		lmc359child.setWo59EarlyTm(earlyTm);

		ProgramInterface.Wo59InputData.Wo59InData.Wo59LateTm lateTm = new ProgramInterface.Wo59InputData.Wo59InData.Wo59LateTm();
		lateTm.setWo59LateTmHh(lteTme[0]);
		lateTm.setWo59LateTmMm(lteTme[1]);
		lateTm.setWo59LateTmSs(MF_DEFAULT_VAL_STRING);
		lmc359child.setWo59LateTm(lateTm);

		log.info("earlyTm >>>>> " + earlyTm.getWo59EarlyTmHh() + ", " + earlyTm.getWo59EarlyTmMm());
		log.info("lateTm >>>>> " + lateTm.getWo59LateTmHh() + ", " + lateTm.getWo59LateTmMm());
	}

	private void updateDestinationAppointment(ProgramInterface.Wo59InputData.Wo59InData lmc359child, String[] erlyDat2,
			String[] lteDat2, String[] erlyTme2, String[] lteTme2) {
		ProgramInterface.Wo59InputData.Wo59InData.Wo59EarlyDt2 earlyDt2 = new ProgramInterface.Wo59InputData.Wo59InData.Wo59EarlyDt2();
		earlyDt2.setWo59EarlyDt2Mm(erlyDat2[0]);
		earlyDt2.setWo59EarlyDt2Dd(erlyDat2[1]);
		earlyDt2.setWo59EarlyDt2Cc(erlyDat2[2].substring(0, 2));
		earlyDt2.setWo59EarlyDt2Yy(erlyDat2[2].substring(2, 4));
		lmc359child.setWo59EarlyDt2(earlyDt2);

		ProgramInterface.Wo59InputData.Wo59InData.Wo59LateDt2 lateDt2 = new ProgramInterface.Wo59InputData.Wo59InData.Wo59LateDt2();
		lateDt2.setWo59LateDt2Mm(lteDat2[0]);
		lateDt2.setWo59LateDt2Dd(lteDat2[1]);
		lateDt2.setWo59LateDt2Cc(lteDat2[2].substring(0, 2));
		lateDt2.setWo59LateDt2Yy(lteDat2[2].substring(2, 4));
		lmc359child.setWo59LateDt2(lateDt2);

		ProgramInterface.Wo59InputData.Wo59InData.Wo59EarlyTm2 earlyTm2 = new ProgramInterface.Wo59InputData.Wo59InData.Wo59EarlyTm2();
		earlyTm2.setWo59EarlyTm2Hh(erlyTme2[0]);
		earlyTm2.setWo59EarlyTm2Mm(erlyTme2[1]);
		earlyTm2.setWo59EarlyTm2Ss(MF_DEFAULT_VAL_STRING);
		lmc359child.setWo59EarlyTm2(earlyTm2);

		ProgramInterface.Wo59InputData.Wo59InData.Wo59LateTm2 lateTm2 = new ProgramInterface.Wo59InputData.Wo59InData.Wo59LateTm2();
		lateTm2.setWo59LateTm2Hh(lteTme2[0]);
		lateTm2.setWo59LateTm2Mm(lteTme2[1]);
		lateTm2.setWo59LateTm2Ss(MF_DEFAULT_VAL_STRING);
		lmc359child.setWo59LateTm2(lateTm2);
	}

	private void callTractorPreplan(OperationalWorkOrderDTO operationWorkOrder, EquipmentResponse equipResponse,
			String jobNbr) {
		com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables lmc342input = populateAndGetLMC342(
				operationWorkOrder, CommonConstants.TRACTOR_PREPLAN_ORDER_ACTION, equipResponse);
		CommonUtils.soapCall((i) -> lMC342Port.lmc342Operation(i), lmc342input);
	}

	private com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables populateAndGetLMC342(
			OperationalWorkOrderDTO operationWorkOrder, String operation, EquipmentResponse equipResponse) {
		BkfilOwoJaAscResponse bkfilOwoJaAscResponse = findOrdDetailsBynxtOwoNum(
				operationWorkOrder.getOperationalWorkOrderNumber());
		List<TSubtask1> subTaskList = subTaskRepository.findSubTaskDetailsByTaskId(bkfilOwoJaAscResponse.getOrdI());

		String timeStampByTaskID = taskRepository.findLastUpdatedTimeStampBytaskId(bkfilOwoJaAscResponse.getOrdI());

		List<com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable.Wo42OrdStopInfo> stopInfoList = lmc342Helper
				.populateStopDetails(subTaskList);

		com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable ordDtlDetail = lmc342Helper
				.populateOrdDtlTable(operation, stopInfoList, bkfilOwoJaAscResponse, timeStampByTaskID,
						operationWorkOrder);
		List<com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable> listOfOrdDtl = new ArrayList<>();
		listOfOrdDtl.add(ordDtlDetail);
		com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData wo42ComRequiredData = lmc342Helper
				.populateWo42ComJavaSentVariables(listOfOrdDtl, equipResponse,
						operationWorkOrder.getLastUpdateUserID());
		com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables wo42ComJavaSentVariables = new com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables();
		wo42ComJavaSentVariables.setWo42ComRequiredData(wo42ComRequiredData);
		return wo42ComJavaSentVariables;
	}
	private String getBusDiv(String financeBusinessUnitCode){
		switch (financeBusinessUnitCode){
			case "JBI":
				return "HJBT JBVAN";
			case "JBT":
				return "HJBT JBVAN";
			case "DCS":
				return "HJBT JBDCS";
			case "ICS":
				return "HJBT JBHA";
			default:
				throw new JBHuntRuntimeException("Business Unit is invalid: "+financeBusinessUnitCode);
		}
	}
}