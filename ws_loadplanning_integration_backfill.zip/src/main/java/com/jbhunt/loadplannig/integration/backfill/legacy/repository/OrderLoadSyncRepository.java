package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource
public interface OrderLoadSyncRepository extends JpaRepository<OrderLoadSync, Integer> {

	
	@Query(value = "SELECT ORD.ORD_LD_SYNC_I, ORD.ORD_I, ORD.ORD_CRT_SYS_C, ORD.CRT_S, ORD.CRT_UID, ORD.CRT_PGM_C, ORD.LST_UPD_S, ORD.LST_UPD_UID, ORD.LST_UPD_PGM_C, ORD.NEW_ORD_I,  ORD.ORD_TRAK_NBR,  ORD.SPR_CUS_C,  ORD.RCV_CUS_C,  ORD.PRM_REF_NBR_TYP_C,  ORD.PRM_REF_NBR_VAL, ORD.RT_I, ORD.XDIV_IND FROM ALI.ORD_LD_SYNC ORD WHERE ORD.NEW_ORD_I = :orderID WITH UR ", nativeQuery = true)
    List<OrderLoadSync> findOrderLoadSyncDTODetailsByOrderID(@Param("orderID") Integer orderID);
   
	@Query(value = "SELECT ORD.ORD_LD_SYNC_I, ORD.ORD_I, ORD.ORD_CRT_SYS_C, ORD.CRT_S, ORD.CRT_UID, ORD.CRT_PGM_C, ORD.LST_UPD_S, ORD.LST_UPD_UID, ORD.LST_UPD_PGM_C, ORD.NEW_ORD_I,  ORD.ORD_TRAK_NBR,  ORD.SPR_CUS_C,  ORD.RCV_CUS_C,  ORD.PRM_REF_NBR_TYP_C,  ORD.PRM_REF_NBR_VAL, ORD.RT_I, ORD.XDIV_IND FROM ALI.ORD_LD_SYNC ORD WHERE ORD.NEW_ORD_I = :orderID WITH UR ", nativeQuery = true)
    List<OrderLoadSync> findLoadAndRouteDetailsByOrderID(@Param("orderID") Integer orderID);
	
	
	@Query(value = "SELECT O.NEW_ORD_I FROM ALI.ORD_LD_SYNC O, ALI.TPND_JOB_ASN P WHERE O.ORD_I= P.TSK_I AND P.EQP_UNT_I=:eqpUnitID AND  P.RSC_RSV_I > 0 ORDER BY P.ETA_D ,P.ETA_H WITH UR ", nativeQuery = true)
    List<Integer> getPlannedNewOrderIdsBylegacyEquipmentId(@Param("eqpUnitID") String eqpUnitID);
	
	OrderLoadSync findByScmOrderID(@Param("scmOrderID") Integer scmOrderID);
	
}
