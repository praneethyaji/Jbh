package com.jbhunt.loadplannig.integration.backfill.controllers;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.json.JSONException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.LoadExecutionIntegrationBackfillService;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.operations.equipmentgroup.dto.AddEquipmentGroupESDTO;
import com.jbhunt.operations.equipmentgroup.dto.EquipmentGroupESDTO;
import com.jbhunt.operations.equipmentgroup.dto.RemoveEquipmentFromGroupBackFillDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class LoadExecutionBackfillController extends BackfillBaseController {

	private final LoadExecutionIntegrationBackfillService loadExecutionIntegrationBackfillService;
	private MasterdataAssetClient masterdataAssetClient;

	@PostMapping("/equipmentgroup")
	public ResponseEntity<BackfillServiceResponse> equipmentAssignment(
			@RequestBody EquipmentGroupESDTO equipmentGroupESDTO) throws URISyntaxException, JSONException {

		log.info("Equipment assignment");
		List<AddEquipmentGroupESDTO> equipmentGroupList = equipmentGroupESDTO.getAddEquipmentGroupESDTO();
		AddEquipmentGroupESDTO truckDetail = equipmentGroupList.stream()
				.filter(equipmentGroup -> equipmentGroup.getEquipmentClassificationCode()
						.equalsIgnoreCase(CommonConstants.TRACTOR))
				.findFirst().orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));

		Optional<AddEquipmentGroupESDTO> trailerDetail = equipmentGroupList.stream()
				.filter(equipmentGroup -> equipmentGroup.getEquipmentClassificationCode()
						.equalsIgnoreCase(CommonConstants.TRAILER))
				.findFirst();

		Optional<AddEquipmentGroupESDTO> containerDetail = equipmentGroupList.stream()
				.filter(equipmentGroup -> equipmentGroup.getEquipmentClassificationCode()
						.equalsIgnoreCase(CommonConstants.CONTAINER))
				.findFirst();

		Optional<AddEquipmentGroupESDTO> chassisDetail = equipmentGroupList.stream()
				.filter(equipmentGroup -> equipmentGroup.getEquipmentClassificationCode()
						.equalsIgnoreCase(CommonConstants.CHASSIS))
				.findFirst();

		if (trailerDetail.isPresent()) {
			log.info("Truck-Trailer Assignment");
			loadExecutionIntegrationBackfillService.checkForPairing(truckDetail, trailerDetail.get(),
					CommonConstants.STRING_A, equipmentGroupESDTO.getUserId());
		} else {
			if (containerDetail.isPresent() && chassisDetail.isPresent()) {
				log.info("Truck-Container Assignment & Chassis-Container Attach");
				loadExecutionIntegrationBackfillService.checkForPairing(truckDetail, containerDetail.get(),
						CommonConstants.STRING_A, equipmentGroupESDTO.getUserId());
				loadExecutionIntegrationBackfillService.chassisAttach(equipmentGroupESDTO);
			}
			if (containerDetail.isPresent() && !chassisDetail.isPresent()) {
				log.info("Truck-Container Assignment");
				loadExecutionIntegrationBackfillService.checkForPairing(truckDetail, containerDetail.get(),
						CommonConstants.STRING_A, equipmentGroupESDTO.getUserId());
			}
			if (!containerDetail.isPresent() && chassisDetail.isPresent()) {
				log.info("Truck-chassis Assignment");
				loadExecutionIntegrationBackfillService.checkForPairing(truckDetail, chassisDetail.get(),
						CommonConstants.STRING_A, equipmentGroupESDTO.getUserId());
			}
		}
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}

	@PatchMapping("/equipmentgroup")
	public ResponseEntity<BackfillServiceResponse> equipmentUnassignment(
			@RequestBody RemoveEquipmentFromGroupBackFillDTO removeEquipmentDTO)
			throws URISyntaxException, JSONException {
		log.info("Equipment Unassignment");
		List<Integer> equipmentIds = removeEquipmentDTO.getRemoveEquipmentRequestDTO().getEquipmentDetailsDtos()
				.stream().map(EquipmentDetailsDto -> EquipmentDetailsDto.getEquipmentId()).collect(Collectors.toList());
		equipmentIds.add(Optional.ofNullable(removeEquipmentDTO.getTruckId())
				.orElseThrow(() -> new JBHuntRuntimeException("Truck Id not found")));

		List<EquipmentDetailsDTO> equipmentDetails = Optional
				.ofNullable(masterdataAssetClient.getEquipmentDetails(equipmentIds))
				.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream()
				.collect(Collectors.toList());

		EquipmentDetailsDTO truckDetail = equipmentDetails.stream()
				.filter(equipmentDetail -> equipmentDetail.getCategory().equalsIgnoreCase("POWER")).findFirst()
				.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));

		Optional<EquipmentDetailsDTO> trailorDetail = equipmentDetails.stream()
				.filter(equipmentDetail -> equipmentDetail.getEquipmentType().equalsIgnoreCase("TRAILER")).findFirst();

		Optional<EquipmentDetailsDTO> chassisDetail = equipmentDetails.stream()
				.filter(equipmentDetail -> equipmentDetail.getCategory().equalsIgnoreCase("CHASSIS")).findFirst();

		Optional<EquipmentDetailsDTO> containerDetail = equipmentDetails.stream()
				.filter(equipmentDetail -> equipmentDetail.getCategory().equalsIgnoreCase("CONTAINER")
						&& !equipmentDetail.getEquipmentType().equalsIgnoreCase("TRAILER"))
				.findFirst();

		if (trailorDetail.isPresent()) {
			log.info("Truck-trailer Unassignment");
			loadExecutionIntegrationBackfillService.truckUnassignment(removeEquipmentDTO, truckDetail,
					trailorDetail.get());
		} else {
			if (containerDetail.isPresent() && chassisDetail.isPresent()) {
				log.info("Truck-Container Unassignment & Chassis-Container Detach");
				loadExecutionIntegrationBackfillService.truckUnassignment(removeEquipmentDTO, truckDetail,
						containerDetail.get());
				loadExecutionIntegrationBackfillService.chassisDetach(removeEquipmentDTO,containerDetail.get(),chassisDetail.get());
			}
			if (containerDetail.isPresent() && !chassisDetail.isPresent()) {
				log.info("Truck-Container Unassignment");
				loadExecutionIntegrationBackfillService.truckUnassignment(removeEquipmentDTO, truckDetail,
						containerDetail.get());
			}
			if (!containerDetail.isPresent() && chassisDetail.isPresent()) {
				log.info("Chassis-Container Detach");
				loadExecutionIntegrationBackfillService.truckUnassignment(removeEquipmentDTO, truckDetail,
						chassisDetail.get());
			}
		}
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
}
