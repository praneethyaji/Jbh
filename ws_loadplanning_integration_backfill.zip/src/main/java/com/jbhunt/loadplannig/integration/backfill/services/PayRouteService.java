package com.jbhunt.loadplannig.integration.backfill.services;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadSyncRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.BkfilOwoJaAscResponse;
import com.jbhunt.loadplannig.integration.backfill.utils.PayRouteHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class PayRouteService {

	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;
	private final OrderLoadSyncRepository orderLoadSyncRepository;
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final PayRouteHelper payRouteHelper;

	public void createOrUpdatePayRoute(final OperationalPlanDTO operationalPlanDTO, String eventType)
			throws URISyntaxException {
		try {
			saveBackTrackingDetails(operationalPlanDTO, eventType);
			List<Integer> newOrderIds = new ArrayList<>();
			List<Integer> legacyOrderIds = new ArrayList<>();
			switch (operationalPlanDTO.getOperationalPlanType().getOperationalPlanTypeCode()) {
			case "Freight":
				List<OrderOperationalPlanAssociationDTO> orderOperationalPlanAssociations = operationalPlanDTO
						.getOrderOperationalPlanAssociations();
				orderOperationalPlanAssociations.forEach(orderOperationalPlanAssociation -> {
					newOrderIds.add(orderOperationalPlanAssociation.getOperationalPlanOrder().getOrderId());
				});
				if (!CollectionUtils.isEmpty(newOrderIds)) {
					newOrderIds.forEach(newOrderId -> {
						OrderLoadSync orderLoadSync = Optional
								.ofNullable(orderLoadSyncRepository.findByScmOrderID(newOrderId))
								.orElseThrow(() -> new JBHuntRuntimeException("Order does not exist."));
						legacyOrderIds.add(orderLoadSync.getLegacyOrderID());
					});
				} else {
					throw new JBHuntRuntimeException("No new Order Id found");
				}
				break;
			case "OWO":
				newOrderIds.add(operationalPlanDTO.getOperationalPlanWorkOrderAssociations().get(0)
						.getOperationalWorkOrderId());
				BkfilOwoJaAscResponse bkfilOwoJaAscResponse = loadplanningIntegrationOWObackfillService
						.findOrdDetailsBynxtOwoNum("W" + operationalPlanDTO.getOperationalPlanWorkOrderAssociations()
								.get(0).getOperationalWorkOrderId());
				legacyOrderIds.add(bkfilOwoJaAscResponse.getOrdI());
				break;
			default:
				break;
			}

			if (!CollectionUtils.isEmpty(legacyOrderIds)) {
				legacyOrderIds.forEach(legacyOrderId -> {
					payRouteHelper.populateLm365InputArea(legacyOrderId, operationalPlanDTO);
				});

			} else {
				throw new JBHuntRuntimeException("Order details not present in the given contract");
			}

		} catch (Exception e) {
			log.error("Exception in createOrUpdatePayRoute:", e);
			updateException(operationalPlanDTO, e);
			throw e;
		}

	}

	private void saveBackTrackingDetails(final OperationalPlanDTO operationalPlanDTO, final String eventSubType) {
		backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
				eventSubType, "");
	}

	private void updateException(OperationalPlanDTO operationalPlanDTO, Exception e) {
		String errorMesage = ExceptionUtils.getRootCauseMessage(e);
		if (errorMesage != null && errorMesage.length() > 500) {
			errorMesage = errorMesage.substring(0, 500);
		}
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
				errorMesage);
	}

}
