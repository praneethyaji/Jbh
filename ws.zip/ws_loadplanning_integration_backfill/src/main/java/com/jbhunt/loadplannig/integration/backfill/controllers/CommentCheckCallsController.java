package com.jbhunt.loadplannig.integration.backfill.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.CommentCheckCallService;
import com.jbhunt.operations.trackandtrace.dto.CheckCallESDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class CommentCheckCallsController extends BackfillBaseController{
	
	private CommentCheckCallService commentCheckCallService;
	@PatchMapping(value = "/commentcalls")
	    public ResponseEntity<BackfillServiceResponse> addCommentCall(@RequestBody CheckCallESDTO checkCallESDTO)   {
	        log.info("Calling commentcalls process:");
	       commentCheckCallService.addCommentCall(checkCallESDTO);
	        return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	        
	    }	
}
