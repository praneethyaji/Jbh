package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TDSP_JOB_XRF", schema = "ALI")
public class TDspJobXrf implements Serializable {

	private static final long serialVersionUID = -7790279542714704996L;

	@Id
	@Column(name = "JOB_I")
	private Integer jobId;

	@Column(name = "ORD_I")
	private Integer orderId;

	@Column(name = "DSP_NBR")
	private Short dispatchNumber;

}
