package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "BKFIL_OWO_JA_ASC", schema = "ALI")
public class BkfilOwoJaAsc implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = -2564879331514461257L;

	@Id
	@Column(name = "BKFIL_OWO_JA_ASC_I")
	private Integer bkfilOwoJaAscI;

	@Column(name = "NEXT_OWO_I")
	private Integer nxtOwoI;

	@Column(name = "NEXT_OWO_NUM")
	private String nxtOwoNum;

	@Column(name = "LGC_JA_I")
	private Integer lgcJaI;

}
