package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TORD_REF_NBR", schema = "ALI")
public class OrdRefNbr implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 5642757006646504503L;
	
	@Id
    @Column(name = "ORD_REF_NBR")
    private String ordRefNbr;
	
	@Column(name = "ORD_REF_NBR_TYP_C")
	private String ordRefNbrTypC;
	 
	@Column(name = "ORD_I")
	private int orderId;
	
	@Column(name = "ORD_STP_SEQ_NBR")
	private int orderStopSeqNbr;
	
	@Column(name = "ORD_REF_NBR_I")
	private int orderRefNbrId;
	
	@Column(name = "USE_F")
	private String useF;
	
	@Column(name = "BUS_SIT_I")
	private int businessSiteId;
	
	@Column(name = "ADR_I")
	private int addressId;
	
	@Column(name = "CRT_S")
	private String createdTimeStamp;
	
	@Column(name = "CRT_UID")
	private String createdUID;
	
	@Column(name = "LST_UPD_S")
	private String lastUpdatedTImeStamp;
	
	@Column(name = "LST_UPD_UID")
	private String lastUpdatedUID;
	
	@Column(name = "LST_UPD_PGM_C")
	private String lastUpdatedProgramCode;
	
	@Column(name = "REC_STT")
	private String recStt;

}
