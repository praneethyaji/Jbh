package com.jbhunt.loadplannig.integration.backfill.services;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.json.JSONException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckCallArrivalDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.SubTaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TActivityJDBCRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TAppointmentJDBCRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TSubtaskJDBCRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.ArrivalCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanCheckCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.jbhunt.mdm.dto.LocationProfileDTO;
import com.jbhunt.mdm.dto.LocationProfileDTOs;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
@Transactional
public class ArrivalCheckCallEditService {

	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final TimeZoneUtilityService timeZoneUtilityService;
	private final SubTaskRepository subTaskRepository;
	private final LocationClient locationClient;
	private final OrderLoadRepository orderLoadRepository;
	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;
	private final TAppointmentJDBCRepository tAppointmentJDBCRepository;
	private final TActivityJDBCRepository tActivityJDBCRepository;
	private final TSubtaskJDBCRepository tSubtaskJDBCRepository;

	public void updateArrivalCheckCall(final OperationalPlanDTO operationalPlanDTO) {
		try {
			editArrivalCheckCall(operationalPlanDTO);
		} catch (Exception e) {
			updateException(operationalPlanDTO, e);
			throw new JBHuntRuntimeException(e.getMessage());
		}
	}

	private void editArrivalCheckCall(final OperationalPlanDTO operationalPlanDTO) throws Exception {

		final CheckCallArrivalDTO checkCallArrivalDTO = new CheckCallArrivalDTO();
		saveBackTrackingDetails(operationalPlanDTO, OperationalPlanEventSubType.ARRIVAL_CHECK_CALL_UPDATED.name());
		final OperationalPlanCheckCallDTO operationalPlanCheckCallDTO = operationalPlanDTO
				.getOperationalPlanCheckCallList().stream()
				.filter(operationalPlanCheckCall -> operationalPlanCheckCall.getCheckCallType().getCheckCallTypeCode()
						.equalsIgnoreCase("Arrival"))
				.findAny().orElseThrow(() -> new JBHuntRuntimeException("Check call type code is not Arrival"));

		final OperationalPlanStopDTO operationalPlanStopDTO = getOperationalPlanStop(operationalPlanDTO,
				operationalPlanCheckCallDTO.getOperationalPlanStopId());

		checkCallArrivalDTO.setLocationTimeZone(
				timeZoneUtilityService.getTimeBasedOnLocation(operationalPlanStopDTO.getLocationId()));
		DateTimeFormatter sdfDate = DateTimeFormatter.ofPattern(CommonConstants.DB2_DATE_FORMAT);
		DateTimeFormatter sdfTime = DateTimeFormatter.ofPattern(CommonConstants.DB2_TIME_FORMAT);
		ArrivalCallDTO arrivalCallDTO = operationalPlanCheckCallDTO.getArrivalCall();

		ZonedDateTime arrivalTimeStamp = arrivalCallDTO.getArrivalTimestamp()
				.atZoneSameInstant(ZoneId.of(checkCallArrivalDTO.getLocationTimeZone()));

		checkCallArrivalDTO.setArrivalDate(sdfDate.format(arrivalTimeStamp));
		checkCallArrivalDTO.setArrivalTime(sdfTime.format(arrivalTimeStamp));

		Optional.ofNullable(arrivalCallDTO.getArrivalTimeDeviation()).ifPresent(arrivalTimeDeviation -> {
			String reasonCode = Optional.ofNullable(arrivalCallDTO.getArrivalTimeDeviation())
					.map(arrivalTimeDeviationResponseDTO -> arrivalTimeDeviationResponseDTO
							.getOperationalPlanStopAppointmentChangeReasonCode())
					.map(String::trim).filter(StringUtils::isNotEmpty).orElse("");
			callServiceBasedOnDeviationCode(reasonCode, checkCallArrivalDTO);

		});

		final List<OrderOperationalPlanAssociationDTO> orderOperationalPlanAssociations = operationalPlanDTO
				.getOrderOperationalPlanAssociations();

		final String stateCityCode = getStateCityCodeByLocationId(operationalPlanStopDTO.getLocationId());

		orderOperationalPlanAssociations.forEach(orderOperationalPlanAssociation -> {

			final Integer newOrderId = orderOperationalPlanAssociation.getOperationalPlanOrder().getOrderId();
			final TOrder orderSync = Optional.ofNullable(orderLoadRepository.findLoadDetailsByOrderID(newOrderId))
					.orElseGet(() -> orderLoadRepository.findLoadDetailsByOrderIDWarehouse(newOrderId));
			log.info("order syn:{}", orderSync.getOrderId());
			log.info("operationalPlanStopDTO.getOperationalPlanStopSequenceNumber :{}",
					operationalPlanStopDTO.getOperationalPlanStopSequenceNumber());

			final TSubtask1 tSubtask1 = subTaskRepository.fetchByTaskIdAndCityIdAndRequestTyId(orderSync.getOrderId(),
					stateCityCode, operationalPlanStopDTO.getOperationalPlanStopSequenceNumber());
			log.info("SubTaskDetails:>> {}" , tSubtask1);
			log.info("ArrivalDate:{}", checkCallArrivalDTO.getArrivalDate());
			log.info("ArrivalTime:{}", checkCallArrivalDTO.getArrivalTime());
			log.info("Subtask Id >>{}", tSubtask1.getSubTaskID());
			tSubtaskJDBCRepository.updateTSubtask(checkCallArrivalDTO.getArrivalDate(),
					checkCallArrivalDTO.getArrivalTime(), tSubtask1.getSubTaskID());

			tActivityJDBCRepository.updateTActivity(checkCallArrivalDTO.getArrivalDate(),
					checkCallArrivalDTO.getArrivalTime(), tSubtask1.getSubTaskID());

			if (arrivalCallDTO.getArrivalTimeDeviation() == null) {
				checkCallArrivalDTO.setArrivalTimeDeviationTypeCode(" ");
				checkCallArrivalDTO.setComment(" ");
			}

			tAppointmentJDBCRepository.updateTAppointment(checkCallArrivalDTO.getArrivalTimeDeviationTypeCode(),
					checkCallArrivalDTO.getComment(), tSubtask1.getSubTaskID());

		});

		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
	}

	private OperationalPlanStopDTO getOperationalPlanStop(final OperationalPlanDTO operationalPlanDTO,
			final Integer oprationalPlanStopId) {
		final String message = "Stop Id " + oprationalPlanStopId + " is not found";
		return operationalPlanDTO.getOperationalPlanStops().stream().filter(
				operationalPlanStop -> operationalPlanStop.getOperationalPlanStopId().equals(oprationalPlanStopId))
				.findFirst().orElseThrow(() -> new JBHuntRuntimeException(message));
	}

	private String getStateCityCodeByLocationId(final Integer locationId) throws JBHuntRuntimeException, JSONException {
		final String customerCode = Optional.ofNullable(locationClient.findLocationProfilebyLocationCode(locationId))
				.map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode)
				.orElseThrow(() -> new JBHuntRuntimeException("Location Profile not found."));

		return Optional.ofNullable(loadplanningIntegrationOWObackfillService.getStateCityForCustomerCode(customerCode))
				.map(String::trim).filter(StringUtils::isNotEmpty).orElseThrow(() -> new JBHuntRuntimeException(
						"City Id is not found for the customer code - " + customerCode));
	}

	private void callServiceBasedOnDeviationCode(String arrivalTimeDeviationTypeCode,
			final CheckCallArrivalDTO checkCallArrivalDTO) {

		checkCallArrivalDTO.setArrivalTimeDeviationTypeCode(CommonConstants.OTHER_CODE);
		checkCallArrivalDTO.setComment(arrivalTimeDeviationTypeCode);
	}

	private void saveBackTrackingDetails(final OperationalPlanDTO operationalPlanDTO, final String eventSubType) {
		backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
				eventSubType, "");
	}

	private void updateException(OperationalPlanDTO operationalPlanDTO, Exception e) {
		String errorMesage = ExceptionUtils.getRootCauseMessage(e);
		if (errorMesage != null && errorMesage.length() > 500) {
			errorMesage = errorMesage.substring(0, 500);
		}
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
				errorMesage);
	}

}
