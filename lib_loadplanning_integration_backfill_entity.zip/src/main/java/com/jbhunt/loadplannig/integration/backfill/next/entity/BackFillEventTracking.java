package com.jbhunt.loadplannig.integration.backfill.next.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.jbhunt.infrastructure.audit.entity.AuditEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "BackFillEventTracking", schema = "BKFIL")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class BackFillEventTracking extends AuditEntity implements Serializable{

    private static final long serialVersionUID = 1573730216891800343L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BackFillEventTrackingID")
    private Integer backFillEventTrackingId;

    @Column(name = "NextOrderID",nullable = false)
    private Integer nextOrderId;

    @Column(name = "NextOrderTrackingNumber", nullable = false)
    private String nextOrderTrackingNumber;

    @Column(name = "NextOperationalPlanID", nullable = false)
    private Integer nextOperationalPlanId;

    @Column(name = "NextOperationalPlanNumber",nullable = false)
    private String nextOperationalPlanNumber;

    @Column(name = "EventStatus",nullable = false)
    private String eventStatus;

    @Column(name = "EventType",nullable = false)
    private String eventType;

    @Column(name = "EventTimestamp",nullable = false)
    private String eventTimestamp;

    @Column(name = "EventMessageText",nullable = true)
    private String eventMessageText;

}
