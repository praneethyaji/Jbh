package com.jbhunt.loadplannig.integration.backfill.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.ResourceAssignmentService;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class ResourceAssignmentController extends BackfillBaseController {

	private final ResourceAssignmentService resourceAssignmentService;

	@PatchMapping("/operationalplans/{operationalPlanId}/resourceassignments")
	public ResponseEntity<BackfillServiceResponse> resourceAssignment(
			@RequestBody final OperationalPlanDTO operationalPlanDTO) {
		log.info("Triggered - /backfill/resourceassignments ");
		resourceAssignmentService.resourceAssignment(operationalPlanDTO);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
	
	@PatchMapping("/operationalplans/{operationalPlanId}/resourceassignments/cancel")
	public ResponseEntity<BackfillServiceResponse> cancelResourceAssignment(
			@RequestBody final OperationalPlanDTO operationalPlanDTO) {
		log.info("Triggered - /backfill/resourceassignments/cancel ");
		resourceAssignmentService.cancelResourceAssignment(operationalPlanDTO);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
}
