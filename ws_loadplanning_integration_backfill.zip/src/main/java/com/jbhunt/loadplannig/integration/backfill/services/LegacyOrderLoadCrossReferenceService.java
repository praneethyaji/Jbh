package com.jbhunt.loadplannig.integration.backfill.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHValidationException;
import com.jbhunt.loadplannig.integration.backfill.dto.LegacyOrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplannig.integration.backfill.next.repository.LegacyOrderOperationalPlanAssociationRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class LegacyOrderLoadCrossReferenceService {

	@Autowired
	private LegacyOrderOperationalPlanAssociationRepository legacyOrderOperationalPlanAssociationRepository;

	public LegacyOrderOperationalPlanAssociationDTO getLegacyOrderDetails(final Integer operationalPlanId) {
		return legacyOrderOperationalPlanAssociationRepository.getLegacyOrderDetails(operationalPlanId);
	}

	public List<LegacyOrderOperationalPlanAssociationDTO> getOperationalPlansByOrderId(final Integer legacyOrderId)
			throws JBHValidationException {
		List<LegacyOrderOperationalPlanAssociationDTO> associationList = new ArrayList<>();
		associationList = legacyOrderOperationalPlanAssociationRepository.getOperationalPlansByOrderId(legacyOrderId);
		if (!associationList.isEmpty()) {
			return associationList;
		} else {
			throw new JBHValidationException("No Legacy Details Found");
		}
	}

	public Integer getOperationalPlanIdByJoborReservationId(Integer legacyorderid, Integer legacyjobid,
			Integer legacyresourcereservationid) throws JBHValidationException {
		Integer operationalPlanId = null;
		if (null != legacyjobid && null == legacyresourcereservationid) {
			operationalPlanId = legacyOrderOperationalPlanAssociationRepository
					.getOperationalPlanIdByJobId(legacyorderid, legacyjobid);
		} else if (null == legacyjobid && null != legacyresourcereservationid) {
			operationalPlanId = legacyOrderOperationalPlanAssociationRepository
					.getOperationalPlanIdByReservationId(legacyorderid, legacyresourcereservationid);
		} else {
			operationalPlanId = legacyOrderOperationalPlanAssociationRepository.getOperationalPlanId(legacyorderid,
					legacyjobid, legacyresourcereservationid);
		}
		return operationalPlanId;
	}

}
