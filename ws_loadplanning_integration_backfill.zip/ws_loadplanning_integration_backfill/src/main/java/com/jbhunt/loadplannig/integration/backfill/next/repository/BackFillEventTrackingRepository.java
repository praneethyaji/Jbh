package com.jbhunt.loadplannig.integration.backfill.next.repository;

import java.time.LocalDateTime;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.jbhunt.loadplannig.integration.backfill.utils.CommonUtils;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.owo.dto.OperationalWorkOrderDTO;

import lombok.AllArgsConstructor;

@Repository
@AllArgsConstructor
public class BackFillEventTrackingRepository {

	private final JdbcTemplate sqlServerjdbcTemplate;

	public void saveBackTrackingDetails(OperationalPlanDTO operationalPlanDTO, String eventStatus, String eventType,
			String EventMessageText) {
		switch (operationalPlanDTO.getOperationalPlanType().getOperationalPlanTypeCode()) {
		case "Freight":
			operationalPlanDTO.getOrderOperationalPlanAssociations().forEach(orderOperationalPlanAssociationDTO -> {
				insertBackfillEventTrackingRecord(
						orderOperationalPlanAssociationDTO.getOperationalPlanOrder().getOrderId(),
						orderOperationalPlanAssociationDTO.getOperationalPlanOrder().getOrderTrackingNumber(),
						operationalPlanDTO, eventStatus, eventType, EventMessageText);
			});
			break;
		case "OWO":
			operationalPlanDTO.getOperationalPlanWorkOrderAssociations()
					.forEach(operationalPlanWorkOrderAssociationsDTO -> {
						insertBackfillEventTrackingRecord(
								operationalPlanWorkOrderAssociationsDTO.getOperationalWorkOrderId(),
								"W" + operationalPlanWorkOrderAssociationsDTO.getOperationalWorkOrderId(),
								operationalPlanDTO, eventStatus, eventType, EventMessageText);
					});
			break;
		default:
			break;
		}
	}

	public void insertBackfillEventTrackingRecord(Integer orderId, String orderTrackingNumber,
			OperationalPlanDTO operationalPlanDTO, String eventStatus, String eventType, String eventMessageText) {
		String currentDateAndTime = CommonUtils.convertToDatabaseColumn(LocalDateTime.now());
		sqlServerjdbcTemplate.update(
				"INSERT INTO BKFIL.BackFillEventTracking (NextOrderID,NextOrderTrackingNumber,NextOperationalPlanID,\r\n"
						+ "NextOperationalPlanNumber,EventStatus,EventType, EventTimestamp,EventMessageText,CreateTimestamp,\r\n"
						+ "CreateUserID,CreateProgramName,LastUpdateTimestamp,LastUpdateUserID,LastUpdateProgramName) \r\n"
						+ " VALUES  (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
				orderId, orderTrackingNumber, operationalPlanDTO.getOperationalPlanId(),
				operationalPlanDTO.getOperationalPlanNumber(), eventStatus, eventType, currentDateAndTime,
				eventMessageText, currentDateAndTime, operationalPlanDTO.getCreateUserId(),
				operationalPlanDTO.getCreateProgramName(), currentDateAndTime, operationalPlanDTO.getLastUpdateUserId(),
				operationalPlanDTO.getLastUpdateProgramName());
	}

	public void updateBackTrackingDetails(OperationalPlanDTO operationalPlanDTO, String eventStatus,
			String eventMessageText) {
		switch (operationalPlanDTO.getOperationalPlanType().getOperationalPlanTypeCode()) {
		case "Freight":
			operationalPlanDTO.getOrderOperationalPlanAssociations().forEach(orderOperationalPlanAssociationDTO -> {
				updateBackfillEventTrackingRecord(
						orderOperationalPlanAssociationDTO.getOperationalPlanOrder().getOrderId(),
						orderOperationalPlanAssociationDTO.getOperationalPlanOrder().getOrderTrackingNumber(),
						operationalPlanDTO, eventStatus, eventMessageText);
			});
			break;
		case "OWO":
			operationalPlanDTO.getOperationalPlanWorkOrderAssociations()
					.forEach(operationalPlanWorkOrderAssociationsDTO -> {
						updateBackfillEventTrackingRecord(
								operationalPlanWorkOrderAssociationsDTO.getOperationalWorkOrderId(),
								"W" + operationalPlanWorkOrderAssociationsDTO.getOperationalWorkOrderId(),
								operationalPlanDTO, eventStatus, eventMessageText);
					});
			break;
		default:
			break;
		}
	}

	public void updateBackfillEventTrackingRecord(Integer orderId, String orderTrackingNumber,
			OperationalPlanDTO operationalPlanDTO, String eventStatus, String eventMessageText) {
		String currentDateAndTime = CommonUtils.convertToDatabaseColumn(LocalDateTime.now());
		sqlServerjdbcTemplate.update(
				"UPDATE BKFIL.BackFillEventTracking SET EventStatus=?, EventMessageText=?, LastUpdateTimestamp=?, LastUpdateUserID=?, LastUpdateProgramName=? "
						+ " WHERE NextOrderID=? AND NextOrderTrackingNumber=? AND NextOperationalPlanID=? AND NextOperationalPlanNumber=? "
						+ "AND BackFillEventTrackingID = (SELECT TOP(1) BackFillEventTrackingID FROM BKFIL.BackFillEventTracking "
						+ "WHERE NextOrderID=? AND NextOrderTrackingNumber=? AND NextOperationalPlanID=? AND NextOperationalPlanNumber=? "
						+ "ORDER BY BackFillEventTrackingID DESC) ",
				eventStatus, eventMessageText, currentDateAndTime, operationalPlanDTO.getLastUpdateUserId(),
				operationalPlanDTO.getLastUpdateProgramName(), orderId, orderTrackingNumber,
				operationalPlanDTO.getOperationalPlanId(), operationalPlanDTO.getOperationalPlanNumber(), orderId,
				orderTrackingNumber, operationalPlanDTO.getOperationalPlanId(),
				operationalPlanDTO.getOperationalPlanNumber());
	}

	public void saveBackTrackingDetails(OperationalWorkOrderDTO operationWorkOrder, String eventStatus,
			String eventType) {
		String currentDateAndTime = CommonUtils.convertToDatabaseColumn(LocalDateTime.now());
		sqlServerjdbcTemplate.update(
				"INSERT INTO BKFIL.BackFillEventTracking (NextOrderID,NextOrderTrackingNumber,NextOperationalPlanID,\r\n"
						+ "NextOperationalPlanNumber,EventStatus,EventType, EventTimestamp,EventMessageText,CreateTimestamp,\r\n"
						+ "CreateUserID,CreateProgramName,LastUpdateTimestamp,LastUpdateUserID,LastUpdateProgramName) \r\n"
						+ " VALUES  (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
				operationWorkOrder.getOperationalWorkOrderID(), operationWorkOrder.getOperationalWorkOrderNumber(),
				operationWorkOrder.getOperationalWorkOrderID(), operationWorkOrder.getOperationalWorkOrderNumber(),
				eventStatus, eventType, currentDateAndTime, null, currentDateAndTime,
				operationWorkOrder.getLastUpdateUserID(), operationWorkOrder.getLastUpdateProgramName(),
				currentDateAndTime, operationWorkOrder.getLastUpdateUserID(),
				operationWorkOrder.getLastUpdateProgramName());
	}

	public void updateBackTrackingDetails(OperationalWorkOrderDTO operationWorkOrder, String eventStatus,
			String eventMessageText) {
		sqlServerjdbcTemplate.update(
				"UPDATE BKFIL.BackFillEventTracking SET EventStatus=?, EventMessageText=?, LastUpdateTimestamp=?, LastUpdateUserID=?, LastUpdateProgramName=? "
						+ " WHERE NextOrderID=? AND NextOrderTrackingNumber=? AND NextOperationalPlanID=? AND NextOperationalPlanNumber=? "
						+ "AND BackFillEventTrackingID = (SELECT TOP(1) BackFillEventTrackingID FROM BKFIL.BackFillEventTracking "
						+ "WHERE NextOrderID=? AND NextOrderTrackingNumber=? AND NextOperationalPlanID=? AND NextOperationalPlanNumber=? ORDER BY BackFillEventTrackingID DESC)",
				eventStatus, eventMessageText, CommonUtils.convertToDatabaseColumn(LocalDateTime.now()),
				operationWorkOrder.getLastUpdateUserID(), operationWorkOrder.getLastUpdateProgramName(),
				operationWorkOrder.getOperationalWorkOrderID(), operationWorkOrder.getOperationalWorkOrderNumber(),
				operationWorkOrder.getOperationalWorkOrderID(), operationWorkOrder.getOperationalWorkOrderNumber(),
				operationWorkOrder.getOperationalWorkOrderID(), operationWorkOrder.getOperationalWorkOrderNumber(),
				operationWorkOrder.getOperationalWorkOrderID(), operationWorkOrder.getOperationalWorkOrderNumber());
	}
}
