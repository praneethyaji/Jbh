package com.jbhunt.loadplannig.integration.backfill.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.LoadEditService;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class LoadEditController extends BackfillBaseController {

	private final LoadEditService loadEditService;

	@PatchMapping("/operationalplans/load/{operationalPlanId}/instructions")
	public ResponseEntity<BackfillServiceResponse> updateInstructions(
			@RequestBody OperationalPlanEvent operationalPlanEvent) throws Exception {
		log.info("update Instructions for load: "
				+ operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanNumber());
		loadEditService.loadInstruction(operationalPlanEvent);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}

	@PatchMapping("/operationalplans/load/{operationalPlanId}/references")
	public ResponseEntity<BackfillServiceResponse> updateReferences(
			@RequestBody OperationalPlanEvent operationalPlanEvent) throws Exception {
		log.info("update References for load: "
				+ operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanNumber());
		loadEditService.loadReference(operationalPlanEvent);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}

}
