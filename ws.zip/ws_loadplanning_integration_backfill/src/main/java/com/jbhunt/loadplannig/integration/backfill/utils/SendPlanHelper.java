package com.jbhunt.loadplannig.integration.backfill.utils;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.CityRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.DriverAssignmentDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.EquipmentAssignmentDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventType;
import com.jbhunt.masterdata.account.dto.CrossReferenceDTO;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.crossreference.client.CrossreferenceClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.jbhunt.personnel.client.PersonnelPeopleClient;
import com.jbhunt.personnel.people.dto.PeopleDetailsDTO;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class SendPlanHelper {

	private PersonnelPeopleClient personnelPeopleClient;
	private MasterdataAssetClient masterdataAssetClient;
	private CityRepository cityRepository;
	private final LocationClient locationClient;
	private final CrossreferenceClient crossreferenceClient;

	public PeopleDetailsDTO populateDriverDetails(ResourceAssignmentPlanDTO resourceAssignmentPlan) {
		return Optional.ofNullable(resourceAssignmentPlan.getDriverAssignment()).map(DriverAssignmentDTO::getDriverId)
				.filter(StringUtils::isNotBlank).map(personnelPeopleClient::getPersonDetails)
				.orElseThrow(() -> new JBHuntRuntimeException("Driver details is not available"));
	}

	public EquipmentDetailsDTO populateEquipment(ResourceAssignmentPlanDTO resourceAssignmentPlan) {
		return Optional.ofNullable(resourceAssignmentPlan.getEquipmentAssignments())
				.map(EquipmentAssignmentDTO::getEquipmentId).map(equimentId -> {
					try {
						return masterdataAssetClient.getEquipmentDetails(Arrays.asList(equimentId));
					} catch (URISyntaxException e) {
						throw new JBHuntRuntimeException(e);
					}
				}).filter(CollectionUtils::isNotEmpty).map(list -> list.get(0))
				.orElseThrow(() -> new JBHuntRuntimeException("Equipemnt details is not available"));
	}

	public String getCityStateForCustomerCode(String cusCode) {
		List<Object[]> cityStateObjArrList = cityRepository.getCityStateForCustomerCode(cusCode);
		return cityStateObjArrList.stream().findFirst().map(objects -> StringUtils.trim((String) objects[5]))
				.orElse("");
	}

	public String getCustomerCode(String cusCode) {
		List<Object[]> cityStateObjArrList = cityRepository.getCityStateForCustomerCode(cusCode);
		return cityStateObjArrList.stream().findFirst().map(objects -> StringUtils.trim((String) objects[0]))
				.orElse("");
	}

	public final LocationProfileDTOs getLocationCode(OperationalPlanEvent operationalPlanEvent) {

		OperationalPlanEventType operationalPlanEventType = operationalPlanEvent.getOperationalPlanEventType();
		List<OperationalPlanEventSubType> eventSubType = operationalPlanEvent.getOperationalPlanEventSubTypes();
		OperationalPlanDTO operationalPlan = operationalPlanEvent.getOperationalPlanDTO();

		Integer locationId = 0;

		LocationProfileDTOs locationProfileDTOs;

		if (operationalPlanEventType.equals(OperationalPlanEventType.UPDATED)
				&& eventSubType.contains(OperationalPlanEventSubType.INBOUND_TO_YARD)) {
			Stream<OperationalPlanStopDTO> operationalPlanStopDTO = operationalPlan.getOperationalPlanStops().stream();
			Optional<OperationalPlanStopDTO> stopDetail = operationalPlanStopDTO
					.max(Comparator.comparing(OperationalPlanStopDTO::getOperationalPlanStopSequenceNumber));
			if (stopDetail.isPresent()) {
				locationId = stopDetail.get().getLocationId();
			}

		} else if (operationalPlanEventType.equals(OperationalPlanEventType.CREATED)
				&& eventSubType.contains(OperationalPlanEventSubType.INBOUND_TO_YARD)) {
			Stream<OperationalPlanStopDTO> operationalPlanStopDTO = operationalPlan.getOperationalPlanStops().stream();
			Optional<OperationalPlanStopDTO> stopDetail = operationalPlanStopDTO
					.min(Comparator.comparing(OperationalPlanStopDTO::getOperationalPlanStopSequenceNumber));
			if (stopDetail.isPresent()) {
				locationId = stopDetail.get().getLocationId();
			}
		}

		try {
			locationProfileDTOs = locationClient.findLocationProfilebyLocationCode(locationId);
		} catch (JSONException e) {
			throw new JBHuntRuntimeException(e.getMessage());
		}
		return locationProfileDTOs;
	}

	public String getLocationCode(final OperationalPlanDTO operationalPlanDTO) throws JSONException {
		Integer locationId = 0;
		Stream<OperationalPlanStopDTO> operationalPlanStopDTO = operationalPlanDTO.getOperationalPlanStops().stream();
		Optional<OperationalPlanStopDTO> stopDetail = operationalPlanStopDTO
				.max(Comparator.comparing(OperationalPlanStopDTO::getOperationalPlanStopSequenceNumber));

		if (stopDetail.isPresent()) {
			locationId = stopDetail.get().getLocationId();
		}
		final LocationProfileDTOs locationProfileDTOs = locationClient.findLocationProfilebyLocationCode(locationId);
		return locationProfileDTOs.getLocationProfileDTO().getLocationCode();
	}
	
	 public City getCityStateCodeByCityID(Integer cityID) {
		return Optional.ofNullable(crossreferenceClient.fetchBridgeTableDetailList("City", "CityID", cityID))
				.flatMap(crossReferenceDTOs -> crossReferenceDTOs.stream().findFirst()
						.map(CrossReferenceDTO::getCciEntityFirstColumnValue).map(cityRepository::findByPnt))
				.orElse(null);
	}
}