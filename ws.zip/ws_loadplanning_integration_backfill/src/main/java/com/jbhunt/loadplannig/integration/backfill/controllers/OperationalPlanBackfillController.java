package com.jbhunt.loadplannig.integration.backfill.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.LoadplanningIntegrationbackfillService;
import com.jbhunt.loadplannig.integration.backfill.services.OperationalPlanBackfillService;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class OperationalPlanBackfillController extends BackfillBaseController{

	private final OperationalPlanBackfillService operationalPlanBackfillService;
	
	private final LoadplanningIntegrationbackfillService loadplanningIntegrationbackfillService;

	@PostMapping("/operationalplans")
	public ResponseEntity<BackfillServiceResponse> backfillTrancking(@RequestBody OperationalPlanEvent operationalPlanEvent) {
	    loadplanningIntegrationbackfillService.loadCreate(operationalPlanEvent);
	    return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
	
	@PatchMapping("/operationalplans")
	public ResponseEntity<BackfillServiceResponse> sendOperationalPlan(@RequestBody OperationalPlanEvent operationalPlanEvent) throws Exception {
		log.info("save operational plan web service");
		operationalPlanBackfillService.operationalPlanService(operationalPlanEvent);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
	
}