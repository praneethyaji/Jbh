package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.Arrays;

import org.springframework.stereotype.Service;

import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.QOperPowAssoc;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TOperatorPowerAssociationRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.operations.drivertruckassignment.dto.PersonESDTO;
import com.jbhunt.operations.drivertruckassignment.dto.ResourceESDTO;
import com.querydsl.core.types.Predicate;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class PairingTruckAndDriverHelper {
	
	private final TOperatorPowerAssociationRepository tOperatorPowerAssociationRepository;
	
	public Boolean isAlreadyPaired(Integer equipmentId, String driverAlphaCode, String type) {
		QOperPowAssoc qOperPowAssoc = QOperPowAssoc.operPowAssoc;
		Predicate predicate = null;
		switch (type) {
		case CommonConstants.ISBOTHPAIRED:
			predicate = qOperPowAssoc.equipmentId.eq(equipmentId).and(qOperPowAssoc.recordStatus.eq("A"))
					.and(qOperPowAssoc.tOperator.driverid.eq(driverAlphaCode));
			break;
		case CommonConstants.ISTRUCKALREADYPAIRED:
			predicate = qOperPowAssoc.equipmentId.eq(equipmentId).and(qOperPowAssoc.recordStatus.eq("A"));
			break;
		case CommonConstants.ISDRIVERALREADYPAIRED:
			predicate = qOperPowAssoc.tOperator.driverid.eq(driverAlphaCode).and(qOperPowAssoc.recordStatus.eq("A"));
			break;
		default:
			break;

		}
		return tOperatorPowerAssociationRepository.exists(predicate);
	}
	
	public ResourceESDTO formResourceESDTO(ResourceAssignmentPlanDTO resourceAssignmentPlanDTO) {
		ResourceESDTO resourceESDTO = new ResourceESDTO();
		resourceESDTO.setAction("Assign");
		resourceESDTO.setEquipmentId(resourceAssignmentPlanDTO.getEquipmentAssignments().getEquipmentId());
		resourceESDTO.setResourceType(Arrays.asList("Driver"));
		PersonESDTO personESDTO = new PersonESDTO();
		personESDTO.setDriverPersonId(resourceAssignmentPlanDTO.getDriverAssignment().getDriverId());
		personESDTO.setDriverCompanionType("PrimaryDriver");
		resourceESDTO.setPerson(Arrays.asList(personESDTO));
		return resourceESDTO;
	}

}
