package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadSyncRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.RscPlanRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc341i.lmc341.LMC341Port;
import com.lmc342i.lmc342.LMC342Port;
import com.lmc362i.lmc362.LMC362Port;
import com.lmc363i.lmc363.LMC363Port;
import com.lmc366i.lmc366.LMC366Port;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables;
import com.response.lmc341i.lmc341.ProgramInterface.Lmc341OutputArea;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava.Wo42ErrorVariables;

import wiremock.com.fasterxml.jackson.core.JsonParseException;
import wiremock.com.fasterxml.jackson.databind.JsonMappingException;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class LoadplanintegrationbackfillControllerIT {

	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http").host("loadplanning-test.jbhunt.com")
			.removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

	public static final String CREATE_SWITCH_REQUEST = "/json/CreateSwitchRequestWithEquipment.json";

	public static final String CREATE_SWITCH_REQUEST_SECOND_RESOURCE_PERSON = "/json/CreateSwitchRequestWithPerson.json";

	private static final String SEND_OPERATIONAL_PLAN = "/sendOperationalPlan";

	private static final String SEND_OPERATIONAL_PLAN_JSON_PATH = "/json/OperationalPlanEvent.json";

	private static final String SEND_OPERATIONAL_PLAN_JSON_CANCELL = "/json/OperationalPlanEventCancell.json";

	private static final String TERMINATE_CHECKCALL_REQUEST = "/json/terminateCheckCall.json";

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private OrderLoadRepository orderLoadRepository;

	@MockBean
	private TaskRepository taskRepository;

	@MockBean
	private LMC341Port lmc341Port;

	@MockBean
	private LMC342Port lmc342Port;

	@MockBean
	private LMC362Port lmc362Port;

	@MockBean
	private LMC363Port lmc363Port;

	@MockBean
	private LMC366Port lmc366Port;

	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	private RscPlanRepository rscPlanRepository;

	@MockBean
	private EquipmentRepository equipmentRepository;

	@MockBean
	private OrderLoadSyncRepository orderLoadSyncRepository;

	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void testSendPlan() throws Exception {

		testSendPlanCancellOrAssign(SEND_OPERATIONAL_PLAN_JSON_PATH);
	}

	@Test
	public void testSendPlanCancell() throws Exception {

		testSendPlanCancellOrAssign(SEND_OPERATIONAL_PLAN_JSON_CANCELL);
	}

	@Test
	public void testTermanteCheckCall() throws Exception {

		testTermanteCall();
	}

	@Test
	public void testMergeLoad() throws Exception {

		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"328850\",\r\n"
				+ "    \"resourceName\": \"ARJUN  LAVEY\",\r\n" + "    \"firstName\": \"ARJUN\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"ARVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/328850")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataAssetForMergeLoad.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[342159]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/MergeLoad.json")),
				OperationalPlanEvent.class);

		TOrder orderDetails = new TOrder();
		// orderDetails.setLastOrderNumber("RA97939");
		orderDetails.setLastUpdateTimeStamp("2019-01-02 10.00.06");
		orderDetails.setOrderId(123456789);
		orderDetails.setOrdrNumber("RA97939");

		// Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(30013190).

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(30013190)).thenReturn(orderDetails);

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderIDWarehouse(30013190)).thenReturn(orderDetails);

		Mockito.when(taskRepository.findLastUpdatedTimeStampBytaskId(123456789)).thenReturn("2019-01-02 10.00.06");

		Lmc341OutputArea output1 = new Lmc341OutputArea();
		output1.setLmc341ErrorMessage("Mock");
		output1.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output1);
		Wo42ComReturnToJava output2 = new Wo42ComReturnToJava();
		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ErrorKey1("");
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		Wo42ErrorVariables.setWo42Message("");
		Wo42ErrorVariables.setWo42CicsReturnCode(399);
		Wo42ErrorVariables.setWo42ErrorKey2("");

		output2.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output2);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

	@Test
	public void testSendDriverPrePlan() throws Exception {
		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[7885243]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/DriverSendPlan.json")),
				OperationalPlanEvent.class);

		TOrder orderDetails = new TOrder();
		// orderDetails.setLastOrderNumber("RA97939");
		orderDetails.setLastUpdateTimeStamp("2019-01-02 10.00.06");
		orderDetails.setOrderId(123456789);
		orderDetails.setOrdrNumber("RA97939");

		// Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(30013190).

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(1010479)).thenReturn(orderDetails);

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderIDWarehouse(1010479)).thenReturn(orderDetails);

		Mockito.when(taskRepository.findLastUpdatedTimeStampBytaskId(123456789)).thenReturn("2019-01-02 10.00.06");

		Lmc341OutputArea output = new Lmc341OutputArea();
		output.setLmc341ErrorMessage("Mock");
		output.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output);

		Wo42ComReturnToJava output2 = new Wo42ComReturnToJava();

		Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
		wo42ErrorVariables.setWo42ReturnFlag("S");
		output2.setWo42ErrorVariables(wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output2);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		System.out.println("response ---- >>> " + response.asString());

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	private void testTermanteCall() throws JsonParseException, JsonMappingException, IOException, URISyntaxException {
		// ARRANGE

		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(TERMINATE_CHECKCALL_REQUEST)),
				OperationalPlanEvent.class);

		City city = new City();
		city.setCityID("MACHI");
		city.setCtyStC("CHIMA");
		city.setDscT("CHICOPEE");
		city.setPntI(27051);
		city.setRecSttF("A");
		city.setState("MA");

		TOrder orderDetails = new TOrder();
		// orderDetails.setLastOrderNumber("RA97939");
		orderDetails.setLastUpdateTimeStamp("2019-01-02 10.00.06");
		orderDetails.setOrderId(2345678);
		orderDetails.setOrdrNumber("RA97939");
		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(30005737)).thenReturn(orderDetails);
		Mockito.when(orderLoadRepository.getJobIdbyOrderId(353086)).thenReturn(124578);
		List<Object[]> taskDetails = new ArrayList();
		Object[] subtaskDetails = new Object[10];
		subtaskDetails[7] = 1000;
		subtaskDetails[8] = 1000;
		taskDetails.add(subtaskDetails);
		Mockito.when(taskRepository.getStopSeqForTerminateCheckCall(Mockito.any(),Mockito.any())).thenReturn(34);
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh("RA97939")).thenReturn(taskDetails);
		Mockito.when(equipmentRepository.getEquipmentUntiId(353086)).thenReturn("353086");
		Mockito.when(orderLoadRepository.getJobIdbyOrderId(353086)).thenReturn(12456);
		Mockito.when(equipmentRepository.getLastLocationOfTruck(353086)).thenReturn("353086");

		wireMockServer.stubFor(WireMock
				.get(WireMock.urlPathEqualTo("/masterdatalocationservices/locations/search/findbylocation/1"))
				.willReturn(WireMock.aResponse().withHeader("Content-Type", "application/json").withBody(
						"{ \"locationProfileDTO\": { \"id\": 10868, \"facilityOperationDTO\": [], \"facilityOverviewRequirementCodeDTO\": [], \"contactDTO\": [], \"addressDTO\": { \"id\": 235523, \"addressLine1\": \"1874 Iron Bridge Rd\", \"addressLine2\": \"\", \"state\": \"KY\", \"city\": \"Bowling Green\", \"cityAliasName\": \"Bowling Green\", \"zipcode\": \"421039757\", \"country\": \"USA\", \"countyName\": \"Warren\", \"latitude\": 36.937973, \"longitude\": -86.254737 }, \"hazmatDTO\": null, \"disallowedEquipmentDTO\": [], \"customerDirections\": null, \"generalInstructions\": null, \"locationCode\": \"IRBO18\", \"locationName\": \"Iron Bridge SOD\" }, \"timezone\": \"America/Chicago\" }")
						.withStatus(200)));

		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
		// mockEndpoint.assertIsSatisfied();

	}

	public void testSendPlanCancellOrAssign(String filePathJson) throws Exception {

		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[7885243]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(filePathJson)), OperationalPlanEvent.class);

		TOrder orderDetails = new TOrder();
		// orderDetails.setLastOrderNumber("RA97939");
		orderDetails.setLastUpdateTimeStamp("2019-01-02 10.00.06");
		orderDetails.setOrderId(123456789);
		orderDetails.setOrdrNumber("RA97939");

		// Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(30013190).

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(1010479)).thenReturn(orderDetails);

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderIDWarehouse(1010479)).thenReturn(orderDetails);

		Mockito.when(taskRepository.findLastUpdatedTimeStampBytaskId(123456789)).thenReturn("2019-01-02 10.00.06");

		Lmc341OutputArea output1 = new Lmc341OutputArea();
		output1.setLmc341ErrorMessage("Mock");
		output1.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output1);
		Wo42ComReturnToJava output2 = new Wo42ComReturnToJava();
		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ErrorKey1("");
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		Wo42ErrorVariables.setWo42Message("");
		Wo42ErrorVariables.setWo42CicsReturnCode(399);
		Wo42ErrorVariables.setWo42ErrorKey2("");

		output2.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output2);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

}
