package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "TTASK", schema = "ALI")
public class TTask implements Serializable {

	   
	
 

	/**
	 * 
	 */
	private static final long serialVersionUID = -94711401017374838L;

	@Id
    @Column(name = "TASK_ID")
    private Integer taskID;
    
    @Column(name="LST_UPDT_TMSTP_S")
    private Timestamp lastUpdatedTimeStamp;

	@Column(name = "REQ_TYP_C")
	private String reqTypC;
	
	@Column(name = "UTL_STT_C")
	private String utlSttC;
	
	@Column(name = "FLT_C")
	private String fltC;
	
	@Column(name = "PROG_STT_C")
	private String progSttC;
	
	@Column(name = "DIV_ID")
	private String divId;
    
}