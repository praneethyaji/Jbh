package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OperActPay;

@Repository
public interface OperationalActPayRepository extends JpaRepository<OperActPay, Integer> {

	@Query(value = "SELECT SEQ_NO_N,ACT_TYP, ORD_I, JOB_ID, OPR_POS, RAT_A, SRCE_ID, SRC_NM FROM ALI.OPR_ACT_PAY WHERE ORD_I = (:orderId) AND SRCE_ID  = (:srcId) AND JOB_ID = (:jobId) AND SRC_NM  = 'RSCCMNLOG' WITH UR", nativeQuery = true)
	List<OperActPay> findBySrcId(@Param("orderId") Integer orderId, @Param("srcId") Integer srcId,
			@Param("jobId") Integer jobId);

}
