package com.jbhunt.loadplannig.integration.backfill.next.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jbhunt.infrastructure.exception.JBHValidationException;
import com.jbhunt.loadplannig.integration.backfill.constants.SQLQueryConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.LegacyOrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplannig.integration.backfill.utils.CommonUtils;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
@AllArgsConstructor
public class LegacyOrderOperationalPlanAssociationRepository {

	private final JdbcTemplate sqlServerjdbcTemplate;

	public void saveLegacyOrderOperationalPlanAssociationDetails(OperationalPlanDTO operationalPlanDTO,
			Integer oldOrderId, String orderNumber) {
		String currentDateAndTime = CommonUtils.convertToDatabaseColumn(LocalDateTime.now());
		sqlServerjdbcTemplate.update(
				"INSERT INTO BKFIL.LegacyOrderOperationalPlanAssociation (LegacyOrderID, LegacyOrderNumber, OperationalPlanID, CreateTimestamp,\r\n"
						+ " CreateUserID, CreateProgramName, LastUpdateTimestamp, LastUpdateUserID, LastUpdateProgramName) \r\n"
						+ " VALUES  (?,?,?,?,?,?,?,?,?)",
				oldOrderId, orderNumber, operationalPlanDTO.getOperationalPlanId(), currentDateAndTime,
				operationalPlanDTO.getCreateUserId(), operationalPlanDTO.getCreateProgramName(), currentDateAndTime,
				operationalPlanDTO.getLastUpdateUserId(), operationalPlanDTO.getLastUpdateProgramName());
	}

	public void updateLegacyOrderOperationalPlanAssociationDetails(OperationalPlanDTO operationalPlanDTO,
			Integer oldOrderId, String orderNumber, Integer dispatchNumber) {
		String currentDateAndTime = CommonUtils.convertToDatabaseColumn(LocalDateTime.now());
		sqlServerjdbcTemplate.update(
				"UPDATE BKFIL.LegacyOrderOperationalPlanAssociation SET LegacyDispatchNumber =?,"
						+ "  LastUpdateTimestamp=?, LastUpdateUserID=?, LastUpdateProgramName=? "
						+ " WHERE LegacyOrderID=? AND LegacyOrderNumber=? AND OperationalPlanID=?  ",
				dispatchNumber, currentDateAndTime, operationalPlanDTO.getLastUpdateUserId(),
				operationalPlanDTO.getLastUpdateProgramName(), oldOrderId, orderNumber,
				operationalPlanDTO.getOperationalPlanId());
	}

	public void updateLegacyOrderOperationalPlanAssociation(Integer LegacyJobID, Integer LegacyResourceReservationID,
			Integer LegacyOrderID) {
		sqlServerjdbcTemplate.update(
				"UPDATE BKFIL.LegacyOrderOperationalPlanAssociation  SET LegacyJobID=?,LegacyResourceReservationID=? WHERE LegacyOrderID=?",
				LegacyJobID, LegacyResourceReservationID, LegacyOrderID);
		/*
		 * UPDATE BKFIL.BackFillEventTracking SET EventStatus=?, EventMessageText=?,
		 * LastUpdateTimestamp=?, LastUpdateUserID=?, LastUpdateProgramName=? " +
		 * " WHERE NextOrderID=? AND NextOrderTrackingNumber=? AND NextOperationalPlanID=? AND NextOperationalPlanNumber=? "
		 */

	}

	public LegacyOrderOperationalPlanAssociationDTO getLegacyOrderDetails(final Integer opertionalPlanId) {
		try {
			return sqlServerjdbcTemplate.queryForObject(SQLQueryConstants.GET_LEGACYORDER_DETAILS_BY_OPERATIONALPLAN_ID,
					new Object[] { opertionalPlanId }, new RowMapper<LegacyOrderOperationalPlanAssociationDTO>() {
						@Override
						public LegacyOrderOperationalPlanAssociationDTO mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return formLegacyOrderAssociationDTO(rs);
						}
					});
		} catch (EmptyResultDataAccessException ex) {
			log.error("No Legacy Details found for given OpertionalPlanId: {}", opertionalPlanId);
			log.error(ex.getMessage());
			return null;
		}
	}

	public List<LegacyOrderOperationalPlanAssociationDTO> getOperationalPlansByOrderId(final Integer legacyOrderId)
			throws JBHValidationException {
		List<LegacyOrderOperationalPlanAssociationDTO> associationList = new ArrayList<>();
		try {
			associationList = sqlServerjdbcTemplate.query(SQLQueryConstants.GET_OPERATIONAL_PLAN_IDS,
					new Object[] { legacyOrderId }, new RowMapper<LegacyOrderOperationalPlanAssociationDTO>() {
						@Override
						public LegacyOrderOperationalPlanAssociationDTO mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return formLegacyOrderAssociationDTO(rs);
						}
					});
		} catch (EmptyResultDataAccessException e) {
			log.error("No Legacy Details found for given LegacyOrderId: {}", legacyOrderId);
			throw new JBHValidationException("No Legacy Details Found");
		}
		return associationList;
	}

	public Integer getOperationalPlanId(final Integer legacyOrderId, final Integer legacyJobId,
			final Integer legacyResourceReservationId) throws JBHValidationException {
		Integer operationalPlanId = null;
		try {
			operationalPlanId = (Integer) sqlServerjdbcTemplate.queryForObject(
					SQLQueryConstants.GET_OPERATIONAL_PLAN_ID,
					new Object[] { legacyOrderId, legacyJobId, legacyResourceReservationId }, Integer.class);
		} catch (EmptyResultDataAccessException e) {
			log.error(
					"No OperationalPlanId Found for given LegacyOrderId: {}, LegacyJobId: {} and LegacyResourceReservationId:{}",
					legacyOrderId, legacyJobId, legacyResourceReservationId);
			throw new JBHValidationException("No Legacy Details Found");
		}
		return operationalPlanId;
	}

	public Integer getOperationalPlanIdByJobId(final Integer legacyOrderId, final Integer legacyJobId)
			throws JBHValidationException {
		Integer operationalPlanId = null;
		try {
			operationalPlanId = (Integer) sqlServerjdbcTemplate.queryForObject(
					SQLQueryConstants.GET_OPERATIONAL_PLAN_ID_BY_JOB_ID, new Object[] { legacyOrderId, legacyJobId },
					Integer.class);
		} catch (EmptyResultDataAccessException e) {
			log.error("No OperationalPlanId Found for given LegacyOrderId: {} and LegacyJobId : {}", legacyOrderId,
					legacyJobId);
			throw new JBHValidationException("No Legacy Details Found");
		}
		return operationalPlanId;
	}

	public Integer getOperationalPlanIdByReservationId(final Integer legacyOrderId,
			final Integer legacyResourceReservationId) throws JBHValidationException {
		Integer operationalPlanId = null;
		try {
			operationalPlanId = (Integer) sqlServerjdbcTemplate.queryForObject(
					SQLQueryConstants.GET_OPERATIONAL_PLAN_ID_BY_RESERVATION_ID,
					new Object[] { legacyOrderId, legacyResourceReservationId }, Integer.class);
		} catch (EmptyResultDataAccessException e) {
			log.error("No OperationalPlanId Found for given LegacyOrderId: {} and LegacyResourceReservationId: {}",
					legacyOrderId, legacyResourceReservationId);
			throw new JBHValidationException("No Legacy Details Found");
		}
		return operationalPlanId;
	}

	private LegacyOrderOperationalPlanAssociationDTO formLegacyOrderAssociationDTO(ResultSet rs) throws SQLException {
		LegacyOrderOperationalPlanAssociationDTO legacyOrderOperationalPlanAssociationDTO = new LegacyOrderOperationalPlanAssociationDTO();
		legacyOrderOperationalPlanAssociationDTO
				.setLegacyOrderOperationalPlanAssociationId(rs.getInt("legacyOrderOperationalPlanAssociationId"));
		legacyOrderOperationalPlanAssociationDTO.setLegacyOrderId(rs.getInt("legacyOrderId"));
		legacyOrderOperationalPlanAssociationDTO.setLegacyJobId((Integer) rs.getObject("legacyJobId"));
		legacyOrderOperationalPlanAssociationDTO
				.setLegacyResourceReservationId((Integer) rs.getObject(("legacyResourceReservationId")));
		legacyOrderOperationalPlanAssociationDTO
				.setLegacyCarrierReservationId((Integer) rs.getObject("legacyCarrierReservationId"));
		legacyOrderOperationalPlanAssociationDTO.setLegacyDispatchNumber((Short) rs.getObject("legacyDispatchNumber"));
		legacyOrderOperationalPlanAssociationDTO.setLegacyOrderNumber(rs.getString("legacyOrderNumber"));
		legacyOrderOperationalPlanAssociationDTO.setOperationalPlanId(rs.getInt("operationalPlanId"));
		legacyOrderOperationalPlanAssociationDTO.setCreateTimestamp(rs.getString("createTimestamp"));
		legacyOrderOperationalPlanAssociationDTO.setCreateUserID(rs.getString("createUserID"));
		legacyOrderOperationalPlanAssociationDTO.setCreateProgramName(rs.getString("createProgramName"));
		legacyOrderOperationalPlanAssociationDTO.setLastUpdateTimestamp(rs.getString("lastUpdateTimestamp"));
		legacyOrderOperationalPlanAssociationDTO.setLastUpdateUserID(rs.getString("lastUpdateUserID"));
		legacyOrderOperationalPlanAssociationDTO.setLastUpdateProgramName(rs.getString("lastUpdateProgramName"));
		return legacyOrderOperationalPlanAssociationDTO;
	}

}
