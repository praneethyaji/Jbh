package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jbhunt.loadplannig.integration.backfill.dto.CheckCallLoadedUnloadedDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class LoadedCheckCallJDBCRepository {

	LoadedCheckCallJDBCRepository(@Qualifier("dataSourceDB2") JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private final JdbcTemplate jdbcTemplate;
	
	public void updateTActivity(final String startDate, final String startHour,
			final String completedDate, final String completedHour, final Integer subTaskId) {

		final String query = "UPDATE ALI.TACTIVITY A SET A.ACL_STRT_D = ?, A.ACL_CMP_D = ?, A.ACL_STRT_H = ?, A.ACL_CMP_H = ? WHERE A.SRCE_ID = ? AND A.ATY_TY_ID != 'ARRIVE'";
		jdbcTemplate.update(query, startDate, completedDate, startHour, completedHour, subTaskId);
	}
	
	public void updateDepatureOnTActivity(final String startDate, final String startHour,
			final String completedDate, final String completedHour, final Integer subTaskId) {

		final String query = "UPDATE ALI.TACTIVITY A SET A.ACL_STRT_D = ?, A.ACL_CMP_D = ?, A.ACL_STRT_H = ?, A.ACL_CMP_H = ? WHERE A.SRCE_ID = ? AND A.ATY_TY_ID = 'DEPART'";
		jdbcTemplate.update(query, startDate, completedDate, startHour, completedHour, subTaskId);
	}
	
	public void updateTypeTActivity(final String newType, final String oldType, final Integer subTaskId) {

		final String query = "UPDATE ALI.TACTIVITY A SET A.ATY_TY_ID = ? WHERE A.SRCE_ID = ? AND A.ATY_TY_ID = ?";
		jdbcTemplate.update(query, newType, subTaskId, oldType);
	}

	/**
	 * @param referenceNumber
	 * @param orderId
	 */
	public void updateTOrderRefereceNumber(final String referenceNumberValue, final Integer orderId, final String referenceNumberTypeCode, final Integer sequenceNumber) {
		final String query = "UPDATE ALI.TORD_REF_NBR T SET T.ORD_REF_NBR = ? WHERE T.ORD_I = ? AND T.ORD_REF_NBR_TYP_C = ? AND T.ORD_STP_SEQ_NBR = ?";
		jdbcTemplate.update(query, referenceNumberValue, orderId, referenceNumberTypeCode, sequenceNumber);
	}
	
	public void updateTOrderLineItem(final Integer quanity , final Double weight, final String weightCode, final Double volume, final String volumeCode, 
			final Integer orderId, final Integer stopSequenceNumber, final String type) {
		final String query = "UPDATE ALI.TORD_LN_ITM_ACT T SET T.PCS_Q=?, T.WGT=?, T.WGT_BAS_C=?, T.VOL=?, T.VOL_BAS_C=? WHERE T.ORD_I = ? AND T.OFR_STP_SEQ_NBR = ? AND T.ACT_TYP_C = ?";
		jdbcTemplate.update(query, quanity, weight, weightCode, volume, volumeCode, orderId, stopSequenceNumber, type);
	}
	
	public void updateTypeOnTOrderLineItem(final String newType, final String oldType, final Integer orderId) {
		log.info("Updating TypeChange oldType:{} newType:{} orderId:{}", oldType,newType,orderId);
		final String query = "UPDATE ALI.TORD_LN_ITM_ACT LI SET LI.ACT_TYP_C = ? WHERE LI.ORD_I = ? AND LI.ACT_TYP_C = ?";
		jdbcTemplate.update(query, newType, orderId, oldType);
	}
	
	
	public CheckCallLoadedUnloadedDTO getOrderLineItem(final Integer orderId, final Integer sequenceNumber, final String type, final CheckCallLoadedUnloadedDTO checkCallLoadedUnloadedDTO) {
		log.info("Order Id >>{}", orderId);
		log.info("sequenceNumber >>{}",sequenceNumber);
		log.info("Type >>{}", type);
		log.info("checkCallLoadedUnloadedDTO >>{}", checkCallLoadedUnloadedDTO);
		try {
			final String query = "SELECT T.PCS_Q, T.WGT, T.WGT_BAS_C, T.VOL, T.VOL_BAS_C FROM ALI.TORD_LN_ITM_ACT T WHERE T.ORD_I = ? AND T.OFR_STP_SEQ_NBR = ? AND T.ACT_TYP_C = ?";
			log.info("Query >>{}", query);
			return jdbcTemplate.queryForObject(query,
					new Object[] { orderId, sequenceNumber, type }, new RowMapper<CheckCallLoadedUnloadedDTO>() {
                @Override
                public CheckCallLoadedUnloadedDTO mapRow(ResultSet rs, int rowNum)
                        throws SQLException {
                    return prepareCheckCallLoadedUnloadedDTO(rs, checkCallLoadedUnloadedDTO);
                }
            });
		} catch (EmptyResultDataAccessException ex) {
			log.info("OrderLineItem not found");
			return null;
		}
	}
	
	private CheckCallLoadedUnloadedDTO prepareCheckCallLoadedUnloadedDTO(final ResultSet resultSet,final CheckCallLoadedUnloadedDTO checkCallLoadedUnloadedDTO) {
		try {
			
			log.info("resultSet : {}",resultSet);
		
			if (checkCallLoadedUnloadedDTO.getQuantity() == null) {
				checkCallLoadedUnloadedDTO.setQuantity(resultSet.getInt("PCS_Q"));
			}
			if (checkCallLoadedUnloadedDTO.getWeight() == null) {
				checkCallLoadedUnloadedDTO.setWeight(resultSet.getDouble("WGT"));

			}
			if (checkCallLoadedUnloadedDTO.getVolume() == null) {
				checkCallLoadedUnloadedDTO.setVolume((double) resultSet.getInt("VOL"));

			}
			if (checkCallLoadedUnloadedDTO.getWeightMeasurement() == null) {
				checkCallLoadedUnloadedDTO.setWeightMeasurement(resultSet.getString("WGT_BAS_C"));
			}
			if (checkCallLoadedUnloadedDTO.getVolumeMeasurement() == null) {
				checkCallLoadedUnloadedDTO.setVolumeMeasurement(resultSet.getString("VOL_BAS_C"));
			}
			
		} catch (SQLException ex) {
			log.info("OrderLineItem not found");
		}
		return checkCallLoadedUnloadedDTO;
	}

}
