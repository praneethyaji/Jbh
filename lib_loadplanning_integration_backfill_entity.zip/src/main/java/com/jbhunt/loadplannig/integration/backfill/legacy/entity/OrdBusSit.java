package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "TORD_BUS_SIT", schema = "ALI")
public class OrdBusSit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1222970608274760959L;

	@Id
	@Column(name = "BUS_SIT_I")
	private Integer busSitI;

	@Column(name = "ORD_I")
	private Integer ordI;

	@Column(name = "REC_STT")
	private String recStt;

	@Column(name = "USE_F")
	private String useF;

	@Column(name = "DPT_C")
	private String dptC;

	@Column(name = "OFR_STP_SEQ_NBR")
	private Integer ofrStpSeqNbr;

}
