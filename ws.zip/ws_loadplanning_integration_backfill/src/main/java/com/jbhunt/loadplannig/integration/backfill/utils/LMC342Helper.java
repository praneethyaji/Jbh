package com.jbhunt.loadplannig.integration.backfill.utils;

import static com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants.MF_DEFAULT_VAL_STRING;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OperatorRepository;
import com.jbhunt.loadplanning.owo.dto.OperationalWorkOrderDTO;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable.Wo42OrdStopInfo;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@AllArgsConstructor
public class LMC342Helper {

	private final OperatorRepository operatorRepository;

	public List<Wo42OrdStopInfo> populateStopDetails(List<TSubtask1> subTaskList) {
		List<Wo42OrdStopInfo> listOfStopDetails = new ArrayList<>();
		for (TSubtask1 subTask : subTaskList) {
			Wo42OrdStopInfo stopDetails = new Wo42OrdStopInfo();
			stopDetails.setWo42StpAptD(" "); //use constants
			stopDetails.setWo42StpAptH1(" ");
			stopDetails.setWo42StpAptH2(" ");
			stopDetails.setWo42StpBsstI(subTask.getBusinessId());
			String cityId = subTask.getCityId().substring(2) + subTask.getCityId().substring(0, 2);
			stopDetails.setWo42StpCity(cityId.replaceAll("\\s+", ""));
			stopDetails.setWo42StpCusC(" ");
			stopDetails.setWo42StpPrfSeqN(subTask.getPreferanceSequenceNumber());
			stopDetails.setWo42StpReqTy(subTask.getRequestTyId());
			stopDetails.setWo42StpSegMil(0);
			stopDetails.setWo42StpStskI(subTask.getSubTaskID());
			listOfStopDetails.add(stopDetails);
		}
		return listOfStopDetails;
	}

	public Wo42OrdDtlTable populateOrdDtlTable(String operation, List<Wo42OrdStopInfo> stoInfoList,
			BkfilOwoJaAscResponse bkfilOwoJaAscResponse, String timestampOfTask,
			OperationalWorkOrderDTO operationalWorkOrderDTO) {

		Wo42OrdDtlTable ordDtlTable = new Wo42OrdDtlTable();
		ordDtlTable.setFiller1(" ");
		log.info("action flag " + operation);
		ordDtlTable.setWo42OrdAction(operation);
		ordDtlTable.setWo42OrdDivId(" ");
		ordDtlTable.setWo42OrdEtaChgSw("N");
		ordDtlTable.setWo42OrdEtaDate("2019-01-23");
		ordDtlTable.setWo42OrdEtaTime("06.52.00");
		ordDtlTable.setWo42OrdEtcChgSw("N");
		ordDtlTable.setWo42OrdEtcDate(" ");
		ordDtlTable.setWo42OrdEtcTime(" ");
		ordDtlTable.setWo42OrdNbrStops(stoInfoList.size());
		ordDtlTable.setWo42OrdOpzAction(" ");
		ordDtlTable.setWo42OrdOpzGroup(" ");
		ordDtlTable.setWo42OrdOpzLdRslI(0);
		ordDtlTable.setWo42OrdOpzOrdPnlVal(0);
		ordDtlTable.setWo42OrdOrdI(bkfilOwoJaAscResponse.getOrdI());
		ordDtlTable.setWo42OrdOrdLstUpdS(Optional.ofNullable(timestampOfTask).orElse(" "));
		ordDtlTable.setWo42OrdOrdNbr(bkfilOwoJaAscResponse.getOrdNbrch());
		ordDtlTable.setWo42NextLdI(0);
		ordDtlTable.setWo42NextLdNum(MF_DEFAULT_VAL_STRING);
		ordDtlTable.setWo42NextOrdI(operationalWorkOrderDTO.getOperationalWorkOrderID());

		ordDtlTable.setWo42OrdOrdPpSw("N");
		ordDtlTable.setWo42OrdPkupDelvSw(" ");
		ordDtlTable.setWo42OrdProgSttC(" ");
		ordDtlTable.setWo42OrdReqTyC(" ");
		ordDtlTable.setWo42OrdResvLstUpdS(" ");
		ordDtlTable.setWo42OrdSegFppInd(" ");
		ordDtlTable.setWo42OrdSeqNbr(1);
		ordDtlTable.getWo42OrdStopInfo().addAll(stoInfoList);
		ordDtlTable.setWo42OrdTaskLstUpdS(Optional.ofNullable(timestampOfTask).orElse(" "));
		ordDtlTable.setWo42OrdTcallAptD(" ");
		ordDtlTable.setWo42OrdTcallAptH(" ");
		ordDtlTable.setWo42OrdTcallCtyC(" ");
		ordDtlTable.setWo42OrdTcallLoc(" ");
		ordDtlTable.setWo42OrdTcallMiles(0);
		ordDtlTable.setWo42OrdTourCnt(0);
		ordDtlTable.setWo42OrdTourI(0);
		ordDtlTable.setWo42OrdTpndLstUpdS(" ");
		ordDtlTable.setWo42OrdTranMode(" ");
		ordDtlTable.setWo42OrdTransferSw(" ");
		return ordDtlTable;
	}

	public Wo42ComRequiredData populateWo42ComJavaSentVariables(List<Wo42OrdDtlTable> ordDtlTableList,
			EquipmentResponse equipResponse, String userId) {

		String driverName = " ";
		Wo42ComRequiredData requiredData = new Wo42ComRequiredData();
		requiredData.setWo42ActionSw(CommonConstants.TRACTOR_PREPLAN_ACTION);
		requiredData.setWo42CallingPgm(CommonConstants.TRACTOR_PRG_CALLING);
		requiredData.setWo42DspEtaChgSw(" ");
		requiredData.setWo42DspEtaDate("          ");
		requiredData.setWo42DspEtaTime("        ");
		requiredData.setWo42DspOrdI(0);
		requiredData.setWo42DspOrdNbr("       ");
		requiredData.setWo42FirstXfrOrdI(0);
		log.info("NumberOf orders  " + ordDtlTableList.size());
		requiredData.setWo42OrdDtlCnt(ordDtlTableList.size());
		requiredData.getWo42OrdDtlTable().addAll(ordDtlTableList);
		driverName = getDriverDetailsByEqpId(equipResponse.getEquipmentId());
		requiredData.setWo42TpndMaxLstUpdS(" ");
		requiredData.setWo42TractorDriver(driverName);
		requiredData.setWo42TourF("N");
		requiredData.setWo42TractorEqpI(equipResponse.getEquipmentId());
		requiredData.setWo42TractorNbr(equipResponse.getEquipmentNumber());
		requiredData.setWo42Userid(userId);
		requiredData.setWo42XfrDspNbr(0);
		requiredData.setWo42XfrFuelChg(0);
		requiredData.setWo42XfrStopoffChg(0000000000);
		requiredData.setWo42XfrTransitChg(0);
		return requiredData;
	}

	public String getDriverDetailsByEqpId(int eqpId) {
		return operatorRepository.getDriverDetailsByEqpId(eqpId).stream().findFirst().
				map(objects -> StringUtils.trim((String) objects[0])).orElse(" ");
	}

}
