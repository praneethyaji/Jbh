package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.ResourceCommunicationLog;

@Repository
public interface CallHistoryRespository extends JpaRepository<ResourceCommunicationLog, Integer> {

	@Query(value = "SELECT A.RSC_CMN_LOG_I, A.LGC_CLL_SEQ_NBR, A.JOB_I, A.ORD_I, A.CLL_TKR_INI, A.OPR_C_1, A.USR_SGN_ON_C, A.LST_UPD_UID, A.SRC_NM, A.CLL_SUB_TYP,A.CLL_SEQ_NBR  FROM  ALI.RSC_CMN_LOG A, ALI.TDSP_JOB_XRF B WHERE A.ORD_I = (:orderId) AND "
			+ "B.DSP_NBR = (:dispatchNumber) AND A.SRC_NM IN ('TSUBTASK','TJOB') AND A.ORD_I   = B.ORD_I AND A.JOB_I   = B.JOB_I ORDER BY A.CLL_SEQ_NBR DESC WITH UR", nativeQuery = true)
	List<ResourceCommunicationLog> getCallHistory(@Param("orderId") int orderId,
			@Param("dispatchNumber") short dispatchNumber);

}
