package com.jbhunt.loadplannig.integration.backfill.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.BkfilOrdLdAsc;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.*;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.services.*;
import com.jbhunt.loadplanning.operationalplan.dto.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.lmc363i.lmc363.LMC363Port;
import com.request.lmc363i.lmc363.ProgramInterface;
import org.apache.commons.io.IOUtils;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.SocketUtils;

import javax.xml.ws.Holder;
import java.io.IOException;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class LoadplanningIntegrationbackfillServiceIT {

    public static WireMockServer wireMockServer;

    @MockBean
    private BkfilOrdLdAscRepository bkfilOrdLdAscRepository;

    @Autowired
    private LoadplanningIntegrationbackfillService loadplanningIntegrationbackfillService;

    @Autowired
    private ArrivalCheckcallService  arrivalCheckcallService;

    @Autowired
    private LoadedCheckcallService loadedCheckcallService;

    @Autowired
    private UnloadedCheckcallService unloadedCheckcallService;

    @Autowired
    private OperationalPlanBackfillService operationalPlanBackfillService;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private EquipmentRepository equipmentRepository;

    @MockBean
    private OrderLoadRepository orderLoadRepository;

    @MockBean
    private BackFillEventTrackingRepository backFillEventTrackingRepository;

    @MockBean
    private SubTaskRepository subTaskRepository;

    public final String OPERATIONAL_PLAN_JSON_PATH = "/operationalplan.json";
    
    public final String OPERATIONAL_PLAN_WORK_ORDER_JSON_PATH = "/operationalplan_workOrder.json";

    public final String OPERATIONAL_PLAN_ARRIVAL_CHECKCALL_PATH = "/json/ArrivalCheckCall.json";

    public final String OPERATIONAL_PLAN_LOADED_CHECKCALL_PATH = "/json/LoadedCheckCall.json";

    public final String OPERATIONAL_PLAN_UNLOADED_CHECKCALL_PATH = "/json/UnloadedCheckCall.json";

    public final String OPERATIONAL_PLAN_ARRIVAL_UNLOADED_CHECKCALL_PATH = "/json/ArrivalUnloadedCheckCall.json";

    public final String OPERATIONAL_PLAN_ARRIVAL_LOADED_CHECKCALL_PATH = "/json/ArrivalLoadedCheckCall.json";

    public final String OPERATIONAL_PLAN_LOADED_STOP_NOT_FOUND_CHECKCALL_PATH= "/json/LoadedCheckCallStopNotFound.json";

    public final String OPERATIONAL_PLAN_UNLOADED_STOP_NOT_FOUND_CHECKCALL_PATH= "/json/UnloadedCheckCallStopNotFound.json";

    public final String OPERATIONAL_PLAN_ARRIVAL_STOP_NOT_FOUND_CHECKCALL_PATH= "/json/ArrivalCheckCallStopNotFound.json";

    public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

    public static final String userName = "user";

    public static final String password = "pass";

    protected RequestSpecification requestSpecification;

    @MockBean
    private LMC363Port lMC363Port;

    @BeforeClass
    public static void beforeClass() throws IOException {
        MockJBHSecurity.initialize();
        System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
        System.setProperty("DOMAIN_PID", "");
        System.setProperty("DOMAIN_PASSWORD", "");
        System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
        System.setProperty("runtime.environment", "QA");
        wireMockServer = new WireMockServer(WIREMOCK_PORT);
        wireMockServer.start();
    }

    @Test(expected = RuntimeException.class)
    public void backfillTranckingTest() throws Exception{
        Mockito.when(bkfilOrdLdAscRepository.save(Mockito.any(BkfilOrdLdAsc.class))).thenThrow(new RuntimeException("exception:"+getError()));
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_JSON_PATH)),
                OperationalPlanEvent.class);
        loadplanningIntegrationbackfillService.loadCreate(operationalPlanEvent);
    }
    
    @Test(expected = RuntimeException.class)
    public void backfillTranckingTestForWorkOrder() throws Exception{
        Mockito.when(bkfilOrdLdAscRepository.save(Mockito.any(BkfilOrdLdAsc.class))).thenThrow(new RuntimeException("exception:"+getError()));
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_WORK_ORDER_JSON_PATH)),
                OperationalPlanEvent.class);
        loadplanningIntegrationbackfillService.loadCreate(operationalPlanEvent);
    }
    @Test
    public void operationalPlanBackfillServiceForArrival() throws Exception{
        testCheckcall();

        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_ARRIVAL_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        arrivalCheckcallService.arrival(operationalPlanEvent.getOperationalPlanDTO());
        Mockito.verify(lMC363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());
    }
    @Test
    public void operationalPlanBackfillServiceForLoaded() throws Exception{
        testCheckcall();

        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_LOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        loadedCheckcallService.loaded(operationalPlanEvent.getOperationalPlanDTO());
        Mockito.verify(lMC363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

    }
    @Test
    public void operationalPlanBackfillServiceForUnloaded() throws Exception{
        testCheckcall();

        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_UNLOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        unloadedCheckcallService.unloaded(operationalPlanEvent.getOperationalPlanDTO());
        Mockito.verify(lMC363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

    }

    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForArrivalNoEquipments() throws Exception{
        testCheckcall();
        TEquipment tEquipment =null;
        when(equipmentRepository.fetchEqpDetailsByEqpId("12774949")).thenReturn(tEquipment);
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_ARRIVAL_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        arrivalCheckcallService.arrival(operationalPlanEvent.getOperationalPlanDTO());
    }
    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForLoadedNoEquipments() throws Exception{
        testCheckcall();
        TEquipment tEquipment =null;
        when(equipmentRepository.fetchEqpDetailsByEqpId("12774949")).thenReturn(tEquipment);
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_LOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        loadedCheckcallService.loaded(operationalPlanEvent.getOperationalPlanDTO());

    }
    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForUnloadedNoEquipments() throws Exception{
        testCheckcall();
        TEquipment tEquipment = null;
        when(equipmentRepository.fetchEqpDetailsByEqpId("12774949")).thenReturn(tEquipment);
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_UNLOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        unloadedCheckcallService.unloaded(operationalPlanEvent.getOperationalPlanDTO());

    }


    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForArrivalNoEquipmentsFromMasterData() throws Exception{
        testCheckcall();
        String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/EquipmentDetailsNoResponse.json"));
        wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
                .withRequestBody(WireMock.equalTo("[193764]"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_ARRIVAL_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        arrivalCheckcallService.arrival(operationalPlanEvent.getOperationalPlanDTO());
    }
    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForLoadedNoEquipmentsFromMasterData() throws Exception{
        testCheckcall();
        String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/EquipmentDetailsNoResponse.json"));
        wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
                .withRequestBody(WireMock.equalTo("[193764]"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_LOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        loadedCheckcallService.loaded(operationalPlanEvent.getOperationalPlanDTO());

    }
    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForUnloadedNoEquipmentsFromMasterData() throws Exception{
        testCheckcall();
        String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/EquipmentDetailsNoResponse.json"));
        wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
                .withRequestBody(WireMock.equalTo("[193764]"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_UNLOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        unloadedCheckcallService.unloaded(operationalPlanEvent.getOperationalPlanDTO());

    }
    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForArrivallFindByLocation() throws Exception{
        testCheckcall();
        String responseMasterDataLocation = IOUtils.toString(this.getClass().getResourceAsStream("/json/locationProfileEmpty.json"));
        wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/26551")).
                willReturn(aResponse()
                        .withHeader("Content-type","application/json").withBody(responseMasterDataLocation).withStatus(200)));
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_ARRIVAL_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        arrivalCheckcallService.arrival(operationalPlanEvent.getOperationalPlanDTO());

    }
    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForUnloadedNoLocation() throws Exception{
        testCheckcall();
        when(subTaskRepository.getLocationForArrivalUnloaded(Long.valueOf(20012455) , 99003)).thenReturn(null);
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_UNLOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        unloadedCheckcallService.unloaded(operationalPlanEvent.getOperationalPlanDTO());

    }

    @Test()
    public void operationalPlanBackfillServiceForArrivalNoJobIdNoStopId() throws Exception{
        testCheckcall();
        Integer[][] jobIdAndstopSequenceNumbersArray={};
        when(subTaskRepository.getStopSeqNumberByOrderId(20012455)).thenReturn(jobIdAndstopSequenceNumbersArray);
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_ARRIVAL_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        when (subTaskRepository.getLocationForArrivalUnloaded(20012455l,0)).thenReturn("ARSS");

        arrivalCheckcallService.arrival(operationalPlanEvent.getOperationalPlanDTO());
        Mockito.verify(lMC363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());
    }
    @Test()
    public void operationalPlanBackfillServiceForLoadedNoJobIdNoStopId() throws Exception{
        testCheckcall();
        Integer[][] jobIdAndstopSequenceNumbersArray={};
        when(subTaskRepository.getStopSeqNumberByOrderId(20012455)).thenReturn(jobIdAndstopSequenceNumbersArray);
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_LOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        loadedCheckcallService.loaded(operationalPlanEvent.getOperationalPlanDTO());
        Mockito.verify(lMC363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());
    }
    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForUnloadedNoJobIdNoStopId() throws Exception{
        testCheckcall();
        Integer[][] jobIdAndstopSequenceNumbersArray={};
        when(subTaskRepository.getStopSeqNumberByOrderId(20012455)).thenReturn(jobIdAndstopSequenceNumbersArray);
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_UNLOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        unloadedCheckcallService.unloaded(operationalPlanEvent.getOperationalPlanDTO());
    }
    @Test()
    public void operationalPlanBackfillServiceForArrivalNoOrder() throws Exception{
        testCheckcall();
        TOrder tOrder = new TOrder();
        tOrder.setOrderId(20012455);
        tOrder.setOrdrNumber("RC45013");
        tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

        when(orderLoadRepository.findLoadDetailsByOrderIDWarehouse(20012455)).thenReturn(tOrder);
        when(orderLoadRepository.findLoadDetailsByOrderID(20012455)).thenReturn(null);;
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_ARRIVAL_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        arrivalCheckcallService.arrival(operationalPlanEvent.getOperationalPlanDTO());
        Mockito.verify(lMC363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());
    }
    @Test()
    public void operationalPlanBackfillServiceForLoadedNoOrder() throws Exception{
        testCheckcall();
        TOrder tOrder = new TOrder();
        tOrder.setOrderId(20012455);
        tOrder.setOrdrNumber("RC45013");
        tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

        when(orderLoadRepository.findLoadDetailsByOrderIDWarehouse(20012455)).thenReturn(tOrder);
        when(orderLoadRepository.findLoadDetailsByOrderID(20012455)).thenReturn(null);;
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_LOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        loadedCheckcallService.loaded(operationalPlanEvent.getOperationalPlanDTO());
        Mockito.verify(lMC363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

    }
    @Test()
    public void operationalPlanBackfillServiceForUnloadedNoOrder() throws Exception{
        testCheckcall();
        TOrder tOrder = new TOrder();
        tOrder.setOrderId(20012455);
        tOrder.setOrdrNumber("RC45013");
        tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

        when(orderLoadRepository.findLoadDetailsByOrderIDWarehouse(20012455)).thenReturn(tOrder);
        when(orderLoadRepository.findLoadDetailsByOrderID(20012455)).thenReturn(null);;
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_UNLOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        unloadedCheckcallService.unloaded(operationalPlanEvent.getOperationalPlanDTO());
        Mockito.verify(lMC363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

    }
    @Test(expected = JBHuntRuntimeException.class)
    public void operationalPlanBackfillServiceForUnloadedNoOrderAtAll() throws Exception{
        testCheckcall();

        when(orderLoadRepository.findLoadDetailsByOrderIDWarehouse(20012455)).thenReturn(null);
        when(orderLoadRepository.findLoadDetailsByOrderID(20012455)).thenReturn(null);;
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_UNLOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        unloadedCheckcallService.unloaded(operationalPlanEvent.getOperationalPlanDTO());
        Mockito.verify(lMC363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

    }
    @Test(expected = RuntimeException.class)
    public void operationalPlanBackfillServiceForLoadedNoStopFound() throws Exception{
        testCheckcall();

        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_LOADED_STOP_NOT_FOUND_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        loadedCheckcallService.loaded(operationalPlanEvent.getOperationalPlanDTO());
    }
    @Test(expected = RuntimeException.class)
    public void operationalPlanBackfillServiceForUnloadedNotStopFound() throws Exception{
        testCheckcall();

        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_UNLOADED_STOP_NOT_FOUND_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        unloadedCheckcallService.unloaded(operationalPlanEvent.getOperationalPlanDTO());
    }
    @Test(expected = RuntimeException.class)
    public void operationalPlanBackfillServiceForArrivalNotStopFound() throws Exception{
        testCheckcall();

        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_ARRIVAL_STOP_NOT_FOUND_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        arrivalCheckcallService.arrival(operationalPlanEvent.getOperationalPlanDTO());
    }
    @Test
    public void operationalPlanBackfillServiceForArrivalUnloaded() throws Exception{
        testCheckcall();
        doNothing().when(backFillEventTrackingRepository).saveBackTrackingDetails(Mockito.any(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_ARRIVAL_UNLOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        operationalPlanBackfillService.operationalPlanService(operationalPlanEvent);
        Mockito.verify(lMC363Port,times(2)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());
    }
    @Test
    public void operationalPlanBackfillServiceForArrivalLoaded() throws Exception{
        testCheckcall();
        doNothing().when(backFillEventTrackingRepository).saveBackTrackingDetails(Mockito.any(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_ARRIVAL_LOADED_CHECKCALL_PATH)),
                OperationalPlanEvent.class);
        operationalPlanBackfillService.operationalPlanService(operationalPlanEvent);
        Mockito.verify(lMC363Port,times(2)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

    }
    private String getError(){
        StringBuffer stringBuffer = new StringBuffer();
        for(int i=0 ;i<400;i++){
            stringBuffer.append("test");
        }
        return stringBuffer.toString();
    }

    private void testCheckcall()throws Exception {
        wireMockServer.resetAll();
        MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

        String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/EquipmentDetailsResponse.json"));
        String responseMasterDataLocation = IOUtils.toString(this.getClass().getResourceAsStream("/json/locationProfile.json"));

        wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
                .withRequestBody(WireMock.equalTo("[193764]"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

        wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/26551")).
                willReturn(aResponse()
                        .withHeader("Content-type","application/json").withBody(responseMasterDataLocation).withStatus(200)));

        TEquipment tEquipment = new TEquipment();
        tEquipment.setTrailerNumber("357376");
        tEquipment.setTrailerPrefix("JBHZ");
        tEquipment.setLastLocation("WESOK");
        tEquipment.setEquipmentId(12774949);
        when(equipmentRepository.fetchEqpDetailsByEqpId("12774949")).thenReturn(tEquipment);
        when(equipmentRepository.getLastLocationForLoadedCheckcall("357376")).thenReturn("ABCD");

        TOrder tOrder = new TOrder();
        tOrder.setOrderId(20012455);
        tOrder.setOrdrNumber("RC45013");
        tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

        when(orderLoadRepository.findLoadDetailsByOrderID(20012455)).thenReturn(tOrder);
        Integer[][] jobIdAndstopSequenceNumbersArray={{6682,99003}};
        when(subTaskRepository.getStopSeqNumberByOrderId(20012455)).thenReturn(jobIdAndstopSequenceNumbersArray);
        when(subTaskRepository.getLocationForArrivalUnloaded(Long.valueOf(20012455) , 99003)).thenReturn("9999");
    }
}
