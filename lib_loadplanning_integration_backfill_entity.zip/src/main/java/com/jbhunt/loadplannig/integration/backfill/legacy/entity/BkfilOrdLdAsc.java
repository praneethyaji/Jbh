package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "BKFIL_ORD_LD_ASC", schema = "ALI")
public class BkfilOrdLdAsc implements Serializable{
	
	private static final long serialVersionUID = 7096418563237813479L;

	@Id
	@SequenceGenerator(name="my_seq",sequenceName="ALI.BKFIL_ORD_LD_ASC_SEQ")
    @Column(name = "BKFIL_ORD_LD_ASC_I")
	
	@GeneratedValue(generator="my_seq" , strategy=GenerationType.SEQUENCE)
    private Integer bkfilOrdLdAscId;

	@Column(name ="NEXT_ORD_I")
	private Integer nxtOrdId;
	
	@Column(name ="NEXT_ORD_NUM")
	private String nxtOrdNo;
	
	@Column(name ="NEXT_LD_NUM",nullable=false)
	private String nxtLoadNo;
	
	@Column(name ="NEXT_LD_SUB_TYP_C",nullable=false)
	private String nxtLoadSubTypeCode;

	@Column(name ="NEXT_OWO_I")
	private Integer nextOWOId;

	@Column(name ="NEXT_OWO_NUM")
	private String nextOWONum;

	@Column(name ="NEXT_LD_TYP_C", nullable=false)
	private String nextLoadTypeC;
	
	@Column(name ="NEXT_ROUTE_SEQ_NUM",nullable=true)
	private Short nxtRouteSeqNo;
	
	@Column(name ="NEXT_LD_I",nullable=false)
	private Integer nxtLoadId;
	
	@Column(name = "CRT_S",nullable=false)
	private String currTimeStamp;
	
	@Column(name ="CRT_UID",nullable=false)
	private String createdUID;
	
	@Column(name ="CRT_PGM_C",nullable=false)
	private String createdPrgmCode;
	
	@Column(name = "LST_UPD_S",nullable=false)
	private String lastUpdateTimeStamp;
	
	@Column(name ="LST_UPD_UID",nullable=false)
	private String lastUpdatedUID;
	
	@Column(name ="LST_UPD_PGM_C",nullable=false)
	private String lastUpdatedPrgmCode;
	
	

}
