package com.jbhunt.loadplannig.integration.backfill.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class BkfilOrdLdAscDTO implements Serializable{
    
    private static final long serialVersionUID = 4782453199898884091L;

    private Integer bkfilOrdLdAscId;

    private Integer nxtOrdId;
    
    private String nxtOrdNo;
    
    private String nxtLoadNo;
    
    private String nxtLoadSubTypeCode;
    
    private Short nxtRouteSeqNo;
    
    private Integer nxtLoadId;
    
    private String currTimeStamp;
    
    private String createdUID;
    
    private String createdPrgmCode;
    
    private String lastUpdateTimeStamp;
    
    private String lastUpdatedUID;
    
    private String lastUpdatedPrgmCode;
    

}
