package com.jbhunt.loadplannig.integration.backfill.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoadCreatedEvent {

    private String eventSubType;
    private Integer loadID;
    private Integer orderID;
    private String status;
    private String warningMessage;
    private Integer routeId;
    private String routeState;
}