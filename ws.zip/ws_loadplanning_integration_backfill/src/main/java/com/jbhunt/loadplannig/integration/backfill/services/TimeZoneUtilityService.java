package com.jbhunt.loadplannig.integration.backfill.services;

import org.springframework.stereotype.Service;

import com.jbhunt.loadplannig.integration.backfill.dto.LocationTimeZone;
import com.jbhunt.loadplannig.integration.backfill.utils.MasterDataLocationClient;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class TimeZoneUtilityService {

    private static final String DEFAULT_TIMEZONE = "US/Central";
    private final MasterDataLocationClient masterDataLocationClient;

    public String getTimeBasedOnLocation( Integer locationId) {

        LocationTimeZone locationTimeZonetimeZone;

        try {
            locationTimeZonetimeZone = masterDataLocationClient.getLocationTime(locationId);
            log.info("locationTimeZonetimeZone: {}",locationTimeZonetimeZone);
            return locationTimeZonetimeZone.getTimezone();
        } catch (Exception e) {
            log.info("Error occured while retrieving time zone from location service");
        }
        log.info("locationTimeZonetimeZone: DEFAULT_TIMEZONE: {}",DEFAULT_TIMEZONE);
        return DEFAULT_TIMEZONE;

    }
}
