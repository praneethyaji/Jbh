package com.jbhunt.loadplannig.integration.backfill.services;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.LegacyOrderOperationalPlanAssociationRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.SendPlanHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanResourceAssignmentAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.jbhunt.mdm.dto.LocationProfileDTO;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.lmc361i.lmc361.LMC361Port;
import com.request.lmc361i.lmc361.ProgramInterface.Lmc361IRecord;
import com.response.lmc361i.lmc361.ProgramInterface.Lmc361ORecord;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class DispatchLoadPlanService {

	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final LegacyOrderOperationalPlanAssociationRepository legacyOrderOperationalPlanAssociationRepository;
	private final OrderLoadRepository orderLoadRepository;
	private final LMC361Port lMC361Port;
	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;
	private final EquipmentRepository equipmentRepository;
	private final SendPlanHelper sendPlanHelper;
	private final LocationClient locationClient;
	private MasterdataAssetClient masterdataAssetClient;

	public void dispatchLoadPlan(OperationalPlanEvent operationalPlanEvent)
			throws JBHuntRuntimeException, JSONException {

		OperationalPlanDTO operationalPlanDTO = operationalPlanEvent.getOperationalPlanDTO();
		Lmc361IRecord lmc361IRecord = new Lmc361IRecord();
		populateLmc361InputDetails(operationalPlanDTO, lmc361IRecord);
		if (CollectionUtils.isNotEmpty(operationalPlanDTO.getOrderOperationalPlanAssociations())) {
			Stream<OrderOperationalPlanAssociationDTO> operationalPlanList = operationalPlanDTO
					.getOrderOperationalPlanAssociations().stream();
			operationalPlanList.forEach(operationalPlan -> {

				Integer newOrderId = operationalPlan.getOperationalPlanOrder().getOrderId();
				TOrder orderSync = Optional.ofNullable(orderLoadRepository.findLoadDetailsByOrderID(newOrderId))
						.orElseGet(() -> orderLoadRepository.findLoadDetailsByOrderIDWarehouse(newOrderId));
				String oldOrderNumber = Optional.ofNullable(orderSync).map(TOrder::getOrdrNumber)
						.orElse(CommonConstants.EMPTY_SPACE);
				log.info("newOrderId and oldOrderNumber: {} {}", newOrderId,oldOrderNumber);
				lmc361IRecord.setLmc361IOrderNbr(oldOrderNumber);

				Lmc361ORecord lmc361oRecord = lMC361Port.lmc361Operation(lmc361IRecord);

				log.info("out put {} , {} " + lmc361oRecord.getLmc361OReturnCode() + " ==="
						+ lmc361oRecord.getLmc361OIoErrorDesc());
				if (lmc361oRecord.getLmc361OReturnCode() != 0) {
					throw new JBHuntRuntimeException(lmc361oRecord.getLmc361OIoErrorDesc());
				} else {

					Integer lastDispatchNumber = Optional
							.ofNullable(orderLoadRepository.getDispatchNumberByOrderNumber(oldOrderNumber)).orElseGet(
									() -> orderLoadRepository.getDispatchNumberByOrderNumberWarehouse(oldOrderNumber));

					legacyOrderOperationalPlanAssociationRepository.updateLegacyOrderOperationalPlanAssociationDetails(
							operationalPlanDTO, orderSync.getOrderId(), orderSync.getOrdrNumber(),
							Optional.ofNullable(lastDispatchNumber).orElse(0));
				}
			});
		}

		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
	}

	private void populateLmc361InputDetails(OperationalPlanDTO operationalPlanDTO, Lmc361IRecord lmc361IRecord)
			throws JBHuntRuntimeException, JSONException {
		
		EquipmentDetailsDTO equipmentDetailsDTO= getTractorDetails(operationalPlanDTO);
		String tractorNumber = equipmentDetailsDTO.getEquipmentNumber();
		log.info("tractorNumber: {}", tractorNumber);
		lmc361IRecord.setLmc361ITractorNbr(tractorNumber);

		TEquipment equipmentDetails = equipmentRepository.getTrailerDetails(tractorNumber);
		lmc361IRecord.setLmc361ITrailerNbr(Optional.ofNullable(equipmentDetails).map(TEquipment::getTrailerNumber).map(String::trim).
				filter(StringUtils::isNotEmpty).orElse(CommonConstants.EMPTY_SPACE)); 

		OffsetDateTime offsetDateTime = operationalPlanDTO.getOperationalPlanStops().stream().findFirst().
		map(operationalPlanStop->operationalPlanStop.getOperationalPlanStopAppointment().getAppointmentStartTimestamp()).orElse(OffsetDateTime.now());
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMdd");

		lmc361IRecord.setLmc361IEtaYymmdd(Long.parseLong(offsetDateTime.format(formatter)));
		lmc361IRecord.setLmc361IEtaHhmm(Integer.parseInt(
				Integer.toString(offsetDateTime.getHour()) + "" + Integer.toString(offsetDateTime.getMinute())));
		
		Integer cityId = operationalPlanDTO.getOperationalPlanStops().stream().findFirst().map(operationalPlanStop->operationalPlanStop.getCityId()).
				orElse(null);
			
		String cityStateCode = null;
		if (cityId != null) {
			City cityState = loadplanningIntegrationOWObackfillService.getCityStateCodeByCityID(cityId);
			cityStateCode = cityState.getCtyStC();
		} else {
			Integer LocationId = operationalPlanDTO.getOperationalPlanStops().stream().findFirst().map(OperationalPlanStopDTO::getLocationId)
					.orElseThrow(() -> new JBHuntRuntimeException("Operational plan stops not available to get Location Id state"));
			
			String customerCode =  Optional
					.ofNullable(locationClient.findLocationProfilebyLocationCode(LocationId))
					.map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode)
					.orElseThrow(() -> new JBHuntRuntimeException("Location Profile not found."));
			
			cityStateCode = Optional
					.ofNullable(loadplanningIntegrationOWObackfillService.getCityStateForCustomerCode(customerCode))
					.map(String::trim).filter(StringUtils::isNotEmpty).orElse("");
		}

		lmc361IRecord.setLmc361ILocationCityst(cityStateCode);
		lmc361IRecord.setLmc361IOperId("NET");

		lmc361IRecord.setLmc361ITrailerPrefix(Optional.ofNullable(equipmentDetails).map(TEquipment::getTrailerPrefix)
				.map(String::trim).filter(StringUtils::isNotEmpty).orElse(CommonConstants.EMPTY_SPACE));
		
		/*if(operationalPlanDTO.getOperationalPlanResourceAssignmentAssociationList().
				get(0).getResourceAssignmentPlan().getCarrierAssignments()!=null) { Integer
				carrierId =
				operationalPlanDTO.getOperationalPlanResourceAssignmentAssociationList().
				get(0).getResourceAssignmentPlan().getCarrierAssignments().getCarrierId();
				if(carrierId != null && !carrierId.equals(0)) {
				lmc361IRecord.setLmc361IDispatchType("T"); } else { String
				ServiceOfferingCode =
				operationalPlanDTO.getOperationalPlanServiceOfferingCode();
				if(ServiceOfferingCode!=null &&
				ServiceOfferingCode.equalsIgnoreCase("Intermodal")) {
				lmc361IRecord.setLmc361IDispatchType("T"); }else {
				lmc361IRecord.setLmc361IDispatchType("J"); } }*/

		lmc361IRecord.setLmc361IDispatchType(CommonConstants.STRING_J);
		lmc361IRecord.setLmc361ISourceActTyp(CommonConstants.STRING_D);
		lmc361IRecord.setLmc361ISourcePgmId(CommonConstants.PROGRAM_LMC361);
		lmc361IRecord.setLmc361IOverrideErrSw(CommonConstants.STRING_Y);
		lmc361IRecord.setLmc361IErrorLogSw(CommonConstants.STRING_1);
		lmc361IRecord.setLmc361ICallBackDate("0000");
		lmc361IRecord.setLmc361ICallBackTime("0000");

		LocalDateTime dispatchTimeStamp = Optional.ofNullable(operationalPlanDTO.getLastUpdateTimestamp()).orElse(LocalDateTime.now());
		lmc361IRecord.setLmc361IProcessYymmdd(dispatchTimeStamp.format(formatter));
		lmc361IRecord.setLmc361IProcessHhmm(
				Integer.toString(dispatchTimeStamp.getHour()) + "" + Integer.toString(dispatchTimeStamp.getMinute()));
		//TEquipment legacyTruckDetails = equipmentRepository.fetchEqpDetailsByEqpId(Integer.toString(equipmentDetailsDTO.getLegacyEquipmentId()));
		lmc361IRecord.setLmc361IBeginHub(15200);
		lmc361IRecord.setLmc361IUpdateControl(CommonConstants.EMPTY_SPACE);
		
		operationalPlanDTO.getOperationalPlanEquipmentRequirements().stream().findFirst().ifPresent(operationalPlanEquipmentRequirementDTO->{
			lmc361IRecord.setLmc361ICpyTrlrFlag(Optional.ofNullable(operationalPlanEquipmentRequirementDTO.getTrailerPreloadedIndicator()).orElse(CommonConstants.EMPTY_SPACE));
			if(operationalPlanEquipmentRequirementDTO.getTrailingEquipmentId()!=null) {
				EquipmentDetailsDTO trailingEqp=null;
				try {
					trailingEqp = Optional
							.ofNullable(masterdataAssetClient.getEquipmentDetails(
									Arrays.asList(operationalPlanEquipmentRequirementDTO.getTrailingEquipmentId())))
							.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream().findFirst()
							.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));
					
				} catch (Exception e) {
					throw new JBHuntRuntimeException(e);
				}
				lmc361IRecord.setLmc361INoncpyEqpId(Optional.ofNullable(trailingEqp).map(EquipmentDetailsDTO::getLegacyEquipmentId).orElse(CommonConstants.ZERO));
			}
		});

		lmc361IRecord.setLmc361ITriggerPgmId(CommonConstants.PROGRAM_LMC361);
		lmc361IRecord.setLmc361ITriggerUserId(Optional.ofNullable(operationalPlanDTO.getLastUpdateUserId()).orElse(CommonConstants.EMPTY_SPACE));
		lmc361IRecord.setLmc361IDs87RetryCnt((short) CommonConstants.SINGLE_STOP);
		lmc361IRecord.setLmc361IImdMvmI(0);
		lmc361IRecord.setLmc361IProcessType(CommonConstants.STRING_U);

		/*
		 * OperationalPlanStopDTO ooperationalPlanDTO =
		 * Optional.ofNullable(operationalPlanDTO.getOperationalPlanStops() .stream()
		 * .sorted((o1, o2) -> o1.getOperationalPlanStopSequenceNumber()
		 * .compareTo(o2.getOperationalPlanStopSequenceNumber())) .filter(reasonCode ->
		 * reasonCode.getStopReasonCode().equalsIgnoreCase("Delivery")).findFirst().get(
		 * )) .orElse(null);
		 * 
		 */
	}

	private EquipmentDetailsDTO getTractorDetails(OperationalPlanDTO operationalPlanDTO) {
		List<OperationalPlanResourceAssignmentAssociationDTO> operationalPlanResourceAssignmentAssociationList = operationalPlanDTO
				.getOperationalPlanResourceAssignmentAssociationList();

		OperationalPlanResourceAssignmentAssociationDTO resourceAssignmentAssociation = Collections
				.max(operationalPlanResourceAssignmentAssociationList, Comparator.comparing(
						OperationalPlanResourceAssignmentAssociationDTO::getOperationalPlanResourceAssignmentAssociationId));

		EquipmentDetailsDTO eqpDetails = sendPlanHelper
				.populateEquipment(resourceAssignmentAssociation.getResourceAssignmentPlan());

		return eqpDetails;
	}
}
