package com.jbhunt.loadplannig.integration.backfill.utils;

import lombok.Data;

@Data
public class OWOResponse {
	
	private String status = "Fail";
	
	private String message = "Not Created";
	
	

}
