package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "TACTIVITY", schema = "ALI")
public class Activity  implements Serializable {

	private static final long serialVersionUID = -314376979093057191L;

	@Id
	@Column(name = "SRCE_ID")
	private Integer srceId;

	@Column(name = "ATY_TY_ID")
	private String atyTyId;

	@Column(name = "PROG_STT_C")
	private String progSttC;

}
