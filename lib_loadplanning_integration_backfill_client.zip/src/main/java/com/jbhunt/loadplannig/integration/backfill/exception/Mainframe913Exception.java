package com.jbhunt.loadplannig.integration.backfill.exception;

public class Mainframe913Exception extends RuntimeException {
    public Mainframe913Exception(String message){
        super(message);
    }
}
