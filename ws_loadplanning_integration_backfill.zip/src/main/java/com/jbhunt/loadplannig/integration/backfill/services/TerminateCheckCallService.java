package com.jbhunt.loadplannig.integration.backfill.services;

import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.operations.trackandtrace.dto.CheckCallESDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class TerminateCheckCallService {

	private final CheckCallHelpService terminateCallHelper;

	public void createTerminateCheckCall(OperationalPlanDTO operationalPlanDTO) throws JBHuntRuntimeException {
		log.info("terminatecheck call service");
		CheckCallESDTO checkCallESDTO = new CheckCallESDTO();

		terminateCallHelper.prepareLMC363Request(operationalPlanDTO, checkCallESDTO.getLastUpdateUserId(),
				checkCallESDTO.getLastUpdateUserId(), checkCallESDTO.getComment(),
				checkCallESDTO.getOperationalPlanId());
	}
}
