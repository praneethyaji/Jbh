package com.jbhunt.loadplannig.integration.backfill.services;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.json.JSONException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckCallLoadedUnloadedDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.Activity;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOfrStopRqm;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.LoadedCheckCallJDBCRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.SubTaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TActivityRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TOfrStopRqmJDBCRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TOfrStopRqmRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanCheckCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanStopActivityCheckCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.jbhunt.mdm.dto.LocationProfileDTO;
import com.jbhunt.mdm.dto.LocationProfileDTOs;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
@Transactional
public class LoadedUnloadedCheckCallEditService {

	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final TimeZoneUtilityService timeZoneUtilityService;
	private final SubTaskRepository subTaskRepository;
	private final LocationClient locationClient;
	private final OrderLoadRepository orderLoadRepository;
	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;
	private final LoadedCheckCallJDBCRepository loadedCheckCallJDBCRepository;
	private final TOfrStopRqmJDBCRepository tOfrStopRqmJDBCRepository;
	private final TOfrStopRqmRepository tOfrStopRqmRepository;
	private final TActivityRepository activityRepository;
	private EntityManager entityManager;

	public void editLoadedCheckCall(final OperationalPlanDTO operationalPlanDTO) {
		saveBackTrackingDetails(operationalPlanDTO, OperationalPlanEventSubType.LOADED_CHECK_CALL_UPDATED.name());

		OperationalPlanCheckCallDTO operationalPlanCheckCallDTO = operationalPlanDTO.getOperationalPlanCheckCallList()
				.stream()
				.filter(operationalPlanCheckCall -> operationalPlanCheckCall.getCheckCallType().getCheckCallTypeCode()
						.equalsIgnoreCase("Loaded"))
				.findAny().orElseThrow(() -> new JBHuntRuntimeException("Loaded Checkcall not found."));

		editLoadUnloadCheckCall(operationalPlanDTO, operationalPlanCheckCallDTO);
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
	}

	public void editUnLoadedCheckCall(final OperationalPlanDTO operationalPlanDTO) {
		saveBackTrackingDetails(operationalPlanDTO, OperationalPlanEventSubType.UNLOADED_CHECK_CALL_UPDATED.name());

		OperationalPlanCheckCallDTO operationalPlanCheckCallDTO = operationalPlanDTO.getOperationalPlanCheckCallList()
				.stream()
				.filter(operationalPlanCheckCall -> operationalPlanCheckCall.getCheckCallType().getCheckCallTypeCode()
						.equalsIgnoreCase("Unloaded"))
				.findAny().orElseThrow(() -> new JBHuntRuntimeException("Unloaded Checkcall not found."));

		editLoadUnloadCheckCall(operationalPlanDTO, operationalPlanCheckCallDTO);
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
	}

	private void editLoadUnloadCheckCall(final OperationalPlanDTO operationalPlanDTO,
			final OperationalPlanCheckCallDTO operationalPlanCheckCallDTO) {

		CheckCallLoadedUnloadedDTO checkCallLoadedUnloadedDTO = new CheckCallLoadedUnloadedDTO();

		OperationalPlanStopDTO operationalPlanStopDTO = operationalPlanDTO.getOperationalPlanStops().stream()
				.filter(operationalPlanStop -> operationalPlanStop.getOperationalPlanStopId()
						.equals(operationalPlanCheckCallDTO.getOperationalPlanStopId()))
				.findFirst().orElseThrow(() -> new JBHuntRuntimeException(
						"Stop Id " + operationalPlanCheckCallDTO.getOperationalPlanStopId() + " is not found"));

		checkCallLoadedUnloadedDTO.setLocationTimeZone(
				timeZoneUtilityService.getTimeBasedOnLocation(operationalPlanStopDTO.getLocationId()));
		DateTimeFormatter sdfDate = DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT);
		DateTimeFormatter sdfTime = DateTimeFormatter.ofPattern(CommonConstants.TIME_FORMAT);

		ZonedDateTime stopActivityTimestamp = operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall()
				.getStopActivityTimestamp()
				.atZoneSameInstant(ZoneId.of(checkCallLoadedUnloadedDTO.getLocationTimeZone()));

		checkCallLoadedUnloadedDTO.setLoadedDate(stopActivityTimestamp.format(sdfDate));
		checkCallLoadedUnloadedDTO.setLoadedTime(stopActivityTimestamp.format(sdfTime));

		OffsetDateTime departureTimestamp = operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall()
				.getDepartureTimestamp();
		if (departureTimestamp != null) {
			checkCallLoadedUnloadedDTO.setDepartureDate(departureTimestamp.format(sdfDate));
			checkCallLoadedUnloadedDTO.setDepartureTime(departureTimestamp.format(sdfTime));
		}

		String customerCode;

		try {
			customerCode = Optional
					.ofNullable(
							locationClient.findLocationProfilebyLocationCode(operationalPlanStopDTO.getLocationId()))
					.map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode)
					.orElseThrow(() -> new JBHuntRuntimeException("Location Profile not found."));
			log.info("customer code", customerCode);
		} catch (JBHuntRuntimeException | JSONException e) {
			backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
					"");
			throw new JBHuntRuntimeException("Failed due to location service");
		}

		String stateCityCode = Optional
				.ofNullable(loadplanningIntegrationOWObackfillService.getStateCityForCustomerCode(customerCode))
				.map(String::trim).filter(StringUtils::isNotEmpty).orElse("");
		log.info("city state code>>>{}", stateCityCode);

		String loadedUnloadedBy = operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall()
				.getOperationalPlanStopActivityPartyType().getOperationalPlanStopActivityPartyTypeCode();

		operationalPlanStopActivityPartyType(loadedUnloadedBy, checkCallLoadedUnloadedDTO, operationalPlanCheckCallDTO,
				operationalPlanDTO);

		countedByPartyType(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getCountedByPartyType()
				.getCountedByPartyTypeCode(), checkCallLoadedUnloadedDTO, operationalPlanDTO);

		Character hazmatIndicator = operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall()
				.getHazardousMaterialIndicator();
		checkCallLoadedUnloadedDTO.setHazmatIndicator(hazmatIndicator.toString());

		Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall())
				.map(OperationalPlanStopActivityCheckCallDTO::getStopActivityWeight).ifPresent(v -> {
					checkCallLoadedUnloadedDTO.setWeight(operationalPlanCheckCallDTO
							.getOperationalPlanStopActivityCheckCall().getStopActivityWeight().doubleValue());
				});

		Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall())
				.map(OperationalPlanStopActivityCheckCallDTO::getUnitOfWeightMeasurementCode).ifPresent(v -> {
					checkCallLoadedUnloadedDTO.setWeightMeasurement(operationalPlanCheckCallDTO
							.getOperationalPlanStopActivityCheckCall().getUnitOfWeightMeasurementCode().toUpperCase());
				});

		Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall())
				.map(OperationalPlanStopActivityCheckCallDTO::getStopActivityQuantity).ifPresent(v -> {
					checkCallLoadedUnloadedDTO.setQuantity(operationalPlanCheckCallDTO
							.getOperationalPlanStopActivityCheckCall().getStopActivityQuantity());
				});

		Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall())
				.map(OperationalPlanStopActivityCheckCallDTO::getStopActivityVolume).ifPresent(v -> {
					checkCallLoadedUnloadedDTO.setVolume(operationalPlanCheckCallDTO
							.getOperationalPlanStopActivityCheckCall().getStopActivityVolume().doubleValue());
				});

		Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall())
				.map(OperationalPlanStopActivityCheckCallDTO::getUnitOfVolumeMeasurementCode).ifPresent(v -> {
					checkCallLoadedUnloadedDTO.setVolumeMeasurement(operationalPlanCheckCallDTO
							.getOperationalPlanStopActivityCheckCall().getUnitOfVolumeMeasurementCode().toUpperCase());
				});
		final List<OrderOperationalPlanAssociationDTO> orderOperationalPlanAssociations = operationalPlanDTO
				.getOrderOperationalPlanAssociations();

		try {
			saveRepository(orderOperationalPlanAssociations, checkCallLoadedUnloadedDTO, stateCityCode,
					operationalPlanCheckCallDTO, operationalPlanStopDTO.getOperationalPlanStopSequenceNumber());
		} catch (Exception e) {
			log.error("Exception in LoadedUnloadedService:", e);
			updateException(operationalPlanDTO, e);
			throw e;
		}

	}

	private void updateActivityType(final Integer stopId, final String type, final String checkCallType,
			final Integer orderId) {
		entityManager.clear();
		final Activity activity = activityRepository.findBySrceIdAndAtyTyId(stopId, type);
		log.info("STop ID >>{}", stopId);
		log.info("Type >>{}", type);
		log.info("Activity >>{}", activity);
		log.info("CheckCallType >>{}", checkCallType);
		Activity activityDetails = null;
		entityManager.clear();
		if (activity == null) {
			if (type.contains("CNT")) {
				activityDetails = activityRepository.fetchBySrceIdForCount(stopId);
			} else {
				if (checkCallType.equalsIgnoreCase("Unloaded")) {
					activityDetails = activityRepository.fetchBySrceIdForUnload(stopId);
				} else {
					activityDetails = activityRepository.fetchBySrceIdForLoad(stopId);
				}
			}
			log.info("Activity Details >>{}", activityDetails);
			loadedCheckCallJDBCRepository.updateTypeTActivity(type, activityDetails.getAtyTyId(), stopId);
			loadedCheckCallJDBCRepository.updateTypeOnTOrderLineItem(type, activityDetails.getAtyTyId(), orderId);
		}
	}

	private void saveRepository(final List<OrderOperationalPlanAssociationDTO> orderOperationalPlanAssociationDTOlist,
			final CheckCallLoadedUnloadedDTO checkCallLoadedUnloadedDTO, String stateCityCode,
			final OperationalPlanCheckCallDTO operationalPlanCheckCallDTO, final Integer sequenceNumber) {

		orderOperationalPlanAssociationDTOlist.forEach(orderOperationalPlanAssociation -> {

			log.info("orderid :{} ", orderOperationalPlanAssociation.getOperationalPlanOrder().getOrderId());
			Integer newOrderId = orderOperationalPlanAssociation.getOperationalPlanOrder().getOrderId();
			TOrder orderSync = Optional.ofNullable(orderLoadRepository.findLoadDetailsByOrderID(newOrderId))
					.orElseGet(() -> orderLoadRepository.findLoadDetailsByOrderIDWarehouse(newOrderId));
			log.info("order syn:{}", orderSync.getOrderId());

			TSubtask1 tSubtask1 = subTaskRepository.fetchByTaskIdAndCityIdAndRequestTyId(orderSync.getOrderId(),
					stateCityCode, sequenceNumber);
			
			log.info("tSubtask1 >>{}", tSubtask1);
			
			TOfrStopRqm tOfrStopRqm = tOfrStopRqmRepository.findByOrderId(tSubtask1.getTaskId());

			if (checkCallLoadedUnloadedDTO.getHazmatIndicator().equals("Y")) {
				if (tOfrStopRqm == null) {
					log.info("Timestamp >>{}", orderSync.getOrderCreatedTimeStamp());
					try {
						tOfrStopRqmJDBCRepository.inserHazmat(tSubtask1.getTaskId(),
								tSubtask1.getPreferanceSequenceNumber(),
								getTimestamp(orderSync.getOrderCreatedTimeStamp()), orderSync.getOrderCreatedUserId(),
								getTimestamp(orderSync.getOrderCreatedTimeStamp()),
								getTimestamp(CommonConstants.EXPIRATION_TIMESTAMP));
					} catch (ParseException e1) {
						log.info("Timestamp parse Exception:" + e1);
					}
				}

			} else {
				if (tOfrStopRqm != null) {
					tOfrStopRqmJDBCRepository.deleteHazmat(tSubtask1.getTaskId());
				}
			}

			final Integer stopId = tSubtask1.getSubTaskID();
			String type = "";
			final String checkCallType = operationalPlanCheckCallDTO.getCheckCallType().getCheckCallTypeCode();

			if (checkCallType.equalsIgnoreCase("Unloaded")) {
				type = checkCallLoadedUnloadedDTO.getUnLoadedBy();

			} else {
				type = checkCallLoadedUnloadedDTO.getLoadedBy();
			}

			loadedCheckCallJDBCRepository.updateTActivity(checkCallLoadedUnloadedDTO.getLoadedDate(),
					checkCallLoadedUnloadedDTO.getLoadedTime(), checkCallLoadedUnloadedDTO.getLoadedDate(),
					checkCallLoadedUnloadedDTO.getLoadedTime(), tSubtask1.getSubTaskID());
			
			if (checkCallLoadedUnloadedDTO.getDepartureDate() != null
					&& checkCallLoadedUnloadedDTO.getDepartureTime() != null) {
				loadedCheckCallJDBCRepository.updateDepatureOnTActivity(checkCallLoadedUnloadedDTO.getDepartureDate(),
						checkCallLoadedUnloadedDTO.getDepartureTime(), checkCallLoadedUnloadedDTO.getDepartureDate(),
						checkCallLoadedUnloadedDTO.getDepartureTime(), tSubtask1.getSubTaskID());
			}
			
			updateActivityType(stopId, checkCallLoadedUnloadedDTO.getCountedBy(), checkCallType,
					orderSync.getOrderId());
			updateActivityType(stopId, type, checkCallType, orderSync.getOrderId());

			Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall()
					.getOperationalPlanStopActivityCheckCallReferenceNumbers())
					.ifPresent(e -> e.forEach(referenceNumber -> {
						loadedCheckCallJDBCRepository.updateTOrderRefereceNumber(
								referenceNumber.getReferenceNumberValue(), tSubtask1.getTaskId(),
								referenceNumber.getReferenceNumberTypeCode(), tSubtask1.getPreferanceSequenceNumber());

					}));

			final CheckCallLoadedUnloadedDTO checkCallLoadedUnloaded = loadedCheckCallJDBCRepository.getOrderLineItem(
					tSubtask1.getTaskId(), tSubtask1.getPreferanceSequenceNumber(), type, checkCallLoadedUnloadedDTO);
			
			log.info("Task Id >>{}",tSubtask1.getTaskId());
			log.info("Preference Number >>{}", tSubtask1.getPreferanceSequenceNumber());
			log.info("Type >>{}", type);
			log.info("CheckcallUnloadedDTO >>{}", checkCallLoadedUnloadedDTO);
			
			log.info("checkCallLoadedUnloaded >>{}", checkCallLoadedUnloaded);

			if (checkCallLoadedUnloaded == null) {
				final String errorMessage = type + " - is not applicable check call for the order "
						+ tSubtask1.getTaskId();
				throw new JBHuntRuntimeException(errorMessage);
			}

			loadedCheckCallJDBCRepository.updateTOrderLineItem(checkCallLoadedUnloadedDTO.getQuantity(),
					checkCallLoadedUnloadedDTO.getWeight(), checkCallLoadedUnloadedDTO.getWeightMeasurement(),
					checkCallLoadedUnloadedDTO.getVolume(), checkCallLoadedUnloadedDTO.getVolumeMeasurement(),
					tSubtask1.getTaskId(), tSubtask1.getPreferanceSequenceNumber(), type);

			loadedCheckCallJDBCRepository.updateTOrderLineItem(checkCallLoadedUnloadedDTO.getQuantity(),
					checkCallLoadedUnloadedDTO.getWeight(), checkCallLoadedUnloadedDTO.getWeightMeasurement(),
					checkCallLoadedUnloadedDTO.getVolume(), checkCallLoadedUnloadedDTO.getVolumeMeasurement(),
					tSubtask1.getTaskId(), tSubtask1.getPreferanceSequenceNumber(),
					checkCallLoadedUnloadedDTO.getCountedBy());

		});
	}

	private void operationalPlanStopActivityPartyType(final String loadedUnloadedBy,
			final CheckCallLoadedUnloadedDTO checkCallLoadedUnloadedDTO,
			final OperationalPlanCheckCallDTO operationalPlanCheckCallDTO,
			final OperationalPlanDTO operationalPlanDTO) {
		switch (loadedUnloadedBy) {
		case "Driver":
			checkCallLoadedUnloadedDTO.setLoadedBy("DRVRLOAD");
			if (operationalPlanCheckCallDTO.getCheckCallType().getCheckCallTypeCode().equalsIgnoreCase("Unloaded")) {
				checkCallLoadedUnloadedDTO.setUnLoadedBy("DRVRUNLD");
			}
			break;
		case "Shipper":
			checkCallLoadedUnloadedDTO.setLoadedBy("SHPRLOAD");
			break;
		case "Receiver":
			checkCallLoadedUnloadedDTO.setUnLoadedBy("RCVRUNLD");
			break;
		case "Lumper":
			checkCallLoadedUnloadedDTO.setLoadedBy("LUMPLOAD");
			if (operationalPlanCheckCallDTO.getCheckCallType().getCheckCallTypeCode().equalsIgnoreCase("Unloaded")) {
				checkCallLoadedUnloadedDTO.setUnLoadedBy("LUMPUNLD");
			}
			break;
		default:
			final String errorMessage = loadedUnloadedBy + " - is not applicable data for loaded / unloaded by";
			backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
					errorMessage);
			throw new JBHuntRuntimeException(errorMessage);
		}
	}

	private void countedByPartyType(final String countedByPartyType,
			final CheckCallLoadedUnloadedDTO checkCallLoadedUnloadedDTO, final OperationalPlanDTO operationalPlanDTO) {
		switch (countedByPartyType) {
		case "Driver":
			checkCallLoadedUnloadedDTO.setCountedBy("DRVRCNT");
			break;
		case "Shipper":
			checkCallLoadedUnloadedDTO.setCountedBy("SHPRCNT");
			break;
		case "Receiver":
			checkCallLoadedUnloadedDTO.setCountedBy("RCVRCNT");
			break;
		default:
			final String errorMessage = countedByPartyType + " - is not applicable data for counted by party type";
			backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
					errorMessage);
			throw new JBHuntRuntimeException(errorMessage);
		}
	}

	private void saveBackTrackingDetails(final OperationalPlanDTO operationalPlanDTO, final String eventSubType) {
		backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
				eventSubType, "");
	}

	private Timestamp getTimestamp(String time) throws ParseException {
		SimpleDateFormat dataFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		return new Timestamp(dataFormat.parse(time).getTime());
	}

	private void updateException(OperationalPlanDTO operationalPlanDTO, Exception e) {
		String errorMesage = ExceptionUtils.getRootCauseMessage(e);
		if (errorMesage != null && errorMesage.length() > 500) {
			errorMesage = errorMesage.substring(0, 500);
		}
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
				errorMesage);
	}

}
