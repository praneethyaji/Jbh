package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "TOPER_POWER_ASSOC", schema = "ALI")
public class OperPowAssoc {

	@Id
	@Column(name = "OPR_CREW_MBR_ID")
	private int oprCrewMbrId;

	@Column(name = "EQP_ID")
	private int equipmentId;

	@Column(name = "EQP_UNIT_ID")
	private String trailerNumber;

	@Column(name = "REC_STT_F")
	private String recordStatus;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "OPR_ID", referencedColumnName = "OPR_ID")
	private TOperator tOperator;
	
	@OneToOne(mappedBy = "operPowAssoc")
	private TOperCrewMember tOperCrewMember;

}
