package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.biz.refNumber.vo.AddNewReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.LineItemVO;
import com.jbhunt.biz.refNumber.vo.UpdatedReferenceNumberVO;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanReferenceNumberDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopItemDTO;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InStpLine;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ReferenceNumberBuilder {

	public List<UpdatedReferenceNumberVO> populateUpdateReferenceNumberList(
			UpdatedReferenceNumberVO updatedReferenceNumberVO, OperationalPlanReferenceNumberDTO referenceNumberDTO,
			Oee5InStpLine oee5OutStpLine, OperationalPlanStopDTO stopDTO, Integer totalStops,
			List<UpdatedReferenceNumberVO> updRefNbrList, OperationalPlanStopItemDTO stopItem) {
		if (CommonConstants.OPERATIONAL_PLAN_STOP
				.equalsIgnoreCase(referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode())
				&& conditionCheck(oee5OutStpLine, stopDTO, totalStops)
				&& referenceNumberDTO.getOperationalPlanStopId().equals(stopDTO.getOperationalPlanStopId())) {
			updatedReferenceNumberVO.setCustomerCode(oee5OutStpLine.getOee5InStpCusC());
			updatedReferenceNumberVO.setDepartment(oee5OutStpLine.getOee5InStpDptC());
			updatedReferenceNumberVO.setSiteID(oee5OutStpLine.getOee5InStpBusSitI());
			updatedReferenceNumberVO.setAddressID(oee5OutStpLine.getOee5InStpAdrI());
			updatedReferenceNumberVO.setSequence(oee5OutStpLine.getOee5InStpoOfrStpSeqNbr());
			updatedReferenceNumberVO
					.setLevel(referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode());
			updateStopItemsForUpdate(updatedReferenceNumberVO, stopItem, oee5OutStpLine);
			LineItemVO lineItemVO = new LineItemVO();
			lineItemVO.setHazF("N");
			updatedReferenceNumberVO.setLineItemVO(lineItemVO);
			updatedReferenceNumberVO.setReferenceNumberType(referenceNumberDTO.getReferenceNumberTypeCode());
			updatedReferenceNumberVO.setReferenceNumber(referenceNumberDTO.getReferenceNumberValue());
			updatedReferenceNumberVO
					.setParentReferenceNumberI(referenceNumberDTO.getOperationalPlanReferenceNumberId());
			updRefNbrList.add(updatedReferenceNumberVO);
		}

		return updRefNbrList;
	}

	private void updateStopItemsForUpdate(UpdatedReferenceNumberVO updatedReferenceNumberVO,
			OperationalPlanStopItemDTO stopItem, Oee5InStpLine oee5OutStpLine) {
		if (stopItem != null) {
			updatedReferenceNumberVO
					.setQuantity(stopItem.getPackagingUnitQuantity() == null ? 0 : stopItem.getPackagingUnitQuantity());
			updatedReferenceNumberVO
					.setWeight(stopItem.getTotalItemWeight() == null ? 0 : stopItem.getTotalItemWeight().doubleValue());
			updatedReferenceNumberVO
					.setVolume(stopItem.getItemVolume() == null ? 0 : stopItem.getItemVolume().intValue());
		} else {
			updatedReferenceNumberVO.setQuantity(Integer.valueOf(oee5OutStpLine.getOee5InStpQty()));
			updatedReferenceNumberVO.setWeight(
					oee5OutStpLine.getOee5InStpWgt() == null ? 0 : oee5OutStpLine.getOee5InStpWgt().doubleValue());
		}
	}

	public List<UpdatedReferenceNumberVO> populateUpdateOrderLevelReference(
			UpdatedReferenceNumberVO updatedReferenceNumberVO, OperationalPlanReferenceNumberDTO referenceNumberDTO,
			Oee5InputChannelData input, String entity, List<UpdatedReferenceNumberVO> updRefNbrList) {
		if (CommonConstants.OPERATIONAL_PLAN
				.equalsIgnoreCase(referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode())
				&& "OrderReferenceNumber".equalsIgnoreCase(entity)) {
			double zero = 0;
			updatedReferenceNumberVO.setReferenceNumberType(
					referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode().toUpperCase());
			updatedReferenceNumberVO.setReferenceNumber(referenceNumberDTO.getReferenceNumberValue());
			updatedReferenceNumberVO
					.setParentReferenceNumberI(referenceNumberDTO.getOperationalPlanReferenceNumberId());
			updatedReferenceNumberVO.setSequence(0);
			updatedReferenceNumberVO.setLevel(
					referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode().toUpperCase());
			updatedReferenceNumberVO.setSiteID(CollectionUtils.isEmpty(input.getOee5InNonstpBuffer4()) ? 0
					: input.getOee5InNonstpBuffer4().get(0).getOee5InNonstpBusSitI());
			updatedReferenceNumberVO.setAddressID(CollectionUtils.isEmpty(input.getOee5InNonstpBuffer4()) ? 0
					: input.getOee5InNonstpBuffer4().get(0).getOee5InNonstpAdrI());
			updatedReferenceNumberVO.setCustomerCode(CollectionUtils.isEmpty(input.getOee5InNonstpBuffer4()) ? ""
					: input.getOee5InNonstpBuffer4().get(0).getOee5InNonstpCusC());
			updatedReferenceNumberVO.setDepartment(CollectionUtils.isEmpty(input.getOee5InNonstpBuffer4()) ? ""
					: input.getOee5InNonstpBuffer4().get(0).getOee5InNonstpDptC());

			updatedReferenceNumberVO.setQuantity(1);
			updatedReferenceNumberVO.setWeight(zero);
			updatedReferenceNumberVO.setVolume(0);

			updRefNbrList.add(updatedReferenceNumberVO);
		}
		return updRefNbrList;
	}

	public void populateNewOrderLevelReference(List<OperationalPlanReferenceNumberDTO> referenceNumberDTOs,
			Oee5InputChannelData input, String entity, List<AddNewReferenceNumberVO> crtRefNbrList) {
		log.info("ReferenceNumberBuilder - populateOrderLevelReference Calling  >>>>>>>>>>>>>>>>>>>>>>");
		for (OperationalPlanReferenceNumberDTO referenceNumberDTO : referenceNumberDTOs) {
			if (CommonConstants.OPERATIONAL_PLAN.equalsIgnoreCase(
					referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode())
					&& "OrderReferenceNumber".equalsIgnoreCase(entity)) {
				log.info(
						"referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode() >>>>>>>>>>>>>>>>> {}",
						referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode());
				AddNewReferenceNumberVO refNbrDetails = new AddNewReferenceNumberVO();
				refNbrDetails.setReferenceNumberType(referenceNumberDTO.getReferenceNumberTypeCode());
				refNbrDetails.setReferenceNumber(referenceNumberDTO.getReferenceNumberValue());
				refNbrDetails.setReferenceNumberI(referenceNumberDTO.getOperationalPlanReferenceNumberId());
				refNbrDetails.setParentReferenceNumberI(0);
				refNbrDetails.setSequence(0);
				refNbrDetails
						.setLevel(referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode());
				refNbrDetails.setSiteID(CollectionUtils.isEmpty(input.getOee5InNonstpBuffer4()) ? 0
						: input.getOee5InNonstpBuffer4().get(0).getOee5InNonstpBusSitI());
				refNbrDetails.setAddressID(CollectionUtils.isEmpty(input.getOee5InNonstpBuffer4()) ? 0
						: input.getOee5InNonstpBuffer4().get(0).getOee5InNonstpAdrI());
				refNbrDetails.setCustomerCode(CollectionUtils.isEmpty(input.getOee5InNonstpBuffer4()) ? ""
						: input.getOee5InNonstpBuffer4().get(0).getOee5InNonstpCusC());
				refNbrDetails.setDepartment(CollectionUtils.isEmpty(input.getOee5InNonstpBuffer4()) ? ""
						: input.getOee5InNonstpBuffer4().get(0).getOee5InNonstpDptC());
				crtRefNbrList.add(refNbrDetails);
			}
		}
	}

	public void populateNewReferenceNumberList(AddNewReferenceNumberVO refNbrDetails,
			OperationalPlanReferenceNumberDTO referenceNumberDTO, Oee5InStpLine oee5OutStpLine,
			OperationalPlanStopDTO stopDTO, Integer totalStops, List<AddNewReferenceNumberVO> crtRefNbrList,
			OperationalPlanStopItemDTO stopItem) {
		if (CommonConstants.OPERATIONAL_PLAN_STOP
				.equalsIgnoreCase(referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode())
				&& conditionCheck(oee5OutStpLine, stopDTO, totalStops)
				&& referenceNumberDTO.getOperationalPlanStopId().equals(stopDTO.getOperationalPlanStopId())) {
			refNbrDetails.setCustomerCode(oee5OutStpLine.getOee5InStpCusC());
			refNbrDetails.setDepartment(oee5OutStpLine.getOee5InStpDptC());
			refNbrDetails.setSiteID(oee5OutStpLine.getOee5InStpBusSitI());
			refNbrDetails.setAddressID(oee5OutStpLine.getOee5InStpAdrI());
			refNbrDetails.setSequence(oee5OutStpLine.getOee5InStpoOfrStpSeqNbr());
			refNbrDetails.setLevel(referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode());
			updateStopItemsForAdd(refNbrDetails, stopItem, oee5OutStpLine);
			LineItemVO lineItemVO = new LineItemVO();
			lineItemVO.setHazF("N");
			refNbrDetails.setLineItemVO(lineItemVO);
			refNbrDetails.setReferenceNumberType(referenceNumberDTO.getReferenceNumberTypeCode());
			refNbrDetails.setReferenceNumber(referenceNumberDTO.getReferenceNumberValue());
			refNbrDetails.setReferenceNumberI(referenceNumberDTO.getOperationalPlanReferenceNumberId());
			refNbrDetails.setParentReferenceNumberI(referenceNumberDTO.getOperationalPlanReferenceNumberId());
			crtRefNbrList.add(refNbrDetails);
		}
	}

	private void updateStopItemsForAdd(AddNewReferenceNumberVO refNbrDetails, OperationalPlanStopItemDTO stopItem,
			Oee5InStpLine oee5OutStpLine) {
		if (stopItem != null) {
			refNbrDetails
					.setQuantity(stopItem.getPackagingUnitQuantity() == null ? 0 : stopItem.getPackagingUnitQuantity());
			refNbrDetails
					.setWeight(stopItem.getTotalItemWeight() == null ? 0 : stopItem.getTotalItemWeight().doubleValue());
			refNbrDetails.setVolume(stopItem.getItemVolume() == null ? 0 : stopItem.getItemVolume().intValue());
		} else {
			refNbrDetails.setQuantity(Integer.valueOf(oee5OutStpLine.getOee5InStpQty()));
			refNbrDetails.setWeight(
					oee5OutStpLine.getOee5InStpWgt() == null ? 0 : oee5OutStpLine.getOee5InStpWgt().doubleValue());
		}
	}

	private boolean conditionCheck(Oee5InStpLine oee5OutStpLine, OperationalPlanStopDTO stopDTO, Integer totalStops) {
		return conditionCheckStopSeqenceNumber(stopDTO, oee5OutStpLine, totalStops)
				&& conditionCheckStopSeqence(oee5OutStpLine, stopDTO);
	}

	private boolean conditionCheckStopSeqenceNumber(OperationalPlanStopDTO stopDTO, Oee5InStpLine oee5OutStpLine,
			Integer totalStops) {
		return Integer.valueOf(oee5OutStpLine.getOee5InStpoOfrStpSeqNbr())
				.equals(stopDTO.getOperationalPlanStopSequenceNumber())
				|| totalStops.equals(stopDTO.getOperationalPlanStopSequenceNumber());
	}

	private boolean conditionCheckStopSeqence(Oee5InStpLine oee5OutStpLine, OperationalPlanStopDTO stopDTO) {
		return Integer.valueOf(oee5OutStpLine.getOee5InStpoOfrStpSeqNbr()).equals(
				stopDTO.getOperationalPlanStopSequenceNumber()) || 99 == oee5OutStpLine.getOee5InStpoOfrStpSeqNbr();
	}

}
