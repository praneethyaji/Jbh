package com.jbhunt.loadplannig.integration.backfill.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class LegacyOrderOperationalPlanAssociationDTO implements Serializable{
	
	private static final long serialVersionUID = 6263383251489493016L;

	private Integer legacyOrderOperationalPlanAssociationId;

    private Integer legacyOrderId;
    
    private Integer legacyJobId;
    
    private Integer legacyResourceReservationId;
    
    private Integer legacyCarrierReservationId;
    
    private Short legacyDispatchNumber;
    
    private String legacyOrderNumber;
    
    private Integer operationalPlanId;
    
    private String createTimestamp;
    
    private String createUserID;
    
    private String createProgramName;
    
    private String lastUpdateTimestamp;
    
    private String lastUpdateUserID;
    
    private String lastUpdateProgramName;
    

}
