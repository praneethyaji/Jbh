package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.VEquipmentLse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface VEquipmentLseRepository extends JpaRepository<VEquipmentLse,Integer> {
    @Query(value = "SELECT EQP_ID, EQP_TY_ID, EQP_UNIT_PREFIX_ID, DIV_ID, LST_CON_D, LST_CON_BSST_ID, REC_STT_F, CUR_PLX_I, CUR_PLX_TYP_C,  \n" +
            " STT_C, EQP_UNIT_ID, UNT_STT_C, MJR_CLS_C, SUB_CLS_C, LST_ORD_NBR_CH  \n" +
            "FROM ALI.VEQUIPMENT_LSE \n" +
            "WHERE EQP_UNIT_ID= :equipmentUnitId AND EQP_UNIT_PREFIX_ID = :equipmentUnitPrefixId AND MJR_CLS_C != 'POWER' AND REC_STT_F  = 'A' WITH UR ",nativeQuery = true)
    public VEquipmentLse getEquipmentLseInfo(@Param("equipmentUnitId") String equipmentUnitId,@Param("equipmentUnitPrefixId") String equipmentUnitPrefixId);
}
