package com.jbhunt.loadplannig.integration.backfill.configuration;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import com.jbhunt.biz.securepid.PIDCredentials;

@Configuration
public class DBConfiguration {

    @Bean
    @Primary
    @ConfigurationProperties(prefix = "jbhunt.general.datasource.com.jbhunt.datasource.JBHDB2P")
    public DataSource dataSource(PIDCredentials pidCredentials) {
        return DataSourceBuilder.create().username(pidCredentials.getUsername()).password(pidCredentials.getPassword()).build();
    }

    @Bean
    @ConfigurationProperties(prefix = "spring.sqlserver.datasource")
    public DataSource dataSourceSqlServer(PIDCredentials pidCredentials) {
        return DataSourceBuilder.create().type(BasicDataSource.class).username(pidCredentials.getUsername()).password(pidCredentials.getPassword()).build();
    }

    @Bean
    public JdbcTemplate sqlServerjdbcTemplate(PIDCredentials pidCredentials) {
        return new JdbcTemplate(dataSourceSqlServer(pidCredentials));
    }
}