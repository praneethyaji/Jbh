package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.RscPlanRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc341i.lmc341.LMC341Port;
import com.lmc342i.lmc342.LMC342Port;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables;
import com.response.lmc341i.lmc341.ProgramInterface.Lmc341OutputArea;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava.Wo42ErrorVariables;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class ResourceAssignmentControllerIT {

	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http")
			.host("loadplanning-test.jbhunt.com").removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";
	
	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private LMC341Port lmc341Port;

	@MockBean
	private LMC342Port lmc342Port;

	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	private RscPlanRepository rscPlanRepository;

	@MockBean
	private EquipmentRepository equipmentRepository;
	
	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void cancelResourceAssignment() throws Exception {

		resourceAssignmentOrCancel("/json/OperationalPlanCancelResourceAssignment.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments/cancel");
	}

	@Test
	public void resourceAssignment() throws Exception {

		resourceAssignmentOrCancel("/json/OperationalPlanResourceAssignment.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments");
	}
	
	@Test
	public void resourceAssignmentForOwo() throws Exception {

		resourceAssignmentOrCancel("/json/OperationalPlanResourceAssignmentForOWO.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments");
	}

	@Test
	public void driverAssignment() throws Exception {
		resourceAssignmentOrCancel("/json/OperationalPlanDriverAssignment.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments");
	}

	private void resourceAssignmentOrCancel(final String filePathJson, final String restURI) throws Exception {

		// ARRANGEl
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		final String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		final String responseMasterData = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		final OperationalPlanDTO operationalPlanDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(filePathJson)), OperationalPlanDTO.class);
		final Lmc341OutputArea lmc341OutputArea = new Lmc341OutputArea();
		lmc341OutputArea.setLmc341ErrorMessage("Mock");
		lmc341OutputArea.setLmc341ReturnFlag("S");

		final Wo42ComReturnToJava wo42ComReturnToJava = new Wo42ComReturnToJava();
		final Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ErrorKey1("");
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		Wo42ErrorVariables.setWo42Message("");
		Wo42ErrorVariables.setWo42CicsReturnCode(399);
		Wo42ErrorVariables.setWo42ErrorKey2("");

		wo42ComReturnToJava.setWo42ErrorVariables(Wo42ErrorVariables);

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[7885243]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(lmc341OutputArea);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42ComReturnToJava);

		final Response response = given(this.requestSpecification).auth().basic(userName, password)
				.accept(ContentType.JSON).contentType(ContentType.JSON).body(operationalPlanDTO).patch(restURI);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}
	
}
