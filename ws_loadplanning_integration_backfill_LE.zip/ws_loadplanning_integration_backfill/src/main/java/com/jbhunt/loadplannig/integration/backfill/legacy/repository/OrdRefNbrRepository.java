package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrdRefNbr;

@Repository
public interface OrdRefNbrRepository extends JpaRepository<OrdRefNbr, String> {
	
	List<OrdRefNbr> findOrdRefNbrDetailsByOrderId(@Param("orderId") int orderId);

}
