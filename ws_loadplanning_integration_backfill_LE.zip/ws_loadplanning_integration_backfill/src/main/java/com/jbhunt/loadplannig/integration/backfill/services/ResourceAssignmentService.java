package com.jbhunt.loadplannig.integration.backfill.services;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class ResourceAssignmentService {

	private final DriverAndTruckAssignmentService driverAndTruckAssignmentService;
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;

	@Transactional
	public void resourceAssignment(final OperationalPlanDTO operationalPlanDTO) {

		try {
			saveBackTrackingDetails(operationalPlanDTO, OperationalPlanEventSubType.RESOURCEASSIGNMENT.name());
			driverAndTruckAssignmentService.driverAndTruckAssignment(operationalPlanDTO,
					CommonConstants.TRACTOR_AND_DRIVER_SAVEPLAN, CommonConstants.TRACTOR_AND_RIVER_SENDPLAN_ORDER_SAVE,
					OperationalPlanEventSubType.RESOURCEASSIGNMENT.name());
		} catch (Exception e) {
			log.error("Exception in resourceAssignment:", e);
			updateException(operationalPlanDTO, e);
			throw e;
		}
	}

	@Transactional
	public void cancelResourceAssignment(final OperationalPlanDTO operationalPlanDTO) {
		try {
			saveBackTrackingDetails(operationalPlanDTO, OperationalPlanEventSubType.RESOURCEPLAN_CANCEL.name());
			driverAndTruckAssignmentService.driverAndTruckAssignment(operationalPlanDTO,
					CommonConstants.TRACTOR_AND_DRIVER_CANCELL, CommonConstants.TRACTOR_AND_DRIVER_CANCELL,
					OperationalPlanEventSubType.RESOURCEPLAN_CANCEL.name());
		} catch (Exception e) {
			log.error("Exception in preplan:", e);
			updateException(operationalPlanDTO, e);
			throw e;
		}
	}

	/**
	 * 
	 * @param operationalPlanDTO
	 * @param eventSubType
	 */
	private void saveBackTrackingDetails(final OperationalPlanDTO operationalPlanDTO, final String eventSubType) {
		backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
				eventSubType, "");
	}

	private void updateException(OperationalPlanDTO operationalPlanDTO, Exception e) {
		String errorMesage = ExceptionUtils.getRootCauseMessage(e);
		if (errorMesage != null && errorMesage.length() > 500) {
			errorMesage = errorMesage.substring(0, 500);
		}
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
				errorMesage);
	}
}
