package com.jbhunt.loadplannig.integration.backfill.controllers;

import java.net.URISyntaxException;

import org.json.JSONException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.BeamingIntegrationBackfillService;
import com.jbhunt.operations.equipmentgroup.dto.OpexEquipmentLocationUpdateDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class BeamingController extends BackfillBaseController{

    private final BeamingIntegrationBackfillService beamingIntegrationBackfillService;

    @PostMapping(value = "/equipments/locations")
    public ResponseEntity<BackfillServiceResponse> beaming(@RequestBody OpexEquipmentLocationUpdateDTO equipmentLocationUpdateDTO) throws URISyntaxException, JSONException {
        log.info("Calling beaming process:");
        beamingIntegrationBackfillService.beaming(equipmentLocationUpdateDTO);
        return ResponseEntity.ok(getBackfillServiceSuccessResponse());
    }

}
