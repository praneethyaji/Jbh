package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallElement;


@Service
public class TerminateCallHelper {
	
	  public String getCheckCallVarsValues(Map<String,String> checkCallElementMap, List<CheckcallElement> checkcallArrivalsList){
	        StringBuilder sb = new StringBuilder("");
	        checkcallArrivalsList.stream().forEach((checkcallElement)->{
	            sb.append(getPaddedValue(checkCallElementMap.containsKey(checkcallElement.getFieldName())?checkCallElementMap.get(checkcallElement.getFieldName()):"" ,checkcallElement.getLength()));
	        });
	        return sb.toString();
	    }
	 
	 private String getPaddedValue(String value,Short length ){
	       return String.format("%1$-" + length + "s", value);
	    }
	

}
