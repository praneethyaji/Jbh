package com.jbhunt.loadplannig.integration.backfill.controllers;

import java.net.URISyntaxException;

import org.json.JSONException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.LoadExecutionIntegrationBackfillService;
import com.jbhunt.operations.equipmentgroup.dto.EquipmentGroupESDTO;
import com.jbhunt.operations.equipmentgroup.dto.RemoveEquipmentFromGroupBackFillDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class LoadExecutionBackfillController extends BackfillBaseController {

	private final LoadExecutionIntegrationBackfillService loadExecutionIntegrationBackfillService;

	@PostMapping("/equipmentgroup")
	public ResponseEntity<BackfillServiceResponse> equipmentAssignment(
			@RequestBody EquipmentGroupESDTO equipmentGroupESDTO) throws URISyntaxException, JSONException {
		log.info("Equipment assignment");
		loadExecutionIntegrationBackfillService.equipmentAssignment(equipmentGroupESDTO);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}

	@PatchMapping("/equipmentgroup")
	public ResponseEntity<BackfillServiceResponse> equipmentUnassignment(
			@RequestBody RemoveEquipmentFromGroupBackFillDTO removeEquipmentDTO)
			throws URISyntaxException, JSONException {
		log.info("Equipment Unassignment");
		loadExecutionIntegrationBackfillService.equipmentUnassignment(removeEquipmentDTO);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
}
