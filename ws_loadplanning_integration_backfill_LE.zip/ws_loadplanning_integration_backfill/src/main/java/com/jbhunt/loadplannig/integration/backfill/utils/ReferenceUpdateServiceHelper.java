package com.jbhunt.loadplannig.integration.backfill.utils;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersBuffer;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersErrorBuffer;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersLink;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersLinkBuffers;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersModeBuffer;
import com.jbhunt.biz.refNumber.vo.AddNewReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.DeletedReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.LineItemVO;
import com.jbhunt.biz.refNumber.vo.UpdatedReferenceNumberVO;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanReferenceNumberDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopItemDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InStpLine;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class ReferenceUpdateServiceHelper {

	private final ReferenceNumberBuilder referenceNumberBuilder;
	private final ReferenceUpdateHelper referenceUpdateHelper;
	private final ItemReferenceNumberHelper itemReferenceNumberHelper;
	private final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");

	public ReferenceNumbersLinkBuffers linkOEC070InSelectMode(Integer orderId, String netUserId, String programName,
			String userName, String password) throws JBHuntRuntimeException {
		ReferenceNumbersLinkBuffers oec070Buffers = new ReferenceNumbersLinkBuffers();
		ReferenceNumbersModeBuffer mode = oec070Buffers.getMode();
		mode.setOrderID(orderId);
		mode.setMode("SELECT-TAB");
		mode.setCount(0);
		mode.setUserID(netUserId);
		mode.setProgramName(programName);
		ReferenceNumbersLinkBuffers retrieveOEC070Info = null;
		try {
			log.info("oec070Buffers in Select  Case >>>>>>>>>>>>>>>>>>>>>>>> {}",CommonUtils.asString(oec070Buffers));
			ReferenceNumbersLink referenceNumbersLink = new ReferenceNumbersLink(oec070Buffers);
			retrieveOEC070Info = (ReferenceNumbersLinkBuffers) referenceNumbersLink.retrieveOEC070Info(userName,
					password);
		} catch (Exception e) {
			log.error("Exception while ReferenceNumbersLink" + e);
			throw new JBHuntRuntimeException("Exception while ReferenceNumbersLink" + e.getLocalizedMessage());
		}
		return retrieveOEC070Info;
	}

	public String linkOEC070InUpdateMode(ReferenceNumbersLinkBuffers oec070Buffers,
			List<UpdatedReferenceNumberVO> updRefNbrList, List<AddNewReferenceNumberVO> newRefNbrList,
			List<DeletedReferenceNumberVO> delRefNbrList, OrderLoadSync orderLoadSyncDTO, String pidCredentials,
			String callMode, String oec070Create) throws JBHuntRuntimeException {
		log.info(" mg7:linkOEC070InUpdateMode::");
		ReferenceNumbersBuffer referenceNumbers = oec070Buffers.getReferenceNumbers();
		int maxReferenceNumbersCount = ReferenceNumbersBuffer.MAX_REF_NBR_COUNT;
		int orderReferenceNumbersCount = this.constructExistingRefNbrBuff(oec070Buffers, referenceNumbers,
				maxReferenceNumbersCount);
		
		 int refNbrInsertCnt = 0;
        if ("LINEITEM".equalsIgnoreCase(callMode)) {
            refNbrInsertCnt = referenceUpdateHelper.populateRefNbrForLineItems(updRefNbrList, newRefNbrList,
                    delRefNbrList, referenceNumbers, orderReferenceNumbersCount);
        } else {
            refNbrInsertCnt = referenceUpdateHelper.populateReferenceNumberForOthers(updRefNbrList, newRefNbrList, delRefNbrList,
                    referenceNumbers, orderReferenceNumbersCount);
        }

		int totalReferenceNumbersCounter = orderReferenceNumbersCount + refNbrInsertCnt;
		log.debug("calling ref nbr update " + totalReferenceNumbersCounter);
		 
		ReferenceNumbersModeBuffer mode = oec070Buffers.getMode();
		mode.setOrderID(orderLoadSyncDTO.getLegacyOrderID());
		mode.setMode("UPDATE-TAB");
		mode.setCount(totalReferenceNumbersCounter);
		mode.setUserID(pidCredentials.split("::")[0]);
		mode.setProgramName(CommonConstants.OPEX_BKFL);

		ReferenceNumbersLink referenceNumbersLink = null;
		ReferenceNumbersLinkBuffers buffers = null;
		ReferenceNumbersErrorBuffer errors = null;
		try {
			log.info("oec070Buffers in Update Case >>>>>>>>>>>>>>>>>>>>>>>> {}",CommonUtils.asString(oec070Buffers));
			referenceNumbersLink = new ReferenceNumbersLink(oec070Buffers);
		} catch (IOException e1) {
			log.error("ReferenceNumbersLink error" + e1);
			throw new JBHuntRuntimeException("ReferenceNumbersLink error" + e1.getLocalizedMessage());
		}
		String errorMessage = null;
		try {
			
				referenceNumbersLink.retrieveOEC070InfoForBackfill(pidCredentials.split("::")[0],
						pidCredentials.split("::")[1], oec070Create, orderLoadSyncDTO.getScmOrderID());
				buffers = referenceNumbersLink.getBuffers();
				if (null != buffers) {
					errors = buffers.getError();
				}
				if (errors != null && errors.getMessage() != null && errors.getMessage().length() > 0) {
					errorMessage = errors.getMessage();
				} else {
					errorMessage = "SUCCESS";
				}
			
		} catch (Exception e) {
			log.error("Exception while retrieve OEC070 Information" + e);
			throw new JBHuntRuntimeException("Exception while retrieve OEC070 Information" + e.getLocalizedMessage());
		}
		return errorMessage;
	}
	

	public int constructExistingRefNbrBuff(ReferenceNumbersLinkBuffers oec070Buffers,
			ReferenceNumbersBuffer referenceNumbers, int maxReferenceNumbersCount) {
		int orderReferenceNumbersCount = 0;
		if (oec070Buffers.getNbrOfRefNbrs() > 0) {
			for (int i = 0; i < maxReferenceNumbersCount; i++) {
				if (!referenceNumbers.getType(i).isEmpty()) {
					referenceNumbers.setAction("UNCHANGED", i);
					referenceNumbers.setOldNumber(referenceNumbers.getNumber(i), i);
					referenceNumbers.setOldType(referenceNumbers.getType(i), i);
					referenceNumbers.setOldSiteID(referenceNumbers.getSiteID(i), i);
					referenceNumbers.setOldAddressID(referenceNumbers.getAddressID(i), i);
					referenceNumbers.setOldSequence(referenceNumbers.getSequence(i), i);
					referenceNumbers.setOldDepartment(referenceNumbers.getDepartment(i), i);
					referenceNumbers.setOldCustomerCode(referenceNumbers.getCustomerCode(i), i);
					orderReferenceNumbersCount++;
				}
			}
		}
		return orderReferenceNumbersCount;
	}

	public void defaultLineItemValuesForRefMode(List<UpdatedReferenceNumberVO> updRefNbrList,
			List<AddNewReferenceNumberVO> crtRefNbrList, List<DeletedReferenceNumberVO> delRefNbrList,
			String callMode) {
		if ("REFNBR".equalsIgnoreCase(callMode)) {
			delRefNbrList.forEach(refNbr -> {
				if (refNbr.getLineItemVO() != null) {
					refNbr.getLineItemVO().setActCls(0);
				}
			});
			crtRefNbrList.forEach(refNbr -> {
				if (refNbr.getLineItemVO() != null) {
					refNbr.getLineItemVO().setActCls(0);
				}
			});
			updRefNbrList.forEach(refNbr -> {
				if (refNbr.getLineItemVO() != null) {
					refNbr.getLineItemVO().setActCls(0);
				}
			});
		}
	}

	// Insert Ref Number
		public List<AddNewReferenceNumberVO> fetchCreateReferenceNumberVO(OperationalPlanEvent operationalPlanEvent,
				List<OperationalPlanReferenceNumberDTO> referenceNumberDTOs, Oee5InputChannelData input, String entity,
				OperationalPlanReferenceNumberDTO referenceNumber) {
			List<AddNewReferenceNumberVO> crtRefNbrList = new ArrayList<>();
			AddNewReferenceNumberVO refNbrDetails = new AddNewReferenceNumberVO();
			if (CollectionUtils
					.isNotEmpty(operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanReferenceNumbers())) {
				for (OperationalPlanReferenceNumberDTO referenceNumberDTO : referenceNumberDTOs) {
					for (Oee5InStpLine oee5OutStpLine : input.getOee5InStpBuffer5()) {
						getStopItem(operationalPlanEvent, referenceNumberDTO, referenceNumber, oee5OutStpLine,
								crtRefNbrList, refNbrDetails);
					}
				}
				referenceNumberBuilder.populateNewOrderLevelReference(refNbrDetails, referenceNumber, input, entity,
						crtRefNbrList);
			}
			return crtRefNbrList;
		}

		private void getStopItem(OperationalPlanEvent operationalPlanEvent,
				OperationalPlanReferenceNumberDTO referenceNumberDTO, OperationalPlanReferenceNumberDTO referenceNumber,
				Oee5InStpLine oee5OutStpLine, List<AddNewReferenceNumberVO> crtRefNbrList,
				AddNewReferenceNumberVO refNbrDetails) {
			for (OperationalPlanStopDTO stopDTO : operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops()) {
				refNbrDetails = new AddNewReferenceNumberVO();
				if (referenceNumberDTO.getOperationalPlanReferenceNumberId() != null
						&& referenceNumber.getOperationalPlanReferenceNumberId()
								.equals(referenceNumberDTO.getOperationalPlanReferenceNumberId())) {
					OperationalPlanStopItemDTO stopItem = itemReferenceNumberHelper
							.getStopItemIfTiedToReferenceNumber(referenceNumberDTO, stopDTO);
					referenceNumberBuilder.populateNewReferenceNumberList(refNbrDetails, referenceNumber, oee5OutStpLine,
							stopDTO, operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops().size(),
							crtRefNbrList, stopItem);
				}
			}
		}
	
	
	// Delete Ref Number
	public List<DeletedReferenceNumberVO> fetchDeleteReferenceNumberVO(List<DeletedReferenceNumberVO> delRefNbrList,
			ReferenceNumbersLinkBuffers ordRefNbrBuffers, OperationalPlanReferenceNumberDTO refNbr) {
		DeletedReferenceNumberVO deletedReferenceNumberVO = new DeletedReferenceNumberVO();
		for (int i = 0; i < ordRefNbrBuffers.getNbrOfRefNbrs(); i++) {
			if (refNbr.getReferenceNumberValue().equalsIgnoreCase(ordRefNbrBuffers.getReferenceNumbers().getNumber(i))
					&& refNbr.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode()
							.equalsIgnoreCase(ordRefNbrBuffers.getReferenceNumbers().getType(i))) {
				deletedReferenceNumberVO.setReferenceNumber(ordRefNbrBuffers.getReferenceNumbers().getNumber(i));
				deletedReferenceNumberVO.setReferenceNumberType(ordRefNbrBuffers.getReferenceNumbers().getType(i));
				deletedReferenceNumberVO.setSequence(ordRefNbrBuffers.getReferenceNumbers().getSequence(i));
				deletedReferenceNumberVO.setCustomerCode(ordRefNbrBuffers.getReferenceNumbers().getCustomerCode(i));
				deletedReferenceNumberVO.setSiteID(ordRefNbrBuffers.getReferenceNumbers().getSiteID(i));
				deletedReferenceNumberVO.setAddressID(ordRefNbrBuffers.getReferenceNumbers().getAddressID(i));
				deletedReferenceNumberVO.setDepartment(ordRefNbrBuffers.getReferenceNumbers().getDepartment(i));
				deletedReferenceNumberVO
						.setReferenceNumberI(ordRefNbrBuffers.getReferenceNumbers().getReferenceNumberI(i));
				LineItemVO lineItemVO = new LineItemVO();
				lineItemVO.setStopLineItemI(ordRefNbrBuffers.getReferenceNumbers().getStopLineItemI(i));
				lineItemVO.setHazF("N");
				deletedReferenceNumberVO.setLineItemVO(lineItemVO);
				delRefNbrList.add(deletedReferenceNumberVO);
			}
		}
		return delRefNbrList;
	}

	// Update Ref Number
	public List<UpdatedReferenceNumberVO> fetchUpdateReferenceNumberVO(OperationalPlanEvent operationalPlanEvent,
			List<OperationalPlanReferenceNumberDTO> referenceNumberDTOs, ReferenceNumbersLinkBuffers ordRefNbrBuffers,
			Oee5InputChannelData input, OperationalPlanReferenceNumberDTO referenceNumber, String entity) {

		// Make reference number uppercase
		String refValue = Optional.ofNullable(referenceNumber)
				.map(OperationalPlanReferenceNumberDTO::getReferenceNumberValue).map(refVAlue -> refVAlue.toUpperCase()).orElse("");
		referenceNumber.setReferenceNumberValue(refValue);
		List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
		for (int i = 0; i < ordRefNbrBuffers.getNbrOfRefNbrs(); i++) {
			if (CollectionUtils.isNotEmpty(operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanReferenceNumbers())) {
				for (OperationalPlanReferenceNumberDTO referenceNumberDTO : referenceNumberDTOs) {
					for (Oee5InStpLine oee5OutStpLine : input.getOee5InStpBuffer5()) {
						for (OperationalPlanStopDTO stopDTO : operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops()) {
							// Make reference number uppercase
							referenceNumberDTO.setReferenceNumberValue(referenceNumberDTO.getReferenceNumberValue().toString().toUpperCase());
							OperationalPlanStopItemDTO stopItem = itemReferenceNumberHelper.getStopItemIfTiedToReferenceNumber(referenceNumberDTO, stopDTO);
								updRefNbrList = populateUpdateReferenceNumber(operationalPlanEvent, ordRefNbrBuffers,
										input, i, entity, referenceNumber, oee5OutStpLine, stopDTO, updRefNbrList, stopItem);
								break;
						}
						break;
					}
					break;
				}
				break;
			}
			break;
		}
		return updRefNbrList;
	}
	
	private List<UpdatedReferenceNumberVO> populateUpdateReferenceNumber(OperationalPlanEvent operationalPlanEvent,
			ReferenceNumbersLinkBuffers ordRefNbrBuffers, Oee5InputChannelData input, int i, String entity,
			OperationalPlanReferenceNumberDTO referenceNumberDTO, Oee5InStpLine oee5OutStpLine, OperationalPlanStopDTO stopDTO, List<UpdatedReferenceNumberVO> updRefNbrList, OperationalPlanStopItemDTO stopItem) {
		
		UpdatedReferenceNumberVO updatedReferenceNumberVO = new UpdatedReferenceNumberVO();
		updatedReferenceNumberVO.setOldReferenceNumberType(
				ordRefNbrBuffers.getReferenceNumbers().getType(i).toUpperCase());
		updatedReferenceNumberVO.setOldReferenceNumber(
				ordRefNbrBuffers.getReferenceNumbers().getNumber(i));
		updatedReferenceNumberVO
				.setOldSequence(ordRefNbrBuffers.getReferenceNumbers().getSequence(i));
		updatedReferenceNumberVO.setOldCustomerCode(
				ordRefNbrBuffers.getReferenceNumbers().getCustomerCode(i));
		updatedReferenceNumberVO
				.setOldSiteID(ordRefNbrBuffers.getReferenceNumbers().getSiteID(i));
		updatedReferenceNumberVO.setOldAddressID(
				ordRefNbrBuffers.getReferenceNumbers().getAddressID(i));
		updatedReferenceNumberVO.setOldDepartment(
				ordRefNbrBuffers.getReferenceNumbers().getDepartment(i));
		updatedReferenceNumberVO.setOldReferenceNumberI(ordRefNbrBuffers.getReferenceNumbers().getReferenceNumberI(i));
		updatedReferenceNumberVO.setReferenceNumberI(ordRefNbrBuffers.getReferenceNumbers().getReferenceNumberI(i));
		LineItemVO lineItemVO = new LineItemVO();
		lineItemVO.setHazF("N");
		updatedReferenceNumberVO.setLineItemVO(lineItemVO);
		Timestamp ts = null;
		try {
			ts = new Timestamp(df
					.parse(ordRefNbrBuffers.getReferenceNumbers().getLastUpdated(i)).getTime());
			updatedReferenceNumberVO.setLstUpdS(ts);
			updatedReferenceNumberVO.setLastUpdated(ts.toString());
		} catch (ParseException e) {
			log.error(e.getMessage(), e);
		}
		
		referenceNumberBuilder.populateUpdateReferenceNumberList(updatedReferenceNumberVO, referenceNumberDTO,
				oee5OutStpLine, stopDTO, operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops().size(), updRefNbrList, stopItem);
		updatedReferenceNumberVO.getLineItemVO().setStopLineItemI(ordRefNbrBuffers.getReferenceNumbers().getStopLineItemI(i));
		referenceNumberBuilder.populateUpdateOrderLevelReference(updatedReferenceNumberVO, referenceNumberDTO,
				input, entity, updRefNbrList);
		log.info("updatedReferenceNumberVO >>>>>>>>>>>>>>>>>>>> {}",CommonUtils.asString(updatedReferenceNumberVO));
		return updRefNbrList;
	}

	
	/*public List<UpdatedReferenceNumberVO> processReferenceNumberUpdateForStopItem(
			ReferenceNumbersLinkBuffers ordRefNbrBuffers, List<OperationalPlanReferenceNumberDTO> referenceNumberDTOsToUpdate,
			OperationalPlanStopItemDTO stopItem, int numberOfStops, int stopSequenceNo) {
		log.info("processReferenceNumberUpdateForStopItem()");
		List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
	
		for (int i = 0; i < ordRefNbrBuffers.getNbrOfRefNbrs(); i++) {
			int legacyStopSequence = ordRefNbrBuffers.getReferenceNumbers().getSequence(i);
			for (OperationalPlanReferenceNumberDTO referenceNumberDTO : referenceNumberDTOsToUpdate) {
				int omStopSequence = stopSequenceNo;
				if (legacyStopSequence == 99) {
					legacyStopSequence = numberOfStops;
				}

				if (ordRefNbrBuffers.getReferenceNumbers().getNumber(i)
						.equalsIgnoreCase(referenceNumberDTO.getReferenceNumberValue())
						&& ordRefNbrBuffers.getReferenceNumbers().getType(i)
								.equalsIgnoreCase(referenceNumberDTO.getReferenceNumberLevelType().getReferenceNumberLevelTypeCode().toUpperCase())
						&& legacyStopSequence == omStopSequence) {
					// Update Old Values
					UpdatedReferenceNumberVO updatedReferenceNumberVO = new UpdatedReferenceNumberVO();
					updatedReferenceNumberVO
							.setOldReferenceNumberType(ordRefNbrBuffers.getReferenceNumbers().getType(i));
					updatedReferenceNumberVO.setOldReferenceNumber(ordRefNbrBuffers.getReferenceNumbers().getNumber(i));
					updatedReferenceNumberVO.setOldSequence(ordRefNbrBuffers.getReferenceNumbers().getSequence(i));
					updatedReferenceNumberVO
							.setOldCustomerCode(ordRefNbrBuffers.getReferenceNumbers().getCustomerCode(i));
					updatedReferenceNumberVO.setOldSiteID(ordRefNbrBuffers.getReferenceNumbers().getSiteID(i));
					updatedReferenceNumberVO.setOldAddressID(ordRefNbrBuffers.getReferenceNumbers().getAddressID(i));
					updatedReferenceNumberVO.setOldDepartment(ordRefNbrBuffers.getReferenceNumbers().getDepartment(i));
					updatedReferenceNumberVO
							.setReferenceNumberI(ordRefNbrBuffers.getReferenceNumbers().getReferenceNumberI(i));

					// Set New Values
					updatedReferenceNumberVO.setReferenceNumberType(ordRefNbrBuffers.getReferenceNumbers().getType(i));
					updatedReferenceNumberVO.setSequence(ordRefNbrBuffers.getReferenceNumbers().getSequence(i));
					updatedReferenceNumberVO.setReferenceNumber(ordRefNbrBuffers.getReferenceNumbers().getNumber(i));
					updatedReferenceNumberVO.setParentReferenceNumberI(
							ordRefNbrBuffers.getReferenceNumbers().getParentReferenceNumberI(i));
					updatedReferenceNumberVO.setSiteID(ordRefNbrBuffers.getReferenceNumbers().getSiteID(i));
					updatedReferenceNumberVO.setAddressID(ordRefNbrBuffers.getReferenceNumbers().getAddressID(i));
					updatedReferenceNumberVO.setCustomerCode(ordRefNbrBuffers.getReferenceNumbers().getCustomerCode(i));
					updatedReferenceNumberVO.setDepartment(ordRefNbrBuffers.getReferenceNumbers().getDepartment(i));

					updatedReferenceNumberVO.setQuantity(stopItem.getPackagingUnitQuantity() == null ? 0
							: stopItem.getPackagingUnitQuantity());
					updatedReferenceNumberVO
							.setWeight(stopItem.getTotalItemWeight() == null ? 0 : stopItem.getTotalItemWeight().doubleValue());
					updatedReferenceNumberVO
							.setVolume(stopItem.getItemVolume() == null ? 0 : stopItem.getItemVolume().intValue());

					updRefNbrList.add(updatedReferenceNumberVO);
				}
			}
		}
		return updRefNbrList;
	}*/
	
}
