package com.jbhunt.loadplannig.integration.backfill.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SpotDBCallDTO {
	private String areaId="";
    private String trailerCustomerCode ="";
    private String trailerCityState ="";
    private String chassisPrefix ="";
    private String chassisNumber ="";
    private String payDHFlag ="";
    private String dropTrailerFlag ="";
    private String verfityMessageFlag ="";
    private String overwriteFlag ="";
    private String warningFlag ="";
    private String dhWarningFlag = "";
    private String filler = "";
}
