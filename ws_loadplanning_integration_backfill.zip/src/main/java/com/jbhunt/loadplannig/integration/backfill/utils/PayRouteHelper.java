package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.HistoryDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.JobSegment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OperActPay;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.ResourceCommunicationLog;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TJob;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.CallHistoryRespository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.JobSegmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OperationalActPayRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TJobRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.services.LoadplanningIntegrationOWObackfillService;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.lmc365i.lmc365.LMC365Port;
import com.request.lmc365i.lmc365.ProgramInterface.Lm365InputArea;
import com.response.lmc365i.lmc365.ProgramInterface.Lm365OutputArea;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class PayRouteHelper {

	private final LMC365Port lmc365Port;
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;
	private final OrderLoadRepository orderLoadRepository;
	private final CallHistoryRespository callHistoryRespository;
	private final TJobRepository tJobRepository;
	private final OperationalActPayRepository operationalActPayRepository;
	private final JobSegmentRepository jobSegmentRepository;

	public void populateLm365InputArea(Integer orderId, OperationalPlanDTO operationalPlanDTO) {

		Lm365InputArea inputArea = new Lm365InputArea();
		HistoryDTO historyDto = new HistoryDTO();
		inputArea.setLm365OrdId(orderId);
		inputArea.setLm365OrdLocSw("M");
		TOrder orderSync = Optional.ofNullable(orderLoadRepository.findByOrderId(orderId))
				.orElseThrow(() -> new JBHuntRuntimeException("Order does not exist."));
		Short dispatchNumber = orderSync.getDispatchNumber();
		if (dispatchNumber > 0) {
			inputArea.setLm365OrdDispNbr(dispatchNumber);
			formHistoryDTO(orderId, dispatchNumber, historyDto);
			inputArea.setLm365ContRecNbr(Optional.ofNullable(historyDto.getLegacyCallSequenceNumber())
					.orElseThrow(() -> new JBHuntRuntimeException("Legacy Call Sequence Number does not exist.")));
			inputArea.setLm365DpContact(createDpContact(operationalPlanDTO, historyDto));
			inputArea.setLm365Userid(operationalPlanDTO.getCreateUserId());
			inputArea.setLm365OperId(Optional.ofNullable(historyDto.getCallTakerInits())
					.orElseThrow(() -> new JBHuntRuntimeException("CallerTakerInits does not exist.")));
			inputArea.setLm365InputFiller(" ");
			inputArea.setLm365CallingPgm("CHKCALL");
			inputArea.setLm365NeedRollbackSw("Y");

			Lm365OutputArea output = CommonUtils.soapCall((i) -> lmc365Port.lmc365Operation(i), inputArea);
			if (!"S".equalsIgnoreCase(output.getLm365ReturnFlag())
					&& output.getLm365ErrorMessage().contains("WARNING- PF6 TO OVERRIDE")) {
				inputArea.setLm365DpContact(
						inputArea.getLm365DpContact().substring(0, inputArea.getLm365DpContact().length() - 1) + "Y");
				Lm365OutputArea overRideoutput = CommonUtils.soapCall((i) -> lmc365Port.lmc365Operation(i), inputArea);
				if (!"S".equalsIgnoreCase(overRideoutput.getLm365ReturnFlag())) {
					throw new JBHuntRuntimeException(overRideoutput.getLm365ErrorMessage());
				}
			} else if (!"S".equalsIgnoreCase(output.getLm365ReturnFlag())) {
				throw new JBHuntRuntimeException(output.getLm365ErrorMessage());
			}

			backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO,
					EventStatusEnum.COMPLETED.name(), "");
		} else {
			throw new JBHuntRuntimeException("Dispatch is Not done");
		}
	}

	private void formHistoryDTO(Integer orderId, Short dispatchNumber, HistoryDTO historyDto) {
		List<ResourceCommunicationLog> resourceCommunicationLogList = callHistoryRespository.getCallHistory(orderId,
				dispatchNumber);
		if (!CollectionUtils.isEmpty(resourceCommunicationLogList)) {
			ResourceCommunicationLog resourceCommunicationLog = resourceCommunicationLogList
					.get((resourceCommunicationLogList.size() - 1));
			Integer jobId = resourceCommunicationLog.getTDspJobXrf().getJobId();
			Integer srcId = resourceCommunicationLog.getResourceCommunicationLogId();
			TJob tJob = tJobRepository.findByJobId(jobId);
			List<OperActPay> payList = operationalActPayRepository.findBySrcId(orderId, srcId, jobId);
			List<JobSegment> jobSegmentList = jobSegmentRepository.findByJobId(jobId);
			historyDto.setResourceCommunicationLogId(srcId);
			historyDto.setLegacyCallSequenceNumber(resourceCommunicationLog.getLegacySequenceNumber());
			historyDto.setJobId(jobId);
			historyDto.setDriverCode1(resourceCommunicationLog.getDriverCode1());
			historyDto.setRate1("0.0000");
			historyDto.setSaveRate1("0.0000");
			historyDto.setRate2("0.0000");
			historyDto.setSaveRate2("0.0000");
			historyDto.setPerDiem1("0.0000");
			historyDto.setSavePerDiem1("0.0000");
			historyDto.setPerDiem2("0.0000");
			historyDto.setSavePerDiem2("0.0000");
			historyDto.setStartHub(0);
			historyDto.setEndHub(0);
			if (!CollectionUtils.isEmpty(jobSegmentList)) {
				Optional<JobSegment> startJob = jobSegmentList.stream().findFirst();
				Optional<JobSegment> endJob = jobSegmentList.stream().skip((long) (jobSegmentList.size() - 1))
						.findFirst();
				if (startJob.isPresent()) {
					historyDto.setStartHub(startJob.get().getBeginHubMiles());
				}
				if (endJob.isPresent()) {
					historyDto.setEndHub(endJob.get().getEndHubMiles());
				}
			}
			if (!CollectionUtils.isEmpty(payList)) {
				IntStream.range(0, payList.size()).forEach(i -> {
					OperActPay pay = payList.get(i);
					String activity = pay.getActivityType();
					if (activity.trim().equals("DRIVING")) {
						Short pos = pay.getPosition();
						if (pos == 1) {
							historyDto.setRate1(pay.getRate1());
							historyDto.setSaveRate1(pay.getRate1());
						}
						if (pos == 2) {
							historyDto.setRate2(pay.getRate1());
							historyDto.setSaveRate2(pay.getRate1());
						}
					} else if (activity.trim().equals("PER DIEM")) {
						Short pos = pay.getPosition();
						if (pos == 1) {
							historyDto.setPerDiem1(pay.getRate1());
							historyDto.setSavePerDiem1(pay.getRate1());
						}
						if (pos == 2) {
							historyDto.setPerDiem2(pay.getRate1());
							historyDto.setSavePerDiem2(pay.getRate1());
						}
					}
				});
			}
			historyDto.setDriverCode2(tJob.getDriverCode2());
			String callTaker = resourceCommunicationLog.getCallTakerInit();
			if (resourceCommunicationLog.getUserSignOn().trim().length() > 0) {
				if (!resourceCommunicationLog.getUserSignOn().trim().equals(callTaker.trim())) {
					callTaker = resourceCommunicationLog.getUserSignOn().trim();
				}
			}
			historyDto.setCallTakerInits(callTaker);
		} else {
			throw new JBHuntRuntimeException(
					"No Records found in ALI.RSC_CMN_LOG A, ALI.TDSP_JOB_XRF for given OrderId and Dispatch number");
		}
	}

	private String createDpContact(OperationalPlanDTO operationalPlan, HistoryDTO historyDto) {
		StringBuilder sb1 = new StringBuilder();
		sb1.append(updateDispatch(historyDto));
		sb1.append(addTrailingZeros(historyDto.getStartHub()));
		sb1.append(addTrailingZeros(historyDto.getEndHub()));
		sb1.append(CommonConstants.SPACE_10);
		sb1.append(getCityName(operationalPlan));
		sb1.append(" ");
		return sb1.toString();
	}

	private String updateDispatch(HistoryDTO historyDto) {
		StringBuilder sb = new StringBuilder();
		if (!StringUtils.isEmpty(historyDto.getDriverCode1())) {
			sb.append(historyDto.getRate1().trim());
			if (!historyDto.getRate1().trim().equals(historyDto.getSaveRate1())) {
				sb.append("Y");
			} else {
				sb.append("N");
			}
			sb.append(historyDto.getPerDiem1().trim());
			if (!historyDto.getPerDiem1().trim().equals(historyDto.getSavePerDiem1())) {
				sb.append("Y");
			} else {
				sb.append("N");
			}
		}
		if (!StringUtils.isEmpty(historyDto.getDriverCode2())) {
			sb.append(historyDto.getRate2().trim());
			if (!historyDto.getRate2().trim().equals(historyDto.getSaveRate2())) {
				sb.append("Y");
			} else {
				sb.append("N");
			}
			sb.append(historyDto.getPerDiem2().trim());
			if (!historyDto.getPerDiem2().trim().equals(historyDto.getSavePerDiem2())) {
				sb.append("Y");
			} else {
				sb.append("N");
			}
		}
		return padSpaces(sb, 28);
	}

	private String getCityName(OperationalPlanDTO operationalPlan) {
		StringBuilder cityAndType = new StringBuilder();
		HashMap<Integer, String> orgDesMap = new HashMap<>();
		operationalPlan.getOperationalPlanPayRouteSegments().forEach(payRouteSegment -> {
			String type = payRouteSegment.getPayRouteSegmentStatus().getPayRouteSegmentStatusCode();
			if (type.trim().equals("Empty")) {
				type = "E";
			} else {
				type = "L";
			}

			City originCityState = null;
			if (orgDesMap.size() == 0) {
				originCityState = loadplanningIntegrationOWObackfillService
						.getCityStateCodeByCityID(payRouteSegment.getOriginCityId());
				cityAndType.append(originCityState.getCtyStC().trim());
			}
			City destCityState = loadplanningIntegrationOWObackfillService
					.getCityStateCodeByCityID(payRouteSegment.getDestinationCityId());

			cityAndType.append(" " + type + destCityState.getCtyStC().trim());
			orgDesMap.put(0, cityAndType.toString());
		});
		return padSpaces(cityAndType, 770);
	}

	private String padSpaces(StringBuilder cityStateAndType, int padSpace) {
		int rest = padSpace - cityStateAndType.length();
		for (int i = 0; i < rest; i++) {
			cityStateAndType.append(" ");
		}
		return cityStateAndType.toString();
	}

	private String addTrailingZeros(Integer number) {
		String str = String.format("%010d", Optional.ofNullable(number).orElse(0));
		return str;
	}

}
