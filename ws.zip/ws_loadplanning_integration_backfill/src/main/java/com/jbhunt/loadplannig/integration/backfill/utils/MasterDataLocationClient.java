package com.jbhunt.loadplannig.integration.backfill.utils;

import com.jbhunt.loadplannig.integration.backfill.dto.LocationTimeZone;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Service
@FeignClient(name="masterDataLocationClient", url="${masterDataLocationService.ribbon.listOfServers}")
public interface MasterDataLocationClient {

    String MILLISECOND_VALUE = "20000";

    @GetMapping("locations/search/findbylocation/{locationId}")
    LocationTimeZone getLocationTime(@PathVariable(name = "locationId") Integer locationId);

}