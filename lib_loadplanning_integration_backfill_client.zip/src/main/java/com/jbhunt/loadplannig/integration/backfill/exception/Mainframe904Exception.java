package com.jbhunt.loadplannig.integration.backfill.exception;

public class Mainframe904Exception extends RuntimeException {
    public Mainframe904Exception(String message){
        super(message);
    }
}
