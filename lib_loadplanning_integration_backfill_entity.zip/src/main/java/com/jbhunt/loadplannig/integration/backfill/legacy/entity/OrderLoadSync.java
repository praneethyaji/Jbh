package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ORD_LD_SYNC", schema = "ALI")
public class OrderLoadSync implements Serializable {

	private static final long serialVersionUID = 1967368022006563051L;

	@Id
	 @Column(name = "ORD_LD_SYNC_I")
	 private Integer orderSyncID;
	 
	 @Column(name = "ORD_I")
	 private Integer legacyOrderID;
	 
	 @Column(name = "ORD_CRT_SYS_C")
	 private String orderCreatedSysCode;
	 
	 @Column(name = "CRT_S")
	 private Date orderCreatedTimeStamp;
	 
	 @Column(name = "CRT_UID")
	 private String orderCreatedUserID;
	 
	 @Column(name = "CRT_PGM_C")
	 private String orderCreatedPgmCode;
	 
	 @Column(name = "LST_UPD_S")
	 private Date lastUpdatedTimeStamp;
	 
	 @Column(name = "LST_UPD_UID")
	 private String lastUpdatedUserID;
	 
	 @Column(name = "LST_UPD_PGM_C")
	 private String lastUpdatedPgmCode;
	 
	 @Column(name = "NEW_ORD_I")
	 private Integer scmOrderID;
	 
	 @Column(name = "ORD_TRAK_NBR")
	 private String orderTrackNumber ;
	 
	 @Column(name = "SPR_CUS_C")
	 private String shipperCustomerCode;
	 
	 @Column(name = "RCV_CUS_C")
	 private String receiverCustomerCode;
	 
	 @Column(name = "PRM_REF_NBR_TYP_C")
	 private String referenceNumberTypeCode;
	 
	 @Column(name = "PRM_REF_NBR_VAL")
	 private String refNbrValue;
	 
	 @Column(name = "RT_I")
    private Integer routeID;

	@Column(name = "XDIV_IND")
	private String xdivInd;

}
