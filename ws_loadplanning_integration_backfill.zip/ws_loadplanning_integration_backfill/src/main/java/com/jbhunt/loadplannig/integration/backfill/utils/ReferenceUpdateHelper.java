package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersBuffer;
import com.jbhunt.biz.refNumber.vo.AddNewReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.DeletedReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.UpdatedReferenceNumberVO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor	
public class ReferenceUpdateHelper {
	
	private final ReferenceBufferHelper referenceBufferHelper;
	private final ReferenceNumberUpdateServiceHelper referenceNumberUpdateHelper;
	
	 public int populateReferenceNumberForOthers(List<UpdatedReferenceNumberVO> updRefNbrList,
	            List<AddNewReferenceNumberVO> newRefNbrList, List<DeletedReferenceNumberVO> delRefNbrList,
	            ReferenceNumbersBuffer referenceNumbers, int orderReferenceNumbersCount) {
	        int refNbrInsertCnt = 0;
	        ReferenceNumbersBuffer referenceNumber=null;
	        if (CollectionUtils.isNotEmpty(updRefNbrList)) {
	            for (UpdatedReferenceNumberVO referenceNumberVO : updRefNbrList) {
	                if (referenceBufferHelper.validate(referenceNumberVO)) {
	                    int refNbrUpdIndex = referenceBufferHelper.fetchOldReferenceNumberIndex(referenceNumbers,
	                            referenceNumberVO);
	                    log.debug("UpdateIndex " + refNbrUpdIndex);
	                    if (refNbrUpdIndex != -1) {
	                        referenceNumber= referenceBufferHelper.assignNewValues(referenceNumbers, referenceNumberVO, refNbrUpdIndex,
	                                "UPDATE");
	                        log.debug("referenceNumber " + referenceNumber.getReferenceNumberI(0));
	                        refNbrInsertCnt++;
	                    }
	                }
	            }
	        }
	        refNbrInsertCnt = processReferenceNumberCreation(newRefNbrList, referenceNumbers, orderReferenceNumbersCount,
					refNbrInsertCnt);
	        referenceNumberUpdateHelper.populateReferenceNumberForDeletion(delRefNbrList, referenceNumbers);
	        return refNbrInsertCnt;
	    }

		private int processReferenceNumberCreation(List<AddNewReferenceNumberVO> newRefNbrList,
				ReferenceNumbersBuffer referenceNumbers, int orderReferenceNumbersCount, int refNbrInsertCnt) {
			if (CollectionUtils.isNotEmpty(newRefNbrList)) {
	            for (AddNewReferenceNumberVO referenceNumberVO : newRefNbrList) {
	                if (referenceBufferHelper.validate(referenceNumberVO)) {
	                	referenceNumberUpdateHelper.newReferenceNumberInsert(referenceNumbers, orderReferenceNumbersCount, refNbrInsertCnt,
	                            referenceNumberVO);
	                    refNbrInsertCnt++;
	                }
	            }
	        }
			return refNbrInsertCnt;
		}

	    public int populateRefNbrForLineItems(List<UpdatedReferenceNumberVO> updRefNbrList,
	            List<AddNewReferenceNumberVO> newRefNbrList, List<DeletedReferenceNumberVO> delRefNbrList,
				ReferenceNumbersBuffer referenceNumbers, int orderReferenceNumbersCount) {
			int refNbrInsertCnt = 0;
			updateLineItems(updRefNbrList, referenceNumbers);
			if (CollectionUtils.isNotEmpty(newRefNbrList)) {
				for (AddNewReferenceNumberVO newRefNbr : newRefNbrList) {
					if (referenceBufferHelper.validateForInsert(newRefNbr)) {
						referenceNumberUpdateHelper.newReferenceNumberInsert(referenceNumbers, orderReferenceNumbersCount,
								refNbrInsertCnt, newRefNbr);
						refNbrInsertCnt++;
					}
				}
			}

			populateDeleteLineItemList(delRefNbrList, referenceNumbers);
			return refNbrInsertCnt;
		}

		private void populateDeleteLineItemList(List<DeletedReferenceNumberVO> delRefNbrList,
				ReferenceNumbersBuffer referenceNumbers) {
			if (CollectionUtils.isNotEmpty(delRefNbrList)) {
				for (DeletedReferenceNumberVO delRefNbr : delRefNbrList) {
					if (referenceNumberUpdateHelper.validateForUpdateDelete(delRefNbr)) {
						int refNbrDelIndex = referenceBufferHelper.fetchReferenceNumberIndexLTL(referenceNumbers,
								delRefNbr);
						log.debug("index for populateDeleteLineItemList" + refNbrDelIndex);
						if (refNbrDelIndex != -1) {
							referenceNumbers.setAction("DELETE", refNbrDelIndex);
						}
					}
				}
			}
		}

		private void updateLineItems(List<UpdatedReferenceNumberVO> updRefNbrList,
				ReferenceNumbersBuffer referenceNumbers) {
			ReferenceNumbersBuffer referenceNumber;
			if (CollectionUtils.isNotEmpty(updRefNbrList)) {
				for (UpdatedReferenceNumberVO updRefNbr : updRefNbrList) {
					if (referenceNumberUpdateHelper.validateForUpdateDelete(updRefNbr)) {
						int refNbrUpdIndex = referenceNumberUpdateHelper.getOldReferenceNumberIndexLTL(referenceNumbers,
								updRefNbr);
						log.debug("updateLineItemsIndex " + refNbrUpdIndex);
						if (refNbrUpdIndex != -1) {
							referenceNumber = referenceBufferHelper.assignNewValues(referenceNumbers, updRefNbr,
									refNbrUpdIndex, "UPDATE");
							log.debug("referenceNumber " + referenceNumber.getAddressID(0));
						}
					}
				}
			}
		}

}
