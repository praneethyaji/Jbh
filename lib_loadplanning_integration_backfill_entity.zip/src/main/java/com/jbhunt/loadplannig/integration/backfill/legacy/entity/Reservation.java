package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "RSC_RSV", schema = "ALI")
public class Reservation implements Serializable { 

	private static final long serialVersionUID = -1444081815481988657L;
	
	 @Id
	 @Column(name = "RSC_RSV_I")
	 private Integer reservationId; 
	
	
	 @Column(name = "LST_UPD_S")
	 private String lastUpdateTimeStamp;
	 
	 @Column(name="REQ_TO_ETY_KEY_I")
	 private Integer reservedOrderId; 
	 
	 
	 @Column(name="REC_STT")
	 private String activationStatus; 
}
