package com.jbhunt.loadplannig.integration.backfill.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jbhunt.biz.securepid.PIDCredentials;

@Configuration
public class PIDConfiguration {

      @Bean
	public PIDCredentials pidCredentials(@Value("${DOMAIN_PID}") String userId, @Value("${DOMAIN_PASSWORD}") String password) {
		return new PIDCredentials(userId, password);
	}

}