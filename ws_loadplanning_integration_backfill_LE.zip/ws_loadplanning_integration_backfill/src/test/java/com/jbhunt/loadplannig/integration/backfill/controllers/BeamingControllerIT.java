package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.relaxedRequestFields;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.document;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.operations.equipmentgroup.dto.OpexEquipmentLocationUpdateDTO;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc362i.lmc362.LMC362Port;
import com.lmc366i.lmc366.LMC366Port;
import com.request.lmc362i.lmc362.ProgramInterface.Lmc362IJavaSentVariables;
import com.request.lmc366i.lmc366.ProgramInterface.Wo66InputArea;
import com.response.lmc362i.lmc362.ProgramInterface.Lmc362OReturnToJava;
import com.response.lmc362i.lmc362.ProgramInterface.Lmc362OReturnToJava.Lmc362OErrorFields;
import com.response.lmc366i.lmc366.ProgramInterface.Wo66OutputArea;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class BeamingControllerIT {

	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http").host("loadplanning-test.jbhunt.com")
			.removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private LMC362Port lmc362Port;

	@MockBean
	private LMC366Port lmc366Port;

	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	private EquipmentRepository equipmentRepository;

	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void testBeaming() throws Exception {
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		String responseMasterDataLocation = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataLocation.json"));

		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[1692276]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/62980"))
				.willReturn(aResponse().withHeader("Content-type", "application/json")
						.withBody(responseMasterDataLocation).withStatus(200)));

		OpexEquipmentLocationUpdateDTO equipmentLocationUpdateDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/Beaming.json")),
				OpexEquipmentLocationUpdateDTO.class);
		Lmc362OReturnToJava output = new Lmc362OReturnToJava();
		Lmc362OErrorFields errorfields = new Lmc362OErrorFields();
		errorfields.setLmc362OErrorFlag("N");
		errorfields.setLmc362OErrorMessage("");
		output.setLmc362OErrorFields(errorfields);
		when(lmc362Port.lmc362Operation(Mockito.any(Lmc362IJavaSentVariables.class))).thenReturn(output);
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessBeaming", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processBeamingRequest())))
				.contentType(ContentType.JSON).body(equipmentLocationUpdateDTO)
				.post("/ws_loadplanning_integration_backfill/backfill/equipments/locations");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

	private static FieldDescriptor[] processBeamingRequest() {
		return new FieldDescriptor[] {
				fieldWithPath("equipmentId").description("Represent the given equipmentId to update location"),
				fieldWithPath("locationId").description("Represent to update the given location for that equipment"),
				fieldWithPath("cityId").description("Represent to update the given city for that equipment"),
				fieldWithPath("addressId").description("Represent to update the given addressId for that equipment"),
				fieldWithPath("addressLine1")
						.description("Represent to update the given detail address area for that equipment"),
				fieldWithPath("addressLine2")
						.description("Represent to update the given detail address area for that equipment"),
				fieldWithPath("cityName").description("Represent to update the given cityname for that equipment"),
				fieldWithPath("stateCode").description("Represent to update the given stateCode for that equipment"),
				fieldWithPath("stateName").description("Represent to update the given stateName for that equipment")
						.optional().type(String.class),
				fieldWithPath("countryCode").description("Represent to update the given countryCode for that equipment")
						.optional().type(String.class),
				fieldWithPath("countryName").description("Represent to update the given countryName for that equipment")
						.optional().type(String.class),
				fieldWithPath("postalCode").description("Represent to update the given postalCode for that equipment")
						.optional().type(String.class) };
	}

	@Test
	public void testBeamingWithoutPrefix() throws Exception {
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		String responseMasterData = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataAssetWithOutPrefix.json"));
		String responseMasterDataLocation = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataLocation.json"));

		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[1692276]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/62980"))
				.willReturn(aResponse().withHeader("Content-type", "application/json")
						.withBody(responseMasterDataLocation).withStatus(200)));

		String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

		wireMockServer.stubFor(get(
				urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999"))
						.willReturn(aResponse().withHeader("Content-Type", "application/json")
								.withBody(crossReferenceResponse).withStatus(200)));

		TEquipment tEquipment = new TEquipment();
		tEquipment.setLastUpdatedTimestamp("2019-07-18-01.59.38.506717");
		Mockito.when(equipmentRepository.fetchEqpDetailsByEqpId("40566279")).thenReturn(tEquipment);

		OpexEquipmentLocationUpdateDTO equipmentLocationUpdateDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/Beaming.json")),
				OpexEquipmentLocationUpdateDTO.class);
		Wo66OutputArea output = new Wo66OutputArea();
		output.setWo66ReturnFlag("N");
		output.setWo66ErrorMessage("");
		when(lmc366Port.lmc366Operation(Mockito.any(Wo66InputArea.class))).thenReturn(output);
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(equipmentLocationUpdateDTO)
				.post("/ws_loadplanning_integration_backfill/backfill/equipments/locations");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

}
