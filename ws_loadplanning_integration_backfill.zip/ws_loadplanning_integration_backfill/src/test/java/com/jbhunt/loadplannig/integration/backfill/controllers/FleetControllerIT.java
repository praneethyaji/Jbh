package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.jbhunt.operations.admin.operationalgroup.dto.event.OperationalGroupEvent;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc367i.lmc367.LMC367Port;
import com.request.lmc367i.lmc367.ProgramInterface.Wo67InputArea;
import com.response.lmc367i.lmc367.ProgramInterface.Wo67OutputArea;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class FleetControllerIT {

	@MockBean
	PIDCredentials pidCredentials;
	
	@MockBean
	LocationProfileDTOs locationProfileDTOs;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http")
			.host("operationsexecutionswitchplan.jbhunt.com").removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

	private static final String FLEET_PATH = "/json/Fleet.json";

	
	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private LMC367Port lmc367Port;


	@MockBean
	@Qualifier("sqlServerjdbcTemplate")
	private JdbcTemplate sqlServerjdbcTemplate;
	
	@MockBean 
	private  EquipmentRepository equipmentRepository;
	
	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void testCreateFleet() throws Exception {

		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		
		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		
		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
	            .willReturn(aResponse()
	                    .withHeader("Content-Type", "application/json")
	                    .withBody(responseMasterData).withStatus(200)));
		

		OperationalGroupEvent operationalGroupEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(FLEET_PATH)),
				OperationalGroupEvent.class);

		Wo67OutputArea output  =  new Wo67OutputArea();

		when(lmc367Port.lmc367Operation(Mockito.any(Wo67InputArea.class))).thenReturn(output);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalGroupEvent)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalevents");
		System.out.println("response ---- >>> " + response.asString());

		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}
	
	@Test
	public void testUpdateFleet() throws Exception {

		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		
		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.willReturn(aResponse()
	                    .withHeader("Content-Type", "application/json")
	                    .withBody(responseMasterData).withStatus(200)));
		
		OperationalGroupEvent operationalGroupEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(FLEET_PATH)),
				OperationalGroupEvent.class);

		Wo67OutputArea output  =  new Wo67OutputArea();

		when(lmc367Port.lmc367Operation(Mockito.any(Wo67InputArea.class))).thenReturn(output);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalGroupEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalevents");
		System.out.println("response ---- >>> " + response.asString());

		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

}
