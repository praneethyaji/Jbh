package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TPndJobAsn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

@RepositoryRestResource
public interface TpndJobAsnRepository extends JpaRepository<TPndJobAsn, Integer> {

	@Query(value = "SELECT TPND_JOB_ASN_ID,EQP_UNT_I,EQP_I,TSK_I,CHAR(ETA_D) AS ETA_D ,CHAR(ETA_H) AS ETA_H ,CHAR(LST_UPD_S) AS LST_UPD_S,RSC_RSV_I FROM ALI.TPND_JOB_ASN WHERE TSK_I=:taskId WITH UR ", nativeQuery = true)
	TPndJobAsn findTPNJobDetailsByTaskId(@Param("taskId") Integer taskId);

	@Query(value = "SELECT TPND_JOB_ASN_ID, TSK_I, EQP_UNT_I, EQP_I, CHAR(ETA_D) AS ETA_D ,CHAR(ETA_H) AS ETA_H ,CHAR(LST_UPD_S) AS LST_UPD_S, RSC_RSV_I FROM ALI.TPND_JOB_ASN WHERE EQP_I = (:eqpId) and TSK_I = (:taskId) WITH UR ", nativeQuery = true)
	List<TPndJobAsn> fetchPreplanDetByTaskIdAndEqpId(@Param("taskId") int taskId, @Param("eqpId") int eqpId);

	@Query(value = "SELECT CHAR(MAX(LST_UPD_S)) FROM ALI.TPND_JOB_ASN WHERE EQP_UNT_I=:equipUnitId AND NOT TSK_I = :lastDspOrderID WITH UR ", nativeQuery = true)
	String getTPNstupdatedTimestampbyEqpUnitId(@Param("equipUnitId") String equipUnitId, @Param("lastDspOrderID") Integer lastDspOrderID);
	
	@Query(value = "SELECT TPND_JOB_ASN_ID, EQP_I, TSK_I, CHAR(ETA_D) AS ETA_D, CHAR(ETA_H) AS ETA_H, EQP_UNT_I, LST_UPD_S, RSC_RSV_I FROM ALI.TPND_JOB_ASN WHERE EQP_UNT_I=:equipUnitId ORDER BY ETA_D DESC, ETA_H DESC FETCH FIRST 1 ROW ONLY WITH UR ", nativeQuery = true)
	TPndJobAsn getMaxEtaDateAndTimeByEqpUnitId(@Param("equipUnitId") String equipUnitId);

}
