package com.jbhunt.loadplannig.integration.backfill.configuration;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;

import javax.annotation.PreDestroy;

@Configuration
@EnableCaching
public class EhCacheConfiguration {

    EhCacheCacheManager ehCacheCacheManager;

    @Bean
    @Primary
    public CacheManager loadplanningIntegrationbackfillCacheManager() {
        ClassPathResource ehCacheConfigFile = new ClassPathResource("ehcache.xml");
        this.ehCacheCacheManager = new EhCacheCacheManager(EhCacheManagerUtils.buildCacheManager(ehCacheConfigFile));
        return ehCacheCacheManager;
    }

    @PreDestroy
    public void destroy() {
        this.ehCacheCacheManager.getCacheManager().shutdown();
    }

}