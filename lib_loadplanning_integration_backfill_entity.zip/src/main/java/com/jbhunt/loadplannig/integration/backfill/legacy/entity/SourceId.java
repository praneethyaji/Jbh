package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Embeddable
@Data
public class SourceId implements Serializable {

	private static final long serialVersionUID = 8625273676164228327L;

	@Column(name = "SEQ_NO_N")
	private Short sequenceNumber;

	@Column(name = "SRCE_ID")
	private Integer srceId;

}