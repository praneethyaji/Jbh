package com.jbhunt.loadplannig.integration.backfill.services;

import java.lang.reflect.Array;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.xml.ws.Holder;

import com.jbhunt.loadplanning.operationalplan.dto.core.*;
import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.dto.TerminateCallDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.PreplanLog;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.BkfilOrdLdAscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.CityRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.PreplanLogRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.SubTaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CheckCallHelper;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.ArrivalCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanCheckCallDTO;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.jbhunt.mdm.dto.LocationProfileDTO;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.lmc363i.lmc363.LMC363Port;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComDraynetVars;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars.Lm36ComCallbackFields;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars.Lm36ComRemarksInfo;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars.Lm36ComRouteInfo;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava;
import com.response.lmc363i.lmc363.ProgramInterface;
import com.response.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaOutputRecord;
import com.response.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJavaOutput;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class CheckCallHelpService extends CheckCallBackfillService {

	private final LMC363Port lmc363Port;
	private final CheckCallHelper checkCallHelper;
	private final OrderLoadRepository orderLoadRepository;
	private final BkfilOrdLdAscRepository bkfilOrdLdAscRepository;
	private final PreplanLogRepository preplanLogRepository;
	private final EquipmentRepository equipmentRepository;
	private final TaskRepository taskRepository;
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final LocationClient locationClient;
	private final SubTaskRepository subTaskRepository;
	private final MasterdataAssetClient masterdataAssetClient;
	private EntityManager entityManager;
	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;
	private final CityRepository cityRepository;

	public void prepareLMC363Request(final OperationalPlanDTO operationalPlanDTO, final String userId,
			final String lastUpdateUserId, final String comment, final Integer operationalPlanId)
			throws JBHuntRuntimeException {

		Lm36ComDraynetVars lm36ComDraynetVars = new Lm36ComDraynetVars();
		lm36ComDraynetVars.setLm36ComCarrier("");
		lm36ComDraynetVars.setLm36ComDataState(CommonConstants.STRING_B);
		lm36ComDraynetVars.setLm36ComTrkRqdFlg(CommonConstants.STRING_Y);
		lm36ComDraynetVars.setLm36ComIeCarrierFlg(CommonConstants.STRING_I);
		Lm36ComStatusUpdateVars lm36ComStatusUpdateVars = new Lm36ComStatusUpdateVars();
		Lm36ComCallbackFields Lm36ComCallbackFields = new Lm36ComCallbackFields();
		lm36ComStatusUpdateVars.setLm36ComCallbackFields(Lm36ComCallbackFields);
		lm36ComStatusUpdateVars.setLm36ComLoadUnldDate(java.time.LocalDate.now().toString().trim());
		lm36ComStatusUpdateVars.setLm36ComLoadUnldTime(java.time.LocalTime.now().toString().trim().substring(0, 4));
		lm36ComStatusUpdateVars.setLm36ComMsgOvrFlg(CommonConstants.STRING_I);
		prepareCommentOrTcallVariables(operationalPlanDTO, operationalPlanId, comment, userId, lastUpdateUserId,
				lm36ComDraynetVars, lm36ComStatusUpdateVars);
	}

	private void prepareCommentOrTcallVariables(OperationalPlanDTO operationalPlanDTO, Integer operationalPlanId,
			String comment, String userId, String lastUpdateUserId, Lm36ComDraynetVars lm36ComDraynetVars,
			Lm36ComStatusUpdateVars lm36ComStatusUpdateVars) {
		List<Integer> listOfNewOrderIds = null;
		if (comment != null && !comment.isEmpty()) {
			lm36ComDraynetVars.setLm36ComCreateUserid(userId);
			lm36ComDraynetVars.setLm36ComUserid(lastUpdateUserId);
			lm36ComStatusUpdateVars.setLm36ComComments(comment);
			lm36ComStatusUpdateVars.setLm36ComCallType(CommonConstants.CALLTYPE_CO);
			listOfNewOrderIds = bkfilOrdLdAscRepository.getNewOrderIdByOperationalPlanId(operationalPlanId);
			lm36ComStatusUpdateVars.setLm36ComCheckCallVars("                  " + CommonConstants.STRING_Y);
		} else {
			lm36ComDraynetVars.setLm36ComCreateUserid(operationalPlanDTO.getCreateUserId());
			lm36ComDraynetVars.setLm36ComUserid(operationalPlanDTO.getLastUpdateUserId());
			lm36ComStatusUpdateVars.setLm36ComCallType(CommonConstants.CALLTYPE_TC);
			listOfNewOrderIds = operationalPlanDTO.getOrderOperationalPlanAssociations().stream()
					.map(OrderOperationalPlanAssociationDTO::getOperationalPlanOrder)
					.map(OperationalPlanOrderDTO::getOrderId).collect(Collectors.toList());
		}
		listOfNewOrderIds.forEach(newOrderId -> {
			log.info("newOrderId: {}", newOrderId);
			preparePayLoadForTorCommentCall(operationalPlanDTO, lm36ComDraynetVars, lm36ComStatusUpdateVars, newOrderId,
					comment);
			final String lm36ComFiller = "";
			Lm36ComCommareaRecord lm36ComCommareaRecord = new Lm36ComCommareaRecord();
			Lm36ComJavaSentVariables lm36ComJavaSentVariables = new Lm36ComJavaSentVariables();
			Lm36ComReturnToJava lm36ComReturnToJava = new Lm36ComReturnToJava();
			javax.xml.ws.Holder<ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder = new Holder<>();
			javax.xml.ws.Holder<String> lm36ComFillerOutputHolder = new Holder<>();
			javax.xml.ws.Holder<ProgramInterface.Lm36ComCommareaOutputRecord> lm36ComCommareaOutputRecordHolder = new Holder<>();
			lm36ComJavaSentVariables.setLm36ComDraynetVars(lm36ComDraynetVars);
			lm36ComJavaSentVariables.setLm36ComStatusUpdateVars(lm36ComStatusUpdateVars);
			lm36ComCommareaRecord.setLm36ComJavaSentVariables(lm36ComJavaSentVariables);
			lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava, lm36ComFiller,
					lm36ComCommareaOutputRecordHolder, lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);
			overRideMethod(lm36ComCommareaRecord, lm36ComReturnToJava, lm36ComFiller, lm36ComCommareaOutputRecordHolder,
					lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);
			backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO,
					EventStatusEnum.COMPLETED.name(), "");
		});
	}

	private void preparePayLoadForTorCommentCall(OperationalPlanDTO operationalPlanDTO,
			Lm36ComDraynetVars lm36ComDraynetVars, Lm36ComStatusUpdateVars lm36ComStatusUpdateVars, Integer newOrderId,
			String comment) {
		final TOrder orderDetails = orderLoadRepository.findLoadDetailsByOrderID(newOrderId);
		if (orderDetails == null) {
			log.error("legac order details not  Found for new orderId: {} and ", newOrderId);
			throw new JBHuntRuntimeException("legacy order details not  Found");
		}
		final PreplanLog preplanLog = preplanLogRepository.getPreplanDetailsByOrd(orderDetails.getOrderId());
		if (preplanLog == null) {
			log.error(" preplan log  details not  Found for  orderId: {} and ", orderDetails.getOrderId());
			throw new JBHuntRuntimeException("preplan log  details not  Found");
		}

		final String equipmentUnitId = equipmentRepository.getEquipmentUntiId(preplanLog.getEquipmentId());
		final Integer jobId = orderLoadRepository.getJobIdbyOrderId(preplanLog.getEquipmentId());
		final String lastLocatonOfTruck = equipmentRepository.getLastLocationOfTruck(preplanLog.getEquipmentId());
		lm36ComDraynetVars.setLm36ComInvertOrd(orderDetails.getOrderId());
		lm36ComDraynetVars.setLm36ComJobId(jobId);
		lm36ComDraynetVars.setLm36ComOrderNbr(orderDetails.getOrdrNumber());
		lm36ComDraynetVars.setLm36ComProject("");
		lm36ComDraynetVars.setLm36ComTrkEqpId(preplanLog.getEquipmentId());
		lm36ComDraynetVars.setLm36ComTrkEqpNbr(equipmentUnitId);

		prepareETADetails(lm36ComStatusUpdateVars, lastLocatonOfTruck, orderDetails, jobId, newOrderId, preplanLog);
		if (comment == null) {
			populateTcallVariables(operationalPlanDTO, lm36ComStatusUpdateVars, preplanLog, orderDetails, lastLocatonOfTruck);
			lm36ComStatusUpdateVars.setLm36ComRouteInfoTable(getRouteDetailsForTcall(operationalPlanDTO,
					orderDetails.getOrderId(), lm36ComStatusUpdateVars.getLm36ComStopSeqNbr()));
		}
	}

	private void prepareETADetails(Lm36ComStatusUpdateVars lm36ComStatusUpdateVars, String lastLocatonOfTruck,
			TOrder orderDetails, Integer jobId, Integer newOrderId, PreplanLog preplanLog) {
		final Map<String, String> eta = prepareETADateAndTime(preplanLog.getEquipmentId());
		lm36ComStatusUpdateVars.setLm36ComEtaDate(eta.get("date"));
		lm36ComStatusUpdateVars.setLm36ComEtaTime(eta.get("time"));
		lm36ComStatusUpdateVars.setLm36ComLocationCityState(lastLocatonOfTruck.trim());
		lm36ComStatusUpdateVars.setLm36ComOrderTimestampIn(orderDetails.getLastUpdateTimeStamp());

		Lm36ComRemarksInfo lm36ComRemarksInfo = new Lm36ComRemarksInfo();
		List<Lm36ComRemarksInfo> lm36ComRemarksInfoList = new ArrayList<>();
		lm36ComRemarksInfoList.add(lm36ComRemarksInfo);
		lm36ComStatusUpdateVars.setLm36ComRemarksTable(lm36ComRemarksInfoList);

		if (lm36ComStatusUpdateVars.getLm36ComCallType().equals(CommonConstants.CALLTYPE_TC)) {
			Integer seqNo = Optional.ofNullable(taskRepository.getStopSeqForTerminateCheckCall(jobId, newOrderId))
					.orElseThrow(() -> new JBHuntRuntimeException("Stop not found for terminate Checkcall"));
			lm36ComStatusUpdateVars.setLm36ComStopSeqNbr(seqNo.longValue());
		} else {
			final List<Object[]> taskDetails = taskRepository.findOrdDetailsByOrdNbrCh(orderDetails.getOrdrNumber());
			final Object[] recordOfTaskDetails = taskDetails.get(taskDetails.size() - 1);
			final Object seqNo = Array.get(recordOfTaskDetails, 8);
			lm36ComStatusUpdateVars.setLm36ComStopSeqNbr(Long.parseLong(seqNo.toString()));
		}
	}

	private void populateTcallVariables(final OperationalPlanDTO operationalPlanDTO,
			Lm36ComStatusUpdateVars lm36ComStatusUpdateVars, PreplanLog preplanLog, TOrder orderDetails, String lastLocatonOfTruck) {
		operationalPlanDTO.getOperationalPlanStops().forEach(operationalPlanStop -> {
			if (CommonConstants.STOP_REASONCODE.equalsIgnoreCase(operationalPlanStop.getStopReasonCode())) {
				try {
					final TerminateCallDTO terminateCallDTO = populateTCallfields(operationalPlanStop,
							preplanLog.getEquipmentId(), orderDetails.getOrderId(),
							lm36ComStatusUpdateVars.getLm36ComStopSeqNbr(), lastLocatonOfTruck);
					Map<String, String> tCallMap = checkCallHelper.populateTerminateCallElements(terminateCallDTO);
					final String checkCallVars = getCheckCallVarsValues(tCallMap,
							checkCallHelper.getCheckcallTerminateElements());
					lm36ComStatusUpdateVars.setLm36ComCheckCallVars(checkCallVars);
					lm36ComStatusUpdateVars.setLm36ComTcallCustomerCode(terminateCallDTO.getCustomerCode());
				} catch (JSONException e) {
					throw new JBHuntRuntimeException(e.getMessage());
				}
			}
		});
	}

	private List<Lm36ComRouteInfo> getRouteDetailsForTcall(final OperationalPlanDTO operationalPlanDTO, Integer orderId,
			Long seqNo) {
		List<Lm36ComRouteInfo> lm36ComRouteInfoList = new ArrayList<>();
		operationalPlanDTO.getOperationalPlanStops().forEach(operationalPlanStop -> {
			Lm36ComRouteInfo lm36ComRouteInfo = new Lm36ComRouteInfo();
			String cityStateCode = "";
			if (operationalPlanStop.getCityId() != null) {
				String[][] locationCodeDetails = cityRepository.fetchLocationCode(orderId, seqNo);
				cityStateCode = locationCodeDetails[0][1];
				if (cityStateCode.length() < 5) {
					throw new JBHuntRuntimeException("");
				}
				cityStateCode = cityStateCode.substring(2, 5) + cityStateCode.substring(0, 2);
			} else {
				String customerCode;
				try {
					customerCode = Optional
							.ofNullable(locationClient
									.findLocationProfilebyLocationCode(operationalPlanStop.getLocationId()))
							.map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode)
							.orElseThrow(() -> new JBHuntRuntimeException("Location Profile not found."));
				} catch (JBHuntRuntimeException | JSONException e) {
					throw new JBHuntRuntimeException("Failed due to location service");
				}
				cityStateCode = Optional
						.ofNullable(loadplanningIntegrationOWObackfillService.getCityStateForCustomerCode(customerCode))
						.map(String::trim).filter(StringUtils::isNotEmpty).orElse("");
			}

			lm36ComRouteInfo.setLm36ComRouteCty(Optional.ofNullable(cityStateCode).map(String::trim)
					.orElseThrow(() -> new JBHuntRuntimeException("City id for route details not found")));
			lm36ComRouteInfo.setLm36ComRouteType(
					operationalPlanStop.getStopReasonCode().equalsIgnoreCase("Terminate") ? "E" : "L");
			lm36ComRouteInfoList.add(lm36ComRouteInfo);
		});
		return lm36ComRouteInfoList;
	}

	/**
	 * Method to prepare ETA details, It returns Map interface which contains both
	 * date & time. Step 1 : Retrieving TEquipment details by passing equipmentId.
	 * Step 2 : If TEquipment is null method throws JBHuntRuntimeException. Step 3 :
	 * If TEquipment is not null then method prepares the Map interface with
	 * TEquipment - Current Estimate Time Arrival Date & Time. Step 4 : Returns Map
	 * interface.
	 * 
	 * @param equipmentId
	 * @return
	 */
	private Map<String, String> prepareETADateAndTime(final Integer equipmentId) {
		log.info("Method - prepareETADateAndTime - EquipmentId : {}", equipmentId);
		final Map<String, String> etaMap = new HashMap<>();
		final TEquipment tEquipment = equipmentRepository.fetchEqpDetailsByEqpId(Integer.toString(equipmentId));
		final String etaDate = Optional.ofNullable(tEquipment).map(TEquipment::getCurrentEstimateTimeArrivelDate)
				.map(String::trim).orElseThrow(() -> new JBHuntRuntimeException(
						"Estimated Arrival Date is not present in Table and Contract"));
		final String etaTime = Optional.ofNullable(tEquipment).map(TEquipment::getCurrentEstimateTimeArrivelHour)
				.map(String::trim).orElseThrow(() -> new JBHuntRuntimeException(
						"Estimated Arrival Time is not present in Table and Contract"));
		log.info("Method - prepareETADateAndTime - Expected Arrival Date : {} and Time : {}", etaDate, etaTime);

		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH.mm");

		LocalDate etaLocalDateFormat = LocalDate.parse(etaDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		String formattedEtaDate = etaLocalDateFormat.format(dateFormatter);

		LocalTime etaLocalTimeFormat = LocalTime.parse(etaTime, DateTimeFormatter.ofPattern("HH.mm.ss"));
		String formattedEtaTime = etaLocalTimeFormat.format(timeFormatter);

		etaMap.put("date", formattedEtaDate);
		etaMap.put("time", formattedEtaTime);
		return etaMap;

	}

	private TerminateCallDTO populateTCallfields(OperationalPlanStopDTO operationalPlanStop, Integer equipmentId,
												 Integer orderId, Long sequenceNo, String lastLocatonOfTruck) throws JSONException {
		TerminateCallDTO terminateCallDTO = new TerminateCallDTO();
		String locationCode = null;
		String cityState = null;
		String ordCityState = null;

		Optional.ofNullable(equipmentRepository.fetchHubMilesByEquipmentId(equipmentId))
				.ifPresent(hubMiles -> terminateCallDTO.setEndHubMiles((hubMiles + 1)));
		log.info("hubMiles {}", terminateCallDTO.getEndHubMiles());

		if (operationalPlanStop.getLocationId() != null) {
			log.info("locationId : {}", operationalPlanStop.getLocationId());
			LocationProfileDTOs locationProfileDTOs = locationClient.findLocationProfilebyLocationCode(operationalPlanStop.getLocationId());
			City city = Optional
					.ofNullable(cityRepository.findCityDetailsByState(
							locationProfileDTOs.getLocationProfileDTO().getAddressDTO().getCity().toUpperCase(),
							locationProfileDTOs.getLocationProfileDTO().getAddressDTO().getState().toUpperCase()))
					.orElseThrow(() -> new JBHuntRuntimeException("City State not found in TCity"));
			cityState = city.getCityID();
			ordCityState = city.getCityID();
			locationCode = locationProfileDTOs.getLocationProfileDTO().getLocationCode();
		}else if (operationalPlanStop.getCityId() != null) {
			City cityStateFromCrossReference = loadplanningIntegrationOWObackfillService.getCityStateCodeByCityID(operationalPlanStop.getCityId());
			cityState = cityStateFromCrossReference.getCtyStC();
			String[][] locationCodeDetails = cityRepository.fetchLocationCode(orderId, sequenceNo);
			locationCode = locationCodeDetails[0][0];
			log.info("locationCode: "+ locationCode);
			ordCityState = locationCodeDetails[0][1];
			log.info("Order City State >>{}", ordCityState);
		} else {
			throw new JBHuntRuntimeException("Stop locationId or CityId are required, not found.");
		}
		cityState = Optional.ofNullable(cityState).orElseThrow(() -> new JBHuntRuntimeException("City details not found"));
		cityState = cityState.substring(2, 5) + cityState.substring(0, 2);
		ordCityState = Optional.ofNullable(ordCityState).orElseThrow(() -> new JBHuntRuntimeException("City details not found"));
		ordCityState = ordCityState.substring(2, 5) + ordCityState.substring(0, 2);
		log.info("cityState: "+cityState);
		terminateCallDTO.setCityState(cityState);
		terminateCallDTO.setCustomerCode(locationCode);
		terminateCallDTO.setDropTrailerFlag(CommonConstants.STRING_N);
		terminateCallDTO.setOrdCityState(ordCityState);

		String pickUpArea = cityRepository.fetchPickUpArea(locationCode.trim(), "HJBT JBDCS", "MKT");
		log.info("Pickup Area: "+ pickUpArea);
		terminateCallDTO.setPickupArea(Optional.ofNullable(pickUpArea).map(String::trim).orElse(""));
		String truckCityState = Optional.ofNullable(lastLocatonOfTruck).map(String::trim).orElseThrow(() -> new JBHuntRuntimeException("Truck City details not found in TEquipment"));
		log.info("truckCityState: "+truckCityState);
		terminateCallDTO.setTruckCityState(truckCityState);
		return terminateCallDTO;
	}
	
	public void populateHubForUnloaded(CheckcallDTO checkcallDTO, Map<String,String> checkCallElementValuesMap ){
		checkCallElementValuesMap.put("LMB4COM-UCALL-END-HUB-MIL","0");
		Integer equipmentId = (int) checkcallDTO.getEqpId();
		Optional.ofNullable(equipmentRepository.fetchHubMilesByEquipmentId(equipmentId))
				.ifPresent(hubMiles -> {Integer hubMilesRq =(hubMiles + 1);
					checkCallElementValuesMap.put("LMB4COM-UCALL-END-HUB-MIL",hubMilesRq.toString());
					log.info("hubMiles {}", hubMilesRq);
				});
	}

	public void populateCustomerCode(Integer locationId, CheckcallDTO checkcallDTO) {
		try {
			Optional.ofNullable(locationClient.findLocationProfilebyLocationCode(locationId))
					.map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode)
					.ifPresent(locationCode -> checkcallDTO.setStopCustomerCode(locationCode.trim()));
		} catch (JSONException e) {
			throw new JBHuntRuntimeException(e);
		}
	}

	public void populateCheckcallWithOrderInformation(
			OrderOperationalPlanAssociationDTO orderOperationalPlanAssociationDTO, CheckcallDTO checkcallDTO) {
		Integer newOrderId = orderOperationalPlanAssociationDTO.getOperationalPlanOrder().getOrderId();
		entityManager.clear();
		TOrder tOrder = Optional.ofNullable(orderLoadRepository.findLoadDetailsByOrderID(newOrderId))
				.orElseGet(() -> orderLoadRepository.findLoadDetailsByOrderIDWarehouse(newOrderId));
		if (tOrder == null) {
			throw new JBHuntRuntimeException(
					"Order Id " + newOrderId + " doesn't exist and It's mandatory for Checkcalls.");
		}
		log.info(" tOrder : {}", tOrder.getOrdrNumber());
		checkcallDTO.setOrderNumber(tOrder.getOrdrNumber());
		checkcallDTO.setInvertOrder(tOrder.getOrderId());
		log.info("tOrder.getOrderCreatedTimeStamp() {} ", tOrder.getLastUpdateTimeStamp());
		checkcallDTO.setOrderTimeStamp(tOrder.getLastUpdateTimeStamp());
		log.info(" OrderId : {}", newOrderId);
		Integer[][] jobIdAndstopSequenceNumbersArray = subTaskRepository.getStopSeqNumberByOrderId(tOrder.getOrderId());
		if (jobIdAndstopSequenceNumbersArray.length > 0) {
			checkcallDTO.setJobId(jobIdAndstopSequenceNumbersArray[0][0]);
			checkcallDTO.setNextStopSeqNbr(jobIdAndstopSequenceNumbersArray[0][1]);
		}
	}

	public void populateArrivalInformation(List<OperationalPlanCheckCallDTO> operationalPlanCheckCallList,
			ArrivalCallDTO arrivalCall, CheckcallDTO checkcallDTO) {
		DateTimeFormatter sdfDate = DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT);
		DateTimeFormatter sdfTime = DateTimeFormatter.ofPattern(CommonConstants.TIME_FORMAT);
		operationalPlanCheckCallList.stream()
				.filter(operationalPlanCheckCall -> operationalPlanCheckCall.getOperationalPlanCheckCallId()
						.equals(arrivalCall.getArrivalCallId()))
				.findFirst().ifPresent(arrivalOperationalPlanCheckCallDTO -> {
					ArrivalCallDTO arrivalCallFromArrivalCall = arrivalOperationalPlanCheckCallDTO.getArrivalCall();
					ZonedDateTime arrivalTimestamp = arrivalCallFromArrivalCall.getArrivalTimestamp()
							.atZoneSameInstant(ZoneId.of(checkcallDTO.getLocationTimeZone()));
					checkcallDTO.setArrivalDate(arrivalTimestamp.format(sdfDate));
					checkcallDTO.setArrivalTime(arrivalTimestamp.format(sdfTime));
				});

	}

	public void populateCheckcallWithEquipmentInformation(ResourceAssignmentPlanDTO resourceAssignmentPlan,
			CheckcallDTO checkcallDTO) throws URISyntaxException {
		EquipmentDetailsDTO equipmentDetailsDTO = Optional
				.ofNullable(masterdataAssetClient.getEquipmentDetails(
						Arrays.asList(resourceAssignmentPlan.getEquipmentAssignments().getEquipmentId())))
				.orElseThrow(() -> new JBHuntRuntimeException("Equipment details not found.")).stream().findFirst()
				.orElseThrow(() -> new JBHuntRuntimeException("Equipment details not found."));
		TEquipment tEquipment = Optional
				.ofNullable(equipmentRepository
						.fetchEqpDetailsByEqpId(Integer.toString(equipmentDetailsDTO.getLegacyEquipmentId())))
				.orElseThrow(() -> new JBHuntRuntimeException("Equipment detail not found"));
		checkcallDTO.setEqpId(equipmentDetailsDTO.getLegacyEquipmentId());
		checkcallDTO.setTractorNbr(equipmentDetailsDTO.getEquipmentNumber().trim());
		log.info("tEquipment.getTrailerNumber() {} ", tEquipment.getTrailerNumber());
		Optional.ofNullable(equipmentRepository.getTrailerContainerByEquipmentId(tEquipment.getTrailerNumber()))
				.ifPresent(trailerEquipment -> {
					checkcallDTO.setTrailerContainerPrefix(trailerEquipment.getTrailerPrefix());
					checkcallDTO.setTrailerContainerNumber(trailerEquipment.getTrailerNumber());
				});
		checkcallDTO.setLocationCityState(tEquipment.getLastLocation().trim());
	}

	public void populateCheckcallWithLocationCityState(CheckcallDTO checkcallDTO) {
		String locationForArrivalLoadedUnloaded = Optional
				.ofNullable(subTaskRepository.getLocationForArrivalUnloaded(checkcallDTO.getInvertOrder(),
						checkcallDTO.getNextStopSeqNbr()))
				.orElseThrow(() -> new JBHuntRuntimeException("Next Stop Sequence Number not found"));
		checkcallDTO.setLocationCityState(convertingCityStateLocation(locationForArrivalLoadedUnloaded.trim()));
	}

	public void populateLoadedcheckcallWithLocationCityState(CheckcallDTO checkcallDTO) {
		TEquipment locationDetails = Optional
				.ofNullable(equipmentRepository.getLastLocationForLoadedCheckcall(checkcallDTO.getTractorNbr()))
				.orElseThrow(() -> new JBHuntRuntimeException(
						"Last Location Unknown for this equipment Unit ID, details not found"));
		checkcallDTO.setLocationCityState(locationDetails.getLastLocation().trim());
	}

	public ResourceAssignmentPlanDTO getResourceAssignmentPlan(OperationalPlanDTO operationalPlanDTO) {
		List<OperationalPlanResourceAssignmentAssociationDTO> operationalPlanResourceAssignmentAssociationDTOList = operationalPlanDTO
				.getOperationalPlanResourceAssignmentAssociationList();
		OperationalPlanResourceAssignmentAssociationDTO resourceAssignmentAssociationDTO = Collections
				.max(operationalPlanResourceAssignmentAssociationDTOList, Comparator.comparing(
						OperationalPlanResourceAssignmentAssociationDTO::getOperationalPlanResourceAssignmentAssociationId));
		ResourceAssignmentPlanDTO resourceAssignmentPlan = resourceAssignmentAssociationDTO.getResourceAssignmentPlan();
		if (resourceAssignmentPlan.getEquipmentAssignments() == null) {
			throw new JBHuntRuntimeException("Checkcall requires at least one EquipmentAssigment element");
		}
		return resourceAssignmentPlan;
	}

	private static String convertingCityStateLocation(String location) {
		String state = location.substring(0, 2);
		String city = location.substring(2, location.length());
		return location.length() > 4 ? city.concat(state) : city.concat(" ").concat(state);
	}

	private void overRideMethod(Lm36ComCommareaRecord lm36ComCommareaRecord, Lm36ComReturnToJava lm36ComReturnToJava,
			String lm36ComFiller, Holder<Lm36ComCommareaOutputRecord> lm36ComCommareaOutputRecordHolder,
			Holder<Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder,
			Holder<String> lm36ComFillerOutputHolder) {
		Optional.ofNullable(lm36ComReturnToJavaOutputHolder.value).ifPresent(value -> {
			Optional.ofNullable(value.getLm36ComErrorFields()).ifPresent(comErrorField -> {
				if (!"S".equalsIgnoreCase(comErrorField.getLm36ComErrorFlag())
						&& comErrorField.getLm36ComErrorMessage().contains("PF6")) {
					Optional.ofNullable(lm36ComCommareaOutputRecordHolder.value).ifPresent(outputFields -> {
						Optional.ofNullable(outputFields.getLm36ComJavaSentVariables().getLm36ComStatusUpdateVars())
								.ifPresent(statusField -> {
									statusField.setLm36ComCheckCallVars(statusField.getLm36ComCheckCallVars());
									lm36ComCommareaRecord.getLm36ComJavaSentVariables().getLm36ComStatusUpdateVars()
											.setLm36ComCheckCallVars(statusField.getLm36ComCheckCallVars());
									lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava,
											lm36ComFiller, lm36ComCommareaOutputRecordHolder,
											lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);
									overRideMethod(lm36ComCommareaRecord, lm36ComReturnToJava, lm36ComFiller,
											lm36ComCommareaOutputRecordHolder, lm36ComReturnToJavaOutputHolder,
											lm36ComFillerOutputHolder);
								});
					});
				} else if (!"S".equalsIgnoreCase(comErrorField.getLm36ComErrorFlag())) {
					String messageError = "";
					messageError = comErrorField.getLm36ComErrorMessage().trim();
					log.info("result of the checkCall operation from the mainframe ErrorFlag: {}",
							comErrorField.getLm36ComErrorFlag());
					log.info("result of the checkCall operation from the mainframe ErrorMessage: {}", messageError);
					if (!StringUtils.isEmpty(messageError)) {
						throw new JBHuntRuntimeException(messageError);
					}
				}
			});
		});
	}

}
