package com.jbhunt.loadplannig.integration.backfill.exception;

public class MainframeCICSWebServiceDownException extends RuntimeException {
    public MainframeCICSWebServiceDownException(String message){
        super(message);
    }
}
