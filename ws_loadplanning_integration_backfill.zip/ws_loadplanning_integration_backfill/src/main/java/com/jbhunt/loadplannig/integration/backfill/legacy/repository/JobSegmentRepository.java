package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.JobSegment;

@Repository
public interface JobSegmentRepository extends JpaRepository<JobSegment, Integer> {

	@Query(value = " SELECT JOB_SEG_I, JOB_I, MIL_TYP_C, SEQ_NO, BEG_HUB_MIL_Q, END_HUB_MIL_Q, INC_JOB_SEG_F FROM ALI.JOB_SEGMENT WHERE JOB_I=(:jobId) AND  INC_JOB_SEG_F  = 'Y' AND "
			+ " MIL_TYP_C IN ('EMPTY','LOADED') ORDER BY SEQ_NO WITH UR ", nativeQuery = true)
	List<JobSegment> findByJobId(@Param("jobId") Integer jobId);

}
