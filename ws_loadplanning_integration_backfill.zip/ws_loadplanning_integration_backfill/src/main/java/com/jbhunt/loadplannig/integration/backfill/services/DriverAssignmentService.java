package com.jbhunt.loadplannig.integration.backfill.services;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.json.JSONException;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOperator;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OperatorRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.SubTaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.BkfilOwoJaAscResponse;
import com.jbhunt.loadplannig.integration.backfill.utils.CommonUtils;
import com.jbhunt.loadplannig.integration.backfill.utils.DriverSendHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.SendPlanHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanWorkOrderAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;
import com.jbhunt.personnel.people.dto.PeopleDetailsDTO;
import com.lmc341i.lmc341.LMC341Port;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea.Lmc341InputArea;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea.Lmc341InputArea.Lmc341DrRscPpTable;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea.Lmc341InputArea.Lmc341DrRscPpTable.Lmc341DrStpTable;
import com.response.lmc341i.lmc341.ProgramInterface.Lmc341OutputArea;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class DriverAssignmentService {

	private final OperatorRepository operatorRepository;
	private final DriverSendHelper driverPreplanHelper;
	private final LMC341Port lmc341Port;
	private final SendPlanHelper sendPlanHelper;
	private final TaskRepository taskRepository;
	private final SubTaskRepository subTaskRepository;
	private final OrderLoadRepository orderLoadRepository;
	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;

	/**
	 * @param operationalPlanDTO
	 * @param operationalFlag
	 * @param resourceAssignmentPlanDTO
	 * @param isTruePlan
	 */
	public void driverAssignment(final OperationalPlanDTO operationalPlanDTO, String operationalFlag,
			final ResourceAssignmentPlanDTO resourceAssignmentPlanDTO, final String isTruePlan,
			final String eventSubType) {
		log.info("inside driver assignment");
		final PeopleDetailsDTO driverDetails = sendPlanHelper.populateDriverDetails(resourceAssignmentPlanDTO);
		final TOperator operatorDetails = operatorRepository.findLstUpdatedTimeByAlphaId(driverDetails.getAlphaCode());
		List<Lmc341DrRscPpTable> drvRsvPeplan = new ArrayList<>();
		Integer countOfOrders = 0;

		switch (operationalPlanDTO.getOperationalPlanType().getOperationalPlanTypeCode()) {
		case "Freight":
			final List<OrderOperationalPlanAssociationDTO> orderOperationalPlanAssociations = operationalPlanDTO
					.getOrderOperationalPlanAssociations();
			countOfOrders = orderOperationalPlanAssociations.size();
			orderOperationalPlanAssociations.forEach(orderOperationalPlanAssociation -> {
				log.info("orderid :{} ", orderOperationalPlanAssociation.getOperationalPlanOrder().getOrderId());
				Integer newOrderId = orderOperationalPlanAssociation.getOperationalPlanOrder().getOrderId();
				TOrder orderSync = Optional.ofNullable(orderLoadRepository.findLoadDetailsByOrderID(newOrderId))
						.orElseGet(() -> orderLoadRepository.findLoadDetailsByOrderIDWarehouse(newOrderId));
				if (orderSync == null) {
					throw new JBHuntRuntimeException(
							"Order Id " + newOrderId + " doesn't exist and It's mandatory for Resource Assignment.");
				}
				getLmc341DrRscPpTableList(operationalPlanDTO, orderSync.getOrderId(), eventSubType, newOrderId,
						orderSync.getOrdrNumber(), operationalFlag, drvRsvPeplan, false);
			});
			break;
		case "OWO":
			final List<OperationalPlanWorkOrderAssociationDTO> operationalPlanWorkOrderAssociationDTOList = operationalPlanDTO
					.getOperationalPlanWorkOrderAssociations();
			countOfOrders = operationalPlanWorkOrderAssociationDTOList.size();
			operationalPlanWorkOrderAssociationDTOList.forEach(operationalPlanWorkOrderAssociationDTO -> {
				BkfilOwoJaAscResponse bkfilOwoJaAscResponse = loadplanningIntegrationOWObackfillService
						.findOrdDetailsBynxtOwoNum(
								"W" + operationalPlanWorkOrderAssociationDTO.getOperationalWorkOrderId());
				getLmc341DrRscPpTableList(operationalPlanDTO, bkfilOwoJaAscResponse.getOrdI(), eventSubType,
						bkfilOwoJaAscResponse.getNxtOWOI(), bkfilOwoJaAscResponse.getOrdNbrch(), operationalFlag,
						drvRsvPeplan, true);
			});
			break;
		default:
			break;
		}
		Lmc341InputArea inputArea = driverPreplanHelper.createInputAreaBuffer(operatorDetails,
				operationalPlanDTO.getCreateUserId(), operationalFlag, countOfOrders, isTruePlan);
		inputArea.getLmc341DrRscPpTable().addAll(drvRsvPeplan);
		Lmc341CommArea finalInput = new Lmc341CommArea();
		finalInput.setLmc341InputArea(inputArea);
		Lmc341OutputArea output = CommonUtils.soapCall((i) -> lmc341Port.lmc341Operation(i), finalInput);
		if (!"S".equalsIgnoreCase(output.getLmc341ReturnFlag())) {
			throw new JBHuntRuntimeException(output.getLmc341ErrorMessage());
		}
	}

	/**
	 * @param operationalPlanDTO
	 * @param orderId
	 * @param eventSubType
	 * @param newOrderId
	 * @param orderNumber
	 * @param operationalFlag
	 * @param lmc341DrRscPpTableList
	 */
	private void getLmc341DrRscPpTableList(final OperationalPlanDTO operationalPlanDTO, final Integer orderId,
			final String eventSubType, final Integer newOrderId, final String orderNumber, final String operationalFlag,
			final List<Lmc341DrRscPpTable> lmc341DrRscPpTableList, final boolean isOWO) {
		List<TSubtask1> listSubTasks = subTaskRepository.findSubTaskDetailsByTaskId(orderId);

		String locationCode = null;
		if (OperationalPlanEventSubType.INBOUND_TO_YARD.name().equalsIgnoreCase(eventSubType)) {
			final Integer stopSequenceNumber = operationalPlanDTO.getOperationalPlanStops().stream()
					.max(Comparator.comparing(OperationalPlanStopDTO::getOperationalPlanStopSequenceNumber))
					.map(OperationalPlanStopDTO::getOperationalPlanStopSequenceNumber).orElse(null);

			final TSubtask1 subTask = listSubTasks.stream()
					.filter(stop -> stop.getPreferanceSequenceNumber().equals(stopSequenceNumber)).findAny()
					.orElse(null);
			listSubTasks.remove(subTask);

			try {
				locationCode = sendPlanHelper.getLocationCode(operationalPlanDTO);
			} catch (JSONException e) {
				throw new JBHuntRuntimeException(e.getMessage());
			}
		}

		String taskTimeStamp = taskRepository.findLastUpdatedTimeStampBytaskId(orderId);
		List<Lmc341DrStpTable> lmc341StpDetails = driverPreplanHelper.createStopBuffer(listSubTasks);
		lmc341DrRscPpTableList.add(driverPreplanHelper.createDriverRsvPreplanBuffer(newOrderId,
				operationalPlanDTO.getOperationalPlanId(), operationalPlanDTO.getOperationalPlanNumber(), taskTimeStamp,
				lmc341StpDetails, orderId, orderNumber, operationalFlag, locationCode, isOWO));
	}

}
