package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;

@Repository
public interface EquipmentRepository extends JpaRepository<TEquipment, Integer> {

	@Query(value = "SELECT  EQP_ID FROM ALI.TEQUIPMENT WHERE EQP_UNIT_ID=:Eqp_unit_id  WITH UR ", nativeQuery = true)
	List<Integer> fetchEquipmentId(@Param("Eqp_unit_id") String eqpunitId);

	@Query(value = "SELECT C.JOB_I FROM ALI.TEQUIPMENT A, ALI.TORDER B,ALI.TDSP_JOB_XRF C WHERE A.EQP_ID = AND A.LST_ORD_NBR_CH = B.ORD_NBR_CH "
			+ " AND B.ORD_I= C.ORD_I AND C.DSP_NBR = A.LST_DSP_NBR WITH UR ", nativeQuery = true)
	List<Integer> fetchJobIdByEquipmentId(@Param("EQP_ID") Integer equipmentId);

	@Query(value = "SELECT C.JOB_I FROM ALI.TEQUIPMENT A, ALI.TORDER B,ALI.TDSP_JOB_XRF C WHERE A.EQP_ID =:eqp_id AND A.LST_ORD_NBR_CH = B.ORD_NBR_CH "
			+ " AND B.ORD_I= C.ORD_I AND C.DSP_NBR = A.LST_DSP_NBR WITH UR ", nativeQuery = true)
	Integer fetchJobIdByEquipmentId(@Param("eqp_id") String equipmentId);

	@Query(value = "SELECT EQP_ID, EQP_UNIT_ID, EQP_TY_ID, EQP_UNIT_PREFIX_ID, REC_STT_F, MJR_CLS_C, CUR_PLX_I, UNT_STT_C, LD_STT,"
			+ " YARD_STT_F, LST_LCTN_C, DIV_ID, CUR_PLX_TYP_C, SUB_CLS_C ,LST_ORD_NBR_CH,CHAR(CURR_ETA_D) AS CURR_ETA_D, CHAR(CURR_ETA_H) AS CURR_ETA_H, LST_DSP_NBR, CHAR(LST_UPDT_TMSTP_S) AS LST_UPDT_TMSTP_S,LST_CSTMR FROM ALI.TEQUIPMENT WHERE EQP_ID=:eqp_id WITH UR ", nativeQuery = true)
	TEquipment fetchEqpDetailsByEqpId(@Param("eqp_id") String eqpId);

	@Query(value = "SELECT EQP_ID, EQP_UNIT_ID, EQP_TY_ID, EQP_UNIT_PREFIX_ID, REC_STT_F, MJR_CLS_C, CUR_PLX_I, UNT_STT_C, LD_STT,"
			+ " YARD_STT_F, LST_LCTN_C, LST_DSP_NBR, LST_ORD_NBR_CH, DIV_ID, CUR_PLX_TYP_C, SUB_CLS_C, CHAR(LST_UPDT_TMSTP_S) AS LST_UPDT_TMSTP_S,CHAR(CURR_ETA_D) AS CURR_ETA_D, CHAR(CURR_ETA_H) AS CURR_ETA_H,LST_CSTMR FROM ALI.TEQUIPMENT "
			+ " WHERE MJR_CLS_C='CONTAINER' and CUR_PLX_I = (SELECT CUR_PLX_I   FROM ALI.TEQUIPMENT "
			+ " WHERE EQP_UNIT_ID =:Eqp_unit_id and CUR_PLX_I<>0 and MJR_CLS_C = 'POWER' and REC_STT_F = 'A')", nativeQuery = true)
	TEquipment getTrailerContainerByEquipmentId(@Param("Eqp_unit_id") String equipmentId);

	@Query(value = "SELECT EQP_ID, EQP_UNIT_ID, EQP_TY_ID, EQP_UNIT_PREFIX_ID, REC_STT_F, MJR_CLS_C, CUR_PLX_I, UNT_STT_C, LD_STT, LST_DSP_NBR, "
			+ " YARD_STT_F, DIV_ID, LST_LCTN_C, CUR_PLX_TYP_C, SUB_CLS_C ,LST_ORD_NBR_CH,CHAR(CURR_ETA_D) AS CURR_ETA_D, CHAR(CURR_ETA_H) AS CURR_ETA_H, CHAR(LST_UPDT_TMSTP_S) AS LST_UPDT_TMSTP_S,LST_CSTMR FROM ALI.TEQUIPMENT WHERE MJR_CLS_C = 'CONTAINER' AND CUR_PLX_I = (SELECT CUR_PLX_I FROM ALI.TEQUIPMENT WHERE EQP_UNIT_ID =:Eqp_unit_id "
			+ "AND MJR_CLS_C = 'POWER' ) WITH UR ", nativeQuery = true)
	TEquipment getTrailerDetails(@Param("Eqp_unit_id") String eqpUnitId);

	@Query(value = "SELECT  EQP_UNIT_ID FROM ALI.TEQUIPMENT WHERE EQP_ID=:eqpId  WITH UR ", nativeQuery = true)
	String getEquipmentUntiId(@Param("eqpId") Integer eqpId);

	@Query(value = "SELECT  LST_LCTN_C FROM ALI.TEQUIPMENT WHERE EQP_ID=:eqp_id  WITH UR ", nativeQuery = true)
	String getLastLocationOfTruck(@Param("eqp_id") Integer eqpId);

	@Query(value = "SELECT EQP_ID, EQP_UNIT_ID, EQP_TY_ID, EQP_UNIT_PREFIX_ID, A.REC_STT_F, MJR_CLS_C, CUR_PLX_I, UNT_STT_C, LD_STT, LST_DSP_NBR, "
			+ " YARD_STT_F, LST_LCTN_C, DIV_ID, CUR_PLX_TYP_C, SUB_CLS_C,LST_ORD_NBR_CH,CHAR(CURR_ETA_D) AS CURR_ETA_D, CHAR(CURR_ETA_H) AS CURR_ETA_H, CHAR(A.LST_UPDT_TMSTP_S) AS LST_UPDT_TMSTP_S,LST_CSTMR  FROM ALI.TEQUIPMENT A LEFT JOIN\n"
			+ "ALI.TCODE_TABLE B\n" + "ON B.CD_C = A.FLT_C\n" + "AND B.TY_C = '0000000300'\n"
			+ "AND B.REC_STT_F = 'A'\n" + "WHERE EQP_UNIT_ID =:Eqp_unit_id\n" + "AND A.REC_STT_F = 'A'\n"
			+ "AND A.UNT_STT_C = 'D'\n" + "AND MJR_CLS_C = 'POWER'\n" + "WITH UR ", nativeQuery = true)
	TEquipment getLastDispatchOrderDetails(@Param("Eqp_unit_id") String eqpUnitId);

	@Query(value = "SELECT LST_LCTN_C FROM ALI.TEQUIPMENT WHERE EQP_UNIT_ID = :Eqp_unit_id AND MJR_CLS_C = 'POWER' AND REC_STT_F = 'A' AND RETIRE_D    IS NULL WITH UR ", nativeQuery = true)
	String getLastLocationForLoadedCheckcall(@Param("Eqp_unit_id") String eqpUnitId);

	@Query(value = "SELECT LST_CSTMR FROM ALI.TEQUIPMENT WHERE EQP_ID = :eqpId AND REC_STT_F = 'A' ORDER BY LST_UPDT_TMSTP_S DESC FETCH FIRST ROW ONLY WITH UR", nativeQuery = true)
	String getCustomerCode(@Param("eqpId") Integer eqpId);

	@Query(value = "SELECT A.EQP_ID, A.EQP_UNIT_ID, A.EQP_TY_ID, A.EQP_UNIT_PREFIX_ID, A.REC_STT_F, A.MJR_CLS_C, A.CUR_PLX_I, A.UNT_STT_C, A.LD_STT," + 
			 " A.YARD_STT_F, A.LST_LCTN_C, A.DIV_ID, A.CUR_PLX_TYP_C, A.SUB_CLS_C ,A.LST_ORD_NBR_CH,CHAR(A.CURR_ETA_D) AS CURR_ETA_D, CHAR(A.CURR_ETA_H) AS CURR_ETA_H, A.LST_DSP_NBR, CHAR(A.LST_UPDT_TMSTP_S) AS LST_UPDT_TMSTP_S,A.LST_CSTMR FROM ALI.TEQUIPMENT A WHERE A.CUR_PLX_I in (SELECT B.CUR_PLX_I FROM ALI.TEQUIPMENT B WHERE B.EQP_ID = :eqpId) WITH UR", nativeQuery = true)
	List<TEquipment> getEquipmentDetails(@Param("eqpId") Integer eqpId);
}
