package com.jbhunt.loadplannig.integration.backfill.dto;

import lombok.Data;

@Data
public class LocationTimeZone {

    Integer id;
    String timezone;

}
