package com.jbhunt.loadplannig.integration.backfill.services;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class OperationalPlanBackfillService {

	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final DispatchLoadPlanService dispatchLoadPlanService;
	private final ArrivalCheckcallService arrivalCheckcallService;
	private final UnloadedCheckcallService unloadedCheckcallService;
	private final LoadedCheckcallService loadedCheckcallService;
	private final TerminateCheckCallService terminateCheckCallService;

	public void operationalPlanService(OperationalPlanEvent operationalPlanEvent) {

		final OperationalPlanDTO operationalPlanDTO = operationalPlanEvent.getOperationalPlanDTO();
		List<OperationalPlanEventSubType> operationalPlanEventSubTypes = operationalPlanEvent
				.getOperationalPlanEventSubTypes().stream().collect(Collectors.toList());

		log.info("sendOperationalPlan :{}", operationalPlanDTO.getOperationalPlanNumber());

		if (operationalPlanEventSubTypes.contains(OperationalPlanEventSubType.DISPATCHED)) {
			backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
					OperationalPlanEventSubType.DISPATCHED.name(), "");
			try {
				dispatchLoadPlanService.dispatchLoadPlan(operationalPlanEvent);
			} catch (Exception e) {
				log.error("Exception in dispatch:", e);
				updateException(operationalPlanDTO, e);
				throw new JBHuntRuntimeException("Exception Occured in DISPATCHED: " + e);
			}
		}

		else if (operationalPlanEventSubTypes.contains(OperationalPlanEventSubType.TERMINATE_CHECKCALL)) {
			backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
					OperationalPlanEventSubType.TERMINATE_CHECKCALL.name(), "");
			try {
				terminateCheckCallService.createTerminateCheckCall(operationalPlanEvent.getOperationalPlanDTO());
			} catch (Exception e) {
				log.error("Exception in TERMINATE_CHECKCALL:", e);
				updateException(operationalPlanDTO, e);
				throw new JBHuntRuntimeException("Exception Occured in TERMINATE_CHECKCALL: " + e);
			}
		} else {
			List<OperationalPlanEventSubType> recommendedOrderCheckCalls = Arrays.asList(
					OperationalPlanEventSubType.ARRIVAL_CHECK_CALL, OperationalPlanEventSubType.LOADED_CHECK_CALL,
					OperationalPlanEventSubType.UNLOADED_CHECK_CALL);
			doOrderWiseCheckcalls(recommendedOrderCheckCalls, operationalPlanEventSubTypes, operationalPlanDTO);
		}
	}

	private void doOrderWiseCheckcalls(List<OperationalPlanEventSubType> recommendedOrderCheckCalls,
			List<OperationalPlanEventSubType> operationalPlanEventSubTypes, OperationalPlanDTO operationalPlanDTO) {
		recommendedOrderCheckCalls.stream().forEach(subType -> {
			if (operationalPlanEventSubTypes.contains(subType)) {
				backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO,
						EventStatusEnum.PENDING.name(), subType.name(), "");
				callServiceBasedOnSubType(subType, operationalPlanDTO);
			}
		});
	}

	private void callServiceBasedOnSubType(OperationalPlanEventSubType subType, OperationalPlanDTO operationalPlanDTO) {
		switch (subType) {
		case ARRIVAL_CHECK_CALL:
			try {
				arrivalCheckcallService.arrival(operationalPlanDTO);
			} catch (Exception e) {
				log.error("Exception in ARRIVAL_CHECK_CALL:", e);
				updateException(operationalPlanDTO, e);
				throw new JBHuntRuntimeException("Exception Occured in ARRIVAL_CHECK_CALL: " + e);
			}
			break;
		case UNLOADED_CHECK_CALL:
			try {
				unloadedCheckcallService.unloaded(operationalPlanDTO);
			} catch (Exception e) {
				log.error("Exception in UNLOADED_CHECK_CALL:", e);
				updateException(operationalPlanDTO, e);
				throw new JBHuntRuntimeException("Exception Occured in UNLOADED_CHECK_CALL: " + e);
			}
			break;
		case LOADED_CHECK_CALL:
			try {
				loadedCheckcallService.loaded(operationalPlanDTO);
			} catch (Exception e) {
				log.error("Exception in LOADED_CHECK_CALL:", e);
				updateException(operationalPlanDTO, e);
				throw new JBHuntRuntimeException("Exception Occured in LOADED_CHECK_CALL: " + e);
			}
			break;
		default:
			break;
		}
	}

	private void updateException(OperationalPlanDTO operationalPlanDTO, Exception e) {
		String errorMesage = ExceptionUtils.getRootCauseMessage(e);
		if (errorMesage != null && errorMesage.length() > 500) {
			errorMesage = errorMesage.substring(0, 500);
		}
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
				errorMesage);
	}
}
