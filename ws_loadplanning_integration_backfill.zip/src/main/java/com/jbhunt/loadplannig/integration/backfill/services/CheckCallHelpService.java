package com.jbhunt.loadplannig.integration.backfill.services;

import java.lang.reflect.Array;
import java.net.URISyntaxException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.ws.Holder;

import org.json.JSONException;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHValidationException;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallElement;
import com.jbhunt.loadplannig.integration.backfill.dto.TerminateCallDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.PreplanLog;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.BkfilOrdLdAscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.CityRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.PreplanLogRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.SubTaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CheckCallHelper;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.ArrivalCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanCheckCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanOrderDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanResourceAssignmentAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.jbhunt.mdm.dto.LocationProfileDTO;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.lmc363i.lmc363.LMC363Port;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComDraynetVars;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars.Lm36ComCallbackFields;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars.Lm36ComRemarksInfo;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars.Lm36ComRouteInfo;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava;
import com.response.lmc363i.lmc363.ProgramInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class CheckCallHelpService {

	
	private final LMC363Port lmc363Port;
	private final CheckCallHelper checkCallHelper;
	private final OrderLoadRepository orderLoadRepository;
	private final BkfilOrdLdAscRepository bkfilOrdLdAscRepository;
	private final PreplanLogRepository preplanLogRepository;
	private final EquipmentRepository equipmentRepository;
	private final TaskRepository taskRepository;
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final LocationClient locationClient;
	private final SubTaskRepository subTaskRepository;
	private final MasterdataAssetClient masterdataAssetClient;

	
	private final CityRepository cityRepository;

	//private final TerminateCallHelper terminateCallHelper;
	
	
	
	public String getCheckCallVarsValues(Map<String, String> checkCallElementMap,
			List<CheckcallElement> checkcallArrivalsList) {
		StringBuilder sb = new StringBuilder();
		checkcallArrivalsList.stream().forEach((checkcallElement) -> {
			sb.append(getPaddedValue(checkCallElementMap.containsKey(checkcallElement.getFieldName())
					? checkCallElementMap.get(checkcallElement.getFieldName())
					: "", checkcallElement.getLength()));
		});
		return sb.toString();
	}

	private String getPaddedValue(String value, Short length) {
		return String.format("%1$-" + length + "s", value);
	}
	
	public void prepareLMC363Request(final OperationalPlanDTO operationalPlanDTO,final String userId, final String lastUpdateUserId,final String comment, final Integer operationalPlanId) throws JBHuntRuntimeException {
		
		Lm36ComCommareaRecord lm36ComCommareaRecord = new Lm36ComCommareaRecord();
		Lm36ComJavaSentVariables lm36ComJavaSentVariables = new Lm36ComJavaSentVariables();
		Lm36ComDraynetVars lm36ComDraynetVars = new Lm36ComDraynetVars();
		lm36ComDraynetVars.setLm36ComCarrier("");
		//lm36ComDraynetVars.setLm36ComCreateUserid(checkCallESDTO.getLastUpdateUserId());
		lm36ComDraynetVars.setLm36ComDataState(CommonConstants.STRING_B);
		lm36ComDraynetVars.setLm36ComTrkRqdFlg(CommonConstants.STRING_Y);
		lm36ComDraynetVars.setLm36ComIeCarrierFlg(CommonConstants.STRING_I);
		//lm36ComDraynetVars.setLm36ComUserid(checkCallESDTO.getLastUpdateUserId());
		Lm36ComStatusUpdateVars lm36ComStatusUpdateVars = new Lm36ComStatusUpdateVars();
		Lm36ComCallbackFields Lm36ComCallbackFields = new Lm36ComCallbackFields();
		lm36ComStatusUpdateVars.setLm36ComCallbackFields(Lm36ComCallbackFields);
		//lm36ComStatusUpdateVars.setLm36ComCallType(CommonConstants.CALLTYPE_CO);
		//lm36ComStatusUpdateVars.setLm36ComCheckCallVars("                  " + CommonConstants.STRING_Y);
		//lm36ComStatusUpdateVars.setLm36ComComments(checkCallESDTO.getComment());
		lm36ComStatusUpdateVars.setLm36ComLoadUnldDate(java.time.LocalDate.now().toString().trim());
		lm36ComStatusUpdateVars.setLm36ComLoadUnldTime(java.time.LocalTime.now().toString().trim().substring(0, 4));
		lm36ComStatusUpdateVars.setLm36ComMsgOvrFlg(CommonConstants.STRING_I);
		Lm36ComReturnToJava lm36ComReturnToJava = new Lm36ComReturnToJava();
		javax.xml.ws.Holder<ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder = new Holder<>();
		javax.xml.ws.Holder<String> lm36ComFillerOutputHolder = new Holder<>();
		javax.xml.ws.Holder<ProgramInterface.Lm36ComCommareaOutputRecord> lm36ComCommareaOutputRecordHolder = new Holder<>();
		final String lm36ComFiller = "";
		 List<Integer> listOfNewOrderIds=null;
		 if(comment != null && !comment.isEmpty()){
		lm36ComDraynetVars.setLm36ComCreateUserid(userId);
		lm36ComDraynetVars.setLm36ComUserid(lastUpdateUserId);
		lm36ComStatusUpdateVars.setLm36ComComments(comment);
		lm36ComStatusUpdateVars.setLm36ComCallType(CommonConstants.CALLTYPE_CO);
		 listOfNewOrderIds = bkfilOrdLdAscRepository.getNewOrderIdByOperationalPlanId(operationalPlanId);
		 lm36ComStatusUpdateVars.setLm36ComCheckCallVars("                  " + CommonConstants.STRING_Y);
		}else {
			lm36ComDraynetVars.setLm36ComCreateUserid(operationalPlanDTO.getCreateUserId());
			lm36ComDraynetVars.setLm36ComUserid(operationalPlanDTO.getLastUpdateUserId());
			lm36ComStatusUpdateVars.setLm36ComCallType(CommonConstants.CALLTYPE_TC);
			 listOfNewOrderIds = operationalPlanDTO.getOrderOperationalPlanAssociations().stream()
					.map(OrderOperationalPlanAssociationDTO::getOperationalPlanOrder)
					.map(OperationalPlanOrderDTO::getOrderId).collect(Collectors.toList());
		}
		listOfNewOrderIds.forEach(newOrderId -> {
			final TOrder orderDetails = orderLoadRepository.findLoadDetailsByOrderID(newOrderId);
			if (orderDetails == null) {
				log.error("legac order details not  Found for new orderId: {} and ", newOrderId);
				throw new JBHValidationException("legac order details not  Found");
			}
			final PreplanLog preplanLog = preplanLogRepository.getPreplanDetailsByOrd(orderDetails.getOrderId());
			final List<Object[]> taskDetails = taskRepository
					.findOrdDetailsByOrdNbrCh(orderDetails.getOrdrNumber());
			final Object[] recordOfTaskDetails = taskDetails.get(taskDetails.size() - 1);
			final Object seqno = Array.get(recordOfTaskDetails, 8);
			if (preplanLog == null) {
				log.error(" preplan log  details not  Found for  orderId: {} and ", orderDetails.getOrderId());
				throw new JBHValidationException("preplan log  details not  Found");
			}
			final String equipmentUnitId = equipmentRepository.getEquipmentUntiId(preplanLog.getEquipmentId());
			final Integer jobId = orderLoadRepository.getJobIdbyOrderId(preplanLog.getEquipmentId());
			final String lastLocatonOfTruck = equipmentRepository
					.getLastLocationOfTruck(preplanLog.getEquipmentId());
			lm36ComDraynetVars.setLm36ComInvertOrd(orderDetails.getOrderId());
			lm36ComDraynetVars.setLm36ComJobId(jobId);
			lm36ComDraynetVars.setLm36ComOrderNbr(orderDetails.getOrdrNumber());
			lm36ComDraynetVars.setLm36ComProject("");
			lm36ComDraynetVars.setLm36ComTrkEqpId(preplanLog.getEquipmentId());
			lm36ComDraynetVars.setLm36ComTrkEqpNbr(equipmentUnitId.toString());
			lm36ComStatusUpdateVars.setLm36ComLocationCityState(lastLocatonOfTruck.trim());
			lm36ComStatusUpdateVars.setLm36ComOrderTimestampIn(orderDetails.getLastUpdateTimeStamp());
			if(comment==null) {
				operationalPlanDTO.getOperationalPlanStops().forEach(operationalPlanStop -> {
					if (CommonConstants.STOP_REASONCODE.equalsIgnoreCase(operationalPlanStop.getStopReasonCode())) {
						try {
							final TerminateCallDTO terminateCallDTO = populateTCallfields(
									operationalPlanStop.getLocationId());
							Map<String, String> tCallMap = checkCallHelper
									.populateTerminateCallElements(terminateCallDTO);
							final String checkCallVars = getCheckCallVarsValues(tCallMap,
									checkCallHelper.getCheckcallTerminateElements());
							lm36ComStatusUpdateVars.setLm36ComCheckCallVars(checkCallVars);
						} catch (Exception e) {
						}
					}
				});
			}
			Lm36ComRemarksInfo Lm36ComRemarksInfo = new Lm36ComRemarksInfo();
			List<Lm36ComRemarksInfo> lm36ComRemarksInfo = new ArrayList<>();
			lm36ComRemarksInfo.add(Lm36ComRemarksInfo);
			lm36ComStatusUpdateVars.setLm36ComRemarksTable(lm36ComRemarksInfo);
			Lm36ComRouteInfo lm36ComRouteInfo = new Lm36ComRouteInfo();
			List<Lm36ComRouteInfo> listOfRoureInfo = new ArrayList<>();
			listOfRoureInfo.add(lm36ComRouteInfo);
			lm36ComStatusUpdateVars.setLm36ComRouteInfoTable(listOfRoureInfo);
			lm36ComStatusUpdateVars.setLm36ComStopSeqNbr(Long.parseLong(seqno.toString()));
			lm36ComJavaSentVariables.setLm36ComDraynetVars(lm36ComDraynetVars);
			lm36ComJavaSentVariables.setLm36ComStatusUpdateVars(lm36ComStatusUpdateVars);
			lm36ComCommareaRecord.setLm36ComJavaSentVariables(lm36ComJavaSentVariables);
			lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava, lm36ComFiller,
					lm36ComCommareaOutputRecordHolder, lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);
			checkCallHelper.loggingCheckcallResponse(lm36ComReturnToJavaOutputHolder);
			backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
					"");
		});
		
	}
	
	private TerminateCallDTO populateTCallfields(Integer locationID) throws JSONException {
		TerminateCallDTO terminateCallDTO = new TerminateCallDTO();
		LocationProfileDTOs locationProfileDTOs = locationClient.findLocationProfilebyLocationCode(locationID);
		City city = cityRepository.findCityDetailsByState(
				locationProfileDTOs.getLocationProfileDTO().getAddressDTO().getCity().toUpperCase(),
				locationProfileDTOs.getLocationProfileDTO().getAddressDTO().getState().toUpperCase());
		terminateCallDTO.setCityState(city.getCityID());
		terminateCallDTO.setCustomerCode(locationProfileDTOs.getLocationProfileDTO().getLocationCode());
		terminateCallDTO.setDropTrailerFlag(CommonConstants.STRING_N);
		terminateCallDTO.setEndHubMiles(12456);
		terminateCallDTO.setPickupArea(locationProfileDTOs.getLocationProfileDTO().getLocationCode());
		terminateCallDTO.setTruckCityState(city.getCityID());
		return terminateCallDTO;
	}
	public void populateCustomerCode(Integer locationId, CheckcallDTO checkcallDTO){
		try{
			Optional.ofNullable( locationClient.findLocationProfilebyLocationCode(locationId)).map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode).ifPresent(locationCode ->
					checkcallDTO.setStopCustomerCode(locationCode.trim())
			);
		}catch (JSONException e){
			throw new JBHuntRuntimeException(e);
		}
	}


	public void populateCheckcallWithOrderInformation(OrderOperationalPlanAssociationDTO orderOperationalPlanAssociationDTO, CheckcallDTO checkcallDTO) {
		Integer newOrderId= orderOperationalPlanAssociationDTO.getOperationalPlanOrder().getOrderId();
		TOrder tOrder=Optional.ofNullable(orderLoadRepository.findLoadDetailsByOrderID(newOrderId)).orElseGet(()->orderLoadRepository.findLoadDetailsByOrderIDWarehouse(newOrderId));
		if (tOrder == null){
			throw new JBHuntRuntimeException("Order Id " +newOrderId+" doesn't exist and It's mandatory for Checkcalls.");
		}
		log.info(" tOrder : {}",tOrder.getOrdrNumber());
		checkcallDTO.setOrderNumber(tOrder.getOrdrNumber());
		checkcallDTO.setInvertOrder(tOrder.getOrderId());
		log.info("tOrder.getOrderCreatedTimeStamp() {} ",tOrder.getLastUpdateTimeStamp());
		checkcallDTO.setOrderTimeStamp(tOrder.getLastUpdateTimeStamp());
		log.info(" OrderId : {}",newOrderId);
		Integer[][] jobIdAndstopSequenceNumbersArray = subTaskRepository.getStopSeqNumberByOrderId(tOrder.getOrderId());
		if (jobIdAndstopSequenceNumbersArray.length>0) {
			checkcallDTO.setJobId(jobIdAndstopSequenceNumbersArray[0][0]);
			checkcallDTO.setNextStopSeqNbr(jobIdAndstopSequenceNumbersArray[0][1]);
		}
	}

	public void populateArrivalInformation(List<OperationalPlanCheckCallDTO> operationalPlanCheckCallList, ArrivalCallDTO arrivalCall, CheckcallDTO checkcallDTO){
		DateTimeFormatter sdfDate = DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT);
		DateTimeFormatter sdfTime = DateTimeFormatter.ofPattern(CommonConstants.TIME_FORMAT);
		operationalPlanCheckCallList.stream().filter(operationalPlanCheckCall->
				operationalPlanCheckCall.getOperationalPlanCheckCallId().equals(arrivalCall.getArrivalCallId())).findFirst().ifPresent(arrivalOperationalPlanCheckCallDTO->{
			ArrivalCallDTO arrivalCallFromArrivalCall = arrivalOperationalPlanCheckCallDTO.getArrivalCall();
			ZonedDateTime arrivalTimestamp = arrivalCallFromArrivalCall.getArrivalTimestamp().atZoneSameInstant(ZoneId.of(checkcallDTO.getLocationTimeZone()));
			checkcallDTO.setArrivalDate(arrivalTimestamp.format(sdfDate));
			checkcallDTO.setArrivalTime(arrivalTimestamp.format(sdfTime));
		});

	}

	public void populateCheckcallWithEquipmentInformation(ResourceAssignmentPlanDTO resourceAssignmentPlan, CheckcallDTO checkcallDTO ) throws URISyntaxException {
		EquipmentDetailsDTO equipmentDetailsDTO = Optional.ofNullable(masterdataAssetClient.getEquipmentDetails(Arrays.asList(resourceAssignmentPlan.getEquipmentAssignments().getEquipmentId()))).orElseThrow(()->new JBHuntRuntimeException("Equipment details not found.")).stream().findFirst().orElseThrow(()->new JBHuntRuntimeException("Equipment details not found."));
		TEquipment tEquipment = Optional.ofNullable(equipmentRepository.fetchEqpDetailsByEqpId(Integer.toString(equipmentDetailsDTO.getLegacyEquipmentId()))).orElseThrow(()->new JBHuntRuntimeException("Equipment detail not found"));
		checkcallDTO.setEqpId(equipmentDetailsDTO.getLegacyEquipmentId());
		checkcallDTO.setTractorNbr(equipmentDetailsDTO.getEquipmentNumber().trim());
		log.info("tEquipment.getTrailerNumber() {} ",tEquipment.getTrailerNumber());
		Optional.ofNullable( equipmentRepository.getTrailerContainerByEquipmentId(tEquipment.getTrailerNumber()) ).ifPresent(trailerEquipment->{
			checkcallDTO.setTrailerContainerPrefix(trailerEquipment.getTrailerPrefix());
			checkcallDTO.setTrailerContainerNumber(trailerEquipment.getTrailerNumber());
		});
		checkcallDTO.setLocationCityState(tEquipment.getLastLocation().trim());
	}

	public void populateCheckcallWithLocationCityState(CheckcallDTO checkcallDTO )  {
		String locationForArrivalLoadedUnloaded = Optional.ofNullable(subTaskRepository.getLocationForArrivalUnloaded(checkcallDTO.getInvertOrder(),checkcallDTO.getNextStopSeqNbr())).orElseThrow(()->new JBHuntRuntimeException("Next Stop Sequence Number not found"));
		checkcallDTO.setLocationCityState(convertingCityStateLocation(locationForArrivalLoadedUnloaded.trim()));
	}
	public void populateLoadedcheckcallWithLocationCityState(CheckcallDTO checkcallDTO )  {
		String locationForArrivalLoadedUnloaded = Optional.ofNullable(equipmentRepository.getLastLocationForLoadedCheckcall(checkcallDTO.getTractorNbr())).orElseThrow(()->new JBHuntRuntimeException("Last Location Unknown for this equipment Unit ID, details not found"));
		checkcallDTO.setLocationCityState(locationForArrivalLoadedUnloaded.trim());
	}
	public ResourceAssignmentPlanDTO getResourceAssignmentPlan( OperationalPlanDTO operationalPlanDTO){
		List<OperationalPlanResourceAssignmentAssociationDTO> operationalPlanResourceAssignmentAssociationDTOList =operationalPlanDTO.
				getOperationalPlanResourceAssignmentAssociationList();
		OperationalPlanResourceAssignmentAssociationDTO resourceAssignmentAssociationDTO =Collections.max(operationalPlanResourceAssignmentAssociationDTOList,
				Comparator.comparing(OperationalPlanResourceAssignmentAssociationDTO::getOperationalPlanResourceAssignmentAssociationId));
		ResourceAssignmentPlanDTO resourceAssignmentPlan =  resourceAssignmentAssociationDTO.getResourceAssignmentPlan();
		if (resourceAssignmentPlan.getEquipmentAssignments()==null){
			throw new JBHuntRuntimeException ("Checkcall requires at least one EquipmentAssigment element");
		}
		return resourceAssignmentPlan;
	}
	private static String convertingCityStateLocation(String location){
		String state = location.substring(0, 2);
		String city = location.substring(2, location.length());
		return  location.length() > 4 ? city.concat(state):city.concat(" ").concat(state);
	}
}
