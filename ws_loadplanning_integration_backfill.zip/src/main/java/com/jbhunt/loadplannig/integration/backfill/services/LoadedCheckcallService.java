package com.jbhunt.loadplannig.integration.backfill.services;

import java.net.URISyntaxException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.xml.ws.Holder;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CheckCallHelper;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanCheckCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanStopActivityCheckCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanStopActivityCheckCallReferenceNumberDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanStopCheckCallServiceDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.lmc363i.lmc363.LMC363Port;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord;
import com.response.lmc363i.lmc363.ProgramInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class LoadedCheckcallService  extends CheckCallBackfillService{

    private final CheckCallHelpService checkCallHelpService;
    private final LMC363Port lmc363Port;
    private final BackFillEventTrackingRepository backFillEventTrackingRepository;
    private final CheckCallHelper checkCallHelper;
    private final TimeZoneUtilityService timeZoneUtilityService;


    public void loaded(OperationalPlanDTO operationalPlanDTO) throws URISyntaxException {
        log.info("Loaded CheckCall");
        ResourceAssignmentPlanDTO resourceAssignmentPlan=checkCallHelpService.getResourceAssignmentPlan(operationalPlanDTO);
        CheckcallDTO checkcallDTO= new CheckcallDTO();
        Map<String,String> checkCallElementValuesMap= new HashMap<>();

        OperationalPlanCheckCallDTO operationalPlanCheckCallDTO =operationalPlanDTO.getOperationalPlanCheckCallList().stream().filter(operationalPlanCheckCall->
                    operationalPlanCheckCall.getCheckCallType().getCheckCallTypeCode().equalsIgnoreCase("Loaded")
                ).findAny().orElseThrow(()-> new JBHuntRuntimeException("Loaded Checkcall not found."));
        OperationalPlanStopDTO operationalPlanStopDTO = operationalPlanDTO.getOperationalPlanStops().stream()
                .filter(operationalPlanStop -> operationalPlanStop.getOperationalPlanStopId()
                        .equals(operationalPlanCheckCallDTO.getOperationalPlanStopId()))
                .findFirst().orElseThrow(() -> new JBHuntRuntimeException(
                        "Stop Id " + operationalPlanCheckCallDTO.getOperationalPlanStopId() + " is not found"));

        checkCallHelpService.populateCheckcallWithEquipmentInformation(resourceAssignmentPlan,checkcallDTO);
        OrderOperationalPlanAssociationDTO orderOperationalPlanAssociationDTO =operationalPlanDTO.getOrderOperationalPlanAssociations().get(0);
        checkCallHelpService.populateCheckcallWithOrderInformation(orderOperationalPlanAssociationDTO,checkcallDTO);

        checkcallDTO.setComment(Optional.ofNullable(operationalPlanCheckCallDTO.getCheckCallComment()).orElse(""));
        checkcallDTO.setDataState(CommonConstants.DATA_STATE_B);
        checkcallDTO.setUserId(operationalPlanDTO.getCreateUserId());
        checkcallDTO.setTractorRqdFlg(CommonConstants.TRACTOR_RQD_FLAG);
        if (StringUtils.isEmpty(checkcallDTO.getCarrier())){
            checkcallDTO.setCarrierFlg("I");
        }
        checkcallDTO.setLocationTimeZone(timeZoneUtilityService.getTimeBasedOnLocation(operationalPlanStopDTO.getLocationId()));

        DateTimeFormatter sdfDate = DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT);
        DateTimeFormatter sdfTime = DateTimeFormatter.ofPattern(CommonConstants.TIME_FORMAT);

        checkcallDTO.setCallType(CommonConstants.LOADED_CALL_TYPE);
        Optional.ofNullable(operationalPlanCheckCallDTO.getArrivalCall()).ifPresent(arrivalCall -> {
            checkCallHelpService.populateArrivalInformation(operationalPlanDTO.getOperationalPlanCheckCallList(), arrivalCall, checkcallDTO);
        });
        ZonedDateTime stopActivityTimestamp =operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getStopActivityTimestamp().atZoneSameInstant(ZoneId.of(checkcallDTO.getLocationTimeZone()));

        checkcallDTO.setLoadUnloadDate(stopActivityTimestamp.format(sdfDate));
        checkcallDTO.setLoadUnloadtime(stopActivityTimestamp.format(sdfTime));

        checkCallElementValuesMap.put("LMB4COM-ACHG-CON-NM", CommonConstants.AUTO_APPLY_REASON_CODE_CONTACT);
        checkCallElementValuesMap.put("LMB4COM-ACALL-DATE-RQD-SW","Y");//getAcallDateRqd below from info checkcall
        Character hazMatFlag=Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getHazardousMaterialIndicator()).orElse('N');

        checkCallElementValuesMap.put("LMB4COM-LCALL-PRO-NBR-CHG-SW","N");
        checkCallElementValuesMap.put("LMB4COM-LCALL-PO-NBR-CHG-SW","N");
        checkCallElementValuesMap.put("LMB4COM-LCALL-DRV-CNT-FLG","N");
        checkCallElementValuesMap.put("LMB4COM-LCALL-DRV-BLKBRC-FLG","N");

        checkCallElementValuesMap.put("LMB4COM-LCALL-SHP-LOD-FLG","Y");
        operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getOperationalPlanStopActivityCheckCallReferenceNumbers().forEach(referenceNumber->
            populateReferenceNumber(referenceNumber,checkCallElementValuesMap,checkcallDTO)
        );
        checkCallElementValuesMap.put("LMB4COM-LCALL-HAZ-MAT-FLG",hazMatFlag.toString());
        checkCallElementValuesMap.put("LMB4COM-LCALL-LUMP-LOD-FLG","N");
        checkCallElementValuesMap.put("LMB4COM-LCALL-DRV-SHRNK-FLG","N");
        checkCallHelpService.populateLoadedcheckcallWithLocationCityState(checkcallDTO);
        operationalPlanCheckCallDTO.getOperationalPlanStopCheckCallServices().forEach(operationalPlanStopCheckCallServiceDTO->
            populateOperationalPlanServiceTypeCode(operationalPlanStopCheckCallServiceDTO,checkCallElementValuesMap)
        );

        Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall())
                .map(OperationalPlanStopActivityCheckCallDTO::getStopActivityWeight)
                .ifPresent(v ->{
                    checkcallDTO.setWeight(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getStopActivityWeight().longValue());
                    checkCallElementValuesMap.put("LMB4COM-LCALL-WGT-RQD-SW","Y");
                });
        Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall())
                .map(OperationalPlanStopActivityCheckCallDTO::getStopActivityQuantity)
                .ifPresent(v -> {
                    checkcallDTO.setQuantity(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getStopActivityQuantity());
                    checkCallElementValuesMap.put("LMB4COM-LCALL-QTY-RQD-SW","Y");
                });

        String checkcallVars= getCheckCallVarsValues(checkCallElementValuesMap,checkCallHelper.getCheckcallLoadedElements());
        checkcallDTO.setCheckCallVars(checkcallVars);
        log.info("checkcallVars {}", checkcallVars);
        log.info("checkcallVars lenght {}", checkcallVars.length());

        Lm36ComCommareaRecord lm36ComCommareaRecord =checkCallHelper.createLm36ComCommareaRecord(checkcallDTO);
        com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava lm36ComReturnToJava =checkCallHelper.getLm36ComReturnToJava(checkcallDTO);

        javax.xml.ws.Holder<ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder = new Holder<>();
        javax.xml.ws.Holder<String> lm36ComFillerOutputHolder = new Holder<>();

        log.info(" sending checkcallDTO {}",checkcallDTO);
        lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava, "", new Holder<>(), lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);

        checkCallHelper.loggingCheckcallResponse( lm36ComReturnToJavaOutputHolder);
        log.info("Result of the Loaded operation from the mainframe: {} ",lm36ComFillerOutputHolder.value);
        backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
    }
    private void populateReferenceNumber(OperationalPlanStopActivityCheckCallReferenceNumberDTO referenceNumber, Map<String,String> checkCallElementValuesMap,CheckcallDTO checkcallDTO){
        switch (referenceNumber.getReferenceNumberTypeCode()){
            case CommonConstants.BOL :
                checkcallDTO.setBolNumber(referenceNumber.getReferenceNumberValue());
                checkCallElementValuesMap.put("LMB4COM-LCALL-BOL-RQD-SW","Y");
                break;
            case CommonConstants.PRO_NBR:
                checkCallElementValuesMap.put("LMB4COM-LCALL-PRO-NBR",referenceNumber.getReferenceNumberValue());
                checkCallElementValuesMap.put("LMB4COM-LCALL-PRO-NBR-CHG-SW","Y");
                break;
            case CommonConstants.SEAL:
                checkCallElementValuesMap.put("LMB4COM-LCALL-SEAL-RQD-SW","Y");
                checkcallDTO.setSeal(referenceNumber.getReferenceNumberValue());
                break;
            case CommonConstants.PO_NBR:
                checkCallElementValuesMap.put("LMB4COM-LCALL-PO-NBR",referenceNumber.getReferenceNumberValue());
                checkCallElementValuesMap.put("LMB4COM-LCALL-PO-NBR-CHG-SW","Y");
                break;
            default:break;
        }
    }
    private void populateOperationalPlanServiceTypeCode(OperationalPlanStopCheckCallServiceDTO operationalPlanStopCheckCallServiceDTO, Map<String,String> checkCallElementValuesMap){
        switch (operationalPlanStopCheckCallServiceDTO.getOperationalPlanServiceTypeCode()){
            case CommonConstants.DRIVER_COUNT_FREIGHT :
                checkCallElementValuesMap.put("LMB4COM-LCALL-DRV-CNT-FLG","Y");
                break;
            case CommonConstants.DRIVER_LOAD :
                checkCallElementValuesMap.put("LMB4COM-LCALL-SHP-LOD-FLG","N");
                break;
            default:break;
        }
    }
}
