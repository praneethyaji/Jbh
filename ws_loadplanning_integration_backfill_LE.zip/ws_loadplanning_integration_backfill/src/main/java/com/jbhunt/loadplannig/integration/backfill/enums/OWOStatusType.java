package com.jbhunt.loadplannig.integration.backfill.enums;

import java.util.HashMap;
import java.util.Map;

public enum OWOStatusType {

	INPROGRESS(1, "In Progress"), COMPLETED(2, "Completed"), CANCELED(3, "Canceled"), AVAILABLE(4, "Available");

	Integer typeId;

	String typeName;
	private static Map<String, String> mapValues = new HashMap<>();

	static {
		mapValues.put("In Progress", "S");
		mapValues.put("Completed", "J");
		mapValues.put("Canceled", "D");
		mapValues.put("Available", "U");
	}

	private OWOStatusType(Integer typeId, String name) {
		this.typeId = typeId;
		this.typeName = name;
	}

	public String getTypeName() {
		return typeName;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public static String getOperationByStatus(String value) {
		return mapValues.get(value);
	}

}