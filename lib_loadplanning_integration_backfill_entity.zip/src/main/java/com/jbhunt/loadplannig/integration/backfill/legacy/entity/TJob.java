package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TJOB", schema = "ALI")
public class TJob implements Serializable {

	private static final long serialVersionUID = -4829606184196914960L;

	@Id
	@Column(name = "JOB_ID")
	private Integer jobId;

	@Column(name = "OPR_2_C")
	private String driverCode2;

}
