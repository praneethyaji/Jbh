package com.jbhunt.loadplannig.integration.backfill.controllers;

import java.net.URISyntaxException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.DriverAndTruckPairingService;
import com.jbhunt.loadplannig.integration.backfill.services.DriverAndTruckUnpairingService;
import com.jbhunt.operations.drivertruckassignment.dto.ResourceESDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class DriverTruckAssignmentBackfillController extends BackfillBaseController{

	private final DriverAndTruckPairingService driverAndTruckPairingService;

	private final DriverAndTruckUnpairingService driverAndTruckUnpairingService;
	
	@PostMapping(value = "/drivertruckassignments")
	public ResponseEntity<BackfillServiceResponse> asssignResource(@RequestBody ResourceESDTO resourceESDTO) throws URISyntaxException {
		if (resourceESDTO.getAction().equalsIgnoreCase(CommonConstants.ASSIGN_ACTION)){
			log.info("pairing of truck and driver ");
			driverAndTruckPairingService.pairingofTruckAndDriver(resourceESDTO,false);
		}else if (resourceESDTO.getAction().equalsIgnoreCase(CommonConstants.UNASSIGN_ACTION)){
			log.info("unpairing of truck and driver");
			driverAndTruckUnpairingService.unpairingOfTruckAndDriver(resourceESDTO);
		}
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
}


