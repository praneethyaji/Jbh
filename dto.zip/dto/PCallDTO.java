package com.jbhunt.loadplannig.integration.backfill.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PCallDTO {
	private String callLocation="";
    private String companyTrailerFlag ="";
    private String trailerChassisFlag ="";
    private String overrideLoadFlag ="";
    private String overrideRODownFlag ="";
    private String overrideLengthErrorFlag ="";
    private String overrideRailCodeFlag ="";
    private String addOrderCommentFlag ="";
    private String notifyARFlag ="";
    private String doCheckCallFlag ="";
    private String subtype ="";
    private String filler = "";
}
