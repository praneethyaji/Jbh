package com.jbhunt.loadplannig.integration.backfill.utils;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.exception.MainframeSoapException;
import com.request.lmc359i.lmc359.ProgramInterface.Wo59InputData;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonUtils {
	
	private CommonUtils() {
	}

	public static String convertToDatabaseColumn(LocalDateTime localDateTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSS");
		return localDateTime.format(formatter);
	}

	public static String asString(Object o) {
		if (o != null) {
			ObjectMapper objectMapper = new ObjectMapper();
			try {
				return objectMapper.writeValueAsString(o);
			} catch (JsonProcessingException e) {
				log.error("exception while parsing:", e);
			}
		}
		return "null";
	}

	public static <I, O> O soapCall(Function<I, O> function, I input) {
		try {
			if (input instanceof Wo59InputData) {
				log.info("WorkOrder Number ################################################## {}",
						((Wo59InputData) input).getWo59InData().getWo59NextOwoNum());
			}
			log.info("SOAP request: {}", CommonUtils.asString(input));
			O response = function.apply(input);
			log.info("SOAP Response: {}", CommonUtils.asString(response));
			return response;
		} catch (Exception e) {
			handleSoapException(e);
			throw e;
		}
	}

	public static void handleSoapException(Exception e) {
		String rootCauseMessage = ExceptionUtils.getRootCauseMessage(e);
		if (rootCauseMessage != null) {
			mainframeExceptionCodes.forEach(code -> {
				if (rootCauseMessage.contains(code)) {
					throw new MainframeSoapException(code, e.getMessage(), e);
				}
			});
		}
	}

	public static <T> T getObjectWithDefaultStringValues(Class<T> clz, String value) {
		try {
			T t = clz.newInstance();
			for (Field field : clz.getDeclaredFields()) {
				if (!field.isSynthetic() && field.getType().equals(String.class)) {
					field.setAccessible(true);
					field.set(t, value);
				}
			}
			return t;
		} catch (InstantiationException | IllegalAccessException e) {
			throw new JBHuntRuntimeException(e);
		}
	}
	

	private static Map<String, String> legacyActivityBySubType = new HashMap<>();
	private static Map<String, String> legacyActivityByPayableToDriver = new HashMap<>();
	private static Map<String, String> legacyActivityByStopReasonCode = new HashMap<>();
	protected static final Set<String> mainframeExceptionCodes = new HashSet<>();

	static {
		legacyActivityBySubType.put(CommonConstants.TRAILING_EQUIP, "DEADHEAD");
		legacyActivityBySubType.put(CommonConstants.CHASIS_PLAN_TYPE1, "BOBTAIL");

		legacyActivityByPayableToDriver.put(CommonConstants.BOBTAIL, "BTAILNOPAY");
		legacyActivityByPayableToDriver.put(CommonConstants.DEADHEAD, "DHNOPAY");

		legacyActivityByStopReasonCode.put(CommonConstants.BOBTAIL, "BOBTAIL");
		legacyActivityByStopReasonCode.put(CommonConstants.DEADHEAD, "DEADHEAD");
		legacyActivityByStopReasonCode.put(CommonConstants.PKUP_EQUI, "PKUPTRLR");
		legacyActivityByStopReasonCode.put(CommonConstants.DROP_EQUI, "DROPTRLR");

		mainframeExceptionCodes.add("904");
		mainframeExceptionCodes.add("911");
		mainframeExceptionCodes.add("913");
		mainframeExceptionCodes.add("CICS Web service is down");
		mainframeExceptionCodes.add("FineNext is down");
		mainframeExceptionCodes.add("401");
	}

	public static String getLegacyActivityBySubType(String subType) {
		return legacyActivityBySubType.get(subType);
	}

	public static String getLegacyActivityByPayableToDriver(String subType) {
		return legacyActivityByPayableToDriver.get(subType);
	}

	public static String getLegacyActivityByStopReasonCode(String stopReasonCode) {
		return legacyActivityByStopReasonCode.get(stopReasonCode);
	}
	
	
}
