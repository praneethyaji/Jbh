package com.jbhunt.loadplannig.integration.backfill.services;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CheckCallHelper;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.ArrivalCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanCheckCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.jbhunt.mdm.dto.LocationProfileDTO;
import com.jbhunt.mdm.dto.LocationProfileDTOs;

import com.lmc363i.lmc363.LMC363Port;
import com.response.lmc363i.lmc363.ProgramInterface;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.xml.ws.Holder;
import java.net.URISyntaxException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@Slf4j
@AllArgsConstructor
public class ArrivalCheckcallService extends CheckCallBackfillService {
    private final CheckCallHelpService checkCallHelpService;
    private final LMC363Port lmc363Port;
    private final LocationClient locationClient;
    private final BackFillEventTrackingRepository backFillEventTrackingRepository;
    private final CheckCallHelper checkCallHelper;
	private final TimeZoneUtilityService timeZoneUtilityService;

	public void arrival(OperationalPlanDTO operationalPlanDTO) throws URISyntaxException, JSONException {
		log.info("arrival CheckCall");
		ResourceAssignmentPlanDTO resourceAssignmentPlan = checkCallHelpService.getResourceAssignmentPlan(operationalPlanDTO);
		CheckcallDTO checkcallDTO = new CheckcallDTO();
		Map<String, String> checkCallElementValuesMap = new HashMap<>();

		OperationalPlanCheckCallDTO operationalPlanCheckCallDTO =operationalPlanDTO.getOperationalPlanCheckCallList().stream().filter(operationalPlanCheckCall->
				operationalPlanCheckCall.getCheckCallType().getCheckCallTypeCode().equalsIgnoreCase("Arrival")
		).findAny().orElseThrow(()-> new JBHuntRuntimeException("Arrival Checkcall not found."));

		OperationalPlanStopDTO operationalPlanStopDTO = operationalPlanDTO.getOperationalPlanStops().stream()
				.filter(operationalPlanStop -> operationalPlanStop.getOperationalPlanStopId()
						.equals(operationalPlanCheckCallDTO.getOperationalPlanStopId()))
				.findFirst().orElseThrow(() -> new JBHuntRuntimeException(
						"Stop Id " + operationalPlanCheckCallDTO.getOperationalPlanStopId() + " is not found"));

		checkCallHelpService.populateCheckcallWithEquipmentInformation(resourceAssignmentPlan, checkcallDTO);
		OrderOperationalPlanAssociationDTO orderOperationalPlanAssociationDTO = operationalPlanDTO
				.getOrderOperationalPlanAssociations().get(0);
		checkCallHelpService.populateCheckcallWithOrderInformation(orderOperationalPlanAssociationDTO, checkcallDTO);

		checkcallDTO.setComment(Optional.ofNullable(operationalPlanCheckCallDTO.getCheckCallComment()).orElse(""));
		checkcallDTO.setDataState(CommonConstants.DATA_STATE_B);
		checkcallDTO.setUserId(operationalPlanDTO.getCreateUserId());

		checkcallDTO.setTractorRqdFlg(CommonConstants.TRACTOR_RQD_FLAG);
		if (StringUtils.isEmpty(checkcallDTO.getCarrier())) {
			checkcallDTO.setCarrierFlg("I");
		}

		checkcallDTO.setLocationTimeZone(timeZoneUtilityService.getTimeBasedOnLocation(operationalPlanStopDTO.getLocationId()));
		DateTimeFormatter sdfDate = DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT);
		DateTimeFormatter sdfTime = DateTimeFormatter.ofPattern(CommonConstants.TIME_FORMAT);
		checkcallDTO.setCallType(CommonConstants.ARRIVAL_CALL_TYPE);
		String locationCode = Optional
				.ofNullable(locationClient.findLocationProfilebyLocationCode(operationalPlanStopDTO.getLocationId()))
				.map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode)
				.orElseThrow(() -> new JBHuntRuntimeException("Location Profile not found."));
		checkcallDTO.setStopCustomerCode(locationCode.trim());
		ArrivalCallDTO arrivalCallDTO = operationalPlanCheckCallDTO.getArrivalCall();

		ZonedDateTime arrivalTimestamp =arrivalCallDTO.getArrivalTimestamp().atZoneSameInstant(ZoneId.of(checkcallDTO.getLocationTimeZone()));
		
		checkcallDTO.setArrivalDate(arrivalTimestamp.format(sdfDate));
		checkcallDTO.setArrivalTime(arrivalTimestamp.format(sdfTime));

		Optional.ofNullable(arrivalCallDTO.getArrivalTimeDeviation()).ifPresent(arrivalTimeDeviation -> {
			if (arrivalCallDTO.getArrivalTimeDeviation().getArrivalTimeDeviationType().getArrivalTimeDeviationTypeCode()
					.equals(CommonConstants.EARLY_ARRIVAL_TIME_DEVIATION)) {
				checkCallElementValuesMap.put("LMB4COM-ACHG-CMNTS", CommonConstants.EARLY_ARRIVAL_FAILURE_DESCRIPTION);
				checkCallElementValuesMap.put("LMB4COM-ACHG-RSN-C", CommonConstants.EARLY_ARRIVAL_FAILURE_REASON_CODE);
				checkCallElementValuesMap.put("LMB4COM-ACHG-RSN-CAT-C", CommonConstants.CATEGORY_OPERATIONS);
			} else {
				checkCallElementValuesMap.put("LMB4COM-ACHG-CMNTS", CommonConstants.SORRY_FOR_DELAY);
				checkCallElementValuesMap.put("LMB4COM-ACHG-RSN-C", CommonConstants.FLEXIBLE_APPT_CHANGE_REASON_CODE);
				checkCallElementValuesMap.put("LMB4COM-ACHG-RSN-CAT-C", CommonConstants.CATEGORY_OTHER);
				checkCallElementValuesMap.put("LMB4COM-ACHG-CON-NM",
						arrivalCallDTO.getArrivalTimeDeviation().getContactPersonId());
			}
		});

		checkCallElementValuesMap.put("LMB4COM-ACHG-COM-FLD", CommonConstants.JBHUNT_CARRIER_ALPHA_CODE);
		checkCallElementValuesMap.put("LMB4COM-ACALL-DATE-RQD-SW", CommonConstants.INCLUDES_BILLING);

		String checkcallVars = getCheckCallVarsValues(checkCallElementValuesMap,
				checkCallHelper.getCheckcallArrivalElements());
		checkCallHelpService.populateCheckcallWithLocationCityState( checkcallDTO);
		checkcallDTO.setCheckCallVars(checkcallVars);
		log.info("checkcallVars {}", checkcallVars);
		log.info("checkcallVars.lenght {}", checkcallVars.length());

		Lm36ComCommareaRecord lm36ComCommareaRecord = checkCallHelper.createLm36ComCommareaRecord(checkcallDTO);
		com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava lm36ComReturnToJava = checkCallHelper
				.getLm36ComReturnToJava(checkcallDTO);

		javax.xml.ws.Holder<ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder = new Holder<>();
		javax.xml.ws.Holder<String> lm36ComFillerOutputHolder = new Holder<>();

		log.info(" sending checkcallDTO {}", checkcallDTO);
		lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava, "", new Holder<>(),
				lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);

		checkCallHelper.loggingCheckcallResponse(lm36ComReturnToJavaOutputHolder);
		log.info("Result of the Loaded operation from the mainframe: {} ", lm36ComFillerOutputHolder.value);
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
	}
}