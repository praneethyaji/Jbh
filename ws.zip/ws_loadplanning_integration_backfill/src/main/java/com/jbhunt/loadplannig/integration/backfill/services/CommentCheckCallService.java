package com.jbhunt.loadplannig.integration.backfill.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanOrderDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanTypeDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.operations.trackandtrace.dto.CheckCallESDTO;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class CommentCheckCallService {

	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final CheckCallHelpService terminateCallHelper;

	public void addCommentCall(final CheckCallESDTO checkCallESDTO) {
		final OperationalPlanDTO operationalPlanDTO = constructOperationalPlanDTO(checkCallESDTO);
		backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
				CommonConstants.SUBEVENTTYPE_COMMENTCALL, "");

		terminateCallHelper.prepareLMC363Request(operationalPlanDTO, checkCallESDTO.getLastUpdateUserId(),
				checkCallESDTO.getLastUpdateUserId(), checkCallESDTO.getComment(),
				checkCallESDTO.getOperationalPlanId());

	}

	private OperationalPlanDTO constructOperationalPlanDTO(CheckCallESDTO checkCallESDTO) {
		final OperationalPlanDTO operationalPlanDto = new OperationalPlanDTO();
		operationalPlanDto.setOperationalPlanId(checkCallESDTO.getOperationalPlanId());
		operationalPlanDto.setOperationalPlanNumber(checkCallESDTO.getOperationalPlanNumber());
		operationalPlanDto.setCreateUserId(checkCallESDTO.getLastUpdateUserId());
		operationalPlanDto.setCreateProgramName(checkCallESDTO.getLastUpdateProgramName());
		operationalPlanDto.setLastUpdateUserId(checkCallESDTO.getLastUpdateUserId());
		operationalPlanDto.setLastUpdateProgramName(checkCallESDTO.getLastUpdateProgramName());
		List<OrderOperationalPlanAssociationDTO> listOfOperationalPlanOrderDTO = new ArrayList<>();
		OrderOperationalPlanAssociationDTO orderOperationalPlanAssociations = new OrderOperationalPlanAssociationDTO();
		OperationalPlanOrderDTO operationalPlanOrderDTO = new OperationalPlanOrderDTO();
		operationalPlanOrderDTO.setOrderId(0);
		operationalPlanOrderDTO.setOrderTrackingNumber("");
		orderOperationalPlanAssociations.setOperationalPlanOrder(operationalPlanOrderDTO);
		listOfOperationalPlanOrderDTO.add(orderOperationalPlanAssociations);
		operationalPlanDto.setOrderOperationalPlanAssociations(listOfOperationalPlanOrderDTO);
		OperationalPlanTypeDTO operationalPlanTypeDTO = new OperationalPlanTypeDTO();
		operationalPlanTypeDTO.setOperationalPlanTypeCode("Freight");
		operationalPlanDto.setOperationalPlanType(operationalPlanTypeDTO);
		return operationalPlanDto;
	}
}
