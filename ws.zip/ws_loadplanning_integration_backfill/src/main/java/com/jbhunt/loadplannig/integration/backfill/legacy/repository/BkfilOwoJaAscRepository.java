package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.BkfilOwoJaAsc;

@RepositoryRestResource
public interface BkfilOwoJaAscRepository extends JpaRepository<BkfilOwoJaAsc, Integer> {

	@Query(value = "SELECT A.NEXT_OWO_I, A.NEXT_OWO_NUM, B.ORD_NBR_CH, B.ORD_I FROM ALI.BKFIL_OWO_JA_ASC A, ALI.TORDER B"
			+ " WHERE A.NEXT_OWO_NUM = (:nxtOwoNum) AND A.LGC_JA_I = B.ORD_I WITH UR ", nativeQuery = true)
	List<Object[]> findOrdIBynxtOwoNum(@Param("nxtOwoNum") String nxtOwoNum);
	
	@Query(value = "SELECT O.NEXT_OWO_I FROM ALI.BKFIL_OWO_JA_ASC O, ALI.TPND_JOB_ASN P WHERE O.LGC_JA_I= P.TSK_I AND P.EQP_UNT_I=:eqpUnitID AND  P.RSC_RSV_I > 0 ORDER BY P.ETA_D ,P.ETA_H WITH UR", nativeQuery = true)
    List<Integer> getPlannedNewOwoOrderIdsBylegacyEquipmentId(@Param("eqpUnitID") String eqpUnitID);

}
