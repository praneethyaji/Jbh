package com.jbhunt.loadplannig.integration.backfill.utils;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersBuffer;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersErrorBuffer;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersLink;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersLinkBuffers;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersModeBuffer;
import com.jbhunt.biz.refNumber.vo.AddNewReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.DeletedReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.LineItemVO;
import com.jbhunt.biz.refNumber.vo.UpdatedReferenceNumberVO;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrdRefNbrRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanReferenceNumberDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopItemDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InStpLine;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class ReferenceUpdateServiceHelper {

	private final ReferenceNumberBuilder referenceNumberBuilder;
	private final ReferenceUpdateHelper referenceUpdateHelper;
	private final ItemReferenceNumberHelper itemReferenceNumberHelper;
	private final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
	private final OrdRefNbrRepository ordRefNbrRepository;

	public ReferenceNumbersLinkBuffers linkOEC070InSelectMode(Integer orderId, String netUserId, String programName,
			String userName, String password) throws JBHuntRuntimeException {
		ReferenceNumbersLinkBuffers oec070Buffers = new ReferenceNumbersLinkBuffers();
		ReferenceNumbersModeBuffer mode = oec070Buffers.getMode();
		mode.setOrderID(orderId);
		mode.setMode("SELECT-TAB");
		mode.setCount(0);
		mode.setUserID(netUserId);
		mode.setProgramName(programName);
		ReferenceNumbersLinkBuffers retrieveOEC070Info = null;
		try {
			log.info("oec070Buffers in Select  Case >>>>>>>>>>>>>>>>>>>>>>>> {}",oec070Buffers);
			ReferenceNumbersLink referenceNumbersLink = new ReferenceNumbersLink(oec070Buffers);
			retrieveOEC070Info = (ReferenceNumbersLinkBuffers) referenceNumbersLink.retrieveOEC070Info(userName,
					password);
		} catch (Exception e) {
			log.error("Exception while ReferenceNumbersLink" + e);
			throw new JBHuntRuntimeException("Exception while ReferenceNumbersLink" + e.getLocalizedMessage());
		}
		return retrieveOEC070Info;
	}

	public String linkOEC070InUpdateMode(ReferenceNumbersLinkBuffers oec070Buffers,
			List<UpdatedReferenceNumberVO> updRefNbrList, List<AddNewReferenceNumberVO> newRefNbrList,
			List<DeletedReferenceNumberVO> delRefNbrList, OrderLoadSync orderLoadSyncDTO, String pidCredentials,
			String callMode, String oec070Create) throws JBHuntRuntimeException {
		log.info(" mg7:linkOEC070InUpdateMode::");
		ReferenceNumbersBuffer referenceNumbers = oec070Buffers.getReferenceNumbers(); 
		int maxReferenceNumbersCount = ReferenceNumbersBuffer.MAX_REF_NBR_COUNT;
		int orderReferenceNumbersCount = this.constructExistingRefNbrBuff(oec070Buffers, referenceNumbers,
				maxReferenceNumbersCount);
		
		 int refNbrInsertCnt = 0;
        if ("LINEITEM".equalsIgnoreCase(callMode)) {
            refNbrInsertCnt = referenceUpdateHelper.populateRefNbrForLineItems(updRefNbrList, newRefNbrList,
                    delRefNbrList, referenceNumbers, orderReferenceNumbersCount);
        } else {
            refNbrInsertCnt = referenceUpdateHelper.populateReferenceNumberForOthers(updRefNbrList, newRefNbrList, delRefNbrList,
                    referenceNumbers, orderReferenceNumbersCount);
        }

		int totalReferenceNumbersCounter = orderReferenceNumbersCount + refNbrInsertCnt;
		log.debug("calling ref nbr update " + totalReferenceNumbersCounter);
		 
		ReferenceNumbersModeBuffer mode = oec070Buffers.getMode();
		mode.setOrderID(orderLoadSyncDTO.getLegacyOrderID());
		mode.setMode("UPDATE-TAB");
		mode.setCount(totalReferenceNumbersCounter);
		mode.setUserID(pidCredentials.split("::")[0]);
		mode.setProgramName(CommonConstants.OPEX);

		ReferenceNumbersLink referenceNumbersLink = null;
		ReferenceNumbersLinkBuffers buffers = null;
		ReferenceNumbersErrorBuffer errors = null;
		try {
			log.info("oec070Buffers in Update Case >>>>>>>>>>>>>>>>>>>>>>>> {}",CommonUtils.asString(oec070Buffers));
			referenceNumbersLink = new ReferenceNumbersLink(oec070Buffers);
		} catch (IOException e1) {
			log.error("ReferenceNumbersLink error" + e1);
			throw new JBHuntRuntimeException("ReferenceNumbersLink error" + e1.getLocalizedMessage());
		}
		String errorMessage = null;
		try {
			
				referenceNumbersLink.retrieveOEC070InfoForBackfill(pidCredentials.split("::")[0],
						pidCredentials.split("::")[1], oec070Create, orderLoadSyncDTO.getScmOrderID());
				buffers = referenceNumbersLink.getBuffers();
				if (null != buffers) {
					errors = buffers.getError();
				}
				if (errors != null && errors.getMessage() != null && errors.getMessage().length() > 0) {
					errorMessage = errors.getMessage();
				} else {
					errorMessage = "SUCCESS";
				}
			
		} catch (Exception e) {
			log.error("Exception while retrieve OEC070 Information" + e);
			throw new JBHuntRuntimeException("Exception while retrieve OEC070 Information" + e.getLocalizedMessage());
		}
		return errorMessage;
	}
	

	public int constructExistingRefNbrBuff(ReferenceNumbersLinkBuffers oec070Buffers,
			ReferenceNumbersBuffer referenceNumbers, int maxReferenceNumbersCount) {
		int orderReferenceNumbersCount = 0;
		if (oec070Buffers.getNbrOfRefNbrs() > 0) {
			for (int i = 0; i < maxReferenceNumbersCount; i++) {
				if (!referenceNumbers.getType(i).isEmpty()) {
					referenceNumbers.setAction("UNCHANGED", i);
					referenceNumbers.setOldNumber(referenceNumbers.getNumber(i), i);
					referenceNumbers.setOldType(referenceNumbers.getType(i), i);
					referenceNumbers.setOldSiteID(referenceNumbers.getSiteID(i), i);
					referenceNumbers.setOldAddressID(referenceNumbers.getAddressID(i), i);
					referenceNumbers.setOldSequence(referenceNumbers.getSequence(i), i);
					referenceNumbers.setOldDepartment(referenceNumbers.getDepartment(i), i);
					referenceNumbers.setOldCustomerCode(referenceNumbers.getCustomerCode(i), i);
					orderReferenceNumbersCount++;
				}
			}
		}
		return orderReferenceNumbersCount;
	}

	public void defaultLineItemValuesForRefMode(List<UpdatedReferenceNumberVO> updRefNbrList,
			List<AddNewReferenceNumberVO> crtRefNbrList, List<DeletedReferenceNumberVO> delRefNbrList,
			String callMode) {
		if ("REFNBR".equalsIgnoreCase(callMode)) {
			delRefNbrList.forEach(refNbr -> {
				if (refNbr.getLineItemVO() != null) {
					refNbr.getLineItemVO().setActCls(0);
				}
			});
			crtRefNbrList.forEach(refNbr -> {
				if (refNbr.getLineItemVO() != null) {
					refNbr.getLineItemVO().setActCls(0);
				}
			});
			updRefNbrList.forEach(refNbr -> {
				if (refNbr.getLineItemVO() != null) {
					refNbr.getLineItemVO().setActCls(0);
				}
			});
		}
	}

	// Insert Ref Number
	public List<AddNewReferenceNumberVO> fetchCreateReferenceNumberVO(OperationalPlanEvent operationalPlanEvent,
			List<OperationalPlanReferenceNumberDTO> referenceNumberDTOs, Oee5InputChannelData input, String entity) {
		List<AddNewReferenceNumberVO> crtRefNbrList = new ArrayList<>();
		getStopItem(operationalPlanEvent, referenceNumberDTOs, input, crtRefNbrList, entity);
		return crtRefNbrList;
	}

	private void getStopItem(OperationalPlanEvent operationalPlanEvent,
			List<OperationalPlanReferenceNumberDTO> referenceNumberDTOs, Oee5InputChannelData input,
			List<AddNewReferenceNumberVO> crtRefNbrList,
			String entity) {
		AddNewReferenceNumberVO refNbrDetails = null;
		for (OperationalPlanReferenceNumberDTO referenceNumberDTO : referenceNumberDTOs) {
			for (Oee5InStpLine oee5OutStpLine : input.getOee5InStpBuffer5()) {
				for (OperationalPlanStopDTO stopDTO : operationalPlanEvent.getOperationalPlanDTO()
						.getOperationalPlanStops()) {
					    refNbrDetails = new AddNewReferenceNumberVO();
						OperationalPlanStopItemDTO stopItem = itemReferenceNumberHelper
								.getStopItemIfTiedToReferenceNumber(referenceNumberDTO, stopDTO);
						referenceNumberBuilder.populateNewReferenceNumberList(refNbrDetails, referenceNumberDTO,
								oee5OutStpLine, stopDTO,
								operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops().size(),
								crtRefNbrList, stopItem);
				}
			}
		}
		referenceNumberBuilder.populateNewOrderLevelReference(referenceNumberDTOs, input, entity,
				crtRefNbrList); 
	}
	
	
	public void deleteReferenceNumbers(Integer legacyOrderID) {
		Integer refNosDeleted = null;
		refNosDeleted = ordRefNbrRepository.deleteReferenceNumbers(legacyOrderID);
		log.info("Deleted reference numbers: " + refNosDeleted);
	}

}
