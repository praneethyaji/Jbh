package com.jbhunt.loadplannig.integration.backfill.configuration;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.interceptor.BasicAuthInterceptor;
import com.jbhunt.loadplannig.integration.backfill.properties.LoadplanningIntegrationbackfillProperties;

@Configuration
@EnableHystrix
@EnableConfigurationProperties(LoadplanningIntegrationbackfillProperties.class)
public class LoadplanningIntegrationbackfillConfiguration {
    private static final int CONNECTION_MAX_TOTAL = 10;

    @Autowired
    private PIDCredentials pidCredentials;

    @Bean
    public RestTemplate loadplanningIntegrationbackfillRestTemplate() {
        final RestTemplate restTemplate = new RestTemplate();
        MappingJackson2HttpMessageConverter mappingMessageconverter = new MappingJackson2HttpMessageConverter();
        restTemplate.getMessageConverters().add(mappingMessageconverter);
        Jaxb2RootElementHttpMessageConverter jaxbMessageConverter = new Jaxb2RootElementHttpMessageConverter();
        restTemplate.getMessageConverters().add(jaxbMessageConverter);
        BasicAuthInterceptor basicAuthInterceptor = new BasicAuthInterceptor(pidCredentials.getUsername(),
                pidCredentials.getPassword());
        restTemplate.getInterceptors().add(basicAuthInterceptor);
        final PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
        connManager.setMaxTotal(CONNECTION_MAX_TOTAL);
        final HttpClient httpClient = HttpClientBuilder.create().setConnectionManager(connManager).build();
        ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
        restTemplate.setRequestFactory(requestFactory);
        return restTemplate;
    }
}
