package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@Entity
@Table(name = "TSUBTASK1", schema = "ALI")
public class TSubtask1 implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6741997410067504800L;

	@Id
	@Column(name = "STSK_ID")
	private Integer subTaskID;

	@Column(name = "PRF_SEQ_N")
	private Integer preferanceSequenceNumber;

	@Column(name = "TASK_ID")
	private String taskId;
	
    @Column(name = "JOB_ID")
	private Integer jobId;

	@Column(name = "RQ_TY_ID")
	private String requestTyId;

	@Column(name = "BSST_ID")
	private Integer businessId;

	@Column(name = "BSST_ALIAS")
	private String customerCode;

	@Column(name = "CITY_ID")
	private String cityId;

	@Column(name = "CURR_APT_BEG_D")
	private String currentAppointmnetBegDate;

	@Column(name = "CURR_APT_BEG_H")
	private String currentAppointmnetBegHour;
	@Column(name = "CURR_APT_END_D")
	private String aptEstimateDate;

	@Column(name = "CURR_APT_END_H")
	private String currentApointmentEndHour;

	@Column(name = "PROG_STT_C")
	private String progressStatusCode;

	@Column(name = "REC_STT_F")
	private String recordStatus;
	
	 @Column(name = "RSC_RSV_I")
	 private Integer reservationId;

}
