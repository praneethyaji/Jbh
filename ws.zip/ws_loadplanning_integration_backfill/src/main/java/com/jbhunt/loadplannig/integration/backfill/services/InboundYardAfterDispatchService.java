package com.jbhunt.loadplannig.integration.backfill.services;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.xml.ws.Holder;

import org.json.JSONException;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOperator;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OperatorRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CheckCallHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.SendPlanHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.personnel.people.dto.PeopleDetailsDTO;
import com.lmc363i.lmc363.LMC363Port;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord;
import com.response.lmc363i.lmc363.ProgramInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class InboundYardAfterDispatchService extends CheckCallBackfillService {
	private final CheckCallHelpService checkCallHelpService;
	private final SendPlanHelper sendPlanHelper;
	private final LMC363Port lmc363Port;
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final CheckCallHelper checkCallHelper;
	private final OperatorRepository operatorRepository;
	private final EquipmentRepository equipmentRepository;

	public void inboundYardAfterDispatch(OperationalPlanDTO operationalPlanDTO)
			throws URISyntaxException, JSONException {
		log.info("inboundYardAfterDispatch");
		ResourceAssignmentPlanDTO resourceAssignmentPlan = checkCallHelpService
				.getResourceAssignmentPlan(operationalPlanDTO);
		
		CheckcallDTO checkcallDTO = new CheckcallDTO();
		String locationCode = sendPlanHelper.getLocationCode(operationalPlanDTO);

		checkCallHelpService.populateCheckcallWithEquipmentInformation(resourceAssignmentPlan, checkcallDTO);
		TEquipment equipmentDetails =  Optional
				.ofNullable(equipmentRepository.getLastLocationForLoadedCheckcall(checkcallDTO.getTractorNbr()))
				.orElseThrow(() -> new JBHuntRuntimeException(
						"Last Location Unknown for this equipment Unit ID, equipment details not found"));
		final PeopleDetailsDTO driverDetails = resourceAssignmentPlan.getDriverAssignment() != null
				? sendPlanHelper.populateDriverDetails(resourceAssignmentPlan)
				: new PeopleDetailsDTO();
		final TOperator operatorDetails = operatorRepository.findLstUpdatedTimeByAlphaId(driverDetails.getAlphaCode());
		Map<String, String> checkCallElementValuesMap = new HashMap<>();
		checkCallElementValuesMap.put("LMB4COM-ETAU-TRK-AUTO-DISP-FLG",
				setAutoDispatch(equipmentDetails.getAutoDispatchFlag(), equipmentDetails.getPplXmnEnaFlag()));
		checkCallElementValuesMap.put("LMB4COM-ETAU-TRK-IB-YRD-CD", locationCode);
		checkCallElementValuesMap.put("LMB4COM-ETAU-HRS-2-DRV", operatorDetails.getHoursToDriver().toString());

		String checkcallVars = getCheckCallVarsValues(checkCallElementValuesMap,
				checkCallHelper.getCheckcallArrivalElements());
		log.info("checkcallVars {}", checkcallVars);
		log.info("checkcallVars.lenght {}", checkcallVars.length());
		checkcallDTO.setCheckCallVars(checkcallVars);

		Lm36ComCommareaRecord lm36ComCommareaRecord = checkCallHelper.createLm36ComCommareaRecord(checkcallDTO);
		com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava lm36ComReturnToJava = checkCallHelper
				.getLm36ComReturnToJava(checkcallDTO);

		javax.xml.ws.Holder<ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder = new Holder<>();
		javax.xml.ws.Holder<String> lm36ComFillerOutputHolder = new Holder<>();

		lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava, "", new Holder<>(),
				lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);

		checkCallHelper.loggingCheckcallResponse(lm36ComReturnToJavaOutputHolder);
		log.info("Result of the Loaded operation from the mainframe: {} ", lm36ComFillerOutputHolder.value);
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
	}

	private String setAutoDispatch(String autoDspFlag, String pplXmtFlag) {
		String autoDispatch = "";
		if (autoDspFlag.equals("Y") && pplXmtFlag.equals("Y")) {
			autoDispatch = "Y";
		} else if (autoDspFlag.equals("Y") && pplXmtFlag.equals("N")) {
			autoDispatch = "D";
		} else if (autoDspFlag.equals("N") && pplXmtFlag.equals("Y")) {
			autoDispatch = "P";
		} else if (autoDspFlag.equals("A") && pplXmtFlag.equals("Y")) {
			autoDispatch = "A";
		} else if (autoDspFlag.equals("A") && pplXmtFlag.equals("N")) {
			autoDispatch = "B";
		} else if (autoDspFlag.equals("R")) {
			autoDispatch = "R";
		} else {
			autoDispatch = "N";
		}
		return autoDispatch;
	}
}