package com.jbhunt.loadplannig.integration.backfill.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.xml.ws.Holder;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallElement;
import com.jbhunt.loadplannig.integration.backfill.dto.PCallDTO;
import com.jbhunt.loadplannig.integration.backfill.dto.SpotDBCallDTO;
import com.jbhunt.loadplannig.integration.backfill.dto.TerminateCallDTO;
import com.request.lmc363i.lmc363.ProgramInterface;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars.Lm36ComRouteInfo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@NoArgsConstructor
@Slf4j
@Getter
@Scope("singleton")
public class CheckCallHelper {
	private List<CheckcallElement> checkcallArrivalElements;
	private List<CheckcallElement> checkcallInfoElements;
	private List<CheckcallElement> checkcallLoadedElements;
	private List<CheckcallElement> checkcallUnloadedElements;
	private List<CheckcallElement> checkcallTerminateElements;
	private List<CheckcallElement> checkcallSDBElements;
	private List<CheckcallElement> checkcallCommentElements;
	private List<CheckcallElement> checkcallUpdateElements;

	@PostConstruct
	public void getCheckCallElementList() {
		log.info("**** Loading configuration fir checkcall vars from json files  *****");
		checkcallArrivalElements = fetchCheckcallLElementListFromFile("comACallVars.json");
		checkcallInfoElements = fetchCheckcallLElementListFromFile("comLCallVars.json");
		checkcallLoadedElements = fetchCheckcallLElementListFromFile("comLCallVars.json");
		checkcallTerminateElements = fetchCheckcallLElementListFromFile("comTCallVars.json");
		checkcallUnloadedElements = fetchCheckcallLElementListFromFile("comUCallVars.json");
		checkcallSDBElements = fetchCheckcallLElementListFromFile("comSDBCallVars.json");
		checkcallCommentElements = fetchCheckcallLElementListFromFile("comPCallVars.json");
		checkcallUpdateElements = fetchCheckcallLElementListFromFile("comUpdateVars.json");
	}

	private List<CheckcallElement> fetchCheckcallLElementListFromFile(String fileName) {
		log.info("loading json file {}", fileName);
		try {
			InputStream in = TypeReference.class.getResourceAsStream("/checkcall/" + fileName);
			ObjectMapper mapper = new ObjectMapper();
			return mapper.readValue(in, new TypeReference<ArrayList<CheckcallElement>>() {
			});
		} catch (JsonParseException | JsonMappingException ex) {
			log.error("Parsing Error loading the json file ", ex);
		} catch (IOException io) {
			log.error("Error loading the json file ", io);
		}
		return new ArrayList<>();
	}

	public ProgramInterface.Lm36ComCommareaRecord createLm36ComCommareaRecord(CheckcallDTO checkcallDTO) {
		ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables lm36ComJavaSentVariables = new ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables();
		ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComDraynetVars lm36ComDraynetVars = new ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComDraynetVars();

		lm36ComDraynetVars.setLm36ComDataState(checkcallDTO.getDataState());
		lm36ComDraynetVars.setLm36ComUserid(checkcallDTO.getUserId());
		lm36ComDraynetVars.setLm36ComJobId(checkcallDTO.getJobId());
		lm36ComDraynetVars.setLm36ComCreateUserid(checkcallDTO.getUserId());
		lm36ComDraynetVars.setLm36ComOrderNbr(checkcallDTO.getOrderNumber());

		lm36ComDraynetVars.setLm36ComTrkEqpId(checkcallDTO.getEqpId());
		lm36ComDraynetVars.setLm36ComTrkEqpNbr(checkcallDTO.getTractorNbr());
		lm36ComDraynetVars.setLm36ComTrkRqdFlg(checkcallDTO.getTractorRqdFlg());
		lm36ComDraynetVars.setLm36ComProject(checkcallDTO.getProject());
		lm36ComDraynetVars.setLm36ComCarrier(checkcallDTO.getCarrier());
		lm36ComDraynetVars.setLm36ComInvertOrd(checkcallDTO.getInvertOrder());

		lm36ComDraynetVars.setLm36ComIeCarrierFlg((checkcallDTO.getCarrierFlg()));

		ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars lm36ComStatusUpdateVars = new ProgramInterface.Lm36ComCommareaRecord.Lm36ComJavaSentVariables.Lm36ComStatusUpdateVars();
		lm36ComStatusUpdateVars.setLm36ComOrderTimestampIn(checkcallDTO.getOrderTimeStamp());
		lm36ComStatusUpdateVars.setLm36ComCallType(checkcallDTO.getCallType());
		lm36ComStatusUpdateVars.setLm36ComLocationCityState(checkcallDTO.getLocationCityState());
		lm36ComStatusUpdateVars.setLm36ComStopSeqNbr(checkcallDTO.getNextStopSeqNbr());
		lm36ComStatusUpdateVars.setLm36ComTrailerOutPfx(checkcallDTO.getTrailerContainerPrefix());
		lm36ComStatusUpdateVars.setLm36ComTrailerOutNbr(checkcallDTO.getTrailerContainerNumber());
		lm36ComStatusUpdateVars.setLm36ComArrivalDate(checkcallDTO.getArrivalDate());
		lm36ComStatusUpdateVars.setLm36ComArrivalTime(checkcallDTO.getArrivalTime());
		lm36ComStatusUpdateVars.setLm36ComCheckCallVars(checkcallDTO.getCheckCallVars());
		lm36ComStatusUpdateVars.setLm36ComTcallCustomerCode(checkcallDTO.getTcallCustomerCode());
		lm36ComStatusUpdateVars.setLm36ComLoadUnldDate(checkcallDTO.getLoadUnloadDate());
		lm36ComStatusUpdateVars.setLm36ComLoadUnldTime(checkcallDTO.getLoadUnloadtime());
		lm36ComStatusUpdateVars.setLm36ComSeal(checkcallDTO.getSeal());
		lm36ComStatusUpdateVars.setLm36ComBol(checkcallDTO.getBolNumber());
		lm36ComStatusUpdateVars.setLm36ComQtyNum(checkcallDTO.getQuantity());
		lm36ComStatusUpdateVars.setLm36ComWgtNum(checkcallDTO.getWeight());
		lm36ComStatusUpdateVars.setLm36ComBeamTrailerOrder(checkcallDTO.getBeamTrailerOrder());
		lm36ComStatusUpdateVars.setLm36ComComments(checkcallDTO.getComment());

		List<Lm36ComRouteInfo> lm36ComRouteInfoList = new ArrayList<>();
		checkcallDTO.getRouteDetails().forEach((k, v) -> {
			Lm36ComRouteInfo lm36ComRouteInfo = new Lm36ComRouteInfo();
			lm36ComRouteInfo.setLm36ComRouteCty(k.trim());
			lm36ComRouteInfo.setLm36ComRouteType(v);
			lm36ComRouteInfoList.add(lm36ComRouteInfo);
		});
		lm36ComStatusUpdateVars.setLm36ComRouteInfoTable(lm36ComRouteInfoList);

		ProgramInterface.Lm36ComCommareaRecord lm36ComCommareaRecord = new ProgramInterface.Lm36ComCommareaRecord();
		lm36ComCommareaRecord.setLm36ComJavaSentVariables(lm36ComJavaSentVariables);
		lm36ComJavaSentVariables.setLm36ComDraynetVars(lm36ComDraynetVars);
		lm36ComJavaSentVariables.setLm36ComStatusUpdateVars(lm36ComStatusUpdateVars);

		return lm36ComCommareaRecord;
	}

	public com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava getLm36ComReturnToJava(
			CheckcallDTO checkcallDTO) {
		com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava lm36ComReturnToJava = new com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava();
		ProgramInterface.Lm36ComReturnToJava.Lm36ComShipmentStatusVars lm36ComShipmentStatusVars = new ProgramInterface.Lm36ComReturnToJava.Lm36ComShipmentStatusVars();
		ProgramInterface.Lm36ComReturnToJava.Lm36ComErrorFields lm36ComErrorFields = new ProgramInterface.Lm36ComReturnToJava.Lm36ComErrorFields();
		lm36ComShipmentStatusVars.setLm36ComStopCustomerCode(checkcallDTO.getStopCustomerCode());
		lm36ComErrorFields.setLm36ComErrorFlag(" ");
		lm36ComReturnToJava.setLm36ComShipmentStatusVars(lm36ComShipmentStatusVars);
		return lm36ComReturnToJava;
	}

	public void loggingCheckcallResponse(
			Holder<com.response.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder) {
		Optional.ofNullable(lm36ComReturnToJavaOutputHolder.value).ifPresent(value -> {
			Optional.ofNullable(value.getLm36ComErrorFields()).ifPresent(comErrorField -> {
				String messageError = "";
				messageError = comErrorField.getLm36ComErrorMessage().trim();
				log.info("result of the checkCall operation from the mainframe ErrorFlag: {}",
						comErrorField.getLm36ComErrorFlag());
				log.info("result of the checkCall operation from the mainframe ErrorMessage: {}", messageError);
				if (!StringUtils.isEmpty(messageError)) {
					throw new JBHuntRuntimeException(messageError);
				}
			});
		});
	}

	public Map<String, String> populateSDBElements(CheckcallDTO checkCallDTO) {
		Map<String, String> checkCallSDBElementsMap = new HashMap<>();
		SpotDBCallDTO spotCallDTO = checkCallDTO.getSpotCallDTO();
		checkCallSDBElementsMap.put("LMB4COM-SDB-AREA-ID", spotCallDTO.getAreaId());
		checkCallSDBElementsMap.put("LMB4COM-SDB-TLR-CUST-CD", spotCallDTO.getTrailerCustomerCode());
		checkCallSDBElementsMap.put("LMB4COM-SDB-TLR-CITY-ST", spotCallDTO.getTrailerCityState());
		checkCallSDBElementsMap.put("LMB4COM-SDB-CHASSIS-PFX", spotCallDTO.getChassisPrefix());
		checkCallSDBElementsMap.put("LMB4COM-SDB-CHASSIS-NBR", spotCallDTO.getChassisNumber());
		checkCallSDBElementsMap.put("LMB4COM-SDB-PAY-DH-FLAG", spotCallDTO.getPayDHFlag());
		checkCallSDBElementsMap.put("LMB4COM-SDB-DROP-TRLR-FLAG", spotCallDTO.getDropTrailerFlag());
		checkCallSDBElementsMap.put("LMB4COM-SDB-VERIFY-MSG-FLAG", spotCallDTO.getVerfityMessageFlag());
		checkCallSDBElementsMap.put("LMB4COM-SDB-DS31-OVR-FLAG", spotCallDTO.getOverwriteFlag());
		checkCallSDBElementsMap.put("LMB4COM-SDB-DS31-WARN-FLAG", spotCallDTO.getWarningFlag());
		checkCallSDBElementsMap.put("LMB4COM-SDB-DHPAY-WARN-FLAG", spotCallDTO.getDhWarningFlag());
		checkCallSDBElementsMap.put("LMB4COM-SDB-FILLER", spotCallDTO.getFiller());

		return checkCallSDBElementsMap;
	}

	public Map<String, String> populateCommentCallElements(CheckcallDTO checkCallDTO) {
		Map<String, String> pCallElementsMap = new HashMap<>();
		PCallDTO pCallDTO = checkCallDTO.getPCallDTO();
		pCallElementsMap.put("LMB4COM-CCALL-CALL-LOCATION", pCallDTO.getCallLocation());
		pCallElementsMap.put("LMB4COM-CCALL-CMPY-TRLR-FLG", pCallDTO.getCompanyTrailerFlag());
		pCallElementsMap.put("LMB4COM-CCALL-TRLR-CHAS-FLG", pCallDTO.getTrailerChassisFlag());
		pCallElementsMap.put("LMB4COM-CCALL-OVR-LOAD-FLG", pCallDTO.getOverrideLoadFlag());
		pCallElementsMap.put("LMB4COM-CCALL-OVR-RO-DOWN-FLG", pCallDTO.getOverrideRODownFlag());
		pCallElementsMap.put("LMB4COM-CCALL-OVR-LEN-ERR-FLG", pCallDTO.getOverrideLengthErrorFlag());
		pCallElementsMap.put("LMB4COM-CCALL-OVR-RAILC-FLG", pCallDTO.getOverrideRailCodeFlag());
		pCallElementsMap.put("LMB4COM-CCALL-ADD-ORD-CMNT-FLG", pCallDTO.getAddOrderCommentFlag());
		pCallElementsMap.put("LMB4COM-CCALL-NOTIFY-AR-FLG", pCallDTO.getNotifyARFlag());
		pCallElementsMap.put("LMB4COM-CCALL-DO-CHKCALL-FLG", pCallDTO.getDoCheckCallFlag());
		pCallElementsMap.put("LMB4COM-CCALL-SUBTYPE", pCallDTO.getSubtype());
		pCallElementsMap.put("LMB4COM-CCALL-FILLER", pCallDTO.getFiller());

		return pCallElementsMap;
	}

	public Map<String, String> populateTerminateCallElements(TerminateCallDTO terminateCallDTO) {
		Map<String, String> terminateCallElementsMap = new HashMap<>();
		terminateCallElementsMap.put("LMB4COM-TCALL-PKUP-AREA", terminateCallDTO.getPickupArea());
		terminateCallElementsMap.put("LMB4COM-TCALL-DROP-TRL-FLG", terminateCallDTO.getDropTrailerFlag().trim());
		terminateCallElementsMap.put("LMB4COM-TCALL-TRK-CITYST", terminateCallDTO.getTruckCityState().trim());
		terminateCallElementsMap.put("LMB4COM-TCALL-TRL-CUST-CODE", terminateCallDTO.getCustomerCode().trim());
		terminateCallElementsMap.put("LMB4COM-TCALL-TRL-CITYST", terminateCallDTO.getCityState().trim());
		terminateCallElementsMap.put("LMB4COM-TCALL-TRL-LOCATION", terminateCallDTO.getCustomerCode().trim());
		terminateCallElementsMap.put("LMB4COM-TCALL-ORD-CTY-ST", terminateCallDTO.getOrdCityState().trim());
		Integer endHubMiles = terminateCallDTO.getEndHubMiles();
		String paddedEndHubMiles = String.format("%09d" , endHubMiles);
		terminateCallElementsMap.put("LMB4COM-TCALL-END-HUB", paddedEndHubMiles);
		terminateCallElementsMap.put("LMB4COM-TCALL-VARIANCE-FLG","4");
		return terminateCallElementsMap;
	}

	public Map<String, String> populateIBYUpdateElements(CheckcallDTO checkCallDTO) {
		Map<String, String> checkCallUpdateElementsMap = new HashMap<>();
		SpotDBCallDTO spotCallDTO = checkCallDTO.getSpotCallDTO();
		checkCallUpdateElementsMap.put("LMB4COM-SDB-AREA-ID", spotCallDTO.getAreaId());
		checkCallUpdateElementsMap.put("LMB4COM-SDB-TLR-CUST-CD", spotCallDTO.getTrailerCustomerCode());

		return checkCallUpdateElementsMap;
	}

}
