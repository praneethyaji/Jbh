package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.relaxedResponseFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;
import static org.springframework.restdocs.request.RequestDocumentation.requestParameters;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.document;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;

import org.apache.commons.httpclient.HttpStatus;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.restdocs.request.ParameterDescriptor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.dto.LegacyOrderOperationalPlanAssociationDTO;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
public class LegacyOrderLoadCrossReferenceControllerIT {

	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http")
			.host("loadplanning-test.jbhunt.com").removePort();
	
	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

	@Autowired
	private ObjectMapper objectMapper;

	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void testGetLegacyOrderDetails() throws Exception {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.filter(document("GetLegacyOrderDetails", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), pathParameters(getLegacyOrderDetailsRequest()),
						relaxedResponseFields(getOperationalPlanDetailsResponse())))
				.accept(ContentType.JSON).contentType(ContentType.JSON)
				.get("/ws_loadplanning_integration_backfill/backfill/legacyorders/operationalplanid/{operationalplanid}",
						14317);

		LegacyOrderOperationalPlanAssociationDTO legacyOrderOperationalPlanAssociationDTO = objectMapper
				.readValue(response.asString(), LegacyOrderOperationalPlanAssociationDTO.class);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
		assertEquals("14317", legacyOrderOperationalPlanAssociationDTO.getOperationalPlanId().toString());

	}

	@Test
	public void testGetLegacyOrderDetailsNoContent() throws Exception {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.accept(ContentType.JSON).contentType(ContentType.JSON)
				.get("/ws_loadplanning_integration_backfill/backfill/legacyorders/operationalplanid/{operationalplanid}",
						123789);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_NO_CONTENT));

	}

	@Test
	public void testOperationalPlanIds() throws Exception {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.filter(document("GetOperationPlanIds", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), pathParameters(getOperationalPlanIdsByOrderId())))
				.accept(ContentType.JSON).contentType(ContentType.JSON)
				.get("/ws_loadplanning_integration_backfill/backfill/legacyorders/operationalplans/legacyorderid/{legacyorderid}",
						862540315);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void testOperationalPlanIdByOrderIdAndJobId() throws Exception {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.filter(document("GetOperationPlanIdByOrderIdAndJobId", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()),
						pathParameters(parameterWithName("legacyorderid").description("Legacy Order ID")),
						requestParameters(parameterWithName("legacyjobid").description("Legacy Job Id"))))
				.queryParam("legacyjobid", 1234567).accept(ContentType.JSON).contentType(ContentType.JSON)
				.get("/ws_loadplanning_integration_backfill/backfill/legacyorders/operationalplans/legacyorderid/{legacyorderid}",
						862540315);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void testOperationalPlanIdByOrderIdAndJobIdNoContent() throws Exception {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.queryParam("legacyjobid", 0).accept(ContentType.JSON).contentType(ContentType.JSON)
				.get("/ws_loadplanning_integration_backfill/backfill/legacyorders/operationalplans/legacyorderid/{legacyorderid}",
						862545);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_NO_CONTENT));

	}

	@Test
	public void testOperationalPlanIdByOrderIdAndReservationId() throws Exception {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.filter(document("GetOperationPlanIdByOrderIdAndReservationId",
						preprocessRequest(uriOverride, prettyPrint()), preprocessResponse(prettyPrint()),
						pathParameters(parameterWithName("legacyorderid").description("Legacy Order ID")),
						requestParameters(parameterWithName("legacyresourcereservationid")
								.description("Legacy Resource Reservation Id"))))
				.queryParam("legacyresourcereservationid", 34567).accept(ContentType.JSON).contentType(ContentType.JSON)
				.get("/ws_loadplanning_integration_backfill/backfill/legacyorders/operationalplans/legacyorderid/{legacyorderid}",
						862540315);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void testOperationalPlanIdByOrderIdAndReservationIdNoContent() throws Exception {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.queryParam("legacyresourcereservationid", 0).accept(ContentType.JSON).contentType(ContentType.JSON)
				.get("/ws_loadplanning_integration_backfill/backfill/legacyorders/operationalplans/legacyorderid/{legacyorderid}",
						862540);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_NO_CONTENT));

	}

	@Test
	public void testOperationalPlanIdByBothJobIdAndReservationId() throws Exception {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.filter(document("GetOperationPlanIdByBothJobIdAndReservationId",
						preprocessRequest(uriOverride, prettyPrint()), preprocessResponse(prettyPrint()),
						pathParameters(parameterWithName("legacyorderid").description("Legacy Order ID")),
						requestParameters(parameterWithName("legacyjobid").description("Legacy Job Id"),
								parameterWithName("legacyresourcereservationid")
										.description("Legacy Resource Reservation Id"))))
				.queryParam("legacyjobid", 1234567).queryParam("legacyresourcereservationid", 34567).accept(ContentType.JSON)
				.contentType(ContentType.JSON)
				.get("/ws_loadplanning_integration_backfill/backfill/legacyorders/operationalplans/legacyorderid/{legacyorderid}",
						862540315);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void testOperationalPlanIdByBothIdNoContent() throws Exception {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.queryParam("legacyjobid", 0).queryParam("legacyresourcereservationid", 0).accept(ContentType.JSON)
				.contentType(ContentType.JSON)
				.get("/ws_loadplanning_integration_backfill/backfill/legacyorders/operationalplans/legacyorderid/{legacyorderid}",
						862540);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_NO_CONTENT));

	}

	private ParameterDescriptor[] getLegacyOrderDetailsRequest() {
		return new ParameterDescriptor[] { parameterWithName("operationalplanid").description("Operationalplan ID") };
	}

	private ParameterDescriptor[] getOperationalPlanIdsByOrderId() {
		return new ParameterDescriptor[] { parameterWithName("legacyorderid").description("Legacy Order ID") };
	}

	public static FieldDescriptor[] getOperationalPlanDetailsResponse() {

		return new FieldDescriptor[] {
				fieldWithPath("legacyOrderOperationalPlanAssociationId").description("Legacy Order Association ID"),
				fieldWithPath("legacyOrderId").description("Legacy Order ID"),
				fieldWithPath("legacyJobId").description("Legacy JobId"),
				fieldWithPath("legacyResourceReservationId").description("Legacy Resource Reservation ID"),
				fieldWithPath("legacyCarrierReservationId").description("Legacy Carrier Reservation ID"),
				fieldWithPath("legacyDispatchNumber").description("Legacy Dispatch Number"),
				fieldWithPath("legacyOrderNumber").description("Legacy Order Number"),
				fieldWithPath("operationalPlanId").description("Operational PlanID"),
				fieldWithPath("createTimestamp").description("Created Timestamp"),
				fieldWithPath("createUserID").description("Created UserID"),
				fieldWithPath("createProgramName").description("Create Program Name"),
				fieldWithPath("lastUpdateTimestamp").description("Last Updated Timestamp"),
				fieldWithPath("lastUpdateUserID").description("Last Updated UserID"),
				fieldWithPath("lastUpdateProgramName").description("Last Updated Program Name") };
	}

}
