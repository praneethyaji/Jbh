package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource
public interface OrderLoadRepository extends JpaRepository<TOrder, Integer> {

	@Query(value = "SELECT B.ORD_NBR_CH, B.ORD_I, B.CRT_S, B.LST_DSP_NBR, CHAR(B.LST_UPD_S) AS LST_UPD_S FROM ALI.ORD_LD_SYNC A, ALI.TORDER B WHERE  A.NEW_ORD_I = :orderId  and A.ORD_I = B.ORD_I and COALESCE(A.XDIV_IND, '') <> 'C' FETCH FIRST ROW ONLY WITH UR ", nativeQuery = true)
	TOrder findLoadDetailsByOrderID(@Param("orderId") Integer orderId);

	@Query(value = "SELECT B.ORD_NBR_CH, B.ORD_I, B.CRT_S, B.LST_DSP_NBR, CHAR(B.LST_UPD_S) AS LST_UPD_S FROM ALI.ORD_LD_SYNC A, ALI.TORDER_W B WHERE  A.NEW_ORD_I = :orderId and A.ORD_I = B.ORD_I and COALESCE(A.XDIV_IND, '') <> 'C' FETCH FIRST ROW ONLY WITH UR ", nativeQuery = true)
	TOrder findLoadDetailsByOrderIDWarehouse(@Param("orderId") Integer orderId);

	@Query(value = "SELECT SA.PRL_TRL_EQP_I  FROM ALI.TORDER SA, ALI.TTASK SB " +
			" WHERE SA.ORD_NBR_CH =:orderNumber  AND SA.ORD_I = SB.TASK_ID FETCH FIRST ROW ONLY WITH UR  ", nativeQuery = true)
	Integer findPrlTrailerEquipmentBytaskId(@Param("orderNumber") String orderNumber);

	@Query(value = " SELECT C.JOB_I FROM  ALI.TEQUIPMENT A ,ALI.TORDER  B ,ALI.TDSP_JOB_XRF C WHERE A.EQP_ID = :eqpId AND A.LST_ORD_NBR_CH = B.ORD_NBR_CH AND B.ORD_I= C.ORD_I AND C.DSP_NBR = A.LST_DSP_NBR  \r\n" +
			"      WITH UR", nativeQuery = true)
	Integer getJobIdbyOrderId(@Param("eqpId") Integer eqpId);

	@Query(value="SELECT ORD_I FROM ALI.TORDER WHERE ORD_NBR_CH=:orderNumber WITH UR ", nativeQuery = true)
	Integer getOrderIDByOrderNumber(@Param("orderNumber") String orderNumber);
	
	@Query(value = "SELECT LST_DSP_NBR FROM ALI.TORDER WHERE ORD_NBR_CH=:orderNumber WITH UR ", nativeQuery = true)
	Integer getDispatchNumberByOrderNumber(@Param("orderNumber") String orderNumber);
	
	@Query(value = "SELECT LST_DSP_NBR FROM ALI.TORDER_W WHERE ORD_NBR_CH=:orderNumber WITH UR ", nativeQuery = true)
	Integer getDispatchNumberByOrderNumberWarehouse(@Param("orderNumber") String orderNumber);
	
	@Query(value = "SELECT ORD_NBR_CH, ORD_I, CRT_S, LST_DSP_NBR, CHAR(LST_UPD_S) AS LST_UPD_S FROM  ALI.TORDER WHERE ORD_NBR_CH = :orderNumber FETCH FIRST ROW ONLY WITH UR ", nativeQuery = true)
	TOrder findLoadDetailsByOrderNumber(@Param("orderNumber") String orderNumber);
	
	@Query(value = "SELECT ORD_NBR_CH, ORD_I, LST_DSP_NBR, CRT_S, CHAR(LST_UPD_S) AS LST_UPD_S FROM  ALI.TORDER_W WHERE ORD_NBR_CH = :orderNumber FETCH FIRST ROW ONLY WITH UR ", nativeQuery = true)
	TOrder findLoadDetailsByOrderNumberWarehouse(@Param("orderNumber") String orderNumber);
	
	TOrder findByOrderId(@Param("orderId") Integer orderId);

}
