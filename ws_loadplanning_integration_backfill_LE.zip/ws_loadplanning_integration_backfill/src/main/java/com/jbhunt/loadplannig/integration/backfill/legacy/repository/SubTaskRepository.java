package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource
public interface SubTaskRepository  extends JpaRepository<TSubtask1, Integer> {
	
	@Query(value = " SELECT STSK_ID,PRF_SEQ_N,TASK_ID, JOB_ID,RQ_TY_ID,BSST_ID,BSST_ALIAS,CITY_ID,CURR_APT_BEG_D,CURR_APT_BEG_H, CURR_APT_END_D,CURR_APT_END_H,PROG_STT_C,REC_STT_F,RSC_RSV_I FROM ALI.TSUBTASK1  WHERE TASK_ID=? AND PROG_STT_C='A'   WITH UR", nativeQuery = true)
   List<TSubtask1> findSubTaskDetailsByTaskId(@Param("subTaskId") Integer subTaskId);
	

	@Query(value = " SELECT A.STSK_ID,A.PRF_SEQ_N,TASK_ID,JOB_ID, A.RQ_TY_ID,A.BSST_ID,A.BSST_ALIAS,A.CITY_ID,A.CURR_APT_BEG_D,A.CURR_APT_BEG_H, CURR_APT_END_D,A.CURR_APT_END_H,PROG_STT_C,A.REC_STT_F,A.RSC_RSV_I FROM ALI.TSUBTASK1  A,ALI.RSC_RSV B WHERE A.TASK_ID = ? AND (A.PROG_STT_C = 'S' OR A.PROG_STT_C = 'A') AND A.RSC_RSV_I = B.RSC_RSV_I WITH UR", nativeQuery = true)
	List<TSubtask1> getSubtaskDetailsForDeleted(@Param("subTaskId") Integer subTaskId);
	
	
	
	@Query(value = " SELECT STSK_ID,PRF_SEQ_N,TASK_ID, JOB_ID,RQ_TY_ID,BSST_ID,BSST_ALIAS,CITY_ID,CURR_APT_BEG_D,CURR_APT_BEG_H, CURR_APT_END_D,CURR_APT_END_H,PROG_STT_C,REC_STT_F,RSC_RSV_I FROM ALI.TSUBTASK1  WHERE TASK_ID=? AND PROG_STT_C='S'   WITH UR", nativeQuery = true)
	   List<TSubtask1> findSubTaskDetailsByTaskIdPlannedLoads(@Param("subTaskId") Integer subTaskId);

	@Query(value = " SELECT A.RSC_RSV_I, A.CURR_APT_END_D, A.REC_STT_F, A.PRF_SEQ_N, A.CITY_ID, A.EST_ARV_D, A.EST_ARV_H, A.EST_AVL_D, A.EST_AVL_H, A.CURR_APT_BEG_D, A.CURR_APT_BEG_H, A.BSST_ALIAS, A.BSST_ID, A.PROG_STT_C, A.STSK_ID, A.JOB_ID, A.RQ_TY_ID, A.CRTN_TMSTP_S, A.TASK_ID, A.CURR_APT_BEG_D, A.CURR_APT_END_H, A.CRTN_UID_N " +
			" FROM ALI.TSUBTASK1 A WHERE (A.JOB_ID =:jobId OR A.TASK_ID = :taskId)AND A.PROG_STT_C IN ('A','W','S','C')  AND A.REC_STT_F = 'A' " +
			" ORDER BY A.PRF_SEQ_N, A.CRTN_TMSTP_S ",nativeQuery = true)
	List<TSubtask1>  fetchSubtaskDetailsByJobIdAndOrderId(@Param("jobId") Integer jobId, @Param("taskId") Integer taskId );

	@Query(value = "SELECT C.JOB_I, D.PRF_SEQ_N  FROM  ALI.TEQUIPMENT A,ALI.TORDER B,ALI.TDSP_JOB_XRF C,ALI.TSUBTASK1 D" +
			"      WHERE C.ORD_I =:orderId AND D.PROG_STT_C IN ('S','W','H') AND A.LST_ORD_NBR_CH = B.ORD_NBR_CH AND D.TASK_ID = B.ORD_I AND B.ORD_I= C.ORD_I AND C.DSP_NBR= A.LST_DSP_NBR ORDER BY D.PRF_SEQ_N  fetch first 1 rows only WITH UR ",nativeQuery = true)
	Integer[][] getStopSeqNumberByOrderId (@Param("orderId") Integer orderId);

	@Query(value = " SELECT CITY_ID FROM ALI.TSUBTASK1 WHERE TASK_ID =:invertOrd AND PRF_SEQ_N =:stopSeqNumber AND REC_STT_F =  'A' fetch first 1 rows only ", nativeQuery = true)
	String  getLocationForArrivalUnloaded(@Param("invertOrd") Long invertOrd, @Param("stopSeqNumber") Integer stopSeqNumber );
	
	
	@Query(value = " SELECT STSK_ID,PRF_SEQ_N,TASK_ID, JOB_ID,RQ_TY_ID,BSST_ID,BSST_ALIAS,CITY_ID,CURR_APT_BEG_D,CURR_APT_BEG_H, CURR_APT_END_D,CURR_APT_END_H,PROG_STT_C,REC_STT_F,RSC_RSV_I FROM ALI.TSUBTASK1  WHERE TASK_ID=? AND PROG_STT_C='S' AND  RSC_RSV_I > 0  WITH UR", nativeQuery = true)
	   List<TSubtask1> getJobandRSCId(@Param("taskId") Integer taskId);
	
	
	
}
