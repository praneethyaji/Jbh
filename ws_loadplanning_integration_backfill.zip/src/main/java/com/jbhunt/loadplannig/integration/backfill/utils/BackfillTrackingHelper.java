package com.jbhunt.loadplannig.integration.backfill.utils;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class BackfillTrackingHelper {

	private final BackFillEventTrackingRepository backFillEventTrackingRepository;

	public void saveBackTrackingDetails(final OperationalPlanDTO operationalPlanDTO, final String eventSubType) {
		backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
				eventSubType, "");
	}

	public void updateException(OperationalPlanDTO operationalPlanDTO, Exception e) {
		String errorMesage = ExceptionUtils.getRootCauseMessage(e);
		if (errorMesage != null && errorMesage.length() > 500) {
			errorMesage = errorMesage.substring(0, 500);
		}
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
				errorMesage);
	}

}