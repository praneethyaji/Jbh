package com.jbhunt.loadplannig.integration.backfill.services;

import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.ws.Holder;

import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.dto.PCallDTO;
import com.jbhunt.loadplannig.integration.backfill.dto.SpotDBCallDTO;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.CityRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CheckCallHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.SendPlanHelper;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.jbhunt.mdm.dto.LocationProfileDTO;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.jbhunt.operations.equipmentgroup.dto.AddEquipmentGroupESDTO;
import com.jbhunt.operations.equipmentgroup.dto.EquipmentGroupESDTO;
import com.jbhunt.operations.equipmentgroup.dto.RemoveEquipmentFromGroupBackFillDTO;
import com.jbhunt.operations.equipmentgroup.dto.RemoveEquipmentRequestDTO;
import com.lmc363i.lmc363.LMC363Port;
import com.lmc364i.lmc364.LMC364Port;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord;
import com.request.lmc364i.lmc364.ProgramInterface.Lmc364IInputArea;
import com.request.lmc364i.lmc364.ProgramInterface.Lmc364IInputArea.Filler1;
import com.request.lmc364i.lmc364.ProgramInterface.Lmc364IInputArea.Filler1.Lmc364INewEqpLocCtyst;
import com.response.lmc363i.lmc363.ProgramInterface;
import com.response.lmc364i.lmc364.ProgramInterface.Lmc364OOutputArea;
import org.apache.commons.lang.StringUtils;
import org.json.JSONException;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class LoadExecutionIntegrationBackfillService extends CheckCallBackfillService{

	private MasterdataAssetClient masterdataAssetClient;
	private final LMC364Port lMC364Port;
	private final LMC363Port lmc363Port;
	private final CheckCallHelper checkCallHelper;
	private final SendPlanHelper sendPlanHelper;
	private final EquipmentRepository equipmentRepository;
	private final OrderLoadRepository orderLoadRepository;
	private final LocationClient locationClient;
	private final CityRepository cityRepository;

	public void chassisAttach(EquipmentGroupESDTO equipmentGroupESDTO)
			throws URISyntaxException {
		log.info("Chassis-Container attach service");
		Lmc364IInputArea lmc364IInputArea = new Lmc364IInputArea();
		populateInputArea(equipmentGroupESDTO.getUserId(), lmc364IInputArea);
		List<AddEquipmentGroupESDTO> equipmentGroupList = equipmentGroupESDTO.getAddEquipmentGroupESDTO();
		AddEquipmentGroupESDTO chassisDetail = equipmentGroupList.stream()
				.filter(equipmentGroup -> equipmentGroup.getEquipmentClassificationCode().equalsIgnoreCase(CommonConstants.CHASSIS)).findFirst()
				.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));
		AddEquipmentGroupESDTO containerDetail = equipmentGroupList.stream()
				.filter(equipmentGroup -> equipmentGroup.getEquipmentClassificationCode().equalsIgnoreCase(CommonConstants.CONTAINER))
				.findFirst().orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));
		
		log.info("Chassis Id : {}" + chassisDetail.getEquipmentId());
		log.info("Container Id : {}" + containerDetail.getEquipmentId());
		
		EquipmentDetailsDTO chassisEqpDetail = Optional
				.ofNullable(masterdataAssetClient
						.getEquipmentDetails(Arrays.asList(Integer.parseInt(chassisDetail.getEquipmentId()))))
				.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream().findFirst()
				.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));

		EquipmentDetailsDTO containerEqpDetail = Optional
				.ofNullable(masterdataAssetClient
						.getEquipmentDetails(Arrays.asList(Integer.parseInt(containerDetail.getEquipmentId()))))
				.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream().findFirst()
				.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));

		List<Filler1> fillerList = populateEquipmentDetails(containerEqpDetail, chassisEqpDetail);
		lmc364IInputArea.getFiller1().addAll(fillerList);
		log.info("Calling LMC364 service..");
		Lmc364OOutputArea lmc364OOutputArea = lMC364Port.lmc364Operation(lmc364IInputArea);
		log.info("out put {} , {} " + lmc364OOutputArea.getLmc364OErrorMessage() + " ==="
				+ lmc364OOutputArea.getLmc364OMsgOvrFlg() + "===" + lmc364OOutputArea.getLmc364OOutputFiller() + "==="
				+ lmc364OOutputArea.getLmc364OReturnFlag());

	}
	
	public void chassisDetach(RemoveEquipmentFromGroupBackFillDTO removeEquipmentDTO, EquipmentDetailsDTO containerDetail, EquipmentDetailsDTO chassisDetail) 
			throws URISyntaxException {
		log.info("Chassis-Container detach service");
		Lmc364IInputArea lmc364IInputArea = new Lmc364IInputArea();
		populateInputArea(removeEquipmentDTO.getRemoveEquipmentRequestDTO().getUserId(), lmc364IInputArea);
		List<Filler1> fillerList = populateEquipmentDetails(containerDetail, chassisDetail);
		lmc364IInputArea.getFiller1().addAll(fillerList);
		log.info("Calling LMC364 service..");
		Lmc364OOutputArea lmc364OOutputArea = lMC364Port.lmc364Operation(lmc364IInputArea);
		log.info("out put {} , {} " + lmc364OOutputArea.getLmc364OErrorMessage() + " ==="
				+ lmc364OOutputArea.getLmc364OMsgOvrFlg() + "===" + lmc364OOutputArea.getLmc364OOutputFiller() + "==="
				+ lmc364OOutputArea.getLmc364OReturnFlag());

	}

	public void checkForPairing(AddEquipmentGroupESDTO truckDetail, AddEquipmentGroupESDTO trailingDetail, String type, String userId)
			throws URISyntaxException, JBHuntRuntimeException, JSONException {
		log.info("Truck Assignment/Unassigment common service call");
		
		
			EquipmentDetailsDTO truckDetailsDTO = Optional
					.ofNullable(masterdataAssetClient.getEquipmentDetails(
							Arrays.asList(Integer.parseInt(truckDetail.getEquipmentId()))))
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream().findFirst()
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));
	
			EquipmentDetailsDTO trailerDetailsDTO = Optional
					.ofNullable(masterdataAssetClient
							.getEquipmentDetails(Arrays.asList(Integer.parseInt(trailingDetail.getEquipmentId()))))
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream().findFirst()
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));
			
			checkIfEqpAlreadyPaired(truckDetailsDTO.getLegacyEquipmentId(),truckDetail.getLocationId());
			checkIfEqpAlreadyPaired(trailerDetailsDTO.getLegacyEquipmentId(),trailingDetail.getLocationId());
			
			truckAssignmentUnassignment(truckDetail, trailingDetail, type, userId);
			
			
	}
	
	
	public void truckAssignmentUnassignment(AddEquipmentGroupESDTO truckDetail, AddEquipmentGroupESDTO trailingDetail, String type, String userId)
			throws URISyntaxException, JBHuntRuntimeException, JSONException {
		log.info("Truck Assignment/Unassigment common service call");
		
		CheckcallDTO checkcallDTO = new CheckcallDTO();
			EquipmentDetailsDTO truckDetailsDTO = Optional
					.ofNullable(masterdataAssetClient.getEquipmentDetails(
							Arrays.asList(Integer.parseInt(truckDetail.getEquipmentId()))))
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream().findFirst()
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));
			TEquipment legacytruckDetails = equipmentRepository
					.fetchEqpDetailsByEqpId(Integer.toString(truckDetailsDTO.getLegacyEquipmentId()));
	
			EquipmentDetailsDTO trailerDetailsDTO = Optional
					.ofNullable(masterdataAssetClient
							.getEquipmentDetails(Arrays.asList(Integer.parseInt(trailingDetail.getEquipmentId()))))
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream().findFirst()
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));
			TEquipment legacyTrailerDetails = equipmentRepository
					.fetchEqpDetailsByEqpId(Integer.toString(trailerDetailsDTO.getLegacyEquipmentId()));
			
			String cityState = Optional.ofNullable(legacytruckDetails.getLastLocation().trim()).orElse(CommonConstants.EMPTY_SPACE);
			
			populateCommonFields(legacytruckDetails.getLastDispatchOrderNumber(), userId,
					truckDetail.getBusinessUnit(), legacytruckDetails, legacyTrailerDetails, cityState, checkcallDTO);
			String customerCode = equipmentRepository.getCustomerCode(trailerDetailsDTO.getLegacyEquipmentId());
			checkcallDTO.setTcallCustomerCode(Optional.ofNullable(customerCode.trim()).orElse(""));
			log.info(legacytruckDetails.getLastDispatchOrderNumber() , " " , legacyTrailerDetails.getLastDispatchOrderNumber());
			String checkCallVars = "";
			if (CommonConstants.STRING_A.equalsIgnoreCase(type)) {
				log.info("Truck Assignment for the equipments {} and {}", truckDetailsDTO.getEquipmentId(),
						trailerDetailsDTO.getEquipmentId());
				checkcallDTO.setCallType(CommonConstants.CHECK_CALL_PICKUP);
				DateTimeFormatter sdfDate = DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT);
				DateTimeFormatter sdfTime = DateTimeFormatter.ofPattern(CommonConstants.TIME_FORMAT);
				LocalDateTime adt = LocalDateTime.now();
				checkcallDTO.setArrivalDate(adt.format(sdfDate));
				checkcallDTO.setArrivalTime(adt.format(sdfTime));
				checkcallDTO.setBeamCustomerCode(cityState);
				String trailingEqpCusCode  = Optional
						.ofNullable(locationClient.findLocationProfilebyLocationCode(
								trailingDetail.getLocationId()))
						.map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode)
						.orElseThrow(() -> new JBHuntRuntimeException("Location Profile not found."));
				String trailingEqpCityState = Optional.ofNullable(getCityStateForCustomerCode(trailingEqpCusCode)).map(String::trim)
						.filter(StringUtils::isNotEmpty).orElse("");
				
				
				checkcallDTO.setPCallDTO(assignPCalldetails(trailingDetail,trailingEqpCityState));
				Map<String, String> pCallMap = checkCallHelper.populateCommentCallElements(checkcallDTO);
				checkCallVars = getCheckCallVarsValues(pCallMap,
						checkCallHelper.getCheckcallCommentElements());
	
			} else if (CommonConstants.STRING_U.equalsIgnoreCase(type)) {
				log.info("Truck Unassignment for the equipments {} and {}", truckDetailsDTO.getEquipmentId(),
						trailerDetailsDTO.getEquipmentId());
				checkcallDTO.setCallType(CommonConstants.CHECK_CALL_DROP);
				//checkcallDTO.setComments(String.format(CommonConstants.FREE_COMMENTS, " "));
				checkcallDTO.setSpotCallDTO(assignSpotCallDetails(trailingDetail, legacyTrailerDetails,customerCode));
				Map<String, String> spotDBcallMap = checkCallHelper.populateSDBElements(checkcallDTO);
				checkCallVars = getCheckCallVarsValues(spotDBcallMap,
						checkCallHelper.getCheckcallSDBElements());
			}
			checkcallDTO.setCheckCallVars(checkCallVars);
	
			log.info(" values to be passed :{}", checkcallDTO);
			Lm36ComCommareaRecord lm36ComCommareaRecord = checkCallHelper.createLm36ComCommareaRecord(checkcallDTO);
			com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava lm36ComReturnToJava = checkCallHelper
					.getLm36ComReturnToJava(checkcallDTO);
			log.info("Calling LMC363 Service..");
			javax.xml.ws.Holder<ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder = new Holder<>();
			javax.xml.ws.Holder<String> lm36ComFillerOutputHolder = new Holder<>();
			javax.xml.ws.Holder<ProgramInterface.Lm36ComCommareaOutputRecord> lm36ComCommareaOutputRecordHolder = new Holder<>();
			String lm36ComFiller = "";
	
			lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava, lm36ComFiller,
					lm36ComCommareaOutputRecordHolder, lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);
	
			checkCallHelper.loggingCheckcallResponse(lm36ComReturnToJavaOutputHolder);
			log.info("result of the freeCall operation from the mainframe: {} ", lm36ComFillerOutputHolder.value);
		//}
	}

	private void populateInputArea(String userId, Lmc364IInputArea lmc364IInputArea) {
		lmc364IInputArea.setLmc364ICallingPgm(CommonConstants.SERVICE_CALL_LMC223);
		lmc364IInputArea.setLmc364IEqpActionSw(CommonConstants.STRING_U);
		lmc364IInputArea.setLmc364IInputFiller(CommonConstants.MF_DEFAULT_VAL_STRING);
		lmc364IInputArea.setLmc364IMsgOvrPfkeySw(CommonConstants.MF_DEFAULT_VAL_STRING);
		lmc364IInputArea.setLmc364INeedOvrTransidSw(CommonConstants.STRING_Y);
		lmc364IInputArea.setLmc364INeedRollbackSw(CommonConstants.STRING_Y);
		lmc364IInputArea.setLmc364IOvrDownChasSw(CommonConstants.MF_DEFAULT_VAL_STRING);
		lmc364IInputArea.setLmc364IOvrTradeChasSw(CommonConstants.MF_DEFAULT_VAL_STRING);
		lmc364IInputArea.setLmc364IUserid(Optional.ofNullable(userId).map(String::trim).
				filter(StringUtils::isNotEmpty).orElseThrow(()->new JBHuntRuntimeException("User Id not available")));
	}

	private List<Filler1> populateEquipmentDetails(EquipmentDetailsDTO containerDetail, EquipmentDetailsDTO chassisDetail)
			throws URISyntaxException {

		List<Filler1> fillerList = new ArrayList<>();

		log.info("Chassis Id : {}" + chassisDetail.getEquipmentId());
		log.info("Container Id : {}" + containerDetail.getEquipmentId());

		Filler1 filler1 = new Filler1();
		if (Optional.ofNullable(containerDetail).isPresent()) {

			filler1.setLmc364IEqpId(containerDetail.getLegacyEquipmentId());
			filler1.setLmc364IEqpNbr(
					containerDetail.getEquipmentNumber() != null ? containerDetail.getEquipmentNumber().trim()
							: CommonConstants.MF_DEFAULT_VAL_STRING);
			filler1.setLmc364IEqpPfx(
					containerDetail.getEquipmentPrefix() != null ? containerDetail.getEquipmentPrefix()
							: CommonConstants.MF_DEFAULT_VAL_STRING);
			filler1.setLmc364INewEqpOvrSw(CommonConstants.MF_DEFAULT_VAL_STRING);
			filler1.setLmc364INewEqpUntStt(CommonConstants.MF_DEFAULT_VAL_STRING);
			filler1.setLmc364INewEqpCustCd(CommonConstants.MF_DEFAULT_VAL_STRING);

			Lmc364INewEqpLocCtyst lmc364INewEqpLocCtyst = new Lmc364INewEqpLocCtyst();
			lmc364INewEqpLocCtyst.setLmc364INewEqpLocCty(CommonConstants.MF_DEFAULT_VAL_STRING);
			lmc364INewEqpLocCtyst.setLmc364INewEqpLocSt(CommonConstants.MF_DEFAULT_VAL_STRING);
			lmc364INewEqpLocCtyst.setFiller2(CommonConstants.MF_DEFAULT_VAL_STRING);
			filler1.setLmc364INewEqpLocCtyst(lmc364INewEqpLocCtyst);

		}
		Filler1 filler2 = new Filler1();
		if (Optional.ofNullable(chassisDetail).isPresent()) {

			filler2.setLmc364IEqpId(chassisDetail.getLegacyEquipmentId());
			filler2.setLmc364IEqpNbr(
					chassisDetail.getEquipmentNumber() != null ? chassisDetail.getEquipmentNumber()
							: CommonConstants.MF_DEFAULT_VAL_STRING);
			filler2.setLmc364IEqpPfx(
					chassisDetail.getEquipmentPrefix() != null ? chassisDetail.getEquipmentPrefix()
							: CommonConstants.MF_DEFAULT_VAL_STRING);
			filler2.setLmc364INewEqpOvrSw(CommonConstants.MF_DEFAULT_VAL_STRING);
			filler2.setLmc364INewEqpUntStt(CommonConstants.MF_DEFAULT_VAL_STRING);
			filler2.setLmc364INewEqpCustCd(CommonConstants.MF_DEFAULT_VAL_STRING);

			Lmc364INewEqpLocCtyst lmc364INewEqpLocCtyst1 = new Lmc364INewEqpLocCtyst();
			lmc364INewEqpLocCtyst1.setLmc364INewEqpLocCty(CommonConstants.MF_DEFAULT_VAL_STRING);
			lmc364INewEqpLocCtyst1.setLmc364INewEqpLocSt(CommonConstants.MF_DEFAULT_VAL_STRING);
			lmc364INewEqpLocCtyst1.setFiller2(CommonConstants.MF_DEFAULT_VAL_STRING);
			filler2.setLmc364INewEqpLocCtyst(lmc364INewEqpLocCtyst1);
		}
		fillerList.add(filler1);
		fillerList.add(filler2);
		return fillerList;
	}
	
	
	

	private void populateCommonFields(String orderNumber, String userId, String businessUnit, TEquipment legacytruckDetails,
			TEquipment legacyTrailerDetails, String cityState, CheckcallDTO checkcallDTO) {

		checkcallDTO.setDataState(CommonConstants.DATA_STATE_B);
		
		checkcallDTO.setUserId(Optional.ofNullable(userId).map(String::toUpperCase).orElseThrow(() -> new JBHuntRuntimeException("User id not found.")));
		
		TOrder orderDetails = Optional
				.ofNullable(orderLoadRepository.findLoadDetailsByOrderNumber(orderNumber.trim()))
				.orElseGet(() -> orderLoadRepository.findLoadDetailsByOrderNumberWarehouse(orderNumber.trim()));
		
		checkcallDTO.setOrderNumber(Optional
				.ofNullable(orderNumber.trim()).orElse(CommonConstants.MF_DEFAULT_VAL_STRING));
		checkcallDTO
				.setOrderTimeStamp(Optional
						.ofNullable(orderDetails.getLastUpdateTimeStamp()).orElse(CommonConstants.MF_DEFAULT_VAL_STRING));
		checkcallDTO.setInvertOrder(Optional
				.ofNullable(orderDetails.getOrderId()).orElse(CommonConstants.ZERO));
		checkcallDTO.setJobId(CommonConstants.ZERO);
		
		checkcallDTO.setCarrier(CommonConstants.MF_DEFAULT_VAL_STRING);
		checkcallDTO.setProject(CommonConstants.MF_DEFAULT_VAL_STRING);
		checkcallDTO.setCreateUserId(userId);
		checkcallDTO.setEqpId(legacytruckDetails.getEquipmentId());
		checkcallDTO.setTractorNbr(legacytruckDetails.getTrailerNumber());
		checkcallDTO.setTractorRqdFlg(CommonConstants.TRACTOR_RQD_FLAG);

		checkcallDTO.setCarrierFlg(businessUnit.equalsIgnoreCase("JBI") ? CommonConstants.MF_DEFAULT_VAL_STRING
				: CommonConstants.STRING_I);

		checkcallDTO.setLocationCityState(cityState);
		checkcallDTO.setNextStopSeqNbr(0);

		checkcallDTO.setTrailerContainerPrefix(legacyTrailerDetails.getTrailerPrefix());
		checkcallDTO.setTrailerContainerNumber(legacyTrailerDetails.getTrailerNumber());
	}
	
	private PCallDTO assignPCalldetails(AddEquipmentGroupESDTO trailerDetail, String cityState) {
		PCallDTO pCallDTO = new PCallDTO();
		pCallDTO.setCallLocation(cityState);
		pCallDTO.setTrailerChassisFlag(
				trailerDetail.getEquipmentClassificationCode().equalsIgnoreCase(CommonConstants.CHASSIS)
						? CommonConstants.STRING_C
						: CommonConstants.STRING_T);
		pCallDTO.setOverrideRailCodeFlag(CommonConstants.MF_DEFAULT_VAL_STRING);
		pCallDTO.setOverrideLoadFlag(CommonConstants.MF_DEFAULT_VAL_STRING);
		pCallDTO.setOverrideRODownFlag(CommonConstants.MF_DEFAULT_VAL_STRING);
		pCallDTO.setOverrideLengthErrorFlag(CommonConstants.STRING_Y);
		return pCallDTO;
	}
	
	private SpotDBCallDTO assignSpotCallDetails(AddEquipmentGroupESDTO trailerDetail, TEquipment legacyTrailerDetails, String customerCode) {
		SpotDBCallDTO spotDBCall = new SpotDBCallDTO();
		String cityState1 = sendPlanHelper.getCityStateForCustomerCode(customerCode);
		spotDBCall.setTrailerCustomerCode(customerCode);
		spotDBCall.setTrailerCityState(cityState1);
		if (trailerDetail.getEquipmentClassificationCode().equalsIgnoreCase(CommonConstants.CHASSIS)) {
			spotDBCall.setChassisNumber(legacyTrailerDetails.getTrailerNumber());
			spotDBCall.setChassisPrefix(legacyTrailerDetails.getTrailerPrefix());
		}
		spotDBCall.setDropTrailerFlag(CommonConstants.STRING_Y);
		return spotDBCall;
	}
	
	public void truckUnassignment(RemoveEquipmentFromGroupBackFillDTO removeEquipmentDTO,EquipmentDetailsDTO truckDetail, EquipmentDetailsDTO trailingDetail)
			throws URISyntaxException, JBHuntRuntimeException, JSONException {
		
		AddEquipmentGroupESDTO truckEquipDetails = constuctEquipmentDetails(truckDetail, removeEquipmentDTO.getRemoveEquipmentRequestDTO().getLocationId());
		AddEquipmentGroupESDTO trailingEquipDetails = constuctEquipmentDetails(trailingDetail, removeEquipmentDTO.getRemoveEquipmentRequestDTO().getLocationId());
		truckAssignmentUnassignment(truckEquipDetails, trailingEquipDetails, CommonConstants.STRING_U, "jcnt571"); // TO DO change test user
	}
	
	private AddEquipmentGroupESDTO constuctEquipmentDetails(EquipmentDetailsDTO  equipmentDetail, Integer locationId) {
		AddEquipmentGroupESDTO addEquipmentGroupESDTO = new AddEquipmentGroupESDTO();
		addEquipmentGroupESDTO.setEquipmentId(Integer.toString(equipmentDetail.getEquipmentId()));
		addEquipmentGroupESDTO.setLocationCode(Optional.ofNullable(Integer.toString(locationId)).orElse(""));
		addEquipmentGroupESDTO.setEquipmentClassificationCode(equipmentDetail.getEquipmentType());
		addEquipmentGroupESDTO.setBusinessUnit(equipmentDetail.getEquipmentType());
		return addEquipmentGroupESDTO;
	}
	
	public String getCityStateForCustomerCode(String cusCode) {
		List<Object[]> cityStateObjArrList = cityRepository.getCityStateForCustomerCode(cusCode);
		return cityStateObjArrList.stream().findFirst().map(objects -> StringUtils.trim((String) objects[5]))
				.orElseThrow(() -> new JBHuntRuntimeException("City details not found."));
	}
	
	private void checkIfEqpAlreadyPaired(Integer equipmentId, Integer locationId) throws NumberFormatException, JBHuntRuntimeException, URISyntaxException, JSONException {
		List<TEquipment> eqpList =  Optional.ofNullable( equipmentRepository.getEquipmentDetails(equipmentId)).orElseThrow(()->new JBHuntRuntimeException("Equipment details not found in TEQUIPMENT "));
		if(eqpList.size()>1) {
			List<String> eqpIds = eqpList.stream().map(TEquipment::getTrailerNumber).collect(Collectors.toList());
			RemoveEquipmentFromGroupBackFillDTO removeEquipmentFromGroupBackFillDTO = new RemoveEquipmentFromGroupBackFillDTO();
			RemoveEquipmentRequestDTO removeEquipmentRequestDTO = new RemoveEquipmentRequestDTO();
			removeEquipmentRequestDTO.setLocationId(Optional.ofNullable(locationId).orElse(0));
			removeEquipmentFromGroupBackFillDTO.setRemoveEquipmentRequestDTO(removeEquipmentRequestDTO);
			List<com.jbhunt.operations.equipmentgroup.dto.EquipmentDetailsDTO> removeEqpList = new ArrayList<>(); //removeEquipmentFromGroupBackFillDTO.getRemoveEquipmentRequestDTO().getEquipmentDetailsDtos();
			
			List<EquipmentDetailsDTO> equipmentDetails = Optional
					.ofNullable(masterdataAssetClient.getEquipDetailsByEquipNumber(eqpIds))
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream()
					.collect(Collectors.toList());
			
			for(EquipmentDetailsDTO equipmentDetailsDTO : equipmentDetails) {
				com.jbhunt.operations.equipmentgroup.dto.EquipmentDetailsDTO equipmentDetail = new com.jbhunt.operations.equipmentgroup.dto.EquipmentDetailsDTO();
				equipmentDetail.setEquipmentId(equipmentDetailsDTO.getEquipmentId());
				removeEqpList.add(equipmentDetail);
			}
			
			EquipmentDetailsDTO truckDetails = equipmentDetails.stream().filter(eqp->eqp.getCategory().equalsIgnoreCase("POWER")).findFirst().orElseThrow(()-> new JBHuntRuntimeException("Truck details not found in the master data service"));
			EquipmentDetailsDTO trailingDetails = equipmentDetails.stream().filter(eqp->!eqp.getCategory().equalsIgnoreCase("POWER")).findFirst().orElseThrow(()-> new JBHuntRuntimeException("trailing Details not found in the master data service"));
			truckUnassignment(removeEquipmentFromGroupBackFillDTO,truckDetails, trailingDetails);
		}
	}
}
