package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.relaxedRequestFields;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.document;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplanning.owo.dto.event.OperationalWorkOrderEvent;
import com.jbhunt.operations.equipmentgroup.dto.OpexEquipmentLocationUpdateDTO;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc342i.lmc342.LMC342Port;
import com.lmc359i.lmc359.LMC359Port;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable.Wo42OrdStopInfo;
import com.request.lmc359i.lmc359.ProgramInterface.Wo59InputData;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava.Wo42ErrorVariables;
import com.response.lmc359i.lmc359.ProgramInterface.Wo59OutputData;
import com.response.lmc359i.lmc359.ProgramInterface.Wo59OutputData.Wo18OutOutputBuffer1;
import com.response.lmc359i.lmc359.ProgramInterface.Wo59OutputData.Wo18OutOutputBuffer1.Wo59ErrorFields;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class LoadplanningIntegrationOWObackfillControllerIT {


	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;


	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http").host("loadplanning-test.jbhunt.com").removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

    @Autowired
    private ObjectMapper objectMapper;
	
	@MockBean
	private LMC359Port lmc359Port;
	
	@MockBean
	private LMC342Port lmc342Port;
	
	@MockBean
	private Wo42OrdStopInfo Wo42OrdStopInfo;

	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;
	
	@MockBean
	private TaskRepository taskRepository;
	
	
	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID","");
		System.setProperty("DOMAIN_PASSWORD","");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}
	
	@Test
	public void testCreateOWO() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		
		/*List<OperationalWorkOrderESDTO> operationalWorkOrderDTOs = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONWORKORDER_CREATE_JSON_PATH)),
                new TypeReference<List<OperationalWorkOrderESDTO>>(){});
		
		String requestJson = objectMapper.writeValueAsString(operationalWorkOrderESDTOs);*/
		
		//String requestJson = "[{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]";
        String requestJson = "{\"operationalWorkOrderEventType\": \"CREATED\",\"operationalWorkOrderEventSubTypes\": [\"OPERATIONAL_WORK_ORDER\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";

        
        String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

        wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));


		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		//getWo42ErrorVariables().getWo42ReturnFlag()
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);
        
		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");


		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);

	}
	
	
	@Test
	public void testCreateOWOWithNoPay() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		
		/*List<OperationalWorkOrderESDTO> operationalWorkOrderDTOs = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONWORKORDER_CREATE_JSON_PATH)),
                new TypeReference<List<OperationalWorkOrderESDTO>>(){});
		
		String requestJson = objectMapper.writeValueAsString(operationalWorkOrderDTOs);*/
		
		//String requestJson = "[{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]";
        String requestJson = "{\"operationalWorkOrderEventType\": \"CREATED\",\"operationalWorkOrderEventSubTypes\": [\"OPERATIONAL_WORK_ORDER\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"N\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";


        String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

        wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));


		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		//getWo42ErrorVariables().getWo42ReturnFlag()
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);
        
		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");


		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);

	}
	
	@Test
	public void testCreateOWOWithOriginOnly() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		
		/*List<OperationalWorkOrderESDTO> operationalWorkOrderDTOs = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONWORKORDER_CREATE_JSON_PATH)),
                new TypeReference<List<OperationalWorkOrderESDTO>>(){});
		
		String requestJson = objectMapper.writeValueAsString(operationalWorkOrderDTOs);*/
		
		//String requestJson = "[{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]";
        String requestJson = "{\"operationalWorkOrderEventType\": \"CREATED\",\"operationalWorkOrderEventSubTypes\": [\"OPERATIONAL_WORK_ORDER\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"N\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";


        String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

        wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));


		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		//getWo42ErrorVariables().getWo42ReturnFlag()
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);
        
		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");


		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);

	}
	
	@Test
	public void testUpdateOWOWithOriginOnly() throws Exception {
		
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		
		Object[] obj1 = new Object[] {"EQUIPMENT ", "FROM-TO", "RC43113", "KA", "WAKEN", "BOBTAIL", 311340315, "A", 1000, "2020-06-18", "10.22.00", "HJBT JBVAN", 14080622, "2020-06-18", "23.59.00", -14080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		List<Object[]> respArray = new ArrayList<>();
		respArray.add(obj1);
		
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh(Mockito.anyString())).thenReturn(respArray);
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		
		String requestJson = "{\"operationalWorkOrderEventType\": \"UPDATED\",\"operationalWorkOrderEventSubTypes\": [\"STOP\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"N\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");

		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);
	}
	
	@Test
	public void testUpdateOWOWithDROPTRLROnly() throws Exception {
		
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		Object[] obj1 = new Object[] {"EQUIPMENT ", "FROM-TO ", "RC43113", "CZ ", "ILCHI", "DROPTRLR", 311340315, "A", 99000, "2020-06-18", "23.59.00", "HJBT JBVAN", 904080622, "2020-06-18", "23.59.00", -904080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		List<Object[]> respArray = new ArrayList<>();
		respArray.add(obj1);
		
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh(Mockito.anyString())).thenReturn(respArray);
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);
        
        
        String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

        wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));

        
		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		
		String requestJson = "{\"operationalWorkOrderEventType\": \"UPDATED\",\"operationalWorkOrderEventSubTypes\": [\"STOP\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Trailing Equipment\", \"financeBusinessUnitCode\": \"DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"DropEqui\", \"operationalWorkOrderStopReasonDescription\": \"DropEqui\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");

		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);
	}
	
	
	@Test
	public void testCreateOWOWithMixedDeadHeadandBobtail() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		
		/*List<OperationalWorkOrderESDTO> operationalWorkOrderDTOs = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONWORKORDER_CREATE_JSON_PATH)),
                new TypeReference<List<OperationalWorkOrderESDTO>>(){});
		
		String requestJson = objectMapper.writeValueAsString(operationalWorkOrderDTOs);*/
		
		//String requestJson = "[{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]";
        String requestJson = "{\"operationalWorkOrderEventType\": \"CREATED\",\"operationalWorkOrderEventSubTypes\": [\"OPERATIONAL_WORK_ORDER\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"DeadHead\", \"operationalWorkOrderStopReasonDescription\": \"DeadHead\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";


        String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

        wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));


		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		//getWo42ErrorVariables().getWo42ReturnFlag()
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);
        
		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");


		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);

	}
	
	@Test
	public void testCreateOWOWithDestinationOnly() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		
		/*List<OperationalWorkOrderESDTO> operationalWorkOrderDTOs = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONWORKORDER_CREATE_JSON_PATH)),
                new TypeReference<List<OperationalWorkOrderESDTO>>(){});
		
		String requestJson = objectMapper.writeValueAsString(operationalWorkOrderDTOs);*/
		
		//String requestJson = "[{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]";
        String requestJson = "{\"operationalWorkOrderEventType\": \"CREATED\",\"operationalWorkOrderEventSubTypes\": [\"OPERATIONAL_WORK_ORDER\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";


        String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

        wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));


		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		//getWo42ErrorVariables().getWo42ReturnFlag()
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);
        
		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");


		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);

	}
	
	@Test
	public void testCreateOWOWithDropTRLROnly() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		
		/*List<OperationalWorkOrderESDTO> operationalWorkOrderDTOs = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONWORKORDER_CREATE_JSON_PATH)),
                new TypeReference<List<OperationalWorkOrderESDTO>>(){});
		
		String requestJson = objectMapper.writeValueAsString(operationalWorkOrderDTOs);*/
		
		//String requestJson = "[{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]";
        String requestJson = "{\"operationalWorkOrderEventType\": \"CREATED\",\"operationalWorkOrderEventSubTypes\": [\"OPERATIONAL_WORK_ORDER\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Trailing Equipment\", \"financeBusinessUnitCode\": \"DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"DropEqui\", \"operationalWorkOrderStopReasonDescription\": \"DropEqui\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";


        String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

        wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));


		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		//getWo42ErrorVariables().getWo42ReturnFlag()
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);
        
		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");


		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);

	}

	@Test
	public void testCreateOWOError() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String requestJson = "{\"operationalWorkOrderEventType\": \"CREATED\",\"operationalWorkOrderEventSubTypes\": [\"OPERATIONAL_WORK_ORDER\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"9999\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";


		String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

		wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));
		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();

		Wo59ErrorFields errFields = new Wo59ErrorFields();
		//getWo42ErrorVariables().getWo42ReturnFlag()
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");

		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");

		output.setWo18OutOutputBuffer1(outputBuffer);
		when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenThrow(new RuntimeException(getError()));


		Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();

		Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
		wo42ErrorVariables.setWo42ReturnFlag("S");

		wo42Output.setWo42ErrorVariables(wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenThrow(new RuntimeException(getError()));

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");
	}
	
	@Test
	public void testUpdateOWO() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		
		Object[] obj1 = new Object[] {"EQUIPMENT ", "FROM-TO", "RC43113", "KA", "WAKEN", "PKUPTRLR", 311340315, "A", 1000, "2020-06-18", "10.22.00", "HJBT JBVAN", 14080622, "2020-06-18", "23.59.00", -14080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		Object[] obj2 = new Object[] {"EQUIPMENT ", "FROM-TO ", "RC43113", "CZ ", "ILCHI", "DROPTRLR", 311340315, "A", 99000, "2020-06-18", "23.59.00", "HJBT JBVAN", 904080622, "2020-06-18", "23.59.00", -904080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		List<Object[]> respArray = new ArrayList<>();
		respArray.add(obj1);
		respArray.add(obj2);
		
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh(Mockito.anyString())).thenReturn(respArray);
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		String requestJson = "{\"operationalWorkOrderEventType\": \"UPDATED\",\"operationalWorkOrderEventSubTypes\": [\"OPERATIONAL_WORK_ORDER\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"48234\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"KA\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"Updated SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");

		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);
	}
	
	@Test
	public void testCancelOWO() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		
		Object[] obj1 = new Object[] {"EQUIPMENT ", "FROM-TO", "RC43113", "KA", "WAKEN", "PKUPTRLR", 311340315, "A", 1000, "2020-06-18", "10.22.00", "HJBT JBVAN", 14080622, "2020-06-18", "23.59.00", -14080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		Object[] obj2 = new Object[] {"EQUIPMENT ", "FROM-TO ", "RC43113", "CZ ", "ILCHI", "DROPTRLR", 311340315, "A", 99000, "2020-06-18", "23.59.00", "HJBT JBVAN", 904080622, "2020-06-18", "23.59.00", -904080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		List<Object[]> respArray = new ArrayList<>();
		respArray.add(obj1);
		respArray.add(obj2);
		
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh(Mockito.anyString())).thenReturn(respArray);
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		String requestJson = "{ \"operationalWorkOrderEventType\": \"UPDATED\", \"operationalWorkOrderEventSubTypes\": [ \"OPERATIONAL_WORK_ORDER\" ], \"operationalWorkOrderDTOs\": [ { \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeCode\": \"Reposition\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeCode\": \"Truck\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStops\": [ { \"operationalWorkOrderStopId\": 15116, \"stopSequenceNumber\": 1, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"originLocation\": null, \"location\": { \"locationCode\": \"KA\", \"countryName\": \"USA\", \"postalCode\": \"610689005\", \"stateName\": \"Illinois\", \"cityName\": \"Rochelle\", \"stateCode\": \"IL\", \"locationID\": 238130, \"locationName\": \"Errett Warehouse\", \"addressLine2\": null, \"addressLine1\": \"324 Errett Rd\", \"oldLocation\": null, \"newLocation\": \"Errett Warehouse (ERRO19), 324 Errett Rd, Rochelle, IL, 61068-9005  USA\" }, \"cityId\": \"12327\", \"cityState\": \"Rochelle , Illinois\", \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2019-09-11T10:22:29.503Z\", \"appointmentEndTimestamp\": \"2019-09-11T23:49:29.503Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [], \"equipment\": { \"operationalWorkOrderEquipmentRequirementID\": null, \"trailingEquipmentID\": null, \"trailingEquipmentNumber\": null, \"trailingEquipmentAssetClassificationCode\": null, \"equipmentClassificationTypeAssociationID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentTypeDescription\": \"\", \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\", \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null } }, { \"operationalWorkOrderStopId\": 15117, \"stopSequenceNumber\": 2, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"originLocation\": null, \"location\": { \"locationCode\": \"RJSA26\", \"countryName\": \"USA\", \"postalCode\": \"951331707\", \"stateName\": \"California\", \"cityName\": \"San Jose\", \"stateCode\": \"CA\", \"locationID\": 226193, \"locationName\": \"RJA Heating\", \"addressLine2\": null, \"addressLine1\": \"675 N King Rd\", \"oldLocation\": null, \"newLocation\": \"RJA Heating (RJSA26), 675 N King Rd, San Jose, CA, 95133-1707  USA\" }, \"cityId\": \"5202\", \"cityState\": \"San Jose , California\", \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2019-09-11T23:49:29.503Z\", \"appointmentEndTimestamp\": \"2019-09-11T23:49:29.503Z\", \"deadlineIndicator\": \"Y\" }, \"operationalWorkOrderStopServices\": [], \"equipment\": { \"operationalWorkOrderEquipmentRequirementID\": null, \"trailingEquipmentID\": null, \"trailingEquipmentNumber\": null, \"trailingEquipmentAssetClassificationCode\": null, \"equipmentClassificationTypeAssociationID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentTypeDescription\": \"\", \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\", \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null } } ], \"operationalWorkOrderComments\": [  ], \"status\": \"Canceled\", \"totalMiles\": \"2070\", \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"05/24/2019 03:17 AM GMT\", \"resource\": { \"operationalWorkOrderDriverAssociationID\": 0, \"operationalWorkOrderCarrierAssociationID\": 0, \"operationalWorkOrderEquipmentAssociationID\": 0, \"assignedResourceType\": null, \"assignedResourceName\": null, \"driverPersonID\": null, \"carrierID\": null, \"powerEquipmentID\": null }, \"resourceESDTO\": { \"assignedResourceType\": null, \"assignedResourceName\": null, \"driver\": null, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": null }, \"carrier\": null }, \"copies\": 1, \"copyDetails\": [ { \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" } ], \"trailingEquipmentFlag\": false, \"stopMilesOverride\": true } ] }";// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");

		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);
	}
	
	@Test
	public void testDispatchOWO() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		
		Object[] obj1 = new Object[] {"EQUIPMENT ", "FROM-TO", "RC43113", "KA", "WAKEN", "PKUPTRLR", 311340315, "A", 1000, "2020-06-18", "10.22.00", "HJBT JBVAN", 14080622, "2020-06-18", "23.59.00", -14080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		Object[] obj2 = new Object[] {"EQUIPMENT ", "FROM-TO ", "RC43113", "CZ ", "ILCHI", "DROPTRLR", 311340315, "A", 99000, "2020-06-18", "23.59.00", "HJBT JBVAN", 904080622, "2020-06-18", "23.59.00", -904080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		List<Object[]> respArray = new ArrayList<>();
		respArray.add(obj1);
		respArray.add(obj2);
		
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh(Mockito.anyString())).thenReturn(respArray);
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		String requestJson = "{ \"operationalWorkOrderEventType\": \"UPDATED\", \"operationalWorkOrderEventSubTypes\": [ \"OPERATIONAL_WORK_ORDER\" ], \"operationalWorkOrderDTOs\": [ { \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeCode\": \"Reposition\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeCode\": \"Truck\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStops\": [ { \"operationalWorkOrderStopId\": 15116, \"stopSequenceNumber\": 1, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"originLocation\": null, \"location\": { \"locationCode\": \"KA\", \"countryName\": \"USA\", \"postalCode\": \"610689005\", \"stateName\": \"Illinois\", \"cityName\": \"Rochelle\", \"stateCode\": \"IL\", \"locationID\": 238130, \"locationName\": \"Errett Warehouse\", \"addressLine2\": null, \"addressLine1\": \"324 Errett Rd\", \"oldLocation\": null, \"newLocation\": \"Errett Warehouse (ERRO19), 324 Errett Rd, Rochelle, IL, 61068-9005  USA\" }, \"cityId\": \"12327\", \"cityState\": \"Rochelle , Illinois\", \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2019-09-11T10:22:29.503Z\", \"appointmentEndTimestamp\": \"2019-09-11T23:49:29.503Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [], \"equipment\": { \"operationalWorkOrderEquipmentRequirementID\": null, \"trailingEquipmentID\": null, \"trailingEquipmentNumber\": null, \"trailingEquipmentAssetClassificationCode\": null, \"equipmentClassificationTypeAssociationID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentTypeDescription\": \"\", \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\", \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null } }, { \"operationalWorkOrderStopId\": 15117, \"stopSequenceNumber\": 2, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"originLocation\": null, \"location\": { \"locationCode\": \"RJSA26\", \"countryName\": \"USA\", \"postalCode\": \"951331707\", \"stateName\": \"California\", \"cityName\": \"San Jose\", \"stateCode\": \"CA\", \"locationID\": 226193, \"locationName\": \"RJA Heating\", \"addressLine2\": null, \"addressLine1\": \"675 N King Rd\", \"oldLocation\": null, \"newLocation\": \"RJA Heating (RJSA26), 675 N King Rd, San Jose, CA, 95133-1707  USA\" }, \"cityId\": \"5202\", \"cityState\": \"San Jose , California\", \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2019-09-11T23:49:29.503Z\", \"appointmentEndTimestamp\": \"2019-09-11T23:49:29.503Z\", \"deadlineIndicator\": \"Y\" }, \"operationalWorkOrderStopServices\": [], \"equipment\": { \"operationalWorkOrderEquipmentRequirementID\": null, \"trailingEquipmentID\": null, \"trailingEquipmentNumber\": null, \"trailingEquipmentAssetClassificationCode\": null, \"equipmentClassificationTypeAssociationID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentTypeDescription\": \"\", \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\", \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null } } ], \"operationalWorkOrderComments\": [  ], \"status\": \"In Progress\", \"totalMiles\": \"2070\", \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"05/24/2019 03:17 AM GMT\", \"resource\": { \"operationalWorkOrderDriverAssociationID\": 0, \"operationalWorkOrderCarrierAssociationID\": 0, \"operationalWorkOrderEquipmentAssociationID\": 0, \"assignedResourceType\": null, \"assignedResourceName\": null, \"driverPersonID\": null, \"carrierID\": null, \"powerEquipmentID\": null }, \"resourceESDTO\": { \"assignedResourceType\": null, \"assignedResourceName\": null, \"driver\": null, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": null }, \"carrier\": null }, \"copies\": 1, \"copyDetails\": [ { \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" } ], \"trailingEquipmentFlag\": false, \"stopMilesOverride\": true } ] }";// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");

		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);
	}
	
	@Test
	public void testCompleteOWO() throws Exception {

		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		
		Object[] obj1 = new Object[] {"EQUIPMENT ", "FROM-TO", "RC43113", "KA", "WAKEN", "PKUPTRLR", 311340315, "A", 1000, "2020-06-18", "10.22.00", "HJBT JBVAN", 14080622, "2020-06-18", "23.59.00", -14080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		Object[] obj2 = new Object[] {"EQUIPMENT ", "FROM-TO ", "RC43113", "CZ ", "ILCHI", "DROPTRLR", 311340315, "A", 99000, "2020-06-18", "23.59.00", "HJBT JBVAN", 904080622, "2020-06-18", "23.59.00", -904080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		List<Object[]> respArray = new ArrayList<>();
		respArray.add(obj1);
		respArray.add(obj2);
		
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh(Mockito.anyString())).thenReturn(respArray);
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		String requestJson = "{ \"operationalWorkOrderEventType\": \"UPDATED\", \"operationalWorkOrderEventSubTypes\": [ \"OPERATIONAL_WORK_ORDER\" ], \"operationalWorkOrderDTOs\": [ { \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeCode\": \"Reposition\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeCode\": \"Truck\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStops\": [ { \"operationalWorkOrderStopId\": 15116, \"stopSequenceNumber\": 1, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"originLocation\": null, \"location\": { \"locationCode\": \"KA\", \"countryName\": \"USA\", \"postalCode\": \"610689005\", \"stateName\": \"Illinois\", \"cityName\": \"Rochelle\", \"stateCode\": \"IL\", \"locationID\": 238130, \"locationName\": \"Errett Warehouse\", \"addressLine2\": null, \"addressLine1\": \"324 Errett Rd\", \"oldLocation\": null, \"newLocation\": \"Errett Warehouse (ERRO19), 324 Errett Rd, Rochelle, IL, 61068-9005  USA\" }, \"cityId\": \"12327\", \"cityState\": \"Rochelle , Illinois\", \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2019-09-11T10:22:29.503Z\", \"appointmentEndTimestamp\": \"2019-09-11T23:49:29.503Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [], \"equipment\": { \"operationalWorkOrderEquipmentRequirementID\": null, \"trailingEquipmentID\": null, \"trailingEquipmentNumber\": null, \"trailingEquipmentAssetClassificationCode\": null, \"equipmentClassificationTypeAssociationID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentTypeDescription\": \"\", \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\", \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null } }, { \"operationalWorkOrderStopId\": 15117, \"stopSequenceNumber\": 2, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"originLocation\": null, \"location\": { \"locationCode\": \"RJSA26\", \"countryName\": \"USA\", \"postalCode\": \"951331707\", \"stateName\": \"California\", \"cityName\": \"San Jose\", \"stateCode\": \"CA\", \"locationID\": 226193, \"locationName\": \"RJA Heating\", \"addressLine2\": null, \"addressLine1\": \"675 N King Rd\", \"oldLocation\": null, \"newLocation\": \"RJA Heating (RJSA26), 675 N King Rd, San Jose, CA, 95133-1707  USA\" }, \"cityId\": \"5202\", \"cityState\": \"San Jose , California\", \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2019-09-11T23:49:29.503Z\", \"appointmentEndTimestamp\": \"2019-09-11T23:49:29.503Z\", \"deadlineIndicator\": \"Y\" }, \"operationalWorkOrderStopServices\": [], \"equipment\": { \"operationalWorkOrderEquipmentRequirementID\": null, \"trailingEquipmentID\": null, \"trailingEquipmentNumber\": null, \"trailingEquipmentAssetClassificationCode\": null, \"equipmentClassificationTypeAssociationID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentTypeDescription\": \"\", \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\", \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null } } ], \"operationalWorkOrderComments\": [  ], \"status\": \"Completed\", \"totalMiles\": \"2070\", \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"05/24/2019 03:17 AM GMT\", \"resource\": { \"operationalWorkOrderDriverAssociationID\": 0, \"operationalWorkOrderCarrierAssociationID\": 0, \"operationalWorkOrderEquipmentAssociationID\": 0, \"assignedResourceType\": null, \"assignedResourceName\": null, \"driverPersonID\": null, \"carrierID\": null, \"powerEquipmentID\": null }, \"resourceESDTO\": { \"assignedResourceType\": null, \"assignedResourceName\": null, \"driver\": null, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": null }, \"carrier\": null }, \"copies\": 1, \"copyDetails\": [ { \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" } ], \"trailingEquipmentFlag\": false, \"stopMilesOverride\": true } ] }";// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");

		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);
	}
	
	
	@Test
	public void testUpdateOWOWithActivity() throws Exception {
		
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		Wo59OutputData output = new Wo59OutputData();
		Wo18OutOutputBuffer1 outputBuffer = new Wo18OutOutputBuffer1();
		
		
		Object[] obj1 = new Object[] {"EQUIPMENT ", "FROM-TO", "RC43113", "KA", "WAKEN", "BOBTAIL", 311340315, "A", 1000, "2020-06-18", "10.22.00", "HJBT JBVAN", 14080622, "2020-06-18", "23.59.00", -14080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		Object[] obj2 = new Object[] {"EQUIPMENT ", "FROM-TO ", "RC43113", "CZ ", "ILCHI", "BOBTAIL", 311340315, "A", 99000, "2020-06-18", "23.59.00", "HJBT JBVAN", 904080622, "2020-06-18", "23.59.00", -904080622, "HJBT JBDCS", "5/27/2019 2:11:56 AM"};
		List<Object[]> respArray = new ArrayList<>();
		respArray.add(obj1);
		respArray.add(obj2);
		
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh(Mockito.anyString())).thenReturn(respArray);
		
		Wo59ErrorFields errFields = new Wo59ErrorFields();
		errFields.setWo59ErrorMessage("Mock");
		errFields.setWo59ErrorFlag("true");
		
		outputBuffer.setWo59ErrorFields(errFields);
		outputBuffer.setWo59OutData("test data from soap call");
		
		output.setWo18OutOutputBuffer1(outputBuffer);
        when(lmc359Port.lmc359Operation(Mockito.any(Wo59InputData.class))).thenReturn(output);

        
        Wo42ComReturnToJava wo42Output = new Wo42ComReturnToJava();
        
        Wo42ErrorVariables wo42ErrorVariables = new Wo42ErrorVariables();
        wo42ErrorVariables.setWo42ReturnFlag("S");
        
        wo42Output.setWo42ErrorVariables(wo42ErrorVariables);
        
        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42Output);

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[40566279]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		
		String requestJson = "{\"operationalWorkOrderEventType\": \"UPDATED\",\"operationalWorkOrderEventSubTypes\": [\"OPERATIONAL_WORK_ORDER\"],\"operationalWorkOrderDTOs\": [{ \"operationalWorkOrderID\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderTypeDescription\": \"Reposition\", \"operationalWorkOrderSubtypeDescription\": \"Tractor\", \"financeBusinessUnitCode\": \"HJBT DCS\", \"transitModeCode\": \"Truck\", \"operationalGroupCode\": \"HJBT DCS\", \"driverPayIndicator\": \"Y\", \"operationalWorkOrderStatusDescription\": \"Available\", \"operationalWorkOrderStops\": [{ \"operationalWorkOrderStopId\": 8939, \"cityId\": \"\", \"cityState\": \"Greenville , New York\", \"location\": { \"locationCode\": \"TOGR4\", \"countryName\": \"USA\", \"postalCode\": \"12083\", \"stateName\": \"New York\", \"cityName\": \"Greenville\", \"stateCode\": \"NY\", \"locationID\": 342960, \"locationName\": \"Tops Friendly Market\", \"addressLine2\": null, \"addressLine1\": \"11573 Ny Hwy 32\" }, \"operationalWorkOrderStopReasonCode\": \"DeadHead\", \"operationalWorkOrderStopReasonDescription\": \"DeadHead\", \"stopSequenceNumber\": 1, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T00:39:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }, { \"operationalWorkOrderStopId\": 8940, \"cityId\": \"48234\", \"cityState\": \"Virginia Beach , Virginia\", \"location\": { \"locationCode\": \"KA\", \"countryName\": \"USA\", \"postalCode\": \"\", \"stateName\": \"Virginia\", \"cityName\": \"Virginia Beach\", \"stateCode\": \"VA\", \"locationID\": null, \"locationName\": \"\", \"addressLine2\": \"\", \"addressLine1\": \"\" }, \"operationalWorkOrderStopReasonCode\": \"Bobtail\", \"operationalWorkOrderStopReasonDescription\": \"Bobtail\", \"stopSequenceNumber\": 2, \"operationalWorkOrderStopAppointment\": { \"appointmentStartTimestamp\": \"2099-12-31T23:59:00Z\", \"appointmentEndTimestamp\": \"2099-12-31T23:59:00Z\", \"deadlineIndicator\": \"N\" }, \"operationalWorkOrderStopServices\": [] }], \"operationalWorkOrderComments\": [{ \"operationalWorkOrderCommentID\": null, \"operationalWorkOrderStopID\": null, \"commentLevelTypeCode\": \"Driver Task\", \"operationalWorkOrderCommentTypeCode\": \"Driver\", \"operationalWorkOrderCommentTypeDescription\": \"Driver\", \"operationalWorkorderCommentText\": \"Updated SF\" }], \"totalMiles\": 0, \"equipment\": { \"equipmentNumber\": { \"trailingEquipmentID\": \"7898227\", \"trailingEquipmentNumber\": \"BF84268    (3DR0)\", \"trailingEquipmentAssetClassificationCode\": \"\" }, \"trailingEquipmentInfo\": { \"equipmentCategoryType\": { \"equipmentClassificationTypeAssociationID\": null, \"operationalWorkOrderEquipmentRequirementID\": null, \"equipmentClassificationDescription\": \"\", \"equipmentClassRequiredIndicator\": \"N\", \"equipmentTypeDescription\": \"\", \"equipmentTypeRequiredIndicator\": \"N\", \"equipmentLengthRequiredIndicator\": \"N\" }, \"equipmentLength\": { \"operationalWorkOrderEquipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationAssociationID\": null, \"equipmentRequirementSpecificationDescription\": \"36 Feet In Length\" } } }, \"lastUpdateProgramName\": \"Process ID\", \"lastUpdateUserID\": \"pidccrfs\", \"lastUpdateTimestamp\": \"03/07/2019 06:39 AM GMT\", \"resourceESDTO\": { \"assignedResourceType\": \"Carrier\", \"assignedResourceName\": \"Aaron Alford (ALFA3)\", \"driver\": { \"operationalWorkOrderDriverAssociationID\": \"0\", \"driverPersonID\": \"260784\" }, \"tractor\": { \"operationalWorkOrderEquipmentAssociationID\": \"0\", \"powerEquipmentID\": \"40566279\" }, \"carrier\": { \"operationalWorkOrderCarrierAssociationID\": \"0\", \"carrierID\": \"354742\" } }, \"copiesDetails\": [{ \"operationalWorkOrderId\": 45765, \"operationalWorkOrderNumber\": \"W45765\", \"operationalWorkOrderStatusDescription\": \"Success\" }], \"copies\": 1 }]}";// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessOperationalWorkOrder", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processOperationWorkOrderRequest())))
				.contentType("application/json; charset=utf-8").body(requestJson)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalworkorders");

		BackfillServiceResponse resp = response.getBody().as(BackfillServiceResponse.class);
		Assert.assertNotNull(resp);
	}
	
	
	private static FieldDescriptor[] processOperationWorkOrderRequest() {
		return new FieldDescriptor[] {
				fieldWithPath("operationalWorkOrderEventType").description("Represents the Event Type of OperationWorkOrder whether Create or Update"),
				fieldWithPath("operationalWorkOrderEventSubTypes").description("Represents the Sub Event Type under Create or Update of OperationWorkOrder"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalWorkOrderID").description("Represents the workOrderID created in the Next System"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalWorkOrderNumber").description("Represents the workOrderNumber associated with the workOrderId created in the Next System"),
				fieldWithPath("operationalWorkOrderDTOs[].financeBusinessUnitCode").description("Represents the Buisness Unit whether DCS or ICS or JBT or JBI"),
				fieldWithPath("operationalWorkOrderDTOs[].transitModeCode").description("Represents the Transit mode of the WorkOrder whether by Truck or Rail"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalGroupCode").description("Represents the Fleet Code of the WorkOrder"),
				fieldWithPath("operationalWorkOrderDTOs[].driverPayIndicator").description("Represents the Driver pay Indicator from the Next System"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalWorkOrderStops[].operationalWorkOrderStopId").description("Represents the Stop Id for the Stop Created in the Next System"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalWorkOrderStops[].stopSequenceNumber").description("Represents the Stop whether Orgin or Destination by the sequence No is 1 or 2"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalWorkOrderStops[].operationalWorkOrderStopReasonCode").description("Represents the Stop reason code whether Bobtail or DeadHead or Pickup or Drop"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalWorkOrderStops[].location.locationCode").description("Represents the location given in the Next System"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalWorkOrderStops[].cityState").description("Represents the City State code populated in the Next System"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalWorkOrderStops[].operationalWorkOrderStopAppointment.appointmentStartTimestamp").description("Represents the Origin Stop appointment time range"),
				fieldWithPath("operationalWorkOrderDTOs[].operationalWorkOrderStops[].operationalWorkOrderStopAppointment.appointmentEndTimestamp").description("Represents the Destination Stop appointment time range"),
				//fieldWithPath("status").description("Represents the Status of workOrder of the Next System"),
				fieldWithPath("operationalWorkOrderDTOs[].totalMiles").description("Represents the total Miles calulated between the origin and Destination stops"),
				fieldWithPath("operationalWorkOrderDTOs[].resourceESDTO.tractor.powerEquipmentID").description("Represents the equipment ID assigned to the workOrder"),
				fieldWithPath("operationalWorkOrderDTOs[].copies").description("Represents the total No of copies"),
				fieldWithPath("operationalWorkOrderDTOs[].lastUpdateUserID").description("Represents the userID who is updated this workOrder"),
				fieldWithPath("operationalWorkOrderDTOs[].lastUpdateProgramName").description("Represents the updated Program Name")
				 };
	}
	
	
	private String getError(){
		StringBuffer stringBuffer = new StringBuffer();
		for(int i=0 ;i<400;i++){
			stringBuffer.append("test");
		}
		return stringBuffer.toString();
	}
}