package com.jbhunt.loadplannig.integration.backfill.constants;

public class SQLQueryConstants {

	public static final String GET_LEGACYORDER_DETAILS_BY_OPERATIONALPLAN_ID = "SELECT * FROM BKFIL.LegacyOrderOperationalPlanAssociation where OperationalPlanID= ?";

	public static final String GET_OPERATIONAL_PLAN_IDS = "SELECT * FROM BKFIL.LegacyOrderOperationalPlanAssociation where LegacyOrderID = ?";
	
	public static final String GET_OPERATIONAL_PLAN_ID_BY_JOB_ID = "SELECT OperationalPlanID FROM BKFIL.LegacyOrderOperationalPlanAssociation where LegacyOrderID = ? and LegacyJobID = ?";
	
	public static final String GET_OPERATIONAL_PLAN_ID_BY_RESERVATION_ID = "SELECT OperationalPlanID FROM BKFIL.LegacyOrderOperationalPlanAssociation where LegacyOrderID = ? and LegacyResourceReservationID = ?";

	public static final String GET_OPERATIONAL_PLAN_ID = "SELECT OperationalPlanID FROM BKFIL.LegacyOrderOperationalPlanAssociation where LegacyOrderID = ? and LegacyJobID = ? and LegacyResourceReservationID = ?";

}
