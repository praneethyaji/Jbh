package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderComment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;




@Repository
public interface OrderCommentRepository extends JpaRepository<OrderComment, Integer> {

	@Query(value = "SELECT ORD_I, CMM_TYP, CMM_TXT FROM ALI.ORDER_COMMENT WHERE ORD_I =:ordI WITH UR", nativeQuery = true)
	List<OrderComment> findCommentDetailsByOrdId(@Param("ordI") Integer ordI);
	
}
