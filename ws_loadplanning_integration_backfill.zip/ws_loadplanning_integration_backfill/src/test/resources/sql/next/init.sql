CREATE SCHEMA IF NOT EXISTS BKFIL;

DROP TABLE BKFIL.BackFillEventTracking;
DROP TABLE BKFIL.LegacyOrderOperationalPlanAssociation;


CREATE TABLE IF NOT EXISTS BKFIL.BackFillEventTracking
	(
	BackFillEventTrackingID     INT IDENTITY NOT NULL,
	NextOrderID     INT NOT NULL,
	NextOrderTrackingNumber NVARCHAR (20) NOT NULL,
	NextOperationalPlanID INT NOT NULL,
	NextOperationalPlanNumber NVARCHAR (20) NOT NULL,
	EventStatus            NVARCHAR (12) NOT NULL,
	EventType          NVARCHAR (30) NOT NULL,
	EventTimestamp DATETIME NOT NULL,
	EventMessageText           NVARCHAR (500) NULL,
	CreateTimestamp                    DATETIME  NOT NULL,
	CreateUserID                       NVARCHAR (8) NOT NULL,
	CreateProgramName                  NVARCHAR (30) NOT NULL,
	LastUpdateTimestamp                DATETIME NOT NULL,
	LastUpdateUserID                   NVARCHAR (8) NOT NULL,
	LastUpdateProgramName              NVARCHAR (30) NOT NULL
	);
	
CREATE TABLE IF NOT EXISTS BKFIL.LegacyOrderOperationalPlanAssociation
	(
	LegacyOrderOperationalPlanAssociationID     INT IDENTITY NOT NULL,
	LegacyOrderID     INT NOT NULL,
	LegacyJobID  INT NULL,
	LegacyResourceReservationID INT NULL,
	LegacyCarrierReservationID INT NULL,
	LegacyDispatchNumber            SMALLINT NULL,
	LegacyOrderNumber			NVARCHAR (8) NOT NULL,
	OperationalPlanID          INT NOT NULL,
	CreateTimestamp                    DATETIME  NOT NULL,
	CreateUserID                       NVARCHAR (8) NOT NULL,
	CreateProgramName                  NVARCHAR (30) NOT NULL,
	LastUpdateTimestamp                DATETIME NOT NULL,
	LastUpdateUserID                   NVARCHAR (8) NOT NULL,
	LastUpdateProgramName              NVARCHAR (30) NOT NULL
	);
	
	
INSERT INTO BKFIL.BackFillEventTracking (NextOrderID,NextOrderTrackingNumber,NextOperationalPlanID,
NextOperationalPlanNumber,EventStatus,EventType,EventTimestamp,EventMessageText,CreateTimestamp,
CreateUserID,CreateProgramName,LastUpdateTimestamp,LastUpdateUserID,LastUpdateProgramName) 
 VALUES 
  (20003690,'DVGY',4860,'L4860','Pending','LoadCreation', CURRENT_TIMESTAMP,
  'Completed',CURRENT_TIMESTAMP,'PIDORDM','LOADPLANNING',CURRENT_TIMESTAMP,
  'PIDORDM','LOADPLANNING');
  
INSERT INTO BKFIL.LegacyOrderOperationalPlanAssociation (LegacyOrderID,LegacyJobID,LegacyResourceReservationID,
							LegacyCarrierReservationID,LegacyDispatchNumber,LegacyOrderNumber,OperationalPlanID,CreateTimestamp,
							CreateUserID,CreateProgramName,LastUpdateTimestamp,LastUpdateUserID,LastUpdateProgramName) 
							 VALUES  (862540315,1234567,34567,0,0,'RD05526',14317,CURRENT_TIMESTAMP,'pidldpn','Process ID',CURRENT_TIMESTAMP,'pidldpn','Process ID');

