package com.jbhunt.loadplannig.integration.backfill.enums;

public enum EventStatusEnum {
    COMPLETED, PENDING, FAILED
}
