package com.jbhunt.loadplannig.integration.backfill.controllers;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.exception.MainframeSoapException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Slf4j
public abstract class BackfillBaseController {

    protected BackfillServiceResponse getBackfillServiceResponse(String statusCode, String statusMessage, boolean retry){
        return new BackfillServiceResponse(statusCode, statusMessage, retry);
    }

    protected BackfillServiceResponse getBackfillServiceSuccessResponse(){
        return new BackfillServiceResponse("200", "success", false);
    }

    @ExceptionHandler(JBHuntRuntimeException.class)
    protected  BackfillServiceResponse exceptionHandling(JBHuntRuntimeException e){
        log.error("Error :  {}",e);
        return  getBackfillServiceResponse("500", e.getMessage(), false);
    }

    @ExceptionHandler(MainframeSoapException.class)
    protected  BackfillServiceResponse mainframeExceptionHandling(MainframeSoapException e){
        log.error("Error :  {}",e);
        return  getBackfillServiceResponse(e.getErrorCode(), e.getMessage(), true);
    }
}
