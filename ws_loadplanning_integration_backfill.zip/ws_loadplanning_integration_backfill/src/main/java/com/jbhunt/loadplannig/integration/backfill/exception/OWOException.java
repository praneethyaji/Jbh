package com.jbhunt.loadplannig.integration.backfill.exception;

import java.io.Serializable;

public class OWOException extends RuntimeException implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -954588227576799812L;

	public OWOException(String message, Throwable cause) {
		super(message, cause);
	}

	public OWOException(String message) {
		super(message);
	}

	public OWOException(Throwable cause) {
		super(cause);
	}

}
