package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "TCITY", schema = "ALI")
public class City implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
    @Column(name = "CITY_ID")
    private String cityID;

    @Column(name = "DSC_T")
    private String dscT;

    @Column(name = "CTY_ST_C")
    private String ctyStC;
    
    @Column(name = "REC_STT_F")
    private String recSttF;
    
    @Column(name = "PNT_I")
    private Integer pntI;
    
    @Column(name="ST_ID")
    private String state;
    
    
    
}
