package com.jbhunt.loadplannig.integration.backfill.services;

import java.net.URISyntaxException;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.utils.CommonUtils;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.operations.admin.operationalgroup.dto.event.DriverAssignmentDTO;
import com.jbhunt.operations.admin.operationalgroup.dto.event.OperationalGroupDetailsDTO;
import com.jbhunt.operations.admin.operationalgroup.dto.event.OperationalGroupEvent;
import com.lmc367i.lmc367.LMC367Port;
import com.request.lmc367i.lmc367.ProgramInterface.Wo67InputArea;
import com.response.lmc367i.lmc367.ProgramInterface.Wo67OutputArea;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class FleetService {

	private final LMC367Port lmc367Port;
	private final MasterdataAssetClient masterdataAssetClient;

	public void populateFleetObj(final OperationalGroupEvent operationalGroupEvent) throws JBHuntRuntimeException {

		final OperationalGroupDetailsDTO operationalGroupDetailsDTO = operationalGroupEvent
				.getOperationalGroupDetailsDTO();

		operationalGroupDetailsDTO.getEquipmentAssignmentDTOs().stream().forEach(equipmentsAssignmentDTO -> {
			try {
				final Integer equipmentId = getEquipmentLegacyId(equipmentsAssignmentDTO.getEquipmentId());
				log.info("Legacy Equipment Id >>> {}", equipmentId);
				final Wo67OutputArea wo67OutputArea = CommonUtils.soapCall((i) -> lmc367Port.lmc367Operation(i),
						prepareWo67InputArea(operationalGroupDetailsDTO, equipmentId));
				log.info("wo67OutputArea response >>>>>>>>>>>>>>>>>>>> {}", CommonUtils.asString(wo67OutputArea));
			} catch (URISyntaxException e) {
				throw new JBHuntRuntimeException(e.getMessage());
			}

		});

	}

	public Integer getEquipmentLegacyId(final Integer nextSystemEquipmentId)
			throws JBHuntRuntimeException, URISyntaxException {
		EquipmentDetailsDTO equipmentDetailsDTO = Optional
				.ofNullable(masterdataAssetClient.getEquipmentDetails(Arrays.asList(nextSystemEquipmentId)))
				.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream()
				.findFirst().orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));

		return equipmentDetailsDTO.getLegacyEquipmentId();

	}

	private Wo67InputArea prepareWo67InputArea(final OperationalGroupDetailsDTO operationalGroupDetailsDTO,
			final Integer equipmentId) {
		final Wo67InputArea wo67InputArea = new Wo67InputArea();
		wo67InputArea.setWo67DivC(operationalGroupDetailsDTO.getFinanceBusinessUnitCode());
		wo67InputArea.setWo67FltC(operationalGroupDetailsDTO.getOperationalGroupCode());
		wo67InputArea.setWo67Dsc(operationalGroupDetailsDTO.getOperationalGroupTypeDescription());
		wo67InputArea.setWo67DftFltF(" ");

		wo67InputArea.setWo67EffD(formatAsOffsetDateTime(operationalGroupDetailsDTO.getEffectiveTimestamp()));
		wo67InputArea.setWo67EndD(formatAsOffsetDateTime(operationalGroupDetailsDTO.getExpirationTimestamp()));
		wo67InputArea.setWo67CrtD(formatAsOffsetDateTime(operationalGroupDetailsDTO.getLastUpdateTimestamp()));
		wo67InputArea.setWo67CrtUid(operationalGroupDetailsDTO.getLastUpdateProgramName());
		wo67InputArea.setWo67LstUpdPgmC("LMC367");
		wo67InputArea.setWo67LstUpdD(formatAsOffsetDateTime(operationalGroupDetailsDTO.getLastUpdateTimestamp()));
		wo67InputArea.setWo67LstUpdUid(operationalGroupDetailsDTO.getLastUpdateProgramName());
		wo67InputArea.setWo67PrjMgrUid(" ");
		wo67InputArea.setWo67CstCtrC(" ");
		wo67InputArea.setWo67PsLdgrCust(" ");
		wo67InputArea.setWo67PsLdgrDeptid(" ");
		wo67InputArea.setWo67PsLdgrReg(" ");
		wo67InputArea.setWo67PsLdgrLoc(" ");
		wo67InputArea.setWo67BkhReqDivC(" ");
		wo67InputArea.setWo67CpcMd(" ");
		wo67InputArea.setWo67FltTyp(" ");
		wo67InputArea.setWo67Filler(" ");

		wo67InputArea.setWo67EqpId(equipmentId);

		wo67InputArea.setWo67FltTyp(operationalGroupDetailsDTO.getOperationalGroupSubTypeCode());

		Optional<List<DriverAssignmentDTO>> driverAssignmentDTOs = Optional
				.ofNullable(operationalGroupDetailsDTO.getDriverAssignmentDTOs());

		if (driverAssignmentDTOs.isPresent()) {
			String driverUserId = driverAssignmentDTOs.get().stream().map(DriverAssignmentDTO::getDriverUserId).findFirst()
					.orElse("");
			log.info("DriverUSerID >>> {}", driverUserId);
			wo67InputArea.setWo67OprCd(driverUserId);
		}

		wo67InputArea.setWo67UserId(operationalGroupDetailsDTO.getLastUpdateProgramName());
		return wo67InputArea;
	}

	private String formatAsOffsetDateTime(final String timestamp) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		OffsetDateTime offsetDateTime = OffsetDateTime.parse(timestamp);
		return offsetDateTime.format(formatter);
	}

}
