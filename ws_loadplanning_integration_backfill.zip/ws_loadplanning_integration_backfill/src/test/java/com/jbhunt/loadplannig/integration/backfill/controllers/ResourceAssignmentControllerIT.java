package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TPndJobAsn;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.RsvrscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TpndJobAsnRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc341i.lmc341.LMC341Port;
import com.lmc342i.lmc342.LMC342Port;
import com.lmc345i.lmc345.LMC345Port;
import com.lmc360i.lmc360.LMC360Port;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables;
import com.response.lmc341i.lmc341.ProgramInterface.Lmc341OutputArea;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava.Wo42ErrorVariables;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class ResourceAssignmentControllerIT {

	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http")
			.host("loadplanning-test.jbhunt.com").removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";
	
	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private LMC341Port lmc341Port;

	@MockBean
	private LMC342Port lmc342Port;
	
	@MockBean
    private LMC360Port lmc360Port;
	
	@MockBean
    private LMC345Port lmc345Port;
	
	@MockBean
	@Qualifier("sqlServerjdbcTemplate")
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	private OrderLoadRepository orderLoadRepository;
	
	@MockBean
	private EquipmentRepository equipmentRepository;

	@MockBean
	private TaskRepository taskRepository;
	
	@MockBean
	private TpndJobAsnRepository tpndJobAsnRepository;
	
	@MockBean
    private RsvrscRepository rsvrscRepository;
	
	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}
	
	@Test
	public void cancelResourceAssignment() throws Exception {

		resourceAssignmentOrCancel("/json/OperationalPlanCancelResourceAssignment.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments/cancel");
	}

	@Test
	public void resourceAssignment() throws Exception {

		resourceAssignmentOrCancel("/json/OperationalPlanResourceAssignment.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments");
	}
	
	@Test
	public void withOutresourceAssignment() throws Exception {

		resourceAssignmentOrCancel("/json/OperationalPlanWithoutResourceAssignment.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments");
	}
	
	@Test
	public void resourceAssignmentForOwo() throws Exception {

		resourceAssignmentOrCancel("/json/OperationalPlanResourceAssignmentForOWO.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments");
	}

	@Test
	public void driverAssignment() throws Exception {
		resourceAssignmentOrCancel("/json/OperationalPlanDriverAssignment.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments");
	}
	
	@Test
	public void driverAssignmentForOWO() throws Exception {
		resourceAssignmentOrCancel("/json/OperationalPlanDriverAssignmentForOWO.json",
				"/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments");
	}
	
	
	@Test
	public void testMergeLoad() throws Exception {

		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"328850\",\r\n"
				+ "    \"resourceName\": \"ARJUN  LAVEY\",\r\n" + "    \"firstName\": \"ARJUN\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"ARVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/328850")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataAssetForMergeLoad.json"));

		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[342159]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		final OperationalPlanDTO operationalPlanDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/MergeLoad.json")), OperationalPlanDTO.class);

		TOrder orderDetails = new TOrder();
		orderDetails.setLastUpdateTimeStamp("2019-01-02 10.00.06");
		orderDetails.setOrderId(123456789);
		orderDetails.setOrdrNumber("RA97939");

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(30013190)).thenReturn(orderDetails);

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderIDWarehouse(30013190)).thenReturn(orderDetails);

		Mockito.when(taskRepository.findLastUpdatedTimeStampBytaskId(123456789)).thenReturn("2019-01-02 10.00.06");
		
		Lmc341OutputArea output1 = new Lmc341OutputArea();
		output1.setLmc341ErrorMessage("Mock");
		output1.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output1);
		Wo42ComReturnToJava output2 = new Wo42ComReturnToJava();
		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ErrorKey1("");
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		Wo42ErrorVariables.setWo42Message("");
		Wo42ErrorVariables.setWo42CicsReturnCode(399);
		Wo42ErrorVariables.setWo42ErrorKey2("");
		
		com.response.lmc360i.lmc360.ProgramInterface.Wo60OutputArea output = new com.response.lmc360i.lmc360.ProgramInterface.Wo60OutputArea();
        when(lmc360Port.lmc360Operation(Mockito.any(com.request.lmc360i.lmc360.ProgramInterface.Wo60InputArea.class))).thenReturn(output);

		output2.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output2);
		
		com.response.lmc345i.lmc345.ProgramInterface.Lmc345OutputArea lmc345OutputArea = new com.response.lmc345i.lmc345.ProgramInterface.Lmc345OutputArea();
        lmc345OutputArea.setLmc345ErrorMessage(null);
        when(lmc345Port.lmc345Operation(Mockito.any(com.request.lmc345i.lmc345.ProgramInterface.Lmc345CommArea.class))).thenReturn(lmc345OutputArea);
        Object[] resourcePlanByDriverAlphaCodeArray={5,10};
        List<Object[]> resourcePlanByDriverAlphaCodeList= new ArrayList<>();
        resourcePlanByDriverAlphaCodeList.add(resourcePlanByDriverAlphaCodeArray);
        when(rsvrscRepository.fetchResourcePlanByDriverAlphaCode(Mockito.anyString())).thenReturn(resourcePlanByDriverAlphaCodeList);
        List<Object[]> OrderStopForTransferList= new ArrayList<>();

        Object[] orderStopForTransferArray={0,"OrdNbr1",2,"TaskLstUpdS3",4,"LstUpdS5",6,7,8,"RqTyId9","ARSS"};
        OrderStopForTransferList.add(orderStopForTransferArray);
        when(taskRepository.findOrderStopForTransfer(Mockito.anyString(),Mockito.anyInt())).thenReturn(OrderStopForTransferList);
        
        TPndJobAsn tPndJobAsn = new TPndJobAsn();
		tPndJobAsn.setEstimateTimeAppointmentDate("2019-08-06");
		tPndJobAsn.setEstimateTimeAppointmentHours("12.51.00");
		Mockito.when(tpndJobAsnRepository.getMaxEtaDateAndTimeByEqpUnitId(Mockito.anyString())).thenReturn(tPndJobAsn);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanDTO)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/1/resourceassignments");

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

	private void resourceAssignmentOrCancel(final String filePathJson, final String restURI) throws Exception {

		// ARRANGEl
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		final String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";
		
		TOrder orderDetails = new TOrder();
		orderDetails.setLastUpdateTimeStamp("2019-01-02 10.00.06");
		orderDetails.setOrderId(123456789);
		orderDetails.setOrdrNumber("RA97939");

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(1010479)).thenReturn(orderDetails);
		
		TPndJobAsn tPndJobAsn = new TPndJobAsn();
		tPndJobAsn.setEstimateTimeAppointmentDate("2019-08-06");
		tPndJobAsn.setEstimateTimeAppointmentHours("12.51.00");
		Mockito.when(tpndJobAsnRepository.getMaxEtaDateAndTimeByEqpUnitId("353086")).thenReturn(tPndJobAsn);
		
		final String responseMasterData = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		final OperationalPlanDTO operationalPlanDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(filePathJson)), OperationalPlanDTO.class);
		final Lmc341OutputArea lmc341OutputArea = new Lmc341OutputArea();
		lmc341OutputArea.setLmc341ErrorMessage("Mock");
		lmc341OutputArea.setLmc341ReturnFlag("S");

		final Wo42ComReturnToJava wo42ComReturnToJava = new Wo42ComReturnToJava();
		final Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ErrorKey1("");
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		Wo42ErrorVariables.setWo42Message("");
		Wo42ErrorVariables.setWo42CicsReturnCode(399);
		Wo42ErrorVariables.setWo42ErrorKey2("");

		wo42ComReturnToJava.setWo42ErrorVariables(Wo42ErrorVariables);

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[7885243]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(lmc341OutputArea);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(wo42ComReturnToJava);

		final Response response = given(this.requestSpecification).auth().basic(userName, password)
				.accept(ContentType.JSON).contentType(ContentType.JSON).body(operationalPlanDTO).patch(restURI);

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}
	
}
