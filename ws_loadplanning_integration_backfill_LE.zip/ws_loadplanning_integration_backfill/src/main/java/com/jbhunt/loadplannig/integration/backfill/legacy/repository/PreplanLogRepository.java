package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.PreplanLog;

public interface PreplanLogRepository extends  JpaRepository<PreplanLog, Integer>  {
	
	@Query(value="SELECT PPL_LOG_I,TSK_I,EQP_I, CHAR(LST_UPD_S) AS LST_UPD_S  FROM ALI.PREPLAN_LOG WHERE  TSK_I=:taskId ORDER BY LST_UPD_S DESC FETCH FIRST 1 ROWS ONLY WITH UR", nativeQuery = true)
	PreplanLog getPreplanDetailsByOrd(@Param("taskId") Integer taskId);
	
}
