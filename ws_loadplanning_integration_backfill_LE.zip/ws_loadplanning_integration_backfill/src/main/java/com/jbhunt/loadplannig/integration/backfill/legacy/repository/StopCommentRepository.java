package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.StopComment;




@Repository
public interface StopCommentRepository extends JpaRepository<StopComment, Integer> {
	
	
	@Modifying
    @Transactional
    @Query(value = "DELETE FROM ALI.STOP_COMMENT where CRT_PGM_C IN ('OEC143','OEC145') AND ORD_I=:orderId", nativeQuery = true)
    Integer deleteStopComments(@Param("orderId") Integer orderId);
	
	@Query(value = "SELECT ORD_I,DSP_NBR,OFR_STP_SEQ_NBR,CRT_PGM_C,CMM_SEQ_NBR,CMM_TYP,EXT_CMM_TXT,CMM_TXT,CMM,CRT_S,CRT_UID,"
            + "LST_UPD_S,LST_UPD_UID,LST_UPD_PGM_C from ALI.STOP_COMMENT where ORD_I=:orderId WITH UR", nativeQuery = true)
    List<Object[]> findStopDetailsByOrdId(@Param("orderId") Integer orderId);

}
