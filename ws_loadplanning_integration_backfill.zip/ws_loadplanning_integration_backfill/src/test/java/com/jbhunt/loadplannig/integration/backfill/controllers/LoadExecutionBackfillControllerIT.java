package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.relaxedRequestFields;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.document;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.jbhunt.operations.equipmentgroup.dto.EquipmentGroupESDTO;
import com.jbhunt.operations.equipmentgroup.dto.RemoveEquipmentFromGroupBackFillDTO;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc341i.lmc341.LMC341Port;
import com.lmc342i.lmc342.LMC342Port;
import com.lmc360i.lmc360.LMC360Port;
import com.lmc363i.lmc363.LMC363Port;
import com.lmc364i.lmc364.LMC364Port;
import com.request.lmc364i.lmc364.ProgramInterface.Lmc364IInputArea;
import com.response.lmc364i.lmc364.ProgramInterface.Lmc364OOutputArea;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class LoadExecutionBackfillControllerIT {

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http")
			.host("loadplanning-test.jbhunt.com").removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	@MockBean
	private LMC341Port lmc341Port;

	@MockBean
	private LMC342Port lmc342Port;

	@MockBean
	private LMC360Port lmc360Port;

	@MockBean
	private LMC363Port lmc363Port;

	@MockBean
	private LMC364Port lmc364Port;

	@MockBean
	private OrderLoadRepository orderLoadRepository;

	public static final String username = "user";

	public static final String password = "pass";

	public final String EQUIPMENT_ASSIGNMENT_JSON = "/operationalplan.json";

	public static final String TRACTOR_ASSIGN_JSON = "/json/TractorContainerAssign.json";

	public static final String CHASSIS_ASSIGN_JSON = "/json/ChassisContainerAssign.json";
	
	public static final String TRACTOR_UNASSIGN_JSON = "/json/TractorContainerUnassign.json";

	public static final String CHASSIS_UNASSIGN_JSON = "/json/ChassisContainerUnassign.json";

	public static final String DEADHEAD_JSON = "/json/DeadheadCheckCall.json";

	public static final String BOBTAIL_JSON = "/json/BobtailCheckCall.json";

	public static final String NO_EQUIPMENT_BOBTAIL_JSON = "/json/NoEquipmentDetails.json";

	@MockBean
	@Qualifier("sqlServerjdbcTemplate")
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	LocationProfileDTOs locationProfileDTOs;

	@Autowired
	private ObjectMapper objectMapper;

	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	public void testEquipmentAssignment(String jsonName, String masterData) throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream(masterData));
		String responseMasterDataByEqpNumber = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataSearchByEquipNumber.json"));
		String responseMasterDataLocation = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataLocation2.json"));
		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/equipmentsbynumbers"))
				.willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterDataByEqpNumber).withStatus(200)));
		
		wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/62980"))
				.willReturn(aResponse().withHeader("Content-type", "application/json")
						.withBody(responseMasterDataLocation).withStatus(200)));
		EquipmentGroupESDTO equipmentGroupESDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(jsonName)),
				EquipmentGroupESDTO.class);

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

		when(orderLoadRepository.findLoadDetailsByOrderNumber(Mockito.anyString())).thenReturn(tOrder);
		Lmc364OOutputArea lmc364OOutputArea = new Lmc364OOutputArea();
		lmc364OOutputArea.setLmc364OErrorMessage("");
		lmc364OOutputArea.setLmc364OMsgOvrFlg("");
		lmc364OOutputArea.setLmc364OOutputFiller("");
		lmc364OOutputArea.setLmc364OReturnFlag("");

		when(lmc364Port.lmc364Operation(Mockito.any(Lmc364IInputArea.class))).thenReturn(lmc364OOutputArea);

		Response response = given(this.requestSpecification).auth().basic(username, password)
				.filter(document("ProcessEquipmentAssignmentForChassis", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processAssignmentRequest())))
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(equipmentGroupESDTO)
				.post("/ws_loadplanning_integration_backfill/backfill/equipmentgroup");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}
	
	@Test
	public void testEquipmentAssignmentForTrailer() throws Exception {
		testEquipmentAssignment("/json/TractorTrailerAssign.json","/json/MasterDataAssetForTrailer.json");
	}
	
	@Test
	public void testEquipmentAssignmentForChassisContainer() throws Exception {
		testEquipmentAssignment(CHASSIS_ASSIGN_JSON,"/json/MasterDataAssetForChassisContainer.json");
	}
	
	@Test
	public void testEquipmentAssignmentForChassis() throws Exception {
		testEquipmentAssignment("/json/TruckChassisAssign.json","/json/MasterDataAssetForChassis.json");
	}
	
	@Test
	public void testEquipmentAssignmentForContainer() throws Exception {
		testEquipmentAssignment("/json/TruckContainerAssign.json","/json/MasterDataAssetForContainer.json");
	}
	
	
	
	public void testEquipmentUnAssignment(String jsonResourceName) throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream(jsonResourceName));
		
		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.willReturn(aResponse().withHeader("Content-Type", "application/json")
						.withBody(responseMasterData).withStatus(200)));
		
		RemoveEquipmentFromGroupBackFillDTO removeEquipmentFromGroupBackFillDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(CHASSIS_UNASSIGN_JSON)),
				RemoveEquipmentFromGroupBackFillDTO.class);
		String responseMasterDataLocation = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataLocation2.json"));
		wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/24"))
				.willReturn(aResponse().withHeader("Content-type", "application/json")
						.withBody(responseMasterDataLocation).withStatus(200)));

		Lmc364OOutputArea lmc364OOutputArea = new Lmc364OOutputArea();
		lmc364OOutputArea.setLmc364OErrorMessage("");
		lmc364OOutputArea.setLmc364OMsgOvrFlg("");
		lmc364OOutputArea.setLmc364OOutputFiller("");
		lmc364OOutputArea.setLmc364OReturnFlag("");

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RA97939");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

		when(orderLoadRepository.findLoadDetailsByOrderNumber(Mockito.anyString())).thenReturn(tOrder);

		when(lmc364Port.lmc364Operation(Mockito.any(Lmc364IInputArea.class))).thenReturn(lmc364OOutputArea);

		Response response = given(this.requestSpecification).auth().basic(username, password)
				.filter(document("ProcessEquipmentUnassignmentForChassis", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processUnassignmentRequest())))
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(removeEquipmentFromGroupBackFillDTO)
				.patch("/ws_loadplanning_integration_backfill/backfill/equipmentgroup");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

	@Test
	public void testEquipmentUnAssignmentForTrailer() throws Exception {
		testEquipmentUnAssignment("/json/MasterDataAssetListForChassis.json");
	}
	
	@Test
	public void testEquipmentUnAssignmentForContainer() throws Exception {
		testEquipmentUnAssignment("/json/MasterDataForTruckContainer.json");
	}
	
	@Test
	public void testEquipmentUnAssignmentForChassisContainer() throws Exception {
		testEquipmentUnAssignment("/json/MasterDataForChassisContainer.json");
	}
	
	@Test
	public void testEquipmentUnAssignmentForChassis() throws Exception {
		testEquipmentUnAssignment("/json/MasterDataForTruckChassis.json");
	}

	@Test
	public void testTruckAssignment() throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAssetForAssign.json"));
		String responseMasterDataByEqpNumber = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataSearchByEquipNumber2.json"));
		String responseMasterDataLocation = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataLocation2.json"));
		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/equipmentsbynumbers"))
				.willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterDataByEqpNumber).withStatus(200)));

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

		when(orderLoadRepository.findLoadDetailsByOrderNumber(Mockito.anyString())).thenReturn(tOrder);
		
		wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/62980"))
				.willReturn(aResponse().withHeader("Content-type", "application/json")
						.withBody(responseMasterDataLocation).withStatus(200)));
		
		Lmc364OOutputArea lmc364OOutputArea = new Lmc364OOutputArea();
		lmc364OOutputArea.setLmc364OErrorMessage("");
		lmc364OOutputArea.setLmc364OMsgOvrFlg("");
		lmc364OOutputArea.setLmc364OOutputFiller("");
		lmc364OOutputArea.setLmc364OReturnFlag("");

		when(lmc364Port.lmc364Operation(Mockito.any(Lmc364IInputArea.class))).thenReturn(lmc364OOutputArea);

		EquipmentGroupESDTO equipmentGroupESDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(TRACTOR_ASSIGN_JSON)),
				EquipmentGroupESDTO.class);
		Response response = given(this.requestSpecification).auth().basic(username, password)
				.filter(document("ProcessEquipmentAssignment", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processAssignmentRequest())))
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(equipmentGroupESDTO)
				.post("/ws_loadplanning_integration_backfill/backfill/equipmentgroup");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

	@Test
	public void testTruckUnAssignment() throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

		when(orderLoadRepository.findLoadDetailsByOrderNumber(Mockito.anyString())).thenReturn(tOrder);

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAssetListForTrailer.json"));
		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.willReturn(aResponse().withHeader("Content-Type", "application/json")
						.withBody(responseMasterData).withStatus(200)));
		RemoveEquipmentFromGroupBackFillDTO removeEquipmentFromGroupBackFillDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(TRACTOR_UNASSIGN_JSON)),
				RemoveEquipmentFromGroupBackFillDTO.class);
		Response response = given(this.requestSpecification).auth().basic(username, password)
				.filter(document("ProcessEquipmentUnassignment", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processUnassignmentRequest())))
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(removeEquipmentFromGroupBackFillDTO)
				.patch("/ws_loadplanning_integration_backfill/backfill/equipmentgroup");
		Assert.assertEquals(response.statusCode(), response.statusCode());
	}

	private static FieldDescriptor[] processAssignmentRequest() {
		return new FieldDescriptor[] {
				fieldWithPath("truckEquipmentId").description("Truck equipment Id to be paired with other equipment").type(String.class),
				fieldWithPath("loadId").description("Load id which will be null always").optional().type(String.class),
				fieldWithPath("userId").description("User id who trigerred the equipment assignment").type(String.class),
				
				fieldWithPath("addEquipmentGroupESDTO[].equipmentId").description("Id of equipment to be paired. It may be truck/trailer/container/chassis").type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].equipmentNumber").description("equipment number of the unit to be paired").type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].equipmentClassificationCode").description("equipment classification code which represents major class of equipment type").type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].equipmentClassificationDescription").description("equipment classification description").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].equipmentTypeCode").description("equipment type code which represents sub class of equipment type").type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].equipmentTypeDescription").description("equipment type description").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].lengthSpecificationCode").description("length specification code of equipment").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].widthSpecificationCode").description("width specification code of equipment").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].heightSpecificationCode").description("height specification code of equipment").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].equipmentStatus").description("equipment status").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].locationId").description("location id").type(Integer.class),
				fieldWithPath("addEquipmentGroupESDTO[].locationCode").description("location code").type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].marketingAreaCode").description("marketing area code").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].equipmentMissing").description("equipment missing status").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].equipmentMaintenanceStatus").description("equipment maintenance status").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].businessUnit").description("business unit of the equipment").type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].operationalGroupCode").description("operational group code").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].operationalGroupCodeType").description("operational group code type").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].sequenceNumber").description("sequence number").optional().type(Integer.class),
				fieldWithPath("addEquipmentGroupESDTO[].stack").description("stack").optional().type(String.class),
				fieldWithPath("addEquipmentGroupESDTO[].userId").description("user id who trigerred the equipment assignment").optional().type(String.class)};
	}

	private static FieldDescriptor[] processUnassignmentRequest() {
		return new FieldDescriptor[] {
			fieldWithPath("truckId").description("Truck equipment Id to be unassigned with other equipment").type(String.class),
			fieldWithPath("removeEquipmentRequestDTO.equipmentAssociationGroupId").description("equipment association group id").optional().type(String.class),
			fieldWithPath("removeEquipmentRequestDTO.locationId").description("User id who trigerred the equipment assignment").type(String.class),
			fieldWithPath("removeEquipmentRequestDTO.cityId").description("city id where the equipment is unassigned").type(String.class),
			fieldWithPath("removeEquipmentRequestDTO.comments").description("Comment given the by user for unassignment").optional().type(String.class),
			
			fieldWithPath("removeEquipmentRequestDTO.equipmentDetailsDtos[].equipmentId").description("Id of equipment to be unpaired. It may be trailer/container/chassis").type(String.class),
			fieldWithPath("removeEquipmentRequestDTO.equipmentDetailsDtos[].stack").description("tells whether the equipment is stacked").optional().type(String.class),
			fieldWithPath("removeEquipmentRequestDTO.equipmentDetailsDtos[].isRemoved").description("tells whether the equipment is removed").optional().type(String.class),
			fieldWithPath("removeEquipmentRequestDTO.equipmentDetailsDtos[].sequenceNumber").description("sequence number of the equipment").optional().type(String.class),
		};
	}
}
