package com.jbhunt.loadplannig.integration.backfill.dto;

import java.util.List;

import lombok.Data;

@Data
public class LoadCreationResponseDTO {

    private List<BkfilOrdLdAscDTO> bkfilOrdLdAscList;
    
    
    
}
