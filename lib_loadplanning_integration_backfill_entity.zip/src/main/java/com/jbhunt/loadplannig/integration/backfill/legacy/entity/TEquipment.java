package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TEQUIPMENT", schema = "ALI")
public class TEquipment implements Serializable {

	private static final long serialVersionUID = -5841092789924439177L;

	@Id
	@Column(name = "EQP_ID")
	private Integer equipmentId;
	
	@Column(name = "EQP_UNIT_ID")
	private String trailerNumber;

	@Column(name = "EQP_TY_ID")
	private String equipmentTypeID;

	@Column(name = "EQP_UNIT_PREFIX_ID")
	private String trailerPrefix;

	@Column(name = "REC_STT_F")
	private String recordStatus;

	@Column(name = "MJR_CLS_C")
	private String equipmentTypeHierarchyCode;

	@Column(name = "CUR_PLX_I")
	private String pluxID;

	@Column(name = "UNT_STT_C")
	private String availabilityStatus;

	@Column(name = "LD_STT")
	private String loadingStatus;

	@Column(name = "YARD_STT_F")
	private String yardStatusFlag;

	@Column(name="LST_LCTN_C")
	private String lastLocation;

	@Column(name="DIV_ID")
	private String divId;

	@Column(name="CUR_PLX_TYP_C")
	private String pluxType;

	@Column(name="SUB_CLS_C")
	private String subClass;

	@Column(name="LST_DSP_NBR")
	private String lastDispositionNumber;

	@Column(name="LST_ORD_NBR_CH")
	private String lastDispatchOrderNumber;

	@Column(name="CURR_ETA_D")
	private String currentEstimateTimeArrivelDate;

	@Column(name="CURR_ETA_H")
	private String  currentEstimateTimeArrivelHour;
	
	@Column(name="LST_UPDT_TMSTP_S")
	private String  lastUpdatedTimestamp;
	
	@Column(name="LST_CSTMR")
	private String  lastCustomerCode;
	
}

