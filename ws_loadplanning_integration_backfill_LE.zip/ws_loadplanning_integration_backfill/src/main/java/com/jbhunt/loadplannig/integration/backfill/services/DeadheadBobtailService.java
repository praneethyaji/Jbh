package com.jbhunt.loadplannig.integration.backfill.services;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.ws.Holder;

import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHValidationException;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.dto.SpotDBCallDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.BackfillTrackingHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.CheckCallHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.SendPlanHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanCommentDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanResourceAssignmentAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.lmc363i.lmc363.LMC363Port;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord;
import com.response.lmc363i.lmc363.ProgramInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class DeadheadBobtailService extends CheckCallBackfillService {

	private final MasterdataAssetClient masterdataAssetClient;
	private final LMC363Port lmc363Port;
	private final CheckCallHelper checkCallHelper;
	private final SendPlanHelper sendPlanHelper;
	private final EquipmentRepository equipmentRepository;
	private final BackfillTrackingHelper backfillTrackingHelper;
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;

	public void deadHeadBobTail(OperationalPlanDTO operationalPlanDTO, String subEvent)
			throws JBHuntRuntimeException, URISyntaxException {
		try {
			backfillTrackingHelper.saveBackTrackingDetails(operationalPlanDTO, subEvent);
			deadHeadBobTailCall(operationalPlanDTO, subEvent);
		} catch (Exception e) {
			log.error("Exception in preplan:", e);
			backfillTrackingHelper.updateException(operationalPlanDTO, e);
			throw e;
		}
	}

	private void deadHeadBobTailCall(OperationalPlanDTO operationalPlanDTO, String subEvent)
			throws JBHuntRuntimeException, URISyntaxException {
		log.info("Deadhead/BobTail check call service");
		CheckcallDTO checkcallDTO = new CheckcallDTO();
		List<OperationalPlanResourceAssignmentAssociationDTO> operationalPlanResourceAssignmentAssociationList = operationalPlanDTO
				.getOperationalPlanResourceAssignmentAssociationList();

		OperationalPlanResourceAssignmentAssociationDTO resourceAssignmentAssociation = Collections
				.max(operationalPlanResourceAssignmentAssociationList, Comparator.comparing(
						OperationalPlanResourceAssignmentAssociationDTO::getOperationalPlanResourceAssignmentAssociationId));
		ResourceAssignmentPlanDTO resourceAssignmentPlan = resourceAssignmentAssociation.getResourceAssignmentPlan();

		EquipmentDetailsDTO equipmentDetailsDTO = null;
		if (Optional.ofNullable(resourceAssignmentPlan.getEquipmentAssignments()).isPresent()) {
			equipmentDetailsDTO = Optional
					.ofNullable(masterdataAssetClient.getEquipmentDetails(
							Arrays.asList(resourceAssignmentPlan.getEquipmentAssignments().getEquipmentId())))
					.orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND)).stream()
					.findFirst().orElseThrow(() -> new JBHuntRuntimeException(CommonConstants.EQUIPNMENT_NOT_FOUND));
		} else {
			throw new JBHValidationException(CommonConstants.NO_EQUIPMENT_DETAILS);
		}

		checkcallDTO.setDataState(CommonConstants.DATA_STATE_B);
		checkcallDTO.setUserId(operationalPlanDTO.getLastUpdateUserId());

		checkcallDTO.setJobId(0);
		checkcallDTO.setCreateUserId(operationalPlanDTO.getCreateUserId());
		checkcallDTO.setEqpId(equipmentDetailsDTO.getLegacyEquipmentId());
		checkcallDTO.setTractorNbr(equipmentDetailsDTO.getEquipmentNumber());
		checkcallDTO.setTractorRqdFlg(CommonConstants.TRACTOR_RQD_FLAG);

		checkcallDTO
				.setCarrierFlg(operationalPlanDTO.getOperationalPlanFinanceBusinessUnitCode().equalsIgnoreCase("JBI")
						? CommonConstants.MF_DEFAULT_VAL_STRING
						: CommonConstants.STRING_I);
		final String callType;
		if (subEvent.equalsIgnoreCase(CommonConstants.CHECK_CALL_DEADHEAD)) {
			TEquipment tEquipment = equipmentRepository.getTrailerDetails(equipmentDetailsDTO.getEquipmentNumber());
			log.info("Deadhead check call service");
			callType = CommonConstants.DEADHEAD;
			checkcallDTO.setCallType(CommonConstants.CHECK_CALL_DEADHEAD);
			if (tEquipment != null) {
				checkcallDTO.setOrderNumber(tEquipment.getLastDispatchOrderNumber().trim());
				checkcallDTO.setTrailerContainerPrefix(tEquipment.getTrailerPrefix());
				checkcallDTO.setTrailerContainerNumber(tEquipment.getTrailerNumber());
			}
		} else {
			log.info("BobTail check call service");
			TEquipment tEquipment = equipmentRepository
					.fetchEqpDetailsByEqpId(Integer.toString(equipmentDetailsDTO.getLegacyEquipmentId()));
			callType = CommonConstants.BOBTAIL;
			checkcallDTO.setCallType(CommonConstants.CHECK_CALL_BOBTAIL);
			checkcallDTO.setOrderNumber(tEquipment != null ? tEquipment.getLastDispatchOrderNumber().trim()
					: CommonConstants.MF_DEFAULT_VAL_STRING);
		}
		
		String locationCityState = equipmentRepository.getLastLocationOfTruck(equipmentDetailsDTO.getLegacyEquipmentId());
		checkcallDTO.setLocationCityState(locationCityState!=null?locationCityState:"");
		checkcallDTO.setNextStopSeqNbr(0);
		
		operationalPlanDTO.getOperationalPlanStops().forEach(operationalPlanStop -> {

			City city = Optional.ofNullable(sendPlanHelper.getCityStateCodeByCityID(operationalPlanStop.getCityId()))
					.orElse(null);
			checkcallDTO.getRouteDetails().put(city.getCityID(),
					operationalPlanStop.getStopReasonCode().equalsIgnoreCase(callType) ? "E" : "L");
			log.info("City Id {} MF value {} Code {}", operationalPlanStop.getCityId(), city.getCityID());

		});

		String commentText = CommonConstants.MF_DEFAULT_VAL_STRING;
		if (operationalPlanDTO.getOperationalPlanComments().stream().findFirst().isPresent()) {
			Optional<OperationalPlanCommentDTO> operationalPlanCommentDTO = operationalPlanDTO
					.getOperationalPlanComments().stream().findFirst();
			if (operationalPlanCommentDTO.isPresent()) {
				commentText = operationalPlanCommentDTO.get().getCommentText();
			}
		}
		checkcallDTO.setComment(String.format(CommonConstants.FREE_COMMENTS, commentText));
		SpotDBCallDTO spotDBCall = new SpotDBCallDTO();
		spotDBCall.setPayDHFlag(CommonConstants.STRING_Y);
		spotDBCall.setWarningFlag(CommonConstants.STRING_Y);
		spotDBCall.setDropTrailerFlag(CommonConstants.STRING_N);
		checkcallDTO.setSpotCallDTO(spotDBCall);

		Map<String, String> spotDBcallMap = checkCallHelper.populateSDBElements(checkcallDTO);
		String checkCallVars = getCheckCallVarsValues(spotDBcallMap, checkCallHelper.getCheckcallSDBElements());
		checkcallDTO.setCheckCallVars(checkCallVars);
		CheckCallService(checkcallDTO);
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
	}

	private void CheckCallService(CheckcallDTO checkcallDTO) {
		log.info(" values to be passed :{}", checkcallDTO);
		Lm36ComCommareaRecord lm36ComCommareaRecord = checkCallHelper.createLm36ComCommareaRecord(checkcallDTO);
		com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava lm36ComReturnToJava = checkCallHelper
				.getLm36ComReturnToJava(checkcallDTO);
		log.info("Calling LMC363 Service..");
		javax.xml.ws.Holder<ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder = new Holder<>();
		javax.xml.ws.Holder<String> lm36ComFillerOutputHolder = new Holder<>();
		javax.xml.ws.Holder<ProgramInterface.Lm36ComCommareaOutputRecord> lm36ComCommareaOutputRecordHolder = new Holder<>();
		String lm36ComFiller = "";

		lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava, lm36ComFiller,
				lm36ComCommareaOutputRecordHolder, lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);

		checkCallHelper.loggingCheckcallResponse(lm36ComReturnToJavaOutputHolder);
		log.info("result of the freeCall operation from the mainframe: {} ", lm36ComFillerOutputHolder.value);

	}

}
