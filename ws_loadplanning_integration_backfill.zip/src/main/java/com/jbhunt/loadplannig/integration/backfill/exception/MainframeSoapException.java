package com.jbhunt.loadplannig.integration.backfill.exception;

import lombok.Getter;

public class MainframeSoapException extends RuntimeException {

    @Getter
    private String errorCode;
    @Getter
    private String message;

    public MainframeSoapException(String errorCode, String message){
        super(message);
        this.errorCode = errorCode;
        this.message = message;
    }

    public MainframeSoapException(String errorCode, String message, Throwable  throwable){
        super(message, throwable);
        this.errorCode = errorCode;
        this.message = message;
    }
}
