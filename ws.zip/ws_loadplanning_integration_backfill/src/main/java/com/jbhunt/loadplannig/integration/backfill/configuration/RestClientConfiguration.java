package com.jbhunt.loadplannig.integration.backfill.configuration;

import com.jbhunt.biz.securepid.PIDCredentials;
import feign.RequestInterceptor;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.charset.Charset;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
@Configuration
public class RestClientConfiguration {
    @Value("${emailTemplateService.token}")
    private String token;
    @Bean
    public RequestInterceptor basicAuthRequestInterceptor(PIDCredentials pidCredentials) {

        return requestTemplate -> {
            if (requestTemplate.url().contains("/templates/")) {
                Map<String, Collection<String>> header = new HashMap<>();
                header.put("Authorization", Collections.singletonList("Bearer " + token));
                header.put("Content-Type", Collections.singletonList("application/json"));
                requestTemplate.headers(header);
            } else {
                String auth = pidCredentials.getUsername() + ":" + pidCredentials.getPassword();
                byte[] encodeAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
                String authHeader = "Basic " + new String(encodeAuth);
                Map<String, Collection<String>> header = new HashMap<>();
                header.put("Authorization", Collections.singletonList(authHeader));
                requestTemplate.headers(header);
            }
        };
    }
}
