package com.jbhunt.loadplannig.integration.backfill.utils;

import org.springframework.stereotype.Service;

import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOrdBuffer2;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOrdBuffer2.Oee5InOrdDstRmpAdrLn02;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOrdBuffer2.Oee5InOrdEqpUntC;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOrdBuffer2.Oee5InOrgRmpAdrLn02;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData;

@Service
public class OEC145MapperUtil {

    public Oee5InOrdBuffer2 mapOrderBuffer2(Oe76OutputChannelData orderDetails) {
        Oee5InOrdBuffer2 orderBuffer = new Oee5InOrdBuffer2();

        orderBuffer.setFiller1(orderDetails.getOe76OutOrdBuffer9().getFiller1());
        orderBuffer.setOee5InOrdActDrpD(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdActDrpD());
        orderBuffer.setOee5InOrdActDrpDow(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdActDrpDow());
        orderBuffer.setOee5InOrdActDrpH(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdActDrpH());
        orderBuffer.setOee5InOrdAgrLnI(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdAgrLnI());
        orderBuffer.setOee5InOrdAlwAtrF("N");
        orderBuffer.setOee5InOrdBdrXngVal(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdBdrXngVal());
        orderBuffer.setOee5InOrdBillStatus(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdBillStatus());
        orderBuffer.setOee5InOrdCpyTrlF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdCpyTrlF());
        orderBuffer.setOee5InOrdCrtPgmC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdCrtPgmC());
        orderBuffer.setOee5InOrdCrtS(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdCrtS());
        orderBuffer.setOee5InOrdCrtUid(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdCrtUid());
        orderBuffer.setOee5InOrdCurOrdSttC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdCurOrdSttC());
        orderBuffer.setOee5InOrdDesirableFrtF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDesirableFrtF());
        orderBuffer.setOee5InOrdDivC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDivC());
        orderBuffer.setOee5InOrdDrpTrlFaxF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDrpTrlFaxF());
        orderBuffer.setOee5InOrdDrpTrlFaxUid(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDrpTrlFaxUid());

       String orderDspStt = orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDspStt();
        /*if(BackfillConstants.ORD_STATUS_CANCELLED.equalsIgnoreCase(orderUpdateEvent.getOrderDTO().getOrderStatusCode())) {
            orderDspStt = "C";
        }*/
        orderBuffer.setOee5InOrdDspStt(orderDspStt);

        orderBuffer.setOee5InOrdDstAr(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDstAr());
        orderBuffer.setOee5InOrdDstGeoC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDstGeoC());
        orderBuffer.setOee5InOrdDstRmp(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDstRmp());
        orderBuffer.setOee5InOrdDstRmpAdrLn01(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDstRmpAdrLn01());
        Oee5InOrdDstRmpAdrLn02 oee5InOrdDstRmpAdrLn02 = new Oee5InOrdDstRmpAdrLn02();
        oee5InOrdDstRmpAdrLn02.setOee5InOrdDstRmpCtyNm(
                orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDstRmpAdrLn02().getOe76OutOrdDstRmpCtyNm());
        oee5InOrdDstRmpAdrLn02.setOee5InOrdDstRmpStC(
                orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDstRmpAdrLn02().getOe76OutOrdDstRmpStC());
        orderBuffer.setOee5InOrdDstRmpAdrLn02(oee5InOrdDstRmpAdrLn02);
        orderBuffer.setOee5InOrdDstRmpC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDstRmpC());
        orderBuffer.setOee5InOrdDstRmpName(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDstRmpName());
        orderBuffer.setOee5InOrdEltEqpDesc(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEltEqpDesc());
        orderBuffer.setOee5InOrdEqpLenC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEqpLenC());
        orderBuffer.setOee5InOrdEqpLenRqdF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEqpLenRqdF());
        orderBuffer.setOee5InOrdEqpSubClsC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEqpSubClsC());
        orderBuffer.setOee5InOrdEqpSubClsRqdF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEqpSubClsRqdF());
        orderBuffer.setOee5InOrdEqpTypC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEqpTypC());
        orderBuffer.setOee5InOrdEqpTypRqdF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEqpTypRqdF());
        Oee5InOrdEqpUntC orderEquip = new Oee5InOrdEqpUntC();
        orderEquip
                .setOee5InOrdFiller1(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEqpUntC().getOe76OutOrdFiller1());
        orderEquip
                .setOee5InOrdFiller2(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEqpUntC().getOe76OutOrdFiller2());
        orderBuffer.setOee5InOrdEqpUntC(orderEquip);
        orderBuffer.setOee5InOrdEqpUntPfx(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdEqpUntPfx());
        orderBuffer.setOee5InOrdFltC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdFltC());
        orderBuffer.setOee5InOrdFrsJobSegUtlC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdFrsJobSegUtlC());
        orderBuffer.setOee5InOrdImdTrtMdC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdImdTrtMdC());
        orderBuffer.setOee5InOrdInternetPostF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdInternetPostF());
        orderBuffer.setOee5InOrdJbhordrS(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdJbhordrS());
        orderBuffer.setOee5InOrdLstJobSegUtlC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdLstJobSegUtlC());
        orderBuffer.setOee5InOrdLstUpdS(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdLstUpdS());
        orderBuffer.setOee5InOrdLtlF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdLtlF());
        orderBuffer.setOee5InOrdMd(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdMd());
        orderBuffer.setOee5InOrdMsg(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdMsg());
        orderBuffer.setOee5InOrdMsgLstUpdS(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdMsgLstUpdS());
        orderBuffer.setOee5InOrdNbrLdsToBeRes(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdNbrLdsToBeRes());
        orderBuffer.setOee5InOrdNbrOfDsp(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdNbrOfDsp());
        orderBuffer.setOee5InOrdNbrOfLds(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdNbrOfLds());
        orderBuffer.setOee5InOrdOfrSrcC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOfrSrcC());
        orderBuffer.setOee5InOrdOfrTypC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOfrTypC());
        orderBuffer.setOee5InOrdOrdI(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOrdI());
        orderBuffer.setOee5InOrdOrdNbrCh(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOrdNbrCh());
        orderBuffer.setOee5InOrdOrdTkrIni(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOrdTkrIni());
        orderBuffer.setOee5InOrdOrdTkrPhn(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOrdTkrPhn());
        orderBuffer.setOee5InOrdOrgAr(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOrgAr());
        orderBuffer.setOee5InOrdOrgGeoC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOrgGeoC());
        orderBuffer.setOee5InOrdOrgMd(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOrgMd());
        orderBuffer.setOee5InOrdOrgRmp(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOrgRmp());
        orderBuffer.setOee5InOrdOrgRmpName(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOrgRmpName());
        orderBuffer.setOee5InOrdOtherOrdI(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdOtherOrdI());
        orderBuffer.setOee5InOrdPlnAvlD(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnAvlD());
        orderBuffer.setOee5InOrdPlnAvlDow(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnAvlDow());
        orderBuffer.setOee5InOrdPlnAvlH(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnAvlH());
        orderBuffer.setOee5InOrdPlnDrpD(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnDrpD());
        orderBuffer.setOee5InOrdPlnDrpDow(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnDrpDow());
        orderBuffer.setOee5InOrdPlnDrpH(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnDrpH());
        orderBuffer.setOee5InOrdPrjC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPrjC());
        orderBuffer.setOee5InOrdPrlTrlF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPrlTrlF());
        orderBuffer.setOee5InOrdProtectFldsFlg(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdProtectFldsFlg());
        orderBuffer.setOee5InOrdPsuDstRamp(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdDstRmpC());
        orderBuffer.setOee5InOrdPsuDstRampDate(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnAvlD());
        orderBuffer.setOee5InOrdPsuDstRampH(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnAvlH());
        orderBuffer.setOee5InOrdPsuOrgRamp(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrgRmpC());
        orderBuffer.setOee5InOrdPsuOrgRampDate(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnDrpD());
        orderBuffer.setOee5InOrdPsuOrgRampH(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdPlnDrpH());
        
        orderBuffer.setOee5InOrdRefNbrLstUpdS(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdRefNbrLstUpdS());
        orderBuffer.setOee5InOrdRmpOvrAlwF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdRmpOvrAlwF());
        orderBuffer.setOee5InOrdSchFrtLnI(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdSchFrtLnI());
        orderBuffer.setOee5InOrdSdiIdx(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdSdiIdx());
        orderBuffer.setOee5InOrdShipId(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdShipId());
        orderBuffer.setOee5InOrdShpLstUpdS(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdShpLstUpdS());
        orderBuffer.setOee5InOrdSubstituteSrvF(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdSubstituteSrvF());
        orderBuffer.setOee5InOrdSvcLvl(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdSvcLvl());
        orderBuffer.setOee5InOrdUnderTrainDsp(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdUnderTrainDsp());
        orderBuffer.setOee5InOrdUtlSttC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdUtlSttC());
        orderBuffer.setOee5InOrgRmpAdrLn01(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrgRmpAdrLn01());
        Oee5InOrgRmpAdrLn02 oee5InOrgRmpAdrLn02 = new Oee5InOrgRmpAdrLn02();
        oee5InOrgRmpAdrLn02.setOee5InOrgRmpCtyNm(
                orderDetails.getOe76OutOrdBuffer9().getOe76OutOrgRmpAdrLn02().getOe76OutOrgRmpCtyNm());
        oee5InOrgRmpAdrLn02.setOee5InOrgRmpStC(
                orderDetails.getOe76OutOrdBuffer9().getOe76OutOrgRmpAdrLn02().getOe76OutOrgRmpStC());
        orderBuffer.setOee5InOrgRmpAdrLn02(oee5InOrgRmpAdrLn02);
        orderBuffer.setOee5InOrgRmpC(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrgRmpC());

        return orderBuffer;
    }

}
