package com.jbhunt.loadplannig.integration.backfill.controllers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersBuffer;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersLinkBuffers;
import com.jbhunt.biz.refNumber.vo.AddNewReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.DeletedReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.LineItemVO;
import com.jbhunt.biz.refNumber.vo.ReferenceNumberDetailsVO;
import com.jbhunt.biz.refNumber.vo.UpdatedReferenceNumberVO;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import com.jbhunt.loadplannig.integration.backfill.utils.ItemReferenceNumberHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.ReferenceNumberBuilder;
import com.jbhunt.loadplannig.integration.backfill.utils.ReferenceNumberUpdateServiceHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.ReferenceUpdateHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.ReferenceUpdateServiceHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanReferenceNumberDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopHandlingUnitAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopItemDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopItemHandlingUnitDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopItemHandlingUnitReferenceNumberAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ReferenceNumberLevelTypeDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InLoadSyncData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InStpLine;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InputBuffer1;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class LoadEditbackfillServiceIT {

	public static WireMockServer wireMockServer;

	@Autowired
	private ReferenceUpdateServiceHelper referenceUpdateServiceHelper;

	@Autowired
	private ReferenceUpdateHelper referenceUpdateHelper;

	@Autowired
	private ReferenceNumberBuilder referenceNumberBuilder;

	@Autowired
	private ItemReferenceNumberHelper itemReferenceNumberHelper;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private ReferenceNumberUpdateServiceHelper referenceNumberUpdateServiceHelper;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	public static final String userName = "user";

	public static final String password = "pass";

	protected RequestSpecification requestSpecification;

	@BeforeClass
	public static void beforeClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test(expected = JBHuntRuntimeException.class)
	public void linkOEC070InSelectMode() throws Exception {
		referenceUpdateServiceHelper.linkOEC070InSelectMode(123, "RBC123", "BACKFILL", "RBC123", "PASSWORD");
	}

	@Test(expected = JBHuntRuntimeException.class)
	public void linkOEC070InUpdateMode() throws Exception {

		ReferenceNumbersBuffer referenceNumbersBuffer = new ReferenceNumbersBuffer();
		referenceNumbersBuffer.setAddressID(1, 0);
		referenceNumbersBuffer.setCustomerCode("A", 0);
		referenceNumbersBuffer.setDepartment("JBI", 0);
		referenceNumbersBuffer.setLevel("ORDER", 0);
		referenceNumbersBuffer.setLineItemActCls(1, 0);
		referenceNumbersBuffer.setLineItemCarrCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemHandlingQuantity(1, 1);
		referenceNumbersBuffer.setLineItemHandlingUnit("A", 0);
		referenceNumbersBuffer.setLineItemHazF("N", 0);
		referenceNumbersBuffer.setLineItemHeight(1, 0);
		referenceNumbersBuffer.setLineItemLength(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemNumber(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemSubC((short) 1, 0);
		referenceNumbersBuffer.setLineItemQtyTyp("A", 0);
		referenceNumbersBuffer.setLineItemRateCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemStackF("A", 0);
		referenceNumbersBuffer.setLineItemWidth(1, 0);
		referenceNumbersBuffer.setNumber("1", 0);
		referenceNumbersBuffer.setParentReferenceNumberI(1, 0);
		referenceNumbersBuffer.setProductDescr("NOTHING", 0);
		referenceNumbersBuffer.setQuantity((short) 1, 0);
		referenceNumbersBuffer.setReferenceNumberI(1, 0);
		referenceNumbersBuffer.setSequence(1, 0);
		referenceNumbersBuffer.setSiteID(1, 0);
		referenceNumbersBuffer.setStopLineItemI(1, 0);
		referenceNumbersBuffer.setType("REF", 0);
		referenceNumbersBuffer.setVolume(1, 0);
		referenceNumbersBuffer.setWeight((double) 1, 0);
		referenceNumbersBuffer.setOldAddressID(2, 0);
		referenceNumbersBuffer.setOldCustomerCode("B", 0);
		referenceNumbersBuffer.setOldDepartment("HJBT JBI", 0);
		referenceNumbersBuffer.setOldSequence(1, 0);
		referenceNumbersBuffer.setOldNumber("1", 0);
		referenceNumbersBuffer.setOldSiteID(1, 0);
		referenceNumbersBuffer.setOldType("REF", 0);
		ReferenceNumbersLinkBuffers oec070Buffers = new ReferenceNumbersLinkBuffers();

		oec070Buffers.setNbrOfRefNbrs(1);
		List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
		OrderLoadSync orderLoadSyncDTO = new OrderLoadSync();
		orderLoadSyncDTO.setLegacyOrderID(12324564);
		referenceUpdateServiceHelper.linkOEC070InUpdateMode(oec070Buffers, updRefNbrList, null, null, orderLoadSyncDTO,
				"PIDORDM::ndhdjfn", "LINEITEM", "");
	}

	@Test
	public void populateRefNbrforOthrs() {
		List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
		List<AddNewReferenceNumberVO> newRefNbrList = new ArrayList<>();
		List<DeletedReferenceNumberVO> delRefNbrList = new ArrayList<>();

		UpdatedReferenceNumberVO updatedReferenceNumberVO = new UpdatedReferenceNumberVO();
		AddNewReferenceNumberVO addNewReferenceNumberVO = new AddNewReferenceNumberVO();
		DeletedReferenceNumberVO deletedReferenceNumberVO = new DeletedReferenceNumberVO();
		ReferenceNumbersBuffer referenceNumbersBuffer = new ReferenceNumbersBuffer();

		LineItemVO lineItemVO = new LineItemVO();
		lineItemVO.setStopLineItemI(1);
		lineItemVO.setHazF("N");
		lineItemVO.setActCls(1);
		lineItemVO.setRateCls(1);
		lineItemVO.setCarrCls(1);
		lineItemVO.setLength(1);
		lineItemVO.setWidth(1);
		lineItemVO.setHeight(1);
		lineItemVO.setQtyTyp("NOTHING");
		lineItemVO.setNmfcItemNumber(1);
		lineItemVO.setNmfcItemSubC((short) 1);
		lineItemVO.setHandlingUnit("REF");
		lineItemVO.setHandlingQuantity(1);

		updatedReferenceNumberVO.setAddressID(1);
		updatedReferenceNumberVO.setCustomerCode("A");
		updatedReferenceNumberVO.setDepartment("JBI");
		updatedReferenceNumberVO.setErrorMessage("");
		updatedReferenceNumberVO.setLastUpdated("2017/05/05");
		updatedReferenceNumberVO.setLevel("ORDER");
		updatedReferenceNumberVO.setLineItemVO(lineItemVO);
		updatedReferenceNumberVO.setOldAddressID(2);
		updatedReferenceNumberVO.setOldCustomerCode("B");
		updatedReferenceNumberVO.setOldDepartment("HJBT JBI");
		updatedReferenceNumberVO.setOldReferenceNumber("2");
		updatedReferenceNumberVO.setOldReferenceNumberType("REF");
		updatedReferenceNumberVO.setOldSequence(1);
		updatedReferenceNumberVO.setOldSiteID(1);
		updatedReferenceNumberVO.setParentReferenceNumberI(3);
		updatedReferenceNumberVO.setPieceCount(1);
		updatedReferenceNumberVO.setProductDescr("NOTHING");
		updatedReferenceNumberVO.setQuantity(1);
		updatedReferenceNumberVO.setReferenceNumber("1");
		updatedReferenceNumberVO.setReferenceNumberI(1);
		updatedReferenceNumberVO.setReferenceNumberType("REF");
		updatedReferenceNumberVO.setSchemaMask("S");
		updatedReferenceNumberVO.setOldReferenceNumberI(1);
		updatedReferenceNumberVO.setSequence(1);
		updatedReferenceNumberVO.setSiteID(1);
		updatedReferenceNumberVO.setValidWithSchema(true);
		updatedReferenceNumberVO.setVolume(1);
		updatedReferenceNumberVO.setWeight((double) 1);

		addNewReferenceNumberVO.setAddressID(1);
		addNewReferenceNumberVO.setCustomerCode("A");
		addNewReferenceNumberVO.setDepartment("JBI");
		addNewReferenceNumberVO.setErrorMessage("");
		addNewReferenceNumberVO.setLastUpdated("2017/05/05");
		addNewReferenceNumberVO.setLevel("ORDER");
		addNewReferenceNumberVO.setLineItemVO(new LineItemVO());
		addNewReferenceNumberVO.setParentReferenceNumberI(3);
		addNewReferenceNumberVO.setPieceCount(1);
		addNewReferenceNumberVO.setProductDescr("NOTHING");
		addNewReferenceNumberVO.setQuantity(1);
		addNewReferenceNumberVO.setReferenceNumber("2");
		addNewReferenceNumberVO.setReferenceNumberI(1);
		addNewReferenceNumberVO.setReferenceNumberType("REF");
		addNewReferenceNumberVO.setSchemaMask("S");
		addNewReferenceNumberVO.setSequence(1);
		addNewReferenceNumberVO.setSiteID(1);
		addNewReferenceNumberVO.setValidWithSchema(true);
		addNewReferenceNumberVO.setVolume(1);
		addNewReferenceNumberVO.setWeight((double) 1);
		addNewReferenceNumberVO.setLineItemVO(lineItemVO);

		deletedReferenceNumberVO.setAddressID(1);
		deletedReferenceNumberVO.setCustomerCode("A");
		deletedReferenceNumberVO.setDepartment("JBI");
		deletedReferenceNumberVO.setErrorMessage("");
		deletedReferenceNumberVO.setLastUpdated("2017/05/05");
		deletedReferenceNumberVO.setLevel("ORDER");
		deletedReferenceNumberVO.setLineItemVO(new LineItemVO());
		deletedReferenceNumberVO.setParentReferenceNumberI(3);
		deletedReferenceNumberVO.setPieceCount(1);
		deletedReferenceNumberVO.setProductDescr("NOTHING");
		deletedReferenceNumberVO.setQuantity(1);
		deletedReferenceNumberVO.setReferenceNumber("2");
		deletedReferenceNumberVO.setReferenceNumberI(1);
		deletedReferenceNumberVO.setReferenceNumberType("REF");
		deletedReferenceNumberVO.setSchemaMask("S");
		deletedReferenceNumberVO.setSequence(1);
		deletedReferenceNumberVO.setSiteID(1);
		deletedReferenceNumberVO.setValidWithSchema(true);
		deletedReferenceNumberVO.setVolume(1);
		deletedReferenceNumberVO.setWeight((double) 1);
		deletedReferenceNumberVO.setLineItemVO(lineItemVO);

		referenceNumbersBuffer.setAddressID(1, 0);
		referenceNumbersBuffer.setCustomerCode("A", 0);
		referenceNumbersBuffer.setDepartment("JBI", 0);
		referenceNumbersBuffer.setLevel("ORDER", 0);
		referenceNumbersBuffer.setLineItemActCls(1, 0);
		referenceNumbersBuffer.setLineItemCarrCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemHandlingQuantity(1, 1);
		referenceNumbersBuffer.setLineItemHandlingUnit("A", 0);
		referenceNumbersBuffer.setLineItemHazF("N", 0);
		referenceNumbersBuffer.setLineItemHeight(1, 0);
		referenceNumbersBuffer.setLineItemLength(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemNumber(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemSubC((short) 1, 0);
		referenceNumbersBuffer.setLineItemQtyTyp("A", 0);
		referenceNumbersBuffer.setLineItemRateCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemStackF("A", 0);
		referenceNumbersBuffer.setLineItemWidth(1, 0);
		referenceNumbersBuffer.setNumber("1", 0);
		referenceNumbersBuffer.setParentReferenceNumberI(1, 0);
		referenceNumbersBuffer.setProductDescr("NOTHING", 0);
		referenceNumbersBuffer.setQuantity((short) 1, 0);
		referenceNumbersBuffer.setReferenceNumberI(1, 0);
		referenceNumbersBuffer.setSequence(1, 0);
		referenceNumbersBuffer.setSiteID(1, 0);
		referenceNumbersBuffer.setStopLineItemI(1, 0);
		referenceNumbersBuffer.setType("REF", 0);
		referenceNumbersBuffer.setVolume(1, 0);
		referenceNumbersBuffer.setWeight((double) 1, 0);
		referenceNumbersBuffer.setOldAddressID(2, 0);
		referenceNumbersBuffer.setOldCustomerCode("B", 0);
		referenceNumbersBuffer.setOldDepartment("HJBT JBI", 0);
		referenceNumbersBuffer.setOldSequence(1, 0);
		referenceNumbersBuffer.setOldNumber("1", 0);
		referenceNumbersBuffer.setOldSiteID(1, 0);
		referenceNumbersBuffer.setOldType("REF", 0);
		referenceNumbersBuffer.setReferenceNumberI(0, 0);

		updRefNbrList.add(updatedReferenceNumberVO);
		delRefNbrList.add(deletedReferenceNumberVO);
		newRefNbrList.add(addNewReferenceNumberVO);
		referenceNumberUpdateServiceHelper.populateReferenceNumberForDeletion(delRefNbrList, referenceNumbersBuffer);
		referenceNumberUpdateServiceHelper.newReferenceNumberInsert(referenceNumbersBuffer, 1, 1,
				addNewReferenceNumberVO);
		ReferenceNumberDetailsVO detail = new ReferenceNumberDetailsVO();
		detail.setReferenceNumberI(23);
		assertTrue(referenceNumberUpdateServiceHelper.validateForUpdateDelete(detail));
		detail.setReferenceNumberI(0);
		assertFalse(referenceNumberUpdateServiceHelper.validateForUpdateDelete(detail));
		detail.setReferenceNumberI(null);
		assertFalse(referenceNumberUpdateServiceHelper.validateForUpdateDelete(detail));
		referenceNumberUpdateServiceHelper.getOldReferenceNumberIndexLTL(referenceNumbersBuffer,
				updatedReferenceNumberVO);
		referenceNumbersBuffer.setReferenceNumberI(1, 0);
		referenceNumberUpdateServiceHelper.getOldReferenceNumberIndexLTL(referenceNumbersBuffer,
				updatedReferenceNumberVO);
	}

	@Test
	public void populateRefNbrforOthr() {
		List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
		List<AddNewReferenceNumberVO> newRefNbrList = new ArrayList<>();
		List<DeletedReferenceNumberVO> delRefNbrList = new ArrayList<>();

		UpdatedReferenceNumberVO updatedReferenceNumberVO = new UpdatedReferenceNumberVO();
		AddNewReferenceNumberVO addNewReferenceNumberVO = new AddNewReferenceNumberVO();
		DeletedReferenceNumberVO deletedReferenceNumberVO = new DeletedReferenceNumberVO();
		ReferenceNumbersBuffer referenceNumbersBuffer = new ReferenceNumbersBuffer();

		LineItemVO lineItemVO = new LineItemVO();
		lineItemVO.setStopLineItemI(1);
		lineItemVO.setHazF("N");
		lineItemVO.setActCls(1);
		lineItemVO.setRateCls(1);
		lineItemVO.setCarrCls(1);
		lineItemVO.setLength(1);
		lineItemVO.setWidth(1);
		lineItemVO.setHeight(1);
		lineItemVO.setQtyTyp("NOTHING");
		lineItemVO.setNmfcItemNumber(1);
		lineItemVO.setNmfcItemSubC((short) 1);
		lineItemVO.setHandlingUnit("REF");
		lineItemVO.setHandlingQuantity(1);

		updatedReferenceNumberVO.setAddressID(1);
		updatedReferenceNumberVO.setCustomerCode("A");
		updatedReferenceNumberVO.setDepartment("JBI");
		updatedReferenceNumberVO.setErrorMessage("");
		updatedReferenceNumberVO.setLastUpdated("2017/05/05");
		updatedReferenceNumberVO.setLevel("ORDER");
		updatedReferenceNumberVO.setLineItemVO(lineItemVO);
		updatedReferenceNumberVO.setOldAddressID(2);
		updatedReferenceNumberVO.setOldCustomerCode("B");
		updatedReferenceNumberVO.setOldDepartment("HJBT JBI");
		updatedReferenceNumberVO.setOldReferenceNumber("2");
		updatedReferenceNumberVO.setOldReferenceNumberType("REF");
		updatedReferenceNumberVO.setOldSequence(1);
		updatedReferenceNumberVO.setOldSiteID(1);
		updatedReferenceNumberVO.setParentReferenceNumberI(3);
		updatedReferenceNumberVO.setPieceCount(1);
		updatedReferenceNumberVO.setProductDescr("NOTHING");
		updatedReferenceNumberVO.setQuantity(1);
		updatedReferenceNumberVO.setReferenceNumber("1");
		updatedReferenceNumberVO.setReferenceNumberI(1);
		updatedReferenceNumberVO.setReferenceNumberType("REF");
		updatedReferenceNumberVO.setSchemaMask("S");
		updatedReferenceNumberVO.setOldReferenceNumberI(1);
		updatedReferenceNumberVO.setSequence(1);
		updatedReferenceNumberVO.setSiteID(1);
		updatedReferenceNumberVO.setValidWithSchema(true);
		updatedReferenceNumberVO.setVolume(1);
		updatedReferenceNumberVO.setWeight((double) 1);

		addNewReferenceNumberVO.setAddressID(1);
		addNewReferenceNumberVO.setCustomerCode("A");
		addNewReferenceNumberVO.setDepartment("JBI");
		addNewReferenceNumberVO.setErrorMessage("");
		addNewReferenceNumberVO.setLastUpdated("2017/05/05");
		addNewReferenceNumberVO.setLevel("ORDER");
		addNewReferenceNumberVO.setLineItemVO(new LineItemVO());
		addNewReferenceNumberVO.setParentReferenceNumberI(3);
		addNewReferenceNumberVO.setPieceCount(1);
		addNewReferenceNumberVO.setProductDescr("NOTHING");
		addNewReferenceNumberVO.setQuantity(1);
		addNewReferenceNumberVO.setReferenceNumber("2");
		addNewReferenceNumberVO.setReferenceNumberI(1);
		addNewReferenceNumberVO.setReferenceNumberType("REF");
		addNewReferenceNumberVO.setSchemaMask("S");
		addNewReferenceNumberVO.setSequence(1);
		addNewReferenceNumberVO.setSiteID(1);
		addNewReferenceNumberVO.setValidWithSchema(true);
		addNewReferenceNumberVO.setVolume(1);
		addNewReferenceNumberVO.setWeight((double) 1);
		addNewReferenceNumberVO.setLineItemVO(lineItemVO);

		deletedReferenceNumberVO.setAddressID(1);
		deletedReferenceNumberVO.setCustomerCode("A");
		deletedReferenceNumberVO.setDepartment("JBI");
		deletedReferenceNumberVO.setErrorMessage("");
		deletedReferenceNumberVO.setLastUpdated("2017/05/05");
		deletedReferenceNumberVO.setLevel("ORDER");
		deletedReferenceNumberVO.setLineItemVO(new LineItemVO());
		deletedReferenceNumberVO.setParentReferenceNumberI(3);
		deletedReferenceNumberVO.setPieceCount(1);
		deletedReferenceNumberVO.setProductDescr("NOTHING");
		deletedReferenceNumberVO.setQuantity(1);
		deletedReferenceNumberVO.setReferenceNumber("2");
		deletedReferenceNumberVO.setReferenceNumberI(1);
		deletedReferenceNumberVO.setReferenceNumberType("REF");
		deletedReferenceNumberVO.setSchemaMask("S");
		deletedReferenceNumberVO.setSequence(1);
		deletedReferenceNumberVO.setSiteID(1);
		deletedReferenceNumberVO.setValidWithSchema(true);
		deletedReferenceNumberVO.setVolume(1);
		deletedReferenceNumberVO.setWeight((double) 1);
		deletedReferenceNumberVO.setLineItemVO(lineItemVO);

		referenceNumbersBuffer.setAddressID(1, 0);
		referenceNumbersBuffer.setCustomerCode("A", 0);
		referenceNumbersBuffer.setDepartment("JBI", 0);
		referenceNumbersBuffer.setLevel("ORDER", 0);
		referenceNumbersBuffer.setLineItemActCls(1, 0);
		referenceNumbersBuffer.setLineItemCarrCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemHandlingQuantity(1, 1);
		referenceNumbersBuffer.setLineItemHandlingUnit("A", 0);
		referenceNumbersBuffer.setLineItemHazF("N", 0);
		referenceNumbersBuffer.setLineItemHeight(1, 0);
		referenceNumbersBuffer.setLineItemLength(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemNumber(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemSubC((short) 1, 0);
		referenceNumbersBuffer.setLineItemQtyTyp("A", 0);
		referenceNumbersBuffer.setLineItemRateCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemStackF("A", 0);
		referenceNumbersBuffer.setLineItemWidth(1, 0);
		referenceNumbersBuffer.setNumber("1", 0);
		referenceNumbersBuffer.setParentReferenceNumberI(1, 0);
		referenceNumbersBuffer.setProductDescr("NOTHING", 0);
		referenceNumbersBuffer.setQuantity((short) 1, 0);
		referenceNumbersBuffer.setReferenceNumberI(1, 0);
		referenceNumbersBuffer.setSequence(1, 0);
		referenceNumbersBuffer.setSiteID(1, 0);
		referenceNumbersBuffer.setStopLineItemI(1, 0);
		referenceNumbersBuffer.setType("REF", 0);
		referenceNumbersBuffer.setVolume(1, 0);
		referenceNumbersBuffer.setWeight((double) 1, 0);
		referenceNumbersBuffer.setOldAddressID(2, 0);
		referenceNumbersBuffer.setOldCustomerCode("B", 0);
		referenceNumbersBuffer.setOldDepartment("HJBT JBI", 0);
		referenceNumbersBuffer.setOldSequence(1, 0);
		referenceNumbersBuffer.setOldNumber("1", 0);
		referenceNumbersBuffer.setOldSiteID(1, 0);
		referenceNumbersBuffer.setOldType("REF", 0);
		referenceNumbersBuffer.setReferenceNumberI(0, 0);

		updRefNbrList.add(updatedReferenceNumberVO);
		delRefNbrList.add(deletedReferenceNumberVO);
		newRefNbrList.add(addNewReferenceNumberVO);
		int res = referenceUpdateHelper.populateReferenceNumberForOthers(updRefNbrList, newRefNbrList, delRefNbrList,
				referenceNumbersBuffer, 1);
		assertNotNull(res);
	}

	@Test
	public void populateRefNbrforCreate() throws JsonParseException, JsonMappingException, IOException {
		Oee5InputChannelData input = new Oee5InputChannelData();
		input.setOee5InputBuffer1(new Oee5InputBuffer1());
		List<Oee5InLoadSyncData> inLoadSyncDatas = new ArrayList<>();
		Oee5InLoadSyncData oee5InLoadSyncData = new Oee5InLoadSyncData();
		inLoadSyncDatas.add(oee5InLoadSyncData);
		input.setOee5InLoadSyncBuffer12(inLoadSyncDatas);
		List<Oee5InStpLine> oee5InStpBuffer5 = new ArrayList<Oee5InStpLine>();
		Oee5InStpLine stop1 = new Oee5InStpLine();
		stop1.setOee5InStpoOfrStpSeqNbr(1);
		stop1.setOee5InStpId(5284);
		Oee5InStpLine stop2 = new Oee5InStpLine();
		stop2.setOee5InStpoOfrStpSeqNbr(99);
		stop2.setOee5InStpId(7004);
		oee5InStpBuffer5.add(stop1);
		oee5InStpBuffer5.add(stop2);
		input.setOee5InStpBuffer5(oee5InStpBuffer5);

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadReference.json")),
				OperationalPlanEvent.class);
		List<OperationalPlanReferenceNumberDTO> referenceNumberDTOs = new ArrayList<>();
		ReferenceNumberLevelTypeDTO referenceNumberLevelType = new ReferenceNumberLevelTypeDTO();
		referenceNumberLevelType.setReferenceNumberLevelTypeCode("OprPlan");
		OperationalPlanReferenceNumberDTO referenceNumberDTO = new OperationalPlanReferenceNumberDTO();
		referenceNumberDTO.setReferenceNumberValue("1");
		referenceNumberDTO.setReferenceNumberLevelType(referenceNumberLevelType);
		referenceNumberDTO.setOperationalPlanReferenceNumberId(23);
		referenceNumberDTOs.add(referenceNumberDTO);
		List<AddNewReferenceNumberVO> res = referenceUpdateServiceHelper.fetchCreateReferenceNumberVO(
				operationalPlanEvent, referenceNumberDTOs, input, "OrderReferenceNumber", referenceNumberDTO);
		assertNotNull(res);
	}

	@Test
	public void populateRefNbrforUpdate() throws JsonParseException, JsonMappingException, IOException {
		Oee5InputChannelData input = new Oee5InputChannelData();
		input.setOee5InputBuffer1(new Oee5InputBuffer1());
		List<Oee5InLoadSyncData> inLoadSyncDatas = new ArrayList<>();
		Oee5InLoadSyncData oee5InLoadSyncData = new Oee5InLoadSyncData();
		inLoadSyncDatas.add(oee5InLoadSyncData);
		input.setOee5InLoadSyncBuffer12(inLoadSyncDatas);
		List<Oee5InStpLine> oee5InStpBuffer5 = new ArrayList<Oee5InStpLine>();
		Oee5InStpLine stop1 = new Oee5InStpLine();
		stop1.setOee5InStpoOfrStpSeqNbr(1);
		stop1.setOee5InStpId(5284);
		Oee5InStpLine stop2 = new Oee5InStpLine();
		stop2.setOee5InStpoOfrStpSeqNbr(99);
		stop2.setOee5InStpId(7004);
		oee5InStpBuffer5.add(stop1);
		oee5InStpBuffer5.add(stop2);
		input.setOee5InStpBuffer5(oee5InStpBuffer5);

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadReference.json")),
				OperationalPlanEvent.class);
		List<OperationalPlanReferenceNumberDTO> referenceNumberDTOs = new ArrayList<>();
		ReferenceNumberLevelTypeDTO referenceNumberLevelType = new ReferenceNumberLevelTypeDTO();
		referenceNumberLevelType.setReferenceNumberLevelTypeCode("OprPlan");
		OperationalPlanReferenceNumberDTO referenceNumberDTO = new OperationalPlanReferenceNumberDTO();
		referenceNumberDTO.setReferenceNumberValue("1");
		referenceNumberDTO.setReferenceNumberLevelType(referenceNumberLevelType);
		referenceNumberDTO.setOperationalPlanReferenceNumberId(23);
		referenceNumberDTOs.add(referenceNumberDTO);
		ReferenceNumbersLinkBuffers outputRefBuffer = new ReferenceNumbersLinkBuffers();
		outputRefBuffer.setNbrOfRefNbrs(1);
		outputRefBuffer.getReferenceNumbers().setType("ITN", 0);
		outputRefBuffer.getReferenceNumbers().setSequence(1, 0);
		outputRefBuffer.getReferenceNumbers().setNumber("544513213", 0);
		outputRefBuffer.getReferenceNumbers().setCustomerCode("SCNEAB", 0);
		outputRefBuffer.getReferenceNumbers().setAddressID(3212, 0);
		outputRefBuffer.getReferenceNumbers().setSiteID(12313, 0);
		outputRefBuffer.getReferenceNumbers().setDepartment("BILL TO", 0);
		List<UpdatedReferenceNumberVO> res = referenceUpdateServiceHelper.fetchUpdateReferenceNumberVO(
				operationalPlanEvent, referenceNumberDTOs, outputRefBuffer, input, referenceNumberDTO,
				"OrderReferenceNumber");
		assertNotNull(res);
	}

	@Test
	public void populateRefNbrforDeleteLoad() {
		List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
		List<AddNewReferenceNumberVO> newRefNbrList = new ArrayList<>();
		List<DeletedReferenceNumberVO> delRefNbrList = new ArrayList<>();

		UpdatedReferenceNumberVO updatedReferenceNumberVO = new UpdatedReferenceNumberVO();
		AddNewReferenceNumberVO addNewReferenceNumberVO = new AddNewReferenceNumberVO();
		DeletedReferenceNumberVO deletedReferenceNumberVO = new DeletedReferenceNumberVO();
		ReferenceNumbersBuffer referenceNumbersBuffer = new ReferenceNumbersBuffer();

		LineItemVO lineItemVO = new LineItemVO();
		lineItemVO.setStopLineItemI(1);
		lineItemVO.setHazF("N");
		lineItemVO.setActCls(1);
		lineItemVO.setRateCls(1);
		lineItemVO.setCarrCls(1);
		lineItemVO.setLength(1);
		lineItemVO.setWidth(1);
		lineItemVO.setHeight(1);
		lineItemVO.setQtyTyp("NOTHING");
		lineItemVO.setNmfcItemNumber(1);
		lineItemVO.setNmfcItemSubC((short) 1);
		lineItemVO.setHandlingUnit("REF");
		lineItemVO.setHandlingQuantity(1);

		updatedReferenceNumberVO.setAddressID(1);
		updatedReferenceNumberVO.setCustomerCode("A");
		updatedReferenceNumberVO.setDepartment("JBI");
		updatedReferenceNumberVO.setErrorMessage("");
		updatedReferenceNumberVO.setLastUpdated("2017/05/05");
		updatedReferenceNumberVO.setLevel("ORDER");
		updatedReferenceNumberVO.setLineItemVO(lineItemVO);
		updatedReferenceNumberVO.setOldAddressID(2);
		updatedReferenceNumberVO.setOldCustomerCode("B");
		updatedReferenceNumberVO.setOldDepartment("HJBT JBI");
		updatedReferenceNumberVO.setOldReferenceNumber("2");
		updatedReferenceNumberVO.setOldReferenceNumberType("REF");
		updatedReferenceNumberVO.setOldSequence(1);
		updatedReferenceNumberVO.setOldSiteID(1);
		updatedReferenceNumberVO.setParentReferenceNumberI(3);
		updatedReferenceNumberVO.setPieceCount(1);
		updatedReferenceNumberVO.setProductDescr("NOTHING");
		updatedReferenceNumberVO.setQuantity(1);
		updatedReferenceNumberVO.setReferenceNumber("1");
		updatedReferenceNumberVO.setReferenceNumberI(1);
		updatedReferenceNumberVO.setReferenceNumberType("REF");
		updatedReferenceNumberVO.setSchemaMask("S");
		updatedReferenceNumberVO.setOldReferenceNumberI(1);
		updatedReferenceNumberVO.setSequence(1);
		updatedReferenceNumberVO.setSiteID(1);
		updatedReferenceNumberVO.setValidWithSchema(true);
		updatedReferenceNumberVO.setVolume(1);
		updatedReferenceNumberVO.setWeight((double) 1);

		addNewReferenceNumberVO.setAddressID(1);
		addNewReferenceNumberVO.setCustomerCode("A");
		addNewReferenceNumberVO.setDepartment("JBI");
		addNewReferenceNumberVO.setErrorMessage("");
		addNewReferenceNumberVO.setLastUpdated("2017/05/05");
		addNewReferenceNumberVO.setLevel("ORDER");
		addNewReferenceNumberVO.setLineItemVO(new LineItemVO());
		addNewReferenceNumberVO.setParentReferenceNumberI(3);
		addNewReferenceNumberVO.setPieceCount(1);
		addNewReferenceNumberVO.setProductDescr("NOTHING");
		addNewReferenceNumberVO.setQuantity(1);
		addNewReferenceNumberVO.setReferenceNumber("2");
		addNewReferenceNumberVO.setReferenceNumberI(1);
		addNewReferenceNumberVO.setReferenceNumberType("REF");
		addNewReferenceNumberVO.setSchemaMask("S");
		addNewReferenceNumberVO.setSequence(1);
		addNewReferenceNumberVO.setSiteID(1);
		addNewReferenceNumberVO.setValidWithSchema(true);
		addNewReferenceNumberVO.setVolume(1);
		addNewReferenceNumberVO.setWeight((double) 1);
		addNewReferenceNumberVO.setLineItemVO(lineItemVO);

		deletedReferenceNumberVO.setAddressID(1);
		deletedReferenceNumberVO.setCustomerCode("A");
		deletedReferenceNumberVO.setDepartment("JBI");
		deletedReferenceNumberVO.setErrorMessage("");
		deletedReferenceNumberVO.setLastUpdated("2017/05/05");
		deletedReferenceNumberVO.setLevel("ORDER");
		deletedReferenceNumberVO.setLineItemVO(new LineItemVO());
		deletedReferenceNumberVO.setParentReferenceNumberI(3);
		deletedReferenceNumberVO.setPieceCount(1);
		deletedReferenceNumberVO.setProductDescr("NOTHING");
		deletedReferenceNumberVO.setQuantity(1);
		deletedReferenceNumberVO.setReferenceNumber("2");
		deletedReferenceNumberVO.setReferenceNumberI(1);
		deletedReferenceNumberVO.setReferenceNumberType("REF");
		deletedReferenceNumberVO.setSchemaMask("S");
		deletedReferenceNumberVO.setSequence(1);
		deletedReferenceNumberVO.setSiteID(1);
		deletedReferenceNumberVO.setValidWithSchema(true);
		deletedReferenceNumberVO.setVolume(1);
		deletedReferenceNumberVO.setWeight((double) 1);
		deletedReferenceNumberVO.setLineItemVO(lineItemVO);

		referenceNumbersBuffer.setAddressID(1, 0);
		referenceNumbersBuffer.setCustomerCode("A", 0);
		referenceNumbersBuffer.setDepartment("JBI", 0);
		referenceNumbersBuffer.setLevel("ORDER", 0);
		referenceNumbersBuffer.setLineItemActCls(1, 0);
		referenceNumbersBuffer.setLineItemCarrCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemHandlingQuantity(1, 1);
		referenceNumbersBuffer.setLineItemHandlingUnit("A", 0);
		referenceNumbersBuffer.setLineItemHazF("N", 0);
		referenceNumbersBuffer.setLineItemHeight(1, 0);
		referenceNumbersBuffer.setLineItemLength(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemNumber(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemSubC((short) 1, 0);
		referenceNumbersBuffer.setLineItemQtyTyp("A", 0);
		referenceNumbersBuffer.setLineItemRateCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemStackF("A", 0);
		referenceNumbersBuffer.setLineItemWidth(1, 0);
		referenceNumbersBuffer.setNumber("1", 0);
		referenceNumbersBuffer.setParentReferenceNumberI(1, 0);
		referenceNumbersBuffer.setProductDescr("NOTHING", 0);
		referenceNumbersBuffer.setQuantity((short) 1, 0);
		referenceNumbersBuffer.setReferenceNumberI(1, 0);
		referenceNumbersBuffer.setSequence(1, 0);
		referenceNumbersBuffer.setSiteID(1, 0);
		referenceNumbersBuffer.setStopLineItemI(1, 0);
		referenceNumbersBuffer.setType("REF", 0);
		referenceNumbersBuffer.setVolume(1, 0);
		referenceNumbersBuffer.setWeight((double) 1, 0);
		referenceNumbersBuffer.setOldAddressID(2, 0);
		referenceNumbersBuffer.setOldCustomerCode("B", 0);
		referenceNumbersBuffer.setOldDepartment("HJBT JBI", 0);
		referenceNumbersBuffer.setOldSequence(1, 0);
		referenceNumbersBuffer.setOldNumber("1", 0);
		referenceNumbersBuffer.setOldSiteID(1, 0);
		referenceNumbersBuffer.setOldType("REF", 0);
		referenceNumbersBuffer.setReferenceNumberI(0, 0);

		updRefNbrList.add(updatedReferenceNumberVO);
		delRefNbrList.add(deletedReferenceNumberVO);
		newRefNbrList.add(addNewReferenceNumberVO);
		ReferenceNumbersLinkBuffers ordRefNbrBuffers = new ReferenceNumbersLinkBuffers();
		ordRefNbrBuffers.setNbrOfRefNbrs(1);
		ordRefNbrBuffers.getReferenceNumbers().setReferenceNumberI(1, 0);
		ordRefNbrBuffers.getReferenceNumbers().setSequence(1, 0);
		ordRefNbrBuffers.getReferenceNumbers().setCustomerCode("XYZ", 0);
		ordRefNbrBuffers.getReferenceNumbers().setSiteID(1, 0);
		ordRefNbrBuffers.getReferenceNumbers().setAddressID(1, 0);
		ordRefNbrBuffers.getReferenceNumbers().setDepartment("HOME", 0);
		ordRefNbrBuffers.getReferenceNumbers().setType("ORDER", 0);
		ordRefNbrBuffers.getReferenceNumbers().setNumber("1", 0);

		ReferenceNumberLevelTypeDTO referenceNumberLevelType = new ReferenceNumberLevelTypeDTO();
		referenceNumberLevelType.setReferenceNumberLevelTypeCode("ORDER");
		OperationalPlanReferenceNumberDTO referenceNumberDTO = new OperationalPlanReferenceNumberDTO();
		referenceNumberDTO.setReferenceNumberValue("1");
		referenceNumberDTO.setReferenceNumberLevelType(referenceNumberLevelType);
		List<DeletedReferenceNumberVO> res = referenceUpdateServiceHelper.fetchDeleteReferenceNumberVO(delRefNbrList,
				ordRefNbrBuffers, referenceNumberDTO);
		assertNotNull(res);
	}

	@Test
	public void populateRefNbrforLineItem() {
		List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
		List<AddNewReferenceNumberVO> newRefNbrList = new ArrayList<>();
		List<DeletedReferenceNumberVO> delRefNbrList = new ArrayList<>();

		UpdatedReferenceNumberVO updatedReferenceNumberVO = new UpdatedReferenceNumberVO();
		AddNewReferenceNumberVO addNewReferenceNumberVO = new AddNewReferenceNumberVO();
		DeletedReferenceNumberVO deletedReferenceNumberVO = new DeletedReferenceNumberVO();
		ReferenceNumbersBuffer referenceNumbersBuffer = new ReferenceNumbersBuffer();

		LineItemVO lineItemVO = new LineItemVO();
		lineItemVO.setStopLineItemI(1);
		lineItemVO.setHazF("N");
		lineItemVO.setActCls(1);
		lineItemVO.setRateCls(1);
		lineItemVO.setCarrCls(1);
		lineItemVO.setLength(1);
		lineItemVO.setWidth(1);
		lineItemVO.setHeight(1);
		lineItemVO.setQtyTyp("NOTHING");
		lineItemVO.setNmfcItemNumber(1);
		lineItemVO.setNmfcItemSubC((short) 1);
		lineItemVO.setHandlingUnit("REF");
		lineItemVO.setHandlingQuantity(1);

		updatedReferenceNumberVO.setAddressID(1);
		updatedReferenceNumberVO.setCustomerCode("A");
		updatedReferenceNumberVO.setDepartment("JBI");
		updatedReferenceNumberVO.setErrorMessage("");
		updatedReferenceNumberVO.setLastUpdated("2017/05/05");
		updatedReferenceNumberVO.setLevel("ORDER");
		updatedReferenceNumberVO.setLineItemVO(lineItemVO);
		updatedReferenceNumberVO.setOldAddressID(2);
		updatedReferenceNumberVO.setOldCustomerCode("B");
		updatedReferenceNumberVO.setOldDepartment("HJBT JBI");
		updatedReferenceNumberVO.setOldReferenceNumber("2");
		updatedReferenceNumberVO.setOldReferenceNumberI(1);
		updatedReferenceNumberVO.setOldReferenceNumberType("REF");
		updatedReferenceNumberVO.setOldSequence(1);
		updatedReferenceNumberVO.setOldSiteID(1);
		updatedReferenceNumberVO.setParentReferenceNumberI(3);
		updatedReferenceNumberVO.setPieceCount(1);
		updatedReferenceNumberVO.setProductDescr("NOTHING");
		updatedReferenceNumberVO.setQuantity(1);
		updatedReferenceNumberVO.setReferenceNumber("1");
		updatedReferenceNumberVO.setReferenceNumberI(1);
		updatedReferenceNumberVO.setReferenceNumberType("REF");
		updatedReferenceNumberVO.setSchemaMask("S");
		updatedReferenceNumberVO.setSequence(1);
		updatedReferenceNumberVO.setSiteID(1);
		updatedReferenceNumberVO.setValidWithSchema(true);
		updatedReferenceNumberVO.setVolume(1);
		updatedReferenceNumberVO.setWeight((double) 1);

		addNewReferenceNumberVO.setAddressID(1);
		addNewReferenceNumberVO.setCustomerCode("A");
		addNewReferenceNumberVO.setDepartment("JBI");
		addNewReferenceNumberVO.setErrorMessage("");
		addNewReferenceNumberVO.setLastUpdated("2017/05/05");
		addNewReferenceNumberVO.setLevel("ORDER");
		addNewReferenceNumberVO.setLineItemVO(new LineItemVO());
		addNewReferenceNumberVO.setParentReferenceNumberI(3);
		addNewReferenceNumberVO.setPieceCount(1);
		addNewReferenceNumberVO.setProductDescr("NOTHING");
		addNewReferenceNumberVO.setQuantity(1);
		addNewReferenceNumberVO.setReferenceNumber("2");
		addNewReferenceNumberVO.setReferenceNumberI(1);
		addNewReferenceNumberVO.setReferenceNumberType("REF");
		addNewReferenceNumberVO.setSchemaMask("S");
		addNewReferenceNumberVO.setSequence(1);
		addNewReferenceNumberVO.setSiteID(1);
		addNewReferenceNumberVO.setValidWithSchema(true);
		addNewReferenceNumberVO.setVolume(1);
		addNewReferenceNumberVO.setWeight((double) 1);
		addNewReferenceNumberVO.setLineItemVO(lineItemVO);

		deletedReferenceNumberVO.setAddressID(1);
		deletedReferenceNumberVO.setCustomerCode("A");
		deletedReferenceNumberVO.setDepartment("JBI");
		deletedReferenceNumberVO.setErrorMessage("");
		deletedReferenceNumberVO.setLastUpdated("2017/05/05");
		deletedReferenceNumberVO.setLevel("ORDER");
		deletedReferenceNumberVO.setLineItemVO(new LineItemVO());
		deletedReferenceNumberVO.setParentReferenceNumberI(3);
		deletedReferenceNumberVO.setPieceCount(1);
		deletedReferenceNumberVO.setProductDescr("NOTHING");
		deletedReferenceNumberVO.setQuantity(1);
		deletedReferenceNumberVO.setReferenceNumber("2");
		deletedReferenceNumberVO.setReferenceNumberI(1);
		deletedReferenceNumberVO.setReferenceNumberType("REF");
		deletedReferenceNumberVO.setSchemaMask("S");
		deletedReferenceNumberVO.setSequence(1);
		deletedReferenceNumberVO.setSiteID(1);
		deletedReferenceNumberVO.setValidWithSchema(true);
		deletedReferenceNumberVO.setVolume(1);
		deletedReferenceNumberVO.setWeight((double) 1);
		deletedReferenceNumberVO.setLineItemVO(lineItemVO);

		referenceNumbersBuffer.setAddressID(1, 0);
		referenceNumbersBuffer.setCustomerCode("A", 0);
		referenceNumbersBuffer.setDepartment("JBI", 0);
		referenceNumbersBuffer.setLevel("ORDER", 0);
		referenceNumbersBuffer.setLineItemActCls(1, 0);
		referenceNumbersBuffer.setLineItemCarrCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemHandlingQuantity(1, 1);
		referenceNumbersBuffer.setLineItemHandlingUnit("A", 0);
		referenceNumbersBuffer.setLineItemHazF("N", 0);
		referenceNumbersBuffer.setLineItemHeight(1, 0);
		referenceNumbersBuffer.setLineItemLength(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemNumber(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemSubC((short) 1, 0);
		referenceNumbersBuffer.setLineItemQtyTyp("A", 0);
		referenceNumbersBuffer.setLineItemRateCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemStackF("A", 0);
		referenceNumbersBuffer.setLineItemWidth(1, 0);
		referenceNumbersBuffer.setNumber("1", 0);
		referenceNumbersBuffer.setParentReferenceNumberI(1, 0);
		referenceNumbersBuffer.setProductDescr("NOTHING", 0);
		referenceNumbersBuffer.setQuantity((short) 1, 0);
		referenceNumbersBuffer.setReferenceNumberI(1, 0);
		referenceNumbersBuffer.setSequence(1, 0);
		referenceNumbersBuffer.setSiteID(1, 0);
		referenceNumbersBuffer.setStopLineItemI(1, 0);
		referenceNumbersBuffer.setType("REF", 0);
		referenceNumbersBuffer.setVolume(1, 0);
		referenceNumbersBuffer.setWeight((double) 1, 0);
		referenceNumbersBuffer.setOldAddressID(2, 0);
		referenceNumbersBuffer.setOldCustomerCode("B", 0);
		referenceNumbersBuffer.setOldDepartment("HJBT JBI", 0);
		referenceNumbersBuffer.setOldSequence(1, 0);
		referenceNumbersBuffer.setOldNumber("1", 0);
		referenceNumbersBuffer.setOldSiteID(1, 0);
		referenceNumbersBuffer.setOldType("REF", 0);

		updRefNbrList.add(updatedReferenceNumberVO);
		newRefNbrList.add(addNewReferenceNumberVO);
		delRefNbrList.add(deletedReferenceNumberVO);
		int res = referenceUpdateHelper.populateRefNbrForLineItems(updRefNbrList, newRefNbrList, delRefNbrList,
				referenceNumbersBuffer, 1);
		assertEquals(1, res);
	}

	@Test
	public void testExistingRefBuffer() {

		ReferenceNumbersBuffer referenceNumbersBuffer = new ReferenceNumbersBuffer();
		referenceNumbersBuffer.setAddressID(1, 0);
		referenceNumbersBuffer.setCustomerCode("A", 0);
		referenceNumbersBuffer.setDepartment("JBI", 0);
		referenceNumbersBuffer.setLevel("ORDER", 0);
		referenceNumbersBuffer.setLineItemActCls(1, 0);
		referenceNumbersBuffer.setLineItemCarrCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemHandlingQuantity(1, 1);
		referenceNumbersBuffer.setLineItemHandlingUnit("A", 0);
		referenceNumbersBuffer.setLineItemHazF("N", 0);
		referenceNumbersBuffer.setLineItemHeight(1, 0);
		referenceNumbersBuffer.setLineItemLength(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemNumber(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemSubC((short) 1, 0);
		referenceNumbersBuffer.setLineItemQtyTyp("A", 0);
		referenceNumbersBuffer.setLineItemRateCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemStackF("A", 0);
		referenceNumbersBuffer.setLineItemWidth(1, 0);
		referenceNumbersBuffer.setNumber("1", 0);
		referenceNumbersBuffer.setParentReferenceNumberI(1, 0);
		referenceNumbersBuffer.setProductDescr("NOTHING", 0);
		referenceNumbersBuffer.setQuantity((short) 1, 0);
		referenceNumbersBuffer.setReferenceNumberI(1, 0);
		referenceNumbersBuffer.setSequence(1, 0);
		referenceNumbersBuffer.setSiteID(1, 0);
		referenceNumbersBuffer.setStopLineItemI(1, 0);
		referenceNumbersBuffer.setType("REF", 0);
		referenceNumbersBuffer.setVolume(1, 0);
		referenceNumbersBuffer.setWeight((double) 1, 0);
		referenceNumbersBuffer.setOldAddressID(2, 0);
		referenceNumbersBuffer.setOldCustomerCode("B", 0);
		referenceNumbersBuffer.setOldDepartment("HJBT JBI", 0);
		referenceNumbersBuffer.setOldSequence(1, 0);
		referenceNumbersBuffer.setOldNumber("1", 0);
		referenceNumbersBuffer.setOldSiteID(1, 0);
		referenceNumbersBuffer.setOldType("REF", 0);
		ReferenceNumbersLinkBuffers oec070Buffers = new ReferenceNumbersLinkBuffers();

		oec070Buffers.setNbrOfRefNbrs(1);

		int res = referenceUpdateServiceHelper.constructExistingRefNbrBuff(oec070Buffers, referenceNumbersBuffer, 1);
		assertEquals(1, res);
	}

	@Test
	public void testExistingRefBufferForZeroCount() {

		ReferenceNumbersBuffer referenceNumbersBuffer = new ReferenceNumbersBuffer();
		referenceNumbersBuffer.setAddressID(1, 0);
		referenceNumbersBuffer.setCustomerCode("A", 0);
		referenceNumbersBuffer.setDepartment("JBI", 0);
		referenceNumbersBuffer.setLevel("ORDER", 0);
		referenceNumbersBuffer.setLineItemActCls(1, 0);
		referenceNumbersBuffer.setLineItemCarrCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemHandlingQuantity(1, 1);
		referenceNumbersBuffer.setLineItemHandlingUnit("A", 0);
		referenceNumbersBuffer.setLineItemHazF("N", 0);
		referenceNumbersBuffer.setLineItemHeight(1, 0);
		referenceNumbersBuffer.setLineItemLength(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemNumber(1, 0);
		referenceNumbersBuffer.setLineItemNmfcItemSubC((short) 1, 0);
		referenceNumbersBuffer.setLineItemQtyTyp("A", 0);
		referenceNumbersBuffer.setLineItemRateCls((double) 1, 0);
		referenceNumbersBuffer.setLineItemStackF("A", 0);
		referenceNumbersBuffer.setLineItemWidth(1, 0);
		referenceNumbersBuffer.setNumber("1", 0);
		referenceNumbersBuffer.setParentReferenceNumberI(1, 0);
		referenceNumbersBuffer.setProductDescr("NOTHING", 0);
		referenceNumbersBuffer.setQuantity((short) 1, 0);
		referenceNumbersBuffer.setReferenceNumberI(1, 0);
		referenceNumbersBuffer.setSequence(1, 0);
		referenceNumbersBuffer.setSiteID(1, 0);
		referenceNumbersBuffer.setStopLineItemI(1, 0);
		referenceNumbersBuffer.setType("REF", 0);
		referenceNumbersBuffer.setVolume(1, 0);
		referenceNumbersBuffer.setWeight((double) 1, 0);
		referenceNumbersBuffer.setOldAddressID(2, 0);
		referenceNumbersBuffer.setOldCustomerCode("B", 0);
		referenceNumbersBuffer.setOldDepartment("HJBT JBI", 0);
		referenceNumbersBuffer.setOldSequence(1, 0);
		referenceNumbersBuffer.setOldNumber("1", 0);
		referenceNumbersBuffer.setOldSiteID(1, 0);
		referenceNumbersBuffer.setOldType("REF", 0);
		ReferenceNumbersLinkBuffers oec070Buffers = new ReferenceNumbersLinkBuffers();

		oec070Buffers.setNbrOfRefNbrs(0);

		int res = referenceUpdateServiceHelper.constructExistingRefNbrBuff(oec070Buffers, referenceNumbersBuffer, 1);
		assertEquals(0, res);
	}

	@Test
	public void testPopulateUpdateReferenceNumberList() throws JsonParseException, JsonMappingException, IOException {
		Oee5InStpLine stop2 = new Oee5InStpLine();
		stop2.setOee5InStpoOfrStpSeqNbr(99);
		stop2.setOee5InStpId(7004);
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadReference.json")),
				OperationalPlanEvent.class);
		OperationalPlanStopDTO stopDTO = operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops().get(0);
		List<OperationalPlanReferenceNumberDTO> referenceNumberDTOs = new ArrayList<>();
		ReferenceNumberLevelTypeDTO referenceNumberLevelType = new ReferenceNumberLevelTypeDTO();
		referenceNumberLevelType.setReferenceNumberLevelTypeCode("OprPlanStp");
		OperationalPlanReferenceNumberDTO referenceNumberDTO = new OperationalPlanReferenceNumberDTO();
		referenceNumberDTO.setReferenceNumberValue("1");
		referenceNumberDTO.setReferenceNumberLevelType(referenceNumberLevelType);
		referenceNumberDTO.setOperationalPlanReferenceNumberId(23);
		referenceNumberDTO.setOperationalPlanStopId(57283);
		List<OperationalPlanStopItemHandlingUnitReferenceNumberAssociationDTO> stopItemReferenceNumberAssociations = new ArrayList<>();
		OperationalPlanStopItemHandlingUnitReferenceNumberAssociationDTO associationDTO = new OperationalPlanStopItemHandlingUnitReferenceNumberAssociationDTO();
		associationDTO.setOperationalPlanStopItemHandlingUnitReferenceNumberAssociationID(23);
		stopItemReferenceNumberAssociations.add(associationDTO);
		
		List<OperationalPlanStopHandlingUnitAssociationDTO> operationalPlanStopHandlingUnitAssociationDTOList = new ArrayList<>();
		OperationalPlanStopHandlingUnitAssociationDTO unitAssociationDTO = new OperationalPlanStopHandlingUnitAssociationDTO();
		List<OperationalPlanStopItemDTO> stopItemList = new ArrayList<>();
		OperationalPlanStopItemDTO planStopItemDTO = new OperationalPlanStopItemDTO();
		stopItemList.add(planStopItemDTO);
		OperationalPlanStopItemHandlingUnitDTO unitDTO = new OperationalPlanStopItemHandlingUnitDTO();
		unitDTO.setOperationalPlanStopItemHandlingUnitReferenceNumberAssociations(stopItemReferenceNumberAssociations);
		unitDTO.setOperationalPlanStopItems(stopItemList);
		unitAssociationDTO.setOperationalPlanStopItemHandlingUnit(unitDTO);
		
		operationalPlanStopHandlingUnitAssociationDTOList.add(unitAssociationDTO);
		
		stopDTO.setOperationalPlanStopHandlingUnitAssociations(operationalPlanStopHandlingUnitAssociationDTOList);
		
		OperationalPlanStopItemDTO stopItemDTO = itemReferenceNumberHelper
				.getStopItemIfTiedToReferenceNumber(referenceNumberDTO, stopDTO);
		referenceNumberDTOs.add(referenceNumberDTO);
		ReferenceNumbersLinkBuffers outputRefBuffer = new ReferenceNumbersLinkBuffers();
		outputRefBuffer.setNbrOfRefNbrs(1);
		outputRefBuffer.getReferenceNumbers().setType("ITN", 0);
		outputRefBuffer.getReferenceNumbers().setSequence(1, 0);
		outputRefBuffer.getReferenceNumbers().setNumber("544513213", 0);
		outputRefBuffer.getReferenceNumbers().setCustomerCode("SCNEAB", 0);
		outputRefBuffer.getReferenceNumbers().setAddressID(3212, 0);
		outputRefBuffer.getReferenceNumbers().setSiteID(12313, 0);
		outputRefBuffer.getReferenceNumbers().setDepartment("BILL TO", 0);
		List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
		UpdatedReferenceNumberVO updatedReferenceNumberVO = new UpdatedReferenceNumberVO();
		List<UpdatedReferenceNumberVO> res = referenceNumberBuilder.populateUpdateReferenceNumberList(
				updatedReferenceNumberVO, referenceNumberDTO, stop2, stopDTO, 1, updRefNbrList, stopItemDTO);
		assertNotNull(res);
	}

}
