package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class TActivityJDBCRepository {

	TActivityJDBCRepository(@Qualifier("dataSourceDB2") JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private final JdbcTemplate jdbcTemplate;

	public void updateTActivity(final String arrivalDate, final String arrivalTime, final Integer sourceId) {
		final String query = "UPDATE ALI.TACTIVITY A SET A.ACL_CMP_D = ?, A.ACL_CMP_H = ?, A.ACL_STRT_H = ?, A.ACL_STRT_D =? WHERE A.SRCE_ID=? AND A.ATY_TY_ID = 'ARRIVE'";
		jdbcTemplate.update(query, arrivalDate, arrivalTime, arrivalTime, arrivalDate, sourceId);
	}

}
