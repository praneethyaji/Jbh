package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;

@RepositoryRestResource
public interface CityRepository extends JpaRepository<City, String> {

	@Query(value = "SELECT DISTINCT A.CUS_C, B.DIV_ID, B.BUS_NAME_I, C.ADR_LNE_01, C.ADR_LNE_02, D.CTY_ST_C, D.DSC_T, C.PST_1_C, "
			+ "C.PST_2_C, C.PST_EXT_C, C.ST_C, C.CRY_C, B.BUS_LOC_ID, B.BUS_ID FROM ALI.TBUS_SIT_ADR_ASC A, ALI.TBUSINESS_SITE B, "
			+ "ALI.TADDRESS C, ALI.TCITY D WHERE A.CUS_C = (:cusCode)  AND A.REC_STT = 'A' AND CURRENT TIMESTAMP BETWEEN A.EFF_S AND "
			+ "A.END_S AND B.BSST_ID = A.BUS_SIT_I AND B.REC_STT_F = 'A' AND B.DIV_ID IN ('HJBT JBVAN', 'HJBT JBDCS') "
			+ "AND C.ADR_I = A.ADR_I AND C.REC_STT = 'A' AND D.CITY_ID = C.CTY_C AND D.REC_STT_F = 'A' WITH UR ", nativeQuery = true)
	List<Object[]> getCityStateForCustomerCode(@Param("cusCode") String cusCode);
	
	@Query(value = "SELECT DISTINCT A.CUS_C, B.DIV_ID, B.BUS_NAME_I, C.ADR_LNE_01, C.ADR_LNE_02, D.CTY_ST_C, D.CITY_ID, D.DSC_T, C.PST_1_C, "
			+ "C.PST_2_C, C.PST_EXT_C, C.ST_C, C.CRY_C, B.BUS_LOC_ID, B.BUS_ID FROM ALI.TBUS_SIT_ADR_ASC A, ALI.TBUSINESS_SITE B, "
			+ "ALI.TADDRESS C, ALI.TCITY D WHERE A.CUS_C = (:cusCode)  AND A.REC_STT = 'A' AND CURRENT TIMESTAMP BETWEEN A.EFF_S AND "
			+ "A.END_S AND B.BSST_ID = A.BUS_SIT_I AND B.REC_STT_F = 'A' AND B.DIV_ID IN ('HJBT JBVAN', 'HJBT JBDCS') "
			+ "AND C.ADR_I = A.ADR_I AND C.REC_STT = 'A' AND D.CITY_ID = C.CTY_C AND D.REC_STT_F = 'A' WITH UR ", nativeQuery = true)
	List<Object[]> getStateCityForCustomerCode(@Param("cusCode") String cusCode);
	
	@Query(value="SELECT CITY.CITY_ID, CITY.DSC_T, CITY.CTY_ST_C, CITY.REC_STT_F, CITY.PNT_I,CITY.ST_ID from ALI.TCITY CITY"
    		+ " WHERE CITY.PNT_I = (:pntI) WITH UR ", nativeQuery = true)
    City findByPnt(@Param("pntI") Integer pntI);
	
	@Query(value="SELECT CITY_ID, DSC_T, CTY_ST_C, REC_STT_F, PNT_I,ST_ID from ALI.TCITY  WHERE DSC_T =:dsc AND ST_ID=:stid WITH UR " , nativeQuery = true)
    City findCityDetailsByState(@Param("dsc") String dsc,@Param("stid") String stid);
	
	@Query(value="SELECT C.AREA_ID FROM ALI.TBUSINESS_SITE A ,ALI.TBUS_SIT_ADR_ASC B  ,ALI.TAREA_POST_CODE  C ,ALI.TAREA D WHERE B.CUS_C = :customerCode AND B.ADR_TYP_C = 'PHYSICAL' AND B.REC_STT = 'A' AND CURRENT TIMESTAMP BETWEEN B.EFF_S AND B.END_S AND A.BSST_ID = B.BUS_SIT_I AND A.DIV_ID = :divId AND CURRENT TIMESTAMP BETWEEN A.EFF_S AND A.END_S AND A.REC_STT_F = 'A' AND A.PST_1_C = C.PST_1_C AND (A.PST_2_C = C.PST_2_C OR C.PST_2_C = ' ') AND (A.PST_EXT_C = C.PST_EXT_C OR C.PST_EXT_C =  ' ') AND A.CNTRY_ID   = C.CNTRY_ID AND C.AREA_TY_ID = :areaTypeId AND C.AREA_INCL_F = 'I' AND C.DIV_ID      = A.DIV_ID AND C.REC_STT_F   = 'A' AND D.DIV_ID = A.DIV_ID AND D.AREA_TY_ID = C.AREA_TY_ID AND D.AREA_ID = C.AREA_ID AND CURRENT DATE BETWEEN D.EFF_D AND D.END_D AND D.REC_STT_F = 'A' ORDER BY C.PST_EXT_C DESC,C.PST_2_C DESC,C.PST_1_C DESC FETCH FIRST ROW ONLY WITH UR" , nativeQuery = true)
    String fetchPickUpArea(@Param("customerCode") String customerCode, @Param("divId") String divId, @Param("areaTypeId") String areaTypeId);

	@Query(value="SELECT CUS_C, CTY_C FROM ALI.TORD_BUS_SIT WHERE ORD_I = :ordId AND OFR_STP_SEQ_NBR =  :seqNo AND USE_F = 'Y' AND REC_STT ='A' WITH UR;" , nativeQuery = true)
    String[][] fetchLocationCode(@Param("ordId") Integer ordId,  @Param("seqNo") Long seqNo);
}
