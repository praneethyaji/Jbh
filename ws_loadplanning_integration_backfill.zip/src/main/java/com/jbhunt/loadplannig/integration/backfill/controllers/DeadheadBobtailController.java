package com.jbhunt.loadplannig.integration.backfill.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.DeadheadBobtailService;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class DeadheadBobtailController extends BackfillBaseController {

	private final DeadheadBobtailService deadheadBobtailService;

	@PatchMapping("/operationalplans/{operationalPlanId}/deadhead")
	public ResponseEntity<BackfillServiceResponse> deadhead(
			@RequestBody final OperationalPlanDTO operationalPlanDTO) throws Exception {
		log.info("Triggered - /backfill/deadheadbobtail");
		deadheadBobtailService.deadHeadBobTail(operationalPlanDTO,CommonConstants.CHECK_CALL_DEADHEAD);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
	
	@PatchMapping("/operationalplans/{operationalPlanId}/bobtail")
	public ResponseEntity<BackfillServiceResponse> bobtail(
			@RequestBody final OperationalPlanDTO operationalPlanDTO) throws Exception {
		log.info("Triggered - /backfill/deadheadbobtail");
		deadheadBobtailService.deadHeadBobTail(operationalPlanDTO,CommonConstants.CHECK_CALL_BOBTAIL);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
}
