package com.jbhunt.loadplannig.integration.backfill.enums;

import java.util.HashMap;
import java.util.Map;

public enum CommentType {

	APPOINTMENT(1, "Appointmnt"), DRIVER(2, "Driver"), GENERAL(3, "General");

	/** The type id. */
	Integer typeId;

	/** The type name. */
	String typeName;

	private static Map<String, String> mapValues = new HashMap<>();

	static{
		mapValues.put("Appointmnt", "A");
		mapValues.put("Driver", "D");
		mapValues.put("General", "C");
	}

	private CommentType(Integer typeId, String name) {
		this.typeId = typeId;
		this.typeName = name;
	}

	public String getTypeName() {
		return typeName;
	}

	public Integer getTypeId() {
		return typeId;
	}
	public static String getCode(String value){
		return mapValues.get(value);
	}
}
