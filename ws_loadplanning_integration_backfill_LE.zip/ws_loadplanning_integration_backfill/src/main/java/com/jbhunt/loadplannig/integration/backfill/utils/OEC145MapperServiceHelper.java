package com.jbhunt.loadplannig.integration.backfill.utils;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOthOrdBuffer9;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutOrdclssLine;

@Service
public class OEC145MapperServiceHelper {

	public Oee5InOthOrdBuffer9 mapOtherOrderBuffer(Oe76OutputChannelData orderDetails) {
		Oee5InOthOrdBuffer9 otherOrderBuffer = new Oee5InOthOrdBuffer9();
		otherOrderBuffer.setOee5InOrdWgt(BigDecimal.TEN);
		for (Oe76OutOrdclssLine oe76OutOrdclssLine : orderDetails.getOe76OutOrdclssBuffer11()) {
			if ("MONITOR".equalsIgnoreCase(oe76OutOrdclssLine.getOe76OutOrdclssRqmClsTypC())) {
				otherOrderBuffer.setOee5InOrdMoniterCd(oe76OutOrdclssLine.getOe76OutOrdclssRqmClsC());
			}
			if ("PYMTMETHOD".equalsIgnoreCase(oe76OutOrdclssLine.getOe76OutOrdclssRqmClsTypC())) {
				otherOrderBuffer.setOee5InOrdPymtMthCd(oe76OutOrdclssLine.getOe76OutOrdclssRqmClsC());
			}
		}
		otherOrderBuffer = populateOtherOrderBuffer9();
		return otherOrderBuffer;
	}

	private Oee5InOthOrdBuffer9 populateOtherOrderBuffer9() {

		Oee5InOthOrdBuffer9 otherOrderBuff = new Oee5InOthOrdBuffer9();
		otherOrderBuff.setOee5InEltTprNm("");
		otherOrderBuff.setOee5InOrgRmpPst1C("");
		otherOrderBuff.setOee5InOrgRmpPst2C("");
		otherOrderBuff.setOee5InDstRmpCtyStC("");
		otherOrderBuff.setOee5InDstRmpPst1C("");
		otherOrderBuff.setOee5InDstRmpPst2C("");
		otherOrderBuff.setOee5InOrgRmpCtyStC("");

		otherOrderBuff.setOee5InOrdWgt(BigDecimal.ZERO);
		otherOrderBuff.setOee5InOrdPcsQ(0);
		otherOrderBuff.setOee5InOrdVol(0);
		otherOrderBuff.setOee5InOrdOwner("");
		otherOrderBuff.setOee5InOrdPymtMthCd("");
		otherOrderBuff.setOee5InOrdOrgTrlNbr("");
		otherOrderBuff.setOee5InOrdMoniterCd("");
		return otherOrderBuff;

	}

}
