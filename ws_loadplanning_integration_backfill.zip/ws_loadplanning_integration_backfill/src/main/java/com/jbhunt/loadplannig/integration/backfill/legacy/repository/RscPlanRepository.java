package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.Plan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RscPlanRepository extends JpaRepository<Plan,Integer> {
    @Query(value = "SELECT BKFIL_RSC_PLAN_I, NEXT_ORD_I, NEXT_LD_I, NEXT_LD_NUM, NEXT_LD_SEQ_NUM, EQP_I, RSC_RSV_I, CRR_RSV_I, JOB_I, " +
            "  TOUR_F, DSP_NBR, PREPLAN_TYPE, PRG_STT_C, ORD_SYS_C  FROM ALI.BKFIL_RSC_PLAN WHERE EQP_I=:eqp_id AND  PRG_STT_C ='S' WITH UR ", nativeQuery = true)
    List<Plan> fetchResourcePlanByEqpId(@Param("eqp_id") Integer eqp_id);

}
