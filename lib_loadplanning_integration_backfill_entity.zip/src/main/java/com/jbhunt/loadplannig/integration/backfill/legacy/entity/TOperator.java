package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TOPERATOR", schema = "ALI")
public class TOperator implements Serializable {

	private static final long serialVersionUID = -3935296297155088210L;

	@Id
	@Column(name = "OPR_ID")
	private Integer operatorId;

	@Column(name = "OPR_CD")
	private String driverid;

	@Column(name = "LST_UPDT_TMSTP_S")
	private String lastUpdateTimeStamp;

}
