package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;

@RepositoryRestResource
public interface CityRepository extends JpaRepository<City, String> {

	@Query(value = "SELECT DISTINCT A.CUS_C, B.DIV_ID, B.BUS_NAME_I, C.ADR_LNE_01, C.ADR_LNE_02, D.CTY_ST_C, D.DSC_T, C.PST_1_C, "
			+ "C.PST_2_C, C.PST_EXT_C, C.ST_C, C.CRY_C, B.BUS_LOC_ID, B.BUS_ID FROM ALI.TBUS_SIT_ADR_ASC A, ALI.TBUSINESS_SITE B, "
			+ "ALI.TADDRESS C, ALI.TCITY D WHERE A.CUS_C = (:cusCode)  AND A.REC_STT = 'A' AND CURRENT TIMESTAMP BETWEEN A.EFF_S AND "
			+ "A.END_S AND B.BSST_ID = A.BUS_SIT_I AND B.REC_STT_F = 'A' AND B.DIV_ID IN ('HJBT JBVAN', 'HJBT JBDCS') "
			+ "AND C.ADR_I = A.ADR_I AND C.REC_STT = 'A' AND D.CITY_ID = C.CTY_C AND D.REC_STT_F = 'A' WITH UR ", nativeQuery = true)
	List<Object[]> getCityStateForCustomerCode(@Param("cusCode") String cusCode);
	
	@Query(value="SELECT CITY.CITY_ID, CITY.DSC_T, CITY.CTY_ST_C, CITY.REC_STT_F, CITY.PNT_I,CITY.ST_ID from ALI.TCITY CITY"
    		+ " WHERE CITY.PNT_I = (:pntI) WITH UR ", nativeQuery = true)
    City findByPnt(@Param("pntI") Integer pntI);
	
	@Query(value="SELECT CITY_ID, DSC_T, CTY_ST_C, REC_STT_F, PNT_I,ST_ID from ALI.TCITY  WHERE DSC_T =:dsc AND ST_ID=:stid WITH UR " , nativeQuery = true)
    City findCityDetailsByState(@Param("dsc") String dsc,@Param("stid") String stid);

}
