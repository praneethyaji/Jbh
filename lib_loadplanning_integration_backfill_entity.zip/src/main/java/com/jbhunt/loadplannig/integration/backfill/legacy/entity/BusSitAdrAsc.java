package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "TBUS_SIT_ADR_ASC", schema = "ALI")
public class BusSitAdrAsc implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "BUS_SIT_I")
	private Integer busSitI;

	@Column(name = "ADR_I")
	private Integer adrI;

	@Column(name = "CUS_C")
	private String cusC;

	@Column(name = "REC_STT")
	private String recSit;

	@Column(name = "EFF_S")
	private String effS;

	@Column(name = "END_S")
	private String endS;

}
