package com.jbhunt.loadplannig.integration.backfill.services;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class LoadEditService {

	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final LoadUpdateService instructionUpdateService;

	@Transactional
	public void loadReference(final OperationalPlanEvent operationalPlanEvent) {
		try {
			saveBackTrackingDetails(operationalPlanEvent.getOperationalPlanDTO(),
					OperationalPlanEventSubType.REFERENCE.name());
			log.info("update Reference web service");
			instructionUpdateService.processReferenceNumberUpdate(operationalPlanEvent);
		} catch (Exception e) {
			log.error("Exception in REFERENCE:", e);
			updateException(operationalPlanEvent.getOperationalPlanDTO(), e);
			throw new JBHuntRuntimeException("Exception Occured in REFERENCE: " + e);
		}

	}

	@Transactional
	public void loadInstruction(final OperationalPlanEvent operationalPlanEvent) {
		try {
			saveBackTrackingDetails(operationalPlanEvent.getOperationalPlanDTO(),
					OperationalPlanEventSubType.INSTRUCTION.name());
			log.info("update Instructions web service");
			instructionUpdateService.processInstructionUpdate(operationalPlanEvent);
		} catch (Exception e) {
			log.error("Exception in INSTRUCTION:", e);
			updateException(operationalPlanEvent.getOperationalPlanDTO(), e);
			throw new JBHuntRuntimeException("Exception Occured in INSTRUCTION: " + e);
		}
	}

	/**
	 * 
	 * @param operationalPlanDTO
	 * @param eventSubType
	 */
	private void saveBackTrackingDetails(final OperationalPlanDTO operationalPlanDTO, final String eventSubType) {
		backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
				eventSubType, "");
	}

	private void updateException(OperationalPlanDTO operationalPlanDTO, Exception e) {
		String errorMesage = ExceptionUtils.getRootCauseMessage(e);
		if (errorMesage != null && errorMesage.length() > 500) {
			errorMesage = errorMesage.substring(0, 500);
		}
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
				errorMesage);
	}
}
