package com.jbhunt.loadplannig.integration.backfill.constants;

public class ApplicationConstants {

    public static final String COLON = ":";
    public static final String BASIC_AUTH_HEADER = "Basic ";
    public static final String AUTHORIZATION = "Authorization";
    public static final String USER_NAME_TOKEN = "usernametoken";
    public static final String EXECUTION_TIMEOUT = "10000";
    public static final String EXECUTION_ISOLATION_THREAD_TIMEOUT_IN_MILLISECONDS = "execution.isolation.thread.timeoutInMilliseconds";
    public static final Integer CONNECTION_MAX_TOTAL = 10;
    

    private ApplicationConstants() {

    }

}