package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.times;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.CityRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplannig.integration.backfill.services.LoadplanningIntegrationOWObackfillService;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc363i.lmc363.LMC363Port;

import wiremock.com.fasterxml.jackson.core.JsonParseException;
import wiremock.com.fasterxml.jackson.databind.JsonMappingException;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class LoadplanintegrationbackfillControllerIT {

	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http").host("loadplanning-test.jbhunt.com")
			.removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

	private static final String TERMINATE_CHECKCALL_REQUEST = "/json/terminateCheckCall.json";

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private OrderLoadRepository orderLoadRepository;

	@MockBean
	private TaskRepository taskRepository;

	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	private EquipmentRepository equipmentRepository;
	
	@MockBean
	private CityRepository cityRepository;
	
	@MockBean
	private LMC363Port lmc363Port;
	
	@MockBean
	private LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;

	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void testTerminateCall() throws JsonParseException, JsonMappingException, IOException, URISyntaxException {
		// ARRANGE

		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(TERMINATE_CHECKCALL_REQUEST)),
				OperationalPlanEvent.class);

		City city = new City();
		city.setCityID("MACHI");
		city.setCtyStC("CHIMA");
		city.setDscT("CHICOPEE");
		city.setPntI(27051);
		city.setRecSttF("A");
		city.setState("MA");
		Mockito.when(cityRepository.findCityDetailsByState(Mockito.anyString(),Mockito.anyString())).thenReturn(city);
		Mockito.when(loadplanningIntegrationOWObackfillService.getCityStateForCustomerCode(Mockito.anyString())).thenReturn("CHIMA");
		TOrder orderDetails = new TOrder();
		orderDetails.setLastUpdateTimeStamp("2019-01-02 10.00.06");
		orderDetails.setOrderId(2345678);
		orderDetails.setOrdrNumber("RA97939");
		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(30005737)).thenReturn(orderDetails);
		Mockito.when(orderLoadRepository.getJobIdbyOrderId(353086)).thenReturn(124578);
		List<Object[]> taskDetails = new ArrayList<>();
		Object[] subtaskDetails = new Object[10];
		subtaskDetails[7] = 1000;
		subtaskDetails[8] = 1000;
		taskDetails.add(subtaskDetails);
		Mockito.when(taskRepository.getStopSeqForTerminateCheckCall(Mockito.any(), Mockito.any())).thenReturn(34);
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh("RA97939")).thenReturn(taskDetails);
		Mockito.when(equipmentRepository.getEquipmentUntiId(353086)).thenReturn("353086");
		Mockito.when(orderLoadRepository.getJobIdbyOrderId(353086)).thenReturn(12456);
		Mockito.when(equipmentRepository.getLastLocationOfTruck(353086)).thenReturn("353086");
		TEquipment tEquipment = new TEquipment();
		tEquipment.setCurrentEstimateTimeArrivelDate("2017-02-20");
		tEquipment.setCurrentEstimateTimeArrivelHour("05.15.00");
		Mockito.when(equipmentRepository.fetchEqpDetailsByEqpId(Integer.toString(353086))).thenReturn(tEquipment);
		Mockito.when(cityRepository.fetchPickUpArea(Mockito.anyString(),Mockito.any(),Mockito.any())).thenReturn("MA");

		wireMockServer.stubFor(WireMock
				.get(WireMock.urlPathEqualTo("/masterdatalocationservices/locations/search/findbylocation/1"))
				.willReturn(WireMock.aResponse().withHeader("Content-Type", "application/json").withBody(
						"{ \"locationProfileDTO\": { \"id\": 10868, \"facilityOperationDTO\": [], \"facilityOverviewRequirementCodeDTO\": [], \"contactDTO\": [], \"addressDTO\": { \"id\": 235523, \"addressLine1\": \"1874 Iron Bridge Rd\", \"addressLine2\": \"\", \"state\": \"KY\", \"city\": \"Bowling Green\", \"cityAliasName\": \"Bowling Green\", \"zipcode\": \"421039757\", \"country\": \"USA\", \"countyName\": \"Warren\", \"latitude\": 36.937973, \"longitude\": -86.254737 }, \"hazmatDTO\": null, \"disallowedEquipmentDTO\": [], \"customerDirections\": null, \"generalInstructions\": null, \"locationCode\": \"IRBO18\", \"locationName\": \"Iron Bridge SOD\" }, \"timezone\": \"America/Chicago\" }")
						.withStatus(200)));

		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		System.out.println("response ---- >>> " + response.asString());
		Mockito.verify(lmc363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

}
