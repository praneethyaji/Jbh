package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.relaxedRequestFields;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.document;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.Activity;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.SubTaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TActivityRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
public class CheckCallUpdateControllerIT {

	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http").host("loadplanning-test.jbhunt.com")
			.removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	@Qualifier("sqlServerjdbcTemplate")
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	@Qualifier("dataSourceDB2")
	private JdbcTemplate dataSourceDB2;

	@MockBean
	private OrderLoadRepository orderLoadRepository;

	@MockBean
	LocationProfileDTOs locationProfileDTOs;

	@MockBean
	TActivityRepository tactivityRepository;

	@MockBean
	SubTaskRepository subTaskRepository;

	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void testEditLoadedCheckCall() throws Exception {
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String responseMasterDataLocation = IOUtils
				.toString(this.getClass().getResourceAsStream("/json/MasterDataLocation.json"));

		wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/62980"))
				.willReturn(aResponse().withHeader("Content-type", "application/json")
						.withBody(responseMasterDataLocation).withStatus(200)));

		TOrder orderDetails = new TOrder();
		orderDetails.setOrderId(4567899);
		orderDetails.setOrdrNumber("R175295");
		orderDetails.setOrderCreatedTimeStamp("2019-10-08 12:18:43.45179");

		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(30022262)).thenReturn(orderDetails);

		Activity activity = new Activity();
		activity.setAtyTyId("SHPRLOAD");
		activity.setSrceId(505919652);
		Mockito.when(tactivityRepository.findBySrceIdAndAtyTyId(505919652, "SHPRLOAD")).thenReturn(activity);
		Activity activity1 = new Activity();
		activity1.setAtyTyId("DRVRCNT");
		activity1.setSrceId(505919652);
		Mockito.when(tactivityRepository.findBySrceIdAndAtyTyId(505919652, "DRVRCNT")).thenReturn(activity1);

		TSubtask1 tSubtask1 = new TSubtask1();
		tSubtask1.setSubTaskID(505919652);
		tSubtask1.setCityId("KYBG");
		tSubtask1.setPreferanceSequenceNumber(1000);
		tSubtask1.setTaskId(4567899);
		Mockito.when(subTaskRepository.fetchByTaskIdAndCityIdAndRequestTyId(4567899, "KYBG", 1))
				.thenReturn(tSubtask1);

		OperationalPlanDTO operationalPlanDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadedCheckCallEditUpdated.json")),
				OperationalPlanDTO.class);

		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.filter(document("ProcessCheckCalls", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processCheckCallsRequest())))
				.contentType(ContentType.JSON).body(operationalPlanDTO)
				.patch("/ws_loadplanning_integration_backfill/backfill/checkcalls/loaded");

	}

	private static FieldDescriptor[] processCheckCallsRequest() {
		return new FieldDescriptor[] {
				fieldWithPath("operationalPlanEventSubTypes[]")
						.description("operationalPlanEventSubTypes of the checkCall"),
				fieldWithPath("operationalPlanEventType")
						.description("operational Plan Event Type code, it can be operational Plan Event Type"),
				fieldWithPath("operationalPlanStops[].locationId").description("location id").type(Integer.class) };

	}

}
