package com.jbhunt.loadplannig.integration.backfill.services;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.City;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.VEquipmentLse;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.VEquipmentLseRepository;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.jbhunt.mdm.dto.LocationProfileDTO;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.jbhunt.operations.equipmentgroup.dto.OpexEquipmentLocationUpdateDTO;
import com.lmc362i.lmc362.LMC362Port;
import com.lmc366i.lmc366.LMC366Port;
import com.request.lmc362i.lmc362.ProgramInterface;
import com.request.lmc366i.lmc366.ProgramInterface.Wo66InputArea;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AllArgsConstructor
@Service
public class BeamingIntegrationBackfillService {

	private final MasterdataAssetClient masterdataAssetClient;
	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;
	private final VEquipmentLseRepository vEquipmentLseRepository;
	private final LocationClient locationClient;
	private final LMC362Port lmc362Port;
	private final LMC366Port lmc366Port;
	private final EquipmentRepository equipmentRepository;

	public void beaming(OpexEquipmentLocationUpdateDTO equipmentLocationUpdateDTO) throws URISyntaxException, JSONException {
		log.info("BeamingIntegrationBackfillService.beaming");

		EquipmentDetailsDTO equipmentDetailsDTO = Optional
				.ofNullable(masterdataAssetClient.getEquipmentDetails(Arrays.asList(equipmentLocationUpdateDTO.getEquipmentId())))
				.orElseThrow(() -> new JBHuntRuntimeException("Equipment details not found.")).stream().findFirst()
				.orElseThrow(() -> new JBHuntRuntimeException("Equipment details not found."));

		if (equipmentDetailsDTO.getEquipmentPrefix().isEmpty()) {
			TEquipment tEquipment = Optional
					.ofNullable(equipmentRepository
							.fetchEqpDetailsByEqpId(Integer.toString(equipmentDetailsDTO.getLegacyEquipmentId())))
					.orElseThrow(() -> new JBHuntRuntimeException("Equipment detail not found"));
			Wo66InputArea wo66InputArea = new Wo66InputArea();
			wo66InputArea.setWo66EqpId(equipmentDetailsDTO.getLegacyEquipmentId());
			String cityStateCode = null;
			if (equipmentLocationUpdateDTO.getCityId() != null) {
				City cityState = loadplanningIntegrationOWObackfillService
						.getCityStateCodeByCityID(equipmentLocationUpdateDTO.getCityId());
				cityStateCode = cityState.getCtyStC();
			} else {
				String customerCode = Optional
						.ofNullable(locationClient.findLocationProfilebyLocationCode(equipmentLocationUpdateDTO.getLocationId()))
						.map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode)
						.orElseThrow(() -> new JBHuntRuntimeException("Location Profile not found."));
				cityStateCode = Optional
						.ofNullable(loadplanningIntegrationOWObackfillService.getCityStateForCustomerCode(customerCode))
						.map(String::trim).filter(StringUtils::isNotEmpty).orElse("");
			}
			wo66InputArea.setWo66CityId(cityStateCode);
			wo66InputArea.setWo66DstArC(equipmentLocationUpdateDTO.getStateCode());
			wo66InputArea.setWo66LstUpdtTmstpS(tEquipment.getLastUpdatedTimestamp());
			wo66InputArea.setWo66UserId(CommonConstants.USER_ID);

			com.response.lmc366i.lmc366.ProgramInterface.Wo66OutputArea wo66OutputArea = lmc366Port
					.lmc366Operation(wo66InputArea);
			String messageError = "";
			messageError = wo66OutputArea.getWo66ErrorMessage().trim();
			log.info("result of the Beaming operation from the mainframe ErrorFlag: {}",
					wo66OutputArea.getWo66ReturnFlag());
			log.info("result of the Beaming operation from the mainframe ErrorMessage: {}", messageError);
			if (!StringUtils.isEmpty(messageError)) {
				throw new JBHuntRuntimeException(messageError);
			}
		} else {
			String customerCode = Optional
					.ofNullable(locationClient.findLocationProfilebyLocationCode(equipmentLocationUpdateDTO.getLocationId()))
					.map(LocationProfileDTOs::getLocationProfileDTO).map(LocationProfileDTO::getLocationCode)
					.orElseThrow(() -> new JBHuntRuntimeException("Location Profile not found."));

			String divisionIn = Optional
					.ofNullable(vEquipmentLseRepository.getEquipmentLseInfo(equipmentDetailsDTO.getEquipmentNumber(),
							equipmentDetailsDTO.getEquipmentPrefix()))
					.map(VEquipmentLse::getDivisionId)
					.orElseThrow(() -> new JBHuntRuntimeException("Division is not available."));
			ProgramInterface.Lmc362IJavaSentVariables lmc362IJavaSentVariables = new ProgramInterface.Lmc362IJavaSentVariables();

			ProgramInterface.Lmc362IJavaSentVariables.Lmc362IRequiredData lmc362IRequiredData = new ProgramInterface.Lmc362IJavaSentVariables.Lmc362IRequiredData();
			lmc362IJavaSentVariables.setLmc362IRequiredData(lmc362IRequiredData);
			lmc362IRequiredData.setLmc362IDataTypeIn(CommonConstants.BOX_LOC_INT);
			lmc362IRequiredData.setLmc362INetAccIIn(0);
			lmc362IRequiredData.setLmc362INetApIIn(CommonConstants.NET_APP_IN);
			lmc362IRequiredData.setLmc362IUserId(CommonConstants.USER_ID);

			ProgramInterface.Lmc362IJavaSentVariables.Lmc362IPoolDataIn lmc362IPoolDataIn = new ProgramInterface.Lmc362IJavaSentVariables.Lmc362IPoolDataIn();
			lmc362IJavaSentVariables.setLmc362IPoolDataIn(lmc362IPoolDataIn);
			lmc362IPoolDataIn.setLmc362IBusLocIIn(0);
			lmc362IPoolDataIn.setLmc362IDivCIn(divisionIn);
			lmc362IPoolDataIn.setLmc362ICustCodeIn(customerCode);

			ProgramInterface.Lmc362IJavaSentVariables.Lmc362IBoxUpdtIn lmc362IBoxUpdtIn = new ProgramInterface.Lmc362IJavaSentVariables.Lmc362IBoxUpdtIn();
			lmc362IJavaSentVariables.setLmc362IBoxUpdtIn(lmc362IBoxUpdtIn);
			lmc362IBoxUpdtIn.setLmc362IEquipIdIn(0);
			lmc362IBoxUpdtIn.setLmc362IEquipNbrIn(equipmentDetailsDTO.getEquipmentNumber());
			lmc362IBoxUpdtIn.setLmc362IEquipPfxIn(equipmentDetailsDTO.getEquipmentPrefix());

			com.response.lmc362i.lmc362.ProgramInterface.Lmc362OReturnToJava lmc362OReturnToJava = lmc362Port
					.lmc362Operation(lmc362IJavaSentVariables);

			Optional.ofNullable(lmc362OReturnToJava.getLmc362OErrorFields()).ifPresent(comErrorField -> {
				String messageError = "";
				messageError = comErrorField.getLmc362OErrorMessage().trim();
				log.info("result of the Beaming operation from the mainframe ErrorFlag: {}",
						comErrorField.getLmc362OErrorFlag());
				log.info("result of the Beaming operation from the mainframe ErrorMessage: {}", messageError);
				if (!StringUtils.isEmpty(messageError)) {
					throw new JBHuntRuntimeException(messageError);
				}
				log.info("Response from mainframe: {}", lmc362OReturnToJava.getLmc362OErrorFields());
			});

		}
	}
}
