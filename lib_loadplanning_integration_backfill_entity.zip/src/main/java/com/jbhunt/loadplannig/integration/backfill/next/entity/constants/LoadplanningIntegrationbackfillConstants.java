package com.jbhunt.loadplannig.integration.backfill.next.entity.constants;

public class LoadplanningIntegrationbackfillConstants {

    public static final String DATE_TIME_OFFSET_FORMATTER_PATTERN = "yyyy-MM-dd HH:mm:ss.SSSSSSS XXX";
    private LoadplanningIntegrationbackfillConstants() {

    }

}