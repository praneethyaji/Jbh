package com.jbhunt.loadplannig.integration.backfill.services;

import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.RsvrscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CommonUtils;
import com.jbhunt.loadplannig.integration.backfill.utils.PairingTruckAndDriverHelper;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.operations.drivertruckassignment.dto.PersonESDTO;
import com.jbhunt.operations.drivertruckassignment.dto.ResourceESDTO;
import com.jbhunt.personnel.client.PersonnelPeopleClient;
import com.jbhunt.personnel.people.dto.PeopleDetailsDTO;
import com.lmc345i.lmc345.LMC345Port;
import com.lmc360i.lmc360.LMC360Port;
import com.request.lmc345i.lmc345.ProgramInterface;
import com.request.lmc360i.lmc360.ProgramInterface.Wo60InputArea;
import com.response.lmc360i.lmc360.ProgramInterface.Wo60OutputArea;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class DriverAndTruckPairingService {

	private LMC360Port lmc360Port;
	private PersonnelPeopleClient personnelPeopleClient;
	private MasterdataAssetClient masterdataAssetClient;
	private final PairingTruckAndDriverHelper pairingTruckAndDriverHelper;
	private RsvrscRepository rsvrscRepository;
	private LMC345Port lmc345Port;
	private TaskRepository taskRepository;

	public void pairingofTruckAndDriver(ResourceESDTO resourceESDTO) throws URISyntaxException {
		for (PersonESDTO driver : resourceESDTO.getPerson()) {
			PeopleDetailsDTO peopleDetailsDTO = personnelPeopleClient.getPersonDetails(driver.getDriverPersonId());
			EquipmentDetailsDTO equipmentDetailsDTO = Optional
					.ofNullable(
							masterdataAssetClient.getEquipmentDetails(Arrays.asList(resourceESDTO.getEquipmentId())))
					.orElseThrow(() -> new JBHuntRuntimeException("Equipment details not found.")).stream().findFirst()
					.orElseThrow(() -> new JBHuntRuntimeException("Equipment details not found."));
			if (!pairingTruckAndDriverHelper.isAlreadyPaired(equipmentDetailsDTO.getLegacyEquipmentId(),
					peopleDetailsDTO.getAlphaCode(), CommonConstants.ISBOTHPAIRED)) {
				Wo60InputArea inputArea = new Wo60InputArea();
				inputArea.setWo60Driver1Code(peopleDetailsDTO.getAlphaCode());
				inputArea.setWo60Driver2Code(CommonConstants.EMPTY_SPACE);
				inputArea.setWo60InputFiller(CommonConstants.EMPTY_SPACE);
				inputArea.setWo60UnitNbr(equipmentDetailsDTO.getEquipmentNumber());
				inputArea.setWo60UserId(CommonConstants.USER_ID);
				Wo60OutputArea response = lmc360Port.lmc360Operation(inputArea);
				Optional.ofNullable(response.getWo60ErrorMessage()).map(String::trim).ifPresent(error -> {
					log.info("result of the operation from the mainframe ErrorMessage: {}", error);
					if (!StringUtils.isEmpty(error)) {
						throw new JBHuntRuntimeException(error);
					}
				});
				log.info("lmc360Operation response: {}", CommonUtils.asString(response));
			} 
			log.info("alpha code {}", peopleDetailsDTO.getAlphaCode());
			List<Object[]> reservationsList = rsvrscRepository.fetchResourcePlanByDriverAlphaCode(peopleDetailsDTO.getAlphaCode());
			transfer(reservationsList,equipmentDetailsDTO,peopleDetailsDTO);
		}
	}
	private void transfer(List<Object[]> reservationsList,EquipmentDetailsDTO equipmentDetailsDTO,PeopleDetailsDTO peopleDetailsDTO){
		int ordDtlCnt = reservationsList.size();
		for (Object[] reservation:reservationsList) {
			log.info("Starting Transfer, Miltiple reservations for this Driver : {}  ", peopleDetailsDTO.getAlphaCode());
			List<Object[]> stopForTransfer =  taskRepository.findOrderStopForTransfer(peopleDetailsDTO.getAlphaCode(),(Integer)reservation[1]);
			log.info("Legacy EquipmentId: {}",equipmentDetailsDTO.getLegacyEquipmentId());
			ProgramInterface.Lmc345CommArea lmc345CommArea = new ProgramInterface.Lmc345CommArea();
			ProgramInterface.Lmc345CommArea.Lmc345InputArea lmc345InputArea = new ProgramInterface.Lmc345CommArea.Lmc345InputArea();
			ProgramInterface.Lmc345CommArea.Lmc345InputArea.Lmc345MultiPp lmc345MultiPp = new ProgramInterface.Lmc345CommArea.Lmc345InputArea.Lmc345MultiPp();

			lmc345MultiPp.setLmc345MpTractorNbr(equipmentDetailsDTO.getEquipmentNumber().trim());
			String tractorDriver = getFormattedDriverValue(peopleDetailsDTO.getAlphaCode());
			lmc345MultiPp.setLmc345MpTractorDriver(tractorDriver);
			lmc345MultiPp.setLmc345MpTractorEqpId(equipmentDetailsDTO.getLegacyEquipmentId());
			lmc345MultiPp.setLmc345MpOrdDtlCnt(ordDtlCnt);
			ProgramInterface.Lmc345CommArea.Lmc345InputArea.Lmc345MultiPp.Lmc345MpOrdDtlTable lmc345MpOrdDtlTable = new ProgramInterface.Lmc345CommArea.Lmc345InputArea.Lmc345MultiPp.Lmc345MpOrdDtlTable();

			Object[] stop2=null;
			for (Object[] stop:stopForTransfer ) {
				ProgramInterface.Lmc345CommArea.Lmc345InputArea.Lmc345MultiPp.Lmc345MpOrdDtlTable.Lmc345MpStopTable lmc345MpStop = new ProgramInterface.Lmc345CommArea.Lmc345InputArea.Lmc345MultiPp.Lmc345MpOrdDtlTable.Lmc345MpStopTable();
				lmc345MpOrdDtlTable.getLmc345MpStopTable().add(lmc345MpStop);
				lmc345MpStop.setLmc345MpPrfSeqN(((Integer)stop[7]));
				lmc345MpStop.setLmc345MpStskId((Integer)stop[6]);
				lmc345MpStop.setLmc345MpBsstId((Integer)stop[8]);
				lmc345MpStop.setLmc345MpRqTyId(((String)stop[9]).trim());
				String stateCityLocation = ((String)stop[10]).trim();
				lmc345MpStop.setLmc345MpCityId(convertingCityStateLocation(stateCityLocation,stateCityLocation.length()));
				stop2=stop;
			}
			stop2=Optional.ofNullable(stop2).orElseThrow(()-> new JBHuntRuntimeException("Stop doesn't exist."));
			lmc345MpOrdDtlTable.setLmc345MpOrdNbr((String)stop2[1]);
			lmc345MpOrdDtlTable.setLmc345MpTaskId(((Integer)stop2[0]));
			lmc345MpOrdDtlTable.setLmc345MpActionType(CommonConstants.TEN_ZEROS);
			lmc345MpOrdDtlTable.setLmc345MpReasonCode(CommonConstants.TEN_ZEROS);
			lmc345MpOrdDtlTable.setLmc345MpXfrFromDrSw("D");
			lmc345MpOrdDtlTable.setLmc345MpRscRsvI((Integer)stop2[4]);
			lmc345MpOrdDtlTable.setLmc345MpRsvLstUpdS((String)stop2[5]);
			lmc345MpOrdDtlTable.setLmc345MpTaskLstUpdS((String)stop2[3]);
			lmc345MpOrdDtlTable.setLmc345MpOrdPpSw("Y");
			lmc345MpOrdDtlTable.setLmc345MpPnlVal(CommonConstants.TEN_ZEROS);
			lmc345MpOrdDtlTable.setLmc345MpOrdPnlVal(CommonConstants.TEN_ZEROS);
			lmc345MpOrdDtlTable.setLmc345MpStopCnt(stopForTransfer.size());
			lmc345MultiPp.getLmc345MpOrdDtlTable().add(lmc345MpOrdDtlTable) ;

			lmc345InputArea.setLmc345MultiPp(lmc345MultiPp);
			lmc345InputArea.setLmc345TransferToSw("M");
			lmc345InputArea.setLmc345Userid(CommonConstants.USER_ID);
			lmc345InputArea.setLmc345CallingPgm("LMC345");
			lmc345CommArea.setLmc345InputArea(lmc345InputArea);
			com.response.lmc345i.lmc345.ProgramInterface.Lmc345OutputArea  lmc345OutputArea= lmc345Port.lmc345Operation(lmc345CommArea);
			Optional.ofNullable(lmc345OutputArea.getLmc345ErrorMessage()).map(String::trim).ifPresent( error->{
				log.info("result of the operation from the mainframe ErrorMessage: {}", error);
				if (!StringUtils.isEmpty(error)) {
					throw new JBHuntRuntimeException(error);
				}
			});
		}
	}
	private  String getFormattedDriverValue(String value){
		return String.format("%1$10s", value).replace(' ','0');
	}
	private static String convertingCityStateLocation(String location, int length) {
		String state = location.substring(0, 2);
		String city = location.substring(2, length);
		return length > 4 ? city.concat(state) : city.concat(" ").concat(state);
	}
}
