package com.jbhunt.loadplannig.integration.backfill.services;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.xml.ws.Holder;

import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.BkfilOwoJaAscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadSyncRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CheckCallHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.DriverAssignmentDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.EquipmentAssignmentDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanResourceAssignmentAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanTypeDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanWorkOrderAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanTypeDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;
import com.jbhunt.masterdata.client.MasterdataAssetClient;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.operations.drivertruckassignment.dto.PersonESDTO;
import com.jbhunt.operations.drivertruckassignment.dto.ResourceESDTO;
import com.lmc363i.lmc363.LMC363Port;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord;
import com.response.lmc363i.lmc363.ProgramInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j

public class DriverAndTruckUnpairingService {

	private final MasterdataAssetClient masterdataAssetClient;
	private final EquipmentRepository equipmentRepository;
	private final LMC363Port lmc363Port;
	private final CheckCallHelper checkCallHelper;
	private final DriverAndTruckAssignmentService driverAndTruckAssignmentService;
	private final OrderLoadSyncRepository orderLoadSyncRepository;
	private final BkfilOwoJaAscRepository bkfilOwoJaAscRepository;

	public void unpairingOfTruckAndDriver(ResourceESDTO resourceESDTO) throws Exception {
		log.info("DriverAndTruckUnpairingService.unpairingOfTruckAndDriver");
		for (PersonESDTO driver : resourceESDTO.getPerson()) {
			EquipmentDetailsDTO equipmentDetailsDTO = Optional
					.ofNullable(
							masterdataAssetClient.getEquipmentDetails(Arrays.asList(resourceESDTO.getEquipmentId())))
					.orElseThrow(() -> new JBHuntRuntimeException("Equipment details not found.")).stream().findFirst()
					.orElseThrow(() -> new JBHuntRuntimeException("Equipment details not found."));

			List<Integer> normalLoads = orderLoadSyncRepository
					.getPlannedNewOrderIdsBylegacyEquipmentId((equipmentDetailsDTO.getEquipmentNumber()));

			List<Integer> owoLoads = bkfilOwoJaAscRepository
					.getPlannedNewOwoOrderIdsBylegacyEquipmentId((equipmentDetailsDTO.getEquipmentNumber()));

			if (resourceESDTO.getResourceType().contains("Truck") && (normalLoads.size() > 0 || owoLoads.size() > 0)) {
				driverAndTruckAssignmentService.driverAndTruckAssignment(
						formOperationalPlanDTO(resourceESDTO.getEquipmentId(), driver.getDriverPersonId(), normalLoads),
						"T", "D", OperationalPlanEventSubType.UNASSIGN_TRUCK.name());
			}

			LocalDateTime adt = LocalDateTime.now();
			TEquipment tEquipment = equipmentRepository
					.fetchEqpDetailsByEqpId(Integer.toString(equipmentDetailsDTO.getLegacyEquipmentId()));

			CheckcallDTO checkcallDTO = new CheckcallDTO();
			checkcallDTO.setComment(String.format(CommonConstants.FREE_COMMENTS, checkcallDTO.getEqpId()));
			checkcallDTO.setDataState(CommonConstants.DATA_STATE_B);
			checkcallDTO.setUserId(CommonConstants.USER_ID);
			checkcallDTO.setJobId(0);
			checkcallDTO.setEqpId(equipmentDetailsDTO.getLegacyEquipmentId());
			checkcallDTO.setTractorNbr(tEquipment.getTrailerNumber());
			checkcallDTO.setTractorRqdFlg(CommonConstants.TRACTOR_RQD_FLAG);
			checkcallDTO.setCallType(CommonConstants.FREE_CALL_TYPE);
			checkcallDTO.setLocationCityState(tEquipment.getLastLocation().trim());
			checkcallDTO.setComments(
					String.format(CommonConstants.FREE_COMMENTS, equipmentDetailsDTO.getEquipmentNumber()));

			DateTimeFormatter sdfDate = DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT);
			DateTimeFormatter sdfTime = DateTimeFormatter.ofPattern(CommonConstants.TIME_FORMAT);
			checkcallDTO.setLoadUnloadDate(adt.format(sdfDate));
			checkcallDTO.setLoadUnloadtime(adt.format(sdfTime));
			log.info(" values to be passed :{}", checkcallDTO);

			Lm36ComCommareaRecord lm36ComCommareaRecord = checkCallHelper.createLm36ComCommareaRecord(checkcallDTO);
			com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava lm36ComReturnToJava = checkCallHelper
					.getLm36ComReturnToJava(checkcallDTO);

			javax.xml.ws.Holder<ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder = new Holder<>();
			javax.xml.ws.Holder<String> lm36ComFillerOutputHolder = new Holder<>();
			javax.xml.ws.Holder<ProgramInterface.Lm36ComCommareaOutputRecord> lm36ComCommareaOutputRecordHolder = new Holder<>();
			String lm36ComFiller = "";

			lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava, lm36ComFiller,
					lm36ComCommareaOutputRecordHolder, lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);

			checkCallHelper.loggingCheckcallResponse(lm36ComReturnToJavaOutputHolder);
			log.info("result of the freeCall operation from the mainframe: {} ", lm36ComFillerOutputHolder.value);
		}
	}

	private OperationalPlanDTO formOperationalPlanDTO(Integer equipmentId, String driverPersonId,
			List<Integer> normalLoads) {
		OperationalPlanDTO operationalPlanDTO = new OperationalPlanDTO();
		List<OperationalPlanResourceAssignmentAssociationDTO> operationalPlanResourceAssignmentAssociationList = new ArrayList<>();
		OperationalPlanResourceAssignmentAssociationDTO operationalPlanResourceAssignmentAssociationDTO = new OperationalPlanResourceAssignmentAssociationDTO();
		operationalPlanResourceAssignmentAssociationDTO.setOperationalPlanResourceAssignmentAssociationId(1);
		ResourceAssignmentPlanDTO resourceAssignmentPlan = new ResourceAssignmentPlanDTO();
		ResourceAssignmentPlanTypeDTO resourceAssignmentPlanType = new ResourceAssignmentPlanTypeDTO();
		EquipmentAssignmentDTO equipmentAssignmentDTO = new EquipmentAssignmentDTO();
		equipmentAssignmentDTO.setEquipmentId(equipmentId);
		DriverAssignmentDTO driverAssignmentDTO = new DriverAssignmentDTO();
		driverAssignmentDTO.setDriverId(driverPersonId);
		resourceAssignmentPlanType.setResourceAssignmentPlanTypeCode(CommonConstants.STANDARD_PLAN);
		resourceAssignmentPlan.setEquipmentAssignments(equipmentAssignmentDTO);
		resourceAssignmentPlan.setDriverAssignment(driverAssignmentDTO);
		resourceAssignmentPlan.setResourceAssignmentPlanType(resourceAssignmentPlanType);
		operationalPlanResourceAssignmentAssociationDTO.setResourceAssignmentPlan(resourceAssignmentPlan);
		operationalPlanResourceAssignmentAssociationList.add(operationalPlanResourceAssignmentAssociationDTO);
		operationalPlanDTO.setCreateUserId(CommonConstants.USER_ID);
		operationalPlanDTO
				.setOperationalPlanResourceAssignmentAssociationList(operationalPlanResourceAssignmentAssociationList);
		OperationalPlanTypeDTO operationalPlanTypeDTO = new OperationalPlanTypeDTO();
		if (normalLoads.size() > 0) {
			List<OrderOperationalPlanAssociationDTO> orderOperationalPlanAssociationList = new ArrayList<>();
			operationalPlanDTO.setOrderOperationalPlanAssociations(orderOperationalPlanAssociationList);
			operationalPlanTypeDTO.setOperationalPlanTypeCode("Freight");
		} else {
			List<OperationalPlanWorkOrderAssociationDTO> OperationalPlanWorkOrderAssociationList = new ArrayList<>();
			operationalPlanDTO.setOperationalPlanWorkOrderAssociations(OperationalPlanWorkOrderAssociationList);
			operationalPlanTypeDTO.setOperationalPlanTypeCode("OWO");
		}
		operationalPlanDTO.setOperationalPlanType(operationalPlanTypeDTO);
		return operationalPlanDTO;
	}
}
