package com.jbhunt.loadplannig.integration.backfill.interceptor;

import static com.jbhunt.loadplannig.integration.backfill.constants.ApplicationConstants.AUTHORIZATION;
import static com.jbhunt.loadplannig.integration.backfill.constants.ApplicationConstants.BASIC_AUTH_HEADER;
import static com.jbhunt.loadplannig.integration.backfill.constants.ApplicationConstants.COLON;
import static com.jbhunt.loadplannig.integration.backfill.constants.ApplicationConstants.USER_NAME_TOKEN;

import java.io.IOException;
import java.util.Base64;
import java.util.Optional;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class BasicAuthInterceptor implements ClientHttpRequestInterceptor {

    private final String username;
    private final String password;

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        final String auth = username + COLON + password;
        final byte[] encodeAuth = Base64.getEncoder().encode(auth.getBytes());
        final String authHeader = BASIC_AUTH_HEADER + new String(encodeAuth);
        request.getHeaders().add(AUTHORIZATION, authHeader);
        request.getHeaders().add(USER_NAME_TOKEN, getLoggedInUser());
        return execution.execute(request, body);
    }

    private String getLoggedInUser() {
        return Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication())
                .map(Authentication::getPrincipal).filter(UserDetails.class::isInstance).map(UserDetails.class::cast)
                .map(UserDetails::getUsername).orElse(null);
    }

}