package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.relaxedRequestFields;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.document;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.common.Slf4jNotifier;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.operations.trackandtrace.dto.CommentCallDTO;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc363i.lmc363.LMC363Port;

import lombok.extern.slf4j.Slf4j;
import wiremock.org.apache.http.HttpStatus;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
@Slf4j
public class CommentCheckCallsControllerIT {
	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();
	// @EndpointInject(uri = "mock:topic:OPERATIONSEXECUTION.T.ADHOC.CHECKCALL")
	// private MockEndpoint mockEndpoint;

	@LocalServerPort
	private int port;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http").host("loadplanning-test.jbhunt.com")
			.removePort();

	protected RequestSpecification requestSpecification;

	public static final String userName = "user";

	public static final String password = "pass";

	@Autowired
	private ObjectMapper objectMapper;


	public static WireMockServer wireMockServer;

	@MockBean
	private OrderLoadRepository orderLoadRepository;

	@MockBean
	private TaskRepository taskRepository;
	
	@MockBean
	private EquipmentRepository equipmentRepository;
	
	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	private LMC363Port lmc363Port;

	private static final String COMMENT_CHECKCALL_REQUEST = "/json/CommentCheckCallRequest.json";
	// private static final String COMMENT_CHECKCALL_NEGATIVE_REQUEST =
	// "/json/CommentCheckCallNegativeRequest.json";

	@Before
	public void setup() {
		
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();
		wireMockServer.resetAll();
		// mockEndpoint.reset();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		RestAssured.basePath = "/ws_loadplanning_integration_backfill";
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");

		WireMockConfiguration confg = new WireMockConfiguration();
		confg.notifier(new Slf4jNotifier(true));
		confg.port(WIREMOCK_PORT);
		wireMockServer = new WireMockServer(confg);
		wireMockServer.start();

	}

	@Test
	public void testAddCommentCall() throws IOException, URISyntaxException, InterruptedException {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		CommentCallDTO commentCallDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(COMMENT_CHECKCALL_REQUEST)), CommentCallDTO.class);
		TOrder orderDetails = new TOrder();
		//orderDetails.setLastOrderNumber("RA97939");
		orderDetails.setLastUpdateTimeStamp("2019-01-02 10.00.06");
		orderDetails.setOrderId(2345678);
		orderDetails.setOrdrNumber("RA97939");
		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(1010479)).thenReturn(orderDetails);
		Mockito.when(orderLoadRepository.getJobIdbyOrderId(353086)).thenReturn(124578);
		List<Object[]> taskDetails = new ArrayList();
		Object[] subtaskDetails = new Object[10];
		subtaskDetails[7] = 1000;
		subtaskDetails[8] = 1000;
		taskDetails.add(subtaskDetails);
		Mockito.when(taskRepository.getStopSeqForTerminateCheckCall(Mockito.any(),Mockito.any())).thenReturn(34);
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh("RA97939")).thenReturn(taskDetails);
		
		TEquipment equipmentDetails = new TEquipment();
		equipmentDetails.setCurrentEstimateTimeArrivelDate("2019-08-29");
		equipmentDetails.setCurrentEstimateTimeArrivelHour("14.45.00");
		Mockito.when(equipmentRepository.fetchEqpDetailsByEqpId("353086")).thenReturn(equipmentDetails);
		
		/*Mockito.when(equipmentRepository.getEquipmentUntiId(353086)).thenReturn("351376");*/
		// ACT
		Response response = given(this.requestSpecification).log().all().auth().basic(userName, password)
				.filter(document("ProcessCommentCheckCalls", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processCommentCheckCallsRequest())))
				.accept(ContentType.JSON).contentType(ContentType.JSON).body(commentCallDTO)
				.patch("/backfill/commentcalls");
		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
		// mockEndpoint.assertIsSatisfied();
	}

	@Test
	public void testAddCommentCallforETA() throws IOException, URISyntaxException, InterruptedException {
		// ARRANGE
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		CommentCallDTO commentCallDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(COMMENT_CHECKCALL_REQUEST)), CommentCallDTO.class);
		TOrder orderDetails = new TOrder();
		//orderDetails.setLastOrderNumber("RA97939");
		orderDetails.setLastUpdateTimeStamp("2019-01-02 10.00.06");
		orderDetails.setOrderId(2345678);
		orderDetails.setOrdrNumber("RA97939");
		Mockito.when(orderLoadRepository.findLoadDetailsByOrderID(1010479)).thenReturn(orderDetails);
		Mockito.when(orderLoadRepository.getJobIdbyOrderId(353086)).thenReturn(124578);
		List<Object[]> taskDetails = new ArrayList();
		Object[] subtaskDetails = new Object[10];
		subtaskDetails[7] = 1000;
		subtaskDetails[8] = 1000;
		taskDetails.add(subtaskDetails);
		Mockito.when(taskRepository.findOrdDetailsByOrdNbrCh("RA97939")).thenReturn(taskDetails);
		
		TEquipment equipmentDetails = new TEquipment();
		equipmentDetails.setCurrentEstimateTimeArrivelDate("2019-08-29");
		equipmentDetails.setCurrentEstimateTimeArrivelHour(null);
		Mockito.when(equipmentRepository.fetchEqpDetailsByEqpId("353086")).thenReturn(equipmentDetails);
		// ACT
		Response response = given(this.requestSpecification).log().all().auth().basic(userName, password)
				.filter(document("ProcessCommentCheckCalls", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processCommentCheckCallsRequest())))
				.accept(ContentType.JSON).contentType(ContentType.JSON).body(commentCallDTO)
				.patch("/backfill/commentcalls");
		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
		// mockEndpoint.assertIsSatisfied();
	}
	private static FieldDescriptor[] processCommentCheckCallsRequest() {
		return new FieldDescriptor[] { fieldWithPath("temperature").description("Temperature of the truck"),
				fieldWithPath("unitOfMeasurementCode")
						.description("Unit of temperature measurement code, it can be Celsius / Fahrenheit"),
				fieldWithPath("comment").description("Comment Text -Start Loaded at + <Stop Number> + <StartDateTime>"),
				fieldWithPath("isLoadComment").description("Attribute to mention, store the comment into load level"),
				fieldWithPath("operationalPlanId")
						.description("Represent the check call comment belongs to which operational plan"),
				fieldWithPath("personList").description(
						"Represent the list of people details (personId, emailId), list may empty when user not tries to post mail") };
	}

}
