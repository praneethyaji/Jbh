package com.jbhunt.loadplannig.integration.backfill.services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.BkfilOrdLdAsc;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.QBkfilOrdLdAsc;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.BkfilOrdLdAscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.LegacyOrderOperationalPlanAssociationRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.BkfilOwoJaAscResponse;
import com.jbhunt.loadplannig.integration.backfill.utils.CommonUtils;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;
import com.querydsl.core.types.Predicate;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class LoadplanningIntegrationbackfillService {
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final LegacyOrderOperationalPlanAssociationRepository legacyOrderOperationalPlanAssociationRepository;
	private final BkfilOrdLdAscRepository bkfilOrdLdAscRepository;
	private final OrderLoadRepository orderLoadRepository;
	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;

	public void loadCreate(OperationalPlanEvent operationalPlanEvent) {
		List<OperationalPlanEventSubType> operationalPlanEventSubTypes = operationalPlanEvent
				.getOperationalPlanEventSubTypes().stream().collect(Collectors.toList());
		if (operationalPlanEventSubTypes.contains(OperationalPlanEventSubType.CREATE_FREIGHT)
				|| operationalPlanEventSubTypes.contains(OperationalPlanEventSubType.CREATE_OWO)
				|| operationalPlanEventSubTypes.contains(OperationalPlanEventSubType.REPOSITION_TRUCK)
				|| operationalPlanEventSubTypes.contains(OperationalPlanEventSubType.TERMINATE_CHECKCALL)
				|| operationalPlanEventSubTypes.contains(OperationalPlanEventSubType.INBOUND_TO_YARD)) {
			if (CollectionUtils.isNotEmpty(
					operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanWorkOrderAssociations())) {
				operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanWorkOrderAssociations().stream()
						.forEach(v -> loadCreate(operationalPlanEvent.getOperationalPlanDTO(), true,
								v.getOperationalWorkOrderId(), CommonConstants.STRING_W + v.getOperationalWorkOrderId(),
								OperationalPlanEventSubType.CREATE_OWO.name()));
			} else if (CollectionUtils
					.isNotEmpty(operationalPlanEvent.getOperationalPlanDTO().getOrderOperationalPlanAssociations())) {
				operationalPlanEvent.getOperationalPlanDTO().getOrderOperationalPlanAssociations().stream()
						.map(OrderOperationalPlanAssociationDTO::getOperationalPlanOrder).forEach(order -> {
							loadCreate(operationalPlanEvent.getOperationalPlanDTO(), false, order.getOrderId(),
									order.getOrderTrackingNumber(), OperationalPlanEventSubType.CREATE_FREIGHT.name());
						});
			} else {
				throw new JBHuntRuntimeException("Invalid data for load Creation: " + operationalPlanEvent);
			}
		} else {
			throw new JBHuntRuntimeException("Invalid Sub Type for Load Creation, Please Send Valid Subtype...");
		}

	}

	private void loadCreate(OperationalPlanDTO operationalPlanDTO, boolean isOperationalWorkOrder, Integer orderId,
			String orderNumber, String eventSubType) {
		log.info("loadCreate  - eventSubtype" + eventSubType);
		if (isExist(isOperationalWorkOrder, orderId, operationalPlanDTO.getOperationalPlanId())) {
			log.info("load is already created, this is not possible in production: load id: {}, order id:{}",
					operationalPlanDTO.getOperationalPlanId(), orderId);
			return;
		}
		backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
				eventSubType, "");

		try {
			bkfilOrdLdAscRepository
					.save(getBkfilOrdLdAsc(operationalPlanDTO, isOperationalWorkOrder, orderId, orderNumber));
			backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO,
					EventStatusEnum.COMPLETED.name(), "");
			Integer legacyOrderId = null;
			String legacyOrderNumber = null;
			if (!isOperationalWorkOrder) {
				TOrder orderDetails = Optional.ofNullable(orderLoadRepository.findLoadDetailsByOrderID(orderId))
						.orElseGet(() -> orderLoadRepository.findLoadDetailsByOrderIDWarehouse(orderId));
				if (orderDetails == null) {
					throw new JBHuntRuntimeException(
							"Order Id " + orderId + " doesn't exist and It's mandatory for Checkcalls.");
				}
				legacyOrderId = orderDetails.getOrderId();
				legacyOrderNumber = orderDetails.getOrdrNumber();
			} else {
				BkfilOwoJaAscResponse bkfilOwoJaAscResponse = loadplanningIntegrationOWObackfillService
						.findOrdDetailsBynxtOwoNum("W" + operationalPlanDTO.getOperationalPlanWorkOrderAssociations()
								.get(0).getOperationalWorkOrderId());
				if (bkfilOwoJaAscResponse == null) {
					throw new JBHuntRuntimeException(
							"OWO Order " + orderId + " doesn't exist and It's mandatory for Checkcalls.");
				}
				legacyOrderId = bkfilOwoJaAscResponse.getOrdI();
				legacyOrderNumber = bkfilOwoJaAscResponse.getOrdNbrch();
			}
			log.info("Create LegacyOrderAssociation record for legacyOrderId: {} and legacyOrderNumber:{}",
					legacyOrderId, legacyOrderNumber);
			if (legacyOrderId != null && !StringUtils.isEmpty(legacyOrderNumber)) {
				legacyOrderOperationalPlanAssociationRepository.saveLegacyOrderOperationalPlanAssociationDetails(
						operationalPlanDTO, legacyOrderId, legacyOrderNumber);
			}

		} catch (Exception e) {
			log.error("legacy persistance exception:", e);
			String errorMesage = ExceptionUtils.getRootCauseMessage(e);
			if (errorMesage != null && errorMesage.length() > 500) {
				errorMesage = errorMesage.substring(0, 500);
			}
			backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
					errorMesage);
			throw new JBHuntRuntimeException("Exception while creating load", e);
		}
	}

	private Boolean isExist(boolean isOperationalWorkOrder, Integer orderId, Integer nextLoadId) {
		QBkfilOrdLdAsc qBkfilOrdLdAsc = QBkfilOrdLdAsc.bkfilOrdLdAsc;
		Predicate predicate = null;
		if (isOperationalWorkOrder) {
			predicate = qBkfilOrdLdAsc.nextOWOId.eq(orderId).and(qBkfilOrdLdAsc.nxtLoadId.eq(nextLoadId));
		} else {
			predicate = qBkfilOrdLdAsc.nxtOrdId.eq(orderId).and(qBkfilOrdLdAsc.nxtLoadId.eq(nextLoadId));
		}
		return bkfilOrdLdAscRepository.exists(predicate);
	}

	private BkfilOrdLdAsc getBkfilOrdLdAsc(OperationalPlanDTO operationalPlan, boolean isOperationalWorkOrder,
			Integer orderId, String orderNumber) {
		BkfilOrdLdAsc bkfilOrdLdAsc = new BkfilOrdLdAsc();
		bkfilOrdLdAsc.setNxtLoadId(operationalPlan.getOperationalPlanId());
		bkfilOrdLdAsc.setNxtLoadNo(operationalPlan.getOperationalPlanNumber());
		if (isOperationalWorkOrder) {
			bkfilOrdLdAsc.setNextOWOId(orderId);
			bkfilOrdLdAsc.setNextOWONum(CommonConstants.STRING_W + orderId);
		} else {
			bkfilOrdLdAsc.setNxtOrdId(orderId);
			bkfilOrdLdAsc.setNxtOrdNo(orderNumber);
		}
		bkfilOrdLdAsc
				.setNxtLoadSubTypeCode(operationalPlan.getOperationalPlanSubtype().getOperationalPlanSubtypeCode());
		bkfilOrdLdAsc.setNextLoadTypeC(operationalPlan.getOperationalPlanType().getOperationalPlanTypeCode());
		Optional.ofNullable(operationalPlan.getRouteOperationalPlanMoveMessageAssociation())
				.ifPresent(routeOperationalPlanMoveMessageAssociation -> {
					bkfilOrdLdAsc.setNxtRouteSeqNo(routeOperationalPlanMoveMessageAssociation.getRouteSequenceNumber());
				});
		bkfilOrdLdAsc.setCurrTimeStamp(CommonUtils.convertToDatabaseColumn(LocalDateTime.now()));
		bkfilOrdLdAsc.setCreatedUID(operationalPlan.getCreateUserId());
		bkfilOrdLdAsc.setCreatedPrgmCode(operationalPlan.getCreateProgramName());
		bkfilOrdLdAsc.setLastUpdateTimeStamp(CommonUtils.convertToDatabaseColumn(LocalDateTime.now()));
		bkfilOrdLdAsc.setLastUpdatedUID(operationalPlan.getLastUpdateUserId());
		bkfilOrdLdAsc.setLastUpdatedPrgmCode(operationalPlan.getLastUpdateProgramName());
		return bkfilOrdLdAsc;
	}
}
