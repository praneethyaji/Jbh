package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersBuffer;
import com.jbhunt.biz.refNumber.vo.AddNewReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.DeletedReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.ReferenceNumberDetailsVO;
import com.jbhunt.biz.refNumber.vo.UpdatedReferenceNumberVO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class ReferenceNumberUpdateServiceHelper {
	
	private final ReferenceBufferHelper referenceBufferHelper;
	
	public void populateReferenceNumberForDeletion(List<DeletedReferenceNumberVO> delRefNbrList,
			ReferenceNumbersBuffer referenceNumbers) {
		if (CollectionUtils.isNotEmpty(delRefNbrList)) {
            for(DeletedReferenceNumberVO delRefNbr:delRefNbrList) {
                if (referenceBufferHelper.validate(delRefNbr)) {
                    int refNbrDelIndex = referenceBufferHelper.fetchReferenceNumberIndex(referenceNumbers, delRefNbr);
                    log.debug("index " + refNbrDelIndex);
                    if (refNbrDelIndex != -1) {
                        referenceNumbers.setAction("DELETE", refNbrDelIndex);
                    }
                }
            }
        }
	}

    public void newReferenceNumberInsert(ReferenceNumbersBuffer referenceNumbers, int orderReferenceNumbersCount,
            int refNbrInsertCnt, AddNewReferenceNumberVO detail) {
        int offset = orderReferenceNumbersCount + refNbrInsertCnt;
        ReferenceNumbersBuffer referenceNumber=null;
        log.debug("offset " + offset);
        referenceNumber= referenceBufferHelper.assignNewValues(referenceNumbers, detail, offset, "CREATE");
        log.debug("referenceNumber " + referenceNumber.getReferenceNumberI(0));
        log.info(String.valueOf("refNbrInsertCnt++" + refNbrInsertCnt));
    }


    public boolean validateForUpdateDelete(ReferenceNumberDetailsVO detailVO) {
        log.debug("validateForUpdateDelete: " + detailVO.getReferenceNumberI());
        return detailVO.getReferenceNumberI() != null && detailVO.getReferenceNumberI() != 0;
    }

    public int getOldReferenceNumberIndexLTL(ReferenceNumbersBuffer referenceNumbers,
            UpdatedReferenceNumberVO detailVO) {
        int returnValue = -1;
        for (int i = 0; i < ReferenceNumbersBuffer.MAX_REF_NBR_COUNT; i++) {
            log.debug("1****" + referenceNumbers.getReferenceNumberI(i) + "*" + referenceNumbers.getStopLineItemI(i));
            log.debug("2****" + detailVO.getOldReferenceNumberI() + "*" + detailVO.getLineItemVO().getStopLineItemI());
            if (Integer.valueOf(referenceNumbers.getReferenceNumberI(i)).equals(detailVO.getOldReferenceNumberI())
                    && Integer.valueOf(referenceNumbers.getStopLineItemI(i))
                            .equals(detailVO.getLineItemVO().getStopLineItemI())) {
                returnValue = i;
                break;
            }
        }
        return returnValue;
    }
	
	
	
}
