package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "TADDRESS", schema = "ALI")
public class Address implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ADR_I")
	private Integer adrI;

	@Column(name = "REC_STT")
	private String recSit;

	@Column(name = "PST_1_C")
	private String pst1C;

	@Column(name = "PST_2_C")
	private String pst2C;

	@Column(name = "PST_EXT_C")
	private String pstExtC;

	@Column(name = "ST_C")
	private String stC;

	@Column(name = "CRY_C")
	private String cryC;

	@Column(name = "CTY_C")
	private String ctyC;

	@Column(name = "ADR_LNE_01")
	private String adrLne01;

	@Column(name = "ADR_LNE_02")
	private String adrLne02;

}
