package com.jbhunt.loadplannig.integration.backfill.services;

import java.util.List;
import java.util.Map;

import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallElement;

class CheckCallBackfillService {


    String getCheckCallVarsValues(Map<String,String> checkCallElementMap, List<CheckcallElement> checkcallArrivalsList){
        StringBuilder sb = new StringBuilder();
        checkcallArrivalsList.forEach(checkcallElement->
            sb.append(getPaddedValue(checkCallElementMap.containsKey(checkcallElement.getFieldName())?checkCallElementMap.get(checkcallElement.getFieldName()):"" ,"%1$-" +checkcallElement.getLength()+ "s"))
        );
        return sb.toString();
    }
    
    private String getPaddedValue(String value,String formatedString ){
       return String.format(formatedString, value);
    }


}