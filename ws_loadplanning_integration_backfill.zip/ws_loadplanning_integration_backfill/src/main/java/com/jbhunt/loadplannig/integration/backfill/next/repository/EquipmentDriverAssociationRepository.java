package com.jbhunt.loadplannig.integration.backfill.next.repository;

import com.jbhunt.loadplannig.integration.backfill.constants.SQLQueryConstants;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.jbhunt.loadplanning.operationalplan.dto.core.DriverAssignmentDTO;

import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
@Slf4j
@AllArgsConstructor
public class EquipmentDriverAssociationRepository {

    private final JdbcTemplate sqlServerjdbcTemplate;

    public DriverAssignmentDTO getDriverAssignmentDetails(final Integer equipmentId) {
        try {
            log.info("populating DriverAssignment from OPEX NEXT DB by equipment {}",equipmentId);
            return sqlServerjdbcTemplate.queryForObject(SQLQueryConstants.GET_DRIVER_BY_EQUIPMENT_ID,
                    new Object[] { equipmentId }, new RowMapper<DriverAssignmentDTO>() {
                        @Override
                        public DriverAssignmentDTO mapRow(ResultSet rs, int rowNum)
                                throws SQLException {
                            return formDriverAssignmentDTO(rs);
                        }
                    });
        } catch (EmptyResultDataAccessException ex) {
            log.error("No Driver Details found for given equipmentId: {}", equipmentId);
            log.error(ex.getMessage());
            return null;
        }
    }

    private DriverAssignmentDTO formDriverAssignmentDTO(ResultSet rs) throws SQLException {
        DriverAssignmentDTO driverAssignmentDTO = new DriverAssignmentDTO();
        driverAssignmentDTO.setDriverId(rs.getString("DriverPersonID"));
        return driverAssignmentDTO;
    }

}


