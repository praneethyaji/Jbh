package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderComment;




@Repository
public interface OrderCommentRepository extends JpaRepository<OrderComment, Integer> {

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM ALI.ORDER_COMMENT where CRT_UID = 'pidldpn' AND (CMM_TXT NOT LIKE 'PRELOADED%') AND (CMM_TXT NOT LIKE 'ORIGINAL RATED%') AND ORD_I=:orderId", nativeQuery = true)
	Integer deleteOrderComments(@Param("orderId") Integer orderId);

    @Query(value = "SELECT ORD_I,DSP_NBR,CRT_PGM_C,CMM_SEQ_NBR,CMM_TYP,EXT_CMM_TXT,CMM_TXT,CRT_S,CRT_UID,LST_UPD_S,LST_UPD_UID,LST_UPD_PGM_C "
            + "from ALI.ORDER_COMMENT where ORD_I=:orderId WITH UR", nativeQuery = true)
    List<Object[]> findCommentDetailsByOrdId(@Param("orderId") Integer orderId);
	
}
