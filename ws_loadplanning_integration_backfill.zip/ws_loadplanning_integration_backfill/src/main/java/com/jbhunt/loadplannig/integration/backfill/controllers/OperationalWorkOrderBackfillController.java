package com.jbhunt.loadplannig.integration.backfill.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.LoadplanningIntegrationOWObackfillService;
import com.jbhunt.loadplanning.owo.dto.event.OperationalWorkOrderEvent;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class OperationalWorkOrderBackfillController extends BackfillBaseController{

	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;

	@PostMapping("/operationalworkorders")
	public ResponseEntity<BackfillServiceResponse> createOWO(@RequestBody OperationalWorkOrderEvent operationalWorkOrderEvent)
			{
		log.info("Calling create OWO: ");
		loadplanningIntegrationOWObackfillService.saveOrUpdateOWO(operationalWorkOrderEvent, "C");
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
	
	@PatchMapping("/operationalworkorders")
	public ResponseEntity<BackfillServiceResponse> updateOWO(
			@RequestBody OperationalWorkOrderEvent operationalWorkOrderEvent) {
		log.info("Calling update OWO: ");
		String operation = loadplanningIntegrationOWObackfillService.getOperationByStatus(operationalWorkOrderEvent);
		loadplanningIntegrationOWObackfillService.saveOrUpdateOWO(operationalWorkOrderEvent, operation);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}	
}
