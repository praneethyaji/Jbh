package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class TOfrStopRqmJDBCRepository {

	TOfrStopRqmJDBCRepository(@Qualifier("dataSourceDB2") JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private final JdbcTemplate jdbcTemplate;

	public void inserHazmat(final Integer orderId, final Integer stopSequenceNumber, 
			final Timestamp timestamp, final String createUserId, final Timestamp timestamp2,
			final Timestamp endTimestamp) {
	 
		jdbcTemplate.update("INSERT INTO ALI.TOFR_STP_RQM (ORD_I, OFR_STP_SEQ_NBR, CRT_S, CRT_UID, EFF_S, END_S, OFR_STP_RQM_CLS_C, OFR_STP_RQM_TYP_C)"
				+"VALUES(?,?,?,?,?,?,?,?)",
				orderId, stopSequenceNumber, timestamp, createUserId, timestamp2, endTimestamp, "HAZMAT", "REQMNT");
	}
	
	public void deleteHazmat(final Integer orderId) {
		jdbcTemplate.update("DELETE FROM ALI.TOFR_STP_RQM WHERE ORD_I=?", orderId);
	}

}
