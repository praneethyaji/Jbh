package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.Reservation;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.RsvrscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.SubTaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TpndJobAsnRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc341i.lmc341.LMC341Port;
import com.lmc342i.lmc342.LMC342Port;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea.Lmc341InputArea;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables;
import com.response.lmc341i.lmc341.ProgramInterface.Lmc341OutputArea;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava.Wo42ErrorVariables;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class InboundToYardControllerIT {

	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@Autowired
	private ObjectMapper objectMapper;

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http")
			.host("loadplanning-test.jbhunt.com").removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

	private Lmc341CommArea finalInput;
	private Lmc341OutputArea output;

	@MockBean
	private LMC341Port lmc341Port;

	@MockBean
	private LMC342Port lmc342Port;

	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	private EquipmentRepository equipmentRepository;

	@MockBean
	private OrderLoadRepository orderLoadRepository;

	@MockBean
	private SubTaskRepository subTaskRepository;

	@MockBean
	private TaskRepository taskRepository;

	@MockBean
	private RsvrscRepository rsvrscRepository;

	@MockBean
	private TpndJobAsnRepository tpndJobAsnRepository;

	// InboundToYardInPlannedStatus.json

	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void inboundToYardDriverPlannedStatus() throws Exception {
		testInboundYardForDriverPreplan("/json/InboundToYardInDriverPlannedStatus.json");
	}

	@Test
	public void inboundToYardTruckPlannedStatus() throws Exception {
		testInboundBoundYard("/json/InboundToYardInTruckPlannedStatus.json");
	}

	private void testInboundYardForDriverPreplan(String jsonPath) throws Exception {

		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(1010479);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

		when(orderLoadRepository.findLoadDetailsByOrderID(Mockito.anyInt())).thenReturn(tOrder);

		TSubtask1 tSubtask1 = new TSubtask1();
		tSubtask1.setJobId(122);
		tSubtask1.setCurrentAppointmnetBegHour("2019-05-31 11:03:51.604942");
		tSubtask1.setCurrentAppointmnetBegDate("2019-05-31 11:03:51.604942");
		tSubtask1.setCurrentApointmentEndHour("2019-05-31 11:03:51.604942");
		tSubtask1.setBusinessId(34);
		tSubtask1.setPreferanceSequenceNumber(1002);
		tSubtask1.setCityId("FDOD7");
		List<TSubtask1> listSubTasks = new ArrayList<>();
		listSubTasks.add(tSubtask1);
		when(subTaskRepository.findSubTaskDetailsByTaskId(Mockito.anyInt())).thenReturn(listSubTasks);
		Reservation reservation = new Reservation();
		reservation.setLastUpdateTimeStamp("2019-05-31 11:03:51.604942");
		reservation.setReservationId(1010479);
		when(rsvrscRepository.getrsvDetailsofDriver(Mockito.anyInt())).thenReturn(reservation);

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[142691]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		wireMockServer.stubFor(WireMock
				.get(WireMock.urlPathEqualTo("/masterdatalocationservices/locations/search/findbylocation/10868"))
				.willReturn(WireMock.aResponse().withHeader("Content-Type", "application/json").withBody(
						"{ \"locationProfileDTO\": { \"id\": 10868, \"facilityOperationDTO\": [], \"facilityOverviewRequirementCodeDTO\": [], \"contactDTO\": [], \"addressDTO\": { \"id\": 235523, \"addressLine1\": \"1874 Iron Bridge Rd\", \"addressLine2\": \"\", \"state\": \"KY\", \"city\": \"Bowling Green\", \"cityAliasName\": \"Bowling Green\", \"zipcode\": \"421039757\", \"country\": \"USA\", \"countyName\": \"Warren\", \"latitude\": 36.937973, \"longitude\": -86.254737 }, \"hazmatDTO\": null, \"disallowedEquipmentDTO\": [], \"customerDirections\": null, \"generalInstructions\": null, \"locationCode\": \"IRBO18\", \"locationName\": \"Iron Bridge SOD\" }, \"timezone\": \"America/Chicago\" }")
						.withStatus(200)));

		// OperationalPlanEvent operationalPlanEvent = objectMapper
		// .readValue(IOUtils.toString(this.getClass().getResourceAsStream(jsonPath)),
		// OperationalPlanEvent.class);
		final OperationalPlanDTO operationalPlanDTO = objectMapper
				.readValue(IOUtils.toString(this.getClass().getResourceAsStream(jsonPath)), OperationalPlanDTO.class);

		output = new Lmc341OutputArea();
		output.setLmc341ErrorMessage("Mock");
		output.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output);

		Wo42ComReturnToJava output = new Wo42ComReturnToJava();

		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		output.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanDTO)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/"+operationalPlanDTO.getOperationalPlanId()+"/inboundtoyard");
		System.out.println("response ---- >>> " + response.asString());

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

	private void testInboundBoundYard(String jsonPath) throws Exception {
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");
		when(orderLoadRepository.findLoadDetailsByOrderID(Mockito.anyInt())).thenReturn(tOrder);

		when(taskRepository.findLastUpdatedTimeStampBytaskId(Mockito.anyInt())).thenReturn("66777");
		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[142691]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		wireMockServer.stubFor(WireMock
				.get(WireMock.urlPathEqualTo("/masterdatalocationservices/locations/search/findbylocation/10868"))
				.willReturn(WireMock.aResponse().withHeader("Content-Type", "application/json").withBody(
						"{ \"locationProfileDTO\": { \"id\": 10868, \"facilityOperationDTO\": [], \"facilityOverviewRequirementCodeDTO\": [], \"contactDTO\": [], \"addressDTO\": { \"id\": 235523, \"addressLine1\": \"1874 Iron Bridge Rd\", \"addressLine2\": \"\", \"state\": \"KY\", \"city\": \"Bowling Green\", \"cityAliasName\": \"Bowling Green\", \"zipcode\": \"421039757\", \"country\": \"USA\", \"countyName\": \"Warren\", \"latitude\": 36.937973, \"longitude\": -86.254737 }, \"hazmatDTO\": null, \"disallowedEquipmentDTO\": [], \"customerDirections\": null, \"generalInstructions\": null, \"locationCode\": \"IRBO18\", \"locationName\": \"Iron Bridge SOD\" }, \"timezone\": \"America/Chicago\" }")
						.withStatus(200)));

		// OperationalPlanEvent operationalPlanEvent = objectMapper
		// .readValue(IOUtils.toString(this.getClass().getResourceAsStream(jsonPath)),
		// OperationalPlanEvent.class);
		final OperationalPlanDTO operationalPlanDTO = objectMapper
				.readValue(IOUtils.toString(this.getClass().getResourceAsStream(jsonPath)), OperationalPlanDTO.class);

		Lmc341InputArea inputArea = null;
		finalInput = new Lmc341CommArea();
		finalInput.setLmc341InputArea(inputArea);

		output = new Lmc341OutputArea();
		output.setLmc341ErrorMessage("Mock");
		output.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output);
		Wo42ComReturnToJava output = new Wo42ComReturnToJava();
		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ErrorKey1("");
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		Wo42ErrorVariables.setWo42Message("");
		Wo42ErrorVariables.setWo42CicsReturnCode(399);
		Wo42ErrorVariables.setWo42ErrorKey2("");

		output.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanDTO)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/"+operationalPlanDTO.getOperationalPlanId()+"/inboundtoyard");
		System.out.println("response ---- >>> " + response.asString());

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}
}
