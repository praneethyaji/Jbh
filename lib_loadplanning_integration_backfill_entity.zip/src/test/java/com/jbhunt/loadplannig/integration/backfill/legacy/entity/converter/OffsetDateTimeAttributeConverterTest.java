package com.jbhunt.loadplannig.integration.backfill.legacy.entity.converter;

import static org.junit.Assert.assertNotNull;

import java.time.OffsetDateTime;

import com.jbhunt.loadplannig.integration.backfill.next.entity.converter.OffsetDateTimeAttributeConverter;
import org.junit.Before;
import org.junit.Test;

public class OffsetDateTimeAttributeConverterTest {

    private OffsetDateTimeAttributeConverter offsetDateTimeAttributeConverter;

    @Before
    public void init() {
        offsetDateTimeAttributeConverter = new OffsetDateTimeAttributeConverter();
    }

    @Test
    public void testConvertToDatabaseColumn() {
        String offSetDateTimeString = offsetDateTimeAttributeConverter.convertToDatabaseColumn(OffsetDateTime.now());
        assertNotNull("Offset Local Date String", offSetDateTimeString);
    }

    @Test
    public void testConvertToEntityAttribute() {
        OffsetDateTime localDateTime = offsetDateTimeAttributeConverter
                .convertToEntityAttribute("2018-03-15 07:39:31.8620000 -05:00");
        assertNotNull("Local Date String", localDateTime);
    }

}