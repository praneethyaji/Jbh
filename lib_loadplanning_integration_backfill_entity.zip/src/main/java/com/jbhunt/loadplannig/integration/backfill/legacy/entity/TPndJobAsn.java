package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TPND_JOB_ASN", schema = "ALI")
public class TPndJobAsn implements Serializable {
	
	private static final long serialVersionUID = 14592317557398607L;

	@Id
	@Column(name = "TPND_JOB_ASN_ID")
	private Integer tPndJobAsnId;

//	@Id
	@Column(name = "EQP_UNT_I")
	private Integer equipmentUnitId;

	@Column(name = "EQP_I")
	private Integer equipmentId; 
	@Column(name = "TSK_I")
	private Integer taskID;

	@Column(name = "ETA_D")
	private String estimateTimeAppointmentDate;  

	@Column(name = "ETA_H")
	private String estimateTimeAppointmentHours;

	@Column(name = "LST_UPD_S")
	private String lasUpdateTimeStamp;


	@Column(name = "RSC_RSV_I")
	private Integer reservationID;

}
