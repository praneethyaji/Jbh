package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersLinkBuffers;
import com.jbhunt.biz.refNumber.vo.LineItemVO;
import com.jbhunt.biz.refNumber.vo.UpdatedReferenceNumberVO;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplannig.integration.backfill.dto.LegacyOrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplannig.integration.backfill.next.repository.LegacyOrderOperationalPlanAssociationRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.ReferenceUpdateServiceHelper;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.oec076i.oec076.OEC076Port;
import com.oec145i.oec145.OEC145Port;
import com.request.oec076i.oec076.ProgramInterface.Oe76InputChannelData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutCommentsLine;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutOrdBuffer9;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutNonstpLine;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutOrdclssLine;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutOrdBuffer9.Oe76OutOrdDstRmpAdrLn02;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutOrdBuffer9.Oe76OutOrdEqpUntC;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutOrdBuffer9.Oe76OutOrgRmpAdrLn02;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutStpLine;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutOtherBuffer19;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutRqmntsLine;
import com.response.oec145i.oec145.ProgramInterface.Oee5OutputChannelData;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;

import static com.github.tomakehurst.wiremock.client.WireMock.get;

import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class LoadEditControllerIT {

	@MockBean
	PIDCredentials pidCredentials;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http")
			.host("operationsexecutionswitchplan.jbhunt.com").removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private OEC076Port oec076Port;

	@MockBean
	private OEC145Port oEC145Port;

	@MockBean
	private ReferenceUpdateServiceHelper referenceNumberUpdateHelper;

	@MockBean
	@Qualifier("sqlServerjdbcTemplate")
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	private LegacyOrderOperationalPlanAssociationRepository legacyOrderOperationalPlanAssociationRepository;

	@Before
	public void setup() {
		RestAssured.port = port;

		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void testLoadInstruction() throws Exception {
		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadInstruction.json")),
				OperationalPlanEvent.class);

		Oe76OutRqmntsLine oe76OutRqmntsLine = new Oe76OutRqmntsLine();
		oe76OutRqmntsLine.setOe76OutRqmntsOfrStpSeq(1);
		oe76OutRqmntsLine.setOe76OutRqmntsRqmClsC("MONITOR");
		oe76OutRqmntsLine.setOe76OutRqmntsRqmClsTypC("MONITOR");
		Oe76OutputChannelData output1 = new Oe76OutputChannelData();
		output1.getOe76OutRqmntsBuffer14().add(oe76OutRqmntsLine);
		Oe76OutCommentsLine Oe76OutCommentsBuffer = new Oe76OutCommentsLine();
		Oe76OutCommentsBuffer.setOe76OutCommentsAction("");
		Oe76OutCommentsBuffer.setOe76OutCommentsCmm("ABC");
		Oe76OutCommentsBuffer.setOe76OutCommentsCmmTypC("ORDER");
		Oe76OutCommentsBuffer.setOe76OutCommentsJbhsoacS("ABC");
		Oe76OutCommentsBuffer.setOe76OutCommentsSeqNbr((short) 1);
		Oe76OutCommentsBuffer.setOe76OutCommentsSource("ABC");
		output1.getOe76OutCommentsBuffer10().add(Oe76OutCommentsBuffer);
		
		output1.setOe76OutOrdBuffer9(prepareOe76OutOrdBuffer9());
		output1.setOe76OutNonstpBuffer12(prepareOe7OutNonstpBuffer12());
		output1.setOe76OutStpBuffer13(prepareOe76OutStpBuffer13());
		output1.setOe76OutOrdclssBuffer11(prepareOe76OutOrdclssBuffer11());
		Oe76OutOtherBuffer19 oe76OutOtherBuffer19 = new Oe76OutOtherBuffer19();
		oe76OutOtherBuffer19.setOe76OutPplanCmntC("TEST");
		output1.setOe76OutOtherBuffer19(oe76OutOtherBuffer19);
		when(oec076Port.oec076Operation(Mockito.any(Oe76InputChannelData.class))).thenReturn(output1);
		Oee5OutputChannelData output = new Oee5OutputChannelData();
		when(oEC145Port.oec145Operation(Mockito.any(Oee5InputChannelData.class))).thenReturn(output);
		// ACT
	
	    String responseMasterDataLocation = IOUtils
	                .toString(this.getClass().getResourceAsStream("/json/locationProfile2.json"));

		wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/154076"))
                .willReturn(aResponse().withHeader("Content-type", "application/json")
                        .withBody(responseMasterDataLocation).withStatus(200)));
		 String responseMasterDataLocation1 = IOUtils
	                .toString(this.getClass().getResourceAsStream("/json/locationProfile.json"));

		wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/26551"))
             .willReturn(aResponse().withHeader("Content-type", "application/json")
                     .withBody(responseMasterDataLocation1).withStatus(200)));
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/load/30243/instructions");
		System.out.println("response ---- >>> " + response.asString());

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void testLoadInstructionException() throws Exception {
		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadInstruction.json")),
				OperationalPlanEvent.class);

		Response response =given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/load/30243/instructions");

	}
	@Test
	public void testLoadInstructionOrderInfoEmpyException() throws Exception {
		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadInstructionOrderAssociationEmpty.json")),
				OperationalPlanEvent.class);

		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/load/30243/instructions");
	}
	@Test
	public void testLoadReferencesException() throws Exception {
		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadReference.json")),
				OperationalPlanEvent.class);

		given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/load/14317/references");

	}

	@Test
	public void testLoadReferences() throws Exception {
		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadReference.json")),
				OperationalPlanEvent.class);

		LegacyOrderOperationalPlanAssociationDTO legacyOrderOperationalPlanAssociationDTO = new LegacyOrderOperationalPlanAssociationDTO();
		legacyOrderOperationalPlanAssociationDTO.setLegacyOrderId(123456789);
		when(legacyOrderOperationalPlanAssociationRepository.getLegacyOrderDetails(Mockito.anyInt()))
				.thenReturn(legacyOrderOperationalPlanAssociationDTO);
		Oe76OutRqmntsLine oe76OutRqmntsLine = new Oe76OutRqmntsLine();
		oe76OutRqmntsLine.setOe76OutRqmntsOfrStpSeq(1);
		oe76OutRqmntsLine.setOe76OutRqmntsRqmClsC("MONITOR");
		oe76OutRqmntsLine.setOe76OutRqmntsRqmClsTypC("MONITOR");
		Oe76OutputChannelData output = new Oe76OutputChannelData();
		output.getOe76OutRqmntsBuffer14().add(oe76OutRqmntsLine);
		Oe76OutCommentsLine Oe76OutCommentsBuffer = new Oe76OutCommentsLine();
		Oe76OutCommentsBuffer.setOe76OutCommentsAction("");
		Oe76OutCommentsBuffer.setOe76OutCommentsCmm("ABC");
		Oe76OutCommentsBuffer.setOe76OutCommentsCmmTypC("ORDER");
		Oe76OutCommentsBuffer.setOe76OutCommentsJbhsoacS("ABC");
		Oe76OutCommentsBuffer.setOe76OutCommentsSeqNbr((short) 1);
		Oe76OutCommentsBuffer.setOe76OutCommentsSource("ABC");
		output.getOe76OutCommentsBuffer10().add(Oe76OutCommentsBuffer);
		output.setOe76OutOrdBuffer9(prepareOe76OutOrdBuffer9());
		Oe76OutOtherBuffer19 oe76OutOtherBuffer19 = new Oe76OutOtherBuffer19();
		oe76OutOtherBuffer19.setOe76OutPplanCmntC("TEST");
		output.setOe76OutOtherBuffer19(oe76OutOtherBuffer19);
		ReferenceNumbersLinkBuffers outputRefBuffer = new ReferenceNumbersLinkBuffers();
		outputRefBuffer.setNbrOfRefNbrs(1);
		outputRefBuffer.getReferenceNumbers().setType("ITN", 0);
		outputRefBuffer.getReferenceNumbers().setSequence(1, 0);
		outputRefBuffer.getReferenceNumbers().setNumber("544513213", 0);
		outputRefBuffer.getReferenceNumbers().setCustomerCode("SCNEAB", 0);
		outputRefBuffer.getReferenceNumbers().setAddressID(3212, 0);
		outputRefBuffer.getReferenceNumbers().setSiteID(12313, 0);
		outputRefBuffer.getReferenceNumbers().setDepartment("BILL TO", 0);
		when(referenceNumberUpdateHelper.linkOEC070InSelectMode(123456789, "pidldpn", "OPEXBKFL", "userid",
				"password")).thenReturn(outputRefBuffer);
		List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
		LineItemVO lineItemVO = new LineItemVO();
		lineItemVO.setStopLineItemI(1);
		lineItemVO.setHazF("N");
		lineItemVO.setActCls(1);
		lineItemVO.setRateCls(1);
		lineItemVO.setCarrCls(1);
		lineItemVO.setLength(1);
		lineItemVO.setWidth(1);
		lineItemVO.setHeight(1);
		lineItemVO.setQtyTyp("NOTHING");
		lineItemVO.setNmfcItemNumber(1);
		lineItemVO.setNmfcItemSubC((short) 1);
		lineItemVO.setHandlingUnit("REF");
		lineItemVO.setHandlingQuantity(1);
		UpdatedReferenceNumberVO updatedReferenceNumberVO = new UpdatedReferenceNumberVO();
		updatedReferenceNumberVO.setAddressID(1);
		updatedReferenceNumberVO.setCustomerCode("A");
		updatedReferenceNumberVO.setDepartment("JBI");
		updatedReferenceNumberVO.setErrorMessage("");
		updatedReferenceNumberVO.setLastUpdated("2017/05/05");
		updatedReferenceNumberVO.setLevel("ORDER");
		updatedReferenceNumberVO.setLineItemVO(lineItemVO);
		updatedReferenceNumberVO.setOldAddressID(2);
		updatedReferenceNumberVO.setOldCustomerCode("B");
		updatedReferenceNumberVO.setOldDepartment("HJBT JBI");
		updatedReferenceNumberVO.setOldReferenceNumber("2");
		updatedReferenceNumberVO.setOldReferenceNumberType("REF");
		updatedReferenceNumberVO.setOldSequence(1);
		updatedReferenceNumberVO.setOldSiteID(1);
		updatedReferenceNumberVO.setParentReferenceNumberI(3);
		updatedReferenceNumberVO.setPieceCount(1);
		updatedReferenceNumberVO.setProductDescr("NOTHING");
		updatedReferenceNumberVO.setQuantity(1);
		updatedReferenceNumberVO.setReferenceNumber("1");
		updatedReferenceNumberVO.setReferenceNumberI(1);
		updatedReferenceNumberVO.setReferenceNumberType("REF");
		updatedReferenceNumberVO.setSchemaMask("S");
		updatedReferenceNumberVO.setOldReferenceNumberI(1);
		updatedReferenceNumberVO.setSequence(1);
		updatedReferenceNumberVO.setSiteID(1);
		updatedReferenceNumberVO.setValidWithSchema(true);
		updatedReferenceNumberVO.setVolume(1);
		updatedReferenceNumberVO.setWeight((double) 1);
		updRefNbrList.add(updatedReferenceNumberVO);
		when(oec076Port.oec076Operation(Mockito.any(Oe76InputChannelData.class))).thenReturn(output);
		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/load/14317/references");
		System.out.println("response ---- >>> " + response.asString());

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	private Oe76OutOrdBuffer9 prepareOe76OutOrdBuffer9() {
		Oe76OutOrdBuffer9 Oe76OutOrdBuffer9 = new Oe76OutOrdBuffer9();
		Oe76OutOrdBuffer9.setFiller1("AB");
		Oe76OutOrdBuffer9.setOe76OutOrdActDrpD("MONDAY");
		Oe76OutOrdBuffer9.setOe76OutOrdActDrpDow("AB");
		Oe76OutOrdBuffer9.setOe76OutOrdActDrpH("08:00");
		Oe76OutOrdBuffer9.setOe76OutOrdAgrLnI(1);
		Oe76OutOrdBuffer9.setOe76OutOrdAlwAtrF("ASD");
		Oe76OutOrdBuffer9.setOe76OutOrdBdrXngVal(BigDecimal.ONE);
		Oe76OutOrdBuffer9.setOe76OutOrdBillStatus("A");
		Oe76OutOrdBuffer9.setOe76OutOrdCpyTrlF("QWERTY");
		Oe76OutOrdBuffer9.setOe76OutOrdCrtPgmC("BACKFILL");
		Oe76OutOrdBuffer9.setOe76OutOrdCrtS("RCON");
		Oe76OutOrdBuffer9.setOe76OutOrdCrtUid("RCON509");
		Oe76OutOrdBuffer9.setOe76OutOrdCurOrdSttC("A");
		Oe76OutOrdBuffer9.setOe76OutOrdDesirableFrtF("A");
		Oe76OutOrdBuffer9.setOe76OutOrdDivC("JBI");
		Oe76OutOrdBuffer9.setOe76OutOrdDrpTrlFaxF("LOWELL");
		Oe76OutOrdBuffer9.setOe76OutOrdDrpTrlFaxUid("JBH123");
		Oe76OutOrdBuffer9.setOe76OutOrdDspStt("A");
		Oe76OutOrdBuffer9.setOe76OutOrdDstAr("SDF");
		Oe76OutOrdBuffer9.setOe76OutOrdDstGeoC("IN");
		Oe76OutOrdBuffer9.setOe76OutOrdDstRmp("EXE");
		Oe76OutOrdBuffer9.setOe76OutOrdDstRmpAdrLn01("1B");
		Oe76OutOrdDstRmpAdrLn02 oe76OutOrdDstRmpAdrLn02 = new Oe76OutOrdDstRmpAdrLn02();
		oe76OutOrdDstRmpAdrLn02.setOe76OutOrdDstRmpCtyNm("CHN");
		oe76OutOrdDstRmpAdrLn02.setOe76OutOrdDstRmpStC("TN");
		Oe76OutOrdBuffer9.setOe76OutOrdDstRmpAdrLn02(oe76OutOrdDstRmpAdrLn02);
		Oe76OutOrdBuffer9.setOe76OutOrdDstRmpC("VCR");
		Oe76OutOrdBuffer9.setOe76OutOrdDstRmpName("ETC");
		Oe76OutOrdBuffer9.setOe76OutOrdEltEqpDesc("DANGER");
		Oe76OutOrdBuffer9.setOe76OutOrdEqpLenC(1);
		Oe76OutOrdBuffer9.setOe76OutOrdEqpLenRqdF("N");
		Oe76OutOrdBuffer9.setOe76OutOrdEqpSubClsC("BNM");
		Oe76OutOrdBuffer9.setOe76OutOrdEqpTypC("ORD");
		Oe76OutOrdBuffer9.setOe76OutOrdEqpTypRqdF("Y");
		Oe76OutOrdEqpUntC oe76OutOrdEqpUntC = new Oe76OutOrdEqpUntC();
		oe76OutOrdEqpUntC.setOe76OutOrdFiller1("FILL");
		oe76OutOrdEqpUntC.setOe76OutOrdFiller2("STOP");
		Oe76OutOrdBuffer9.setOe76OutOrdEqpUntC(oe76OutOrdEqpUntC);
		Oe76OutOrdBuffer9.setOe76OutOrdEqpUntPfx("PRE");
		Oe76OutOrdBuffer9.setOe76OutOrdFltC("AMAZON");
		Oe76OutOrdBuffer9.setOe76OutOrdFrsJobSegUtlC("AXC");
		Oe76OutOrdBuffer9.setOe76OutOrdImdTrtMdC("ASD");
		Oe76OutOrdBuffer9.setOe76OutOrdInternetPostF("N");
		Oe76OutOrdBuffer9.setOe76OutOrdJbhordrS("HHH");
		Oe76OutOrdBuffer9.setOe76OutOrdLstJobSegUtlC("RCON509");
		Oe76OutOrdBuffer9.setOe76OutOrdLstUpdS("2017");
		Oe76OutOrdBuffer9.setOe76OutOrdLtlF("N");
		Oe76OutOrdBuffer9.setOe76OutOrdMd("ASXC");
		Oe76OutOrdBuffer9.setOe76OutOrdMsg("ORDERMESSAGE");
		Oe76OutOrdBuffer9.setOe76OutOrdMsgLstUpdS("BACKFILL");
		Oe76OutOrdBuffer9.setOe76OutOrdNbrLdsToBeRes(1);
		Oe76OutOrdBuffer9.setOe76OutOrdNbrOfDsp((short) 1);
		Oe76OutOrdBuffer9.setOe76OutOrdNbrOfLds((short) 1);
		Oe76OutOrdBuffer9.setOe76OutOrdOfrSrcC("ZXC");
		Oe76OutOrdBuffer9.setOe76OutOrdOfrTypC("TEMP");
		Oe76OutOrdBuffer9.setOe76OutOrdOrdI(12345);
		Oe76OutOrdBuffer9.setOe76OutOrdOrdNbrCh("JB123");
		Oe76OutOrdBuffer9.setOe76OutOrdOrdTkrIni("JB78456");
		Oe76OutOrdBuffer9.setOe76OutOrdOrdTkrPhn("4569874");
		Oe76OutOrdBuffer9.setOe76OutOrdOrgAr("A");
		Oe76OutOrdBuffer9.setOe76OutOrdOrgGeoC("IN");
		Oe76OutOrdBuffer9.setOe76OutOrdOrgMd("MD");
		Oe76OutOrdBuffer9.setOe76OutOrdOrgRmp("RMP");
		Oe76OutOrdBuffer9.setOe76OutOrdOrgRmpName("DUMMY");
		Oe76OutOrdBuffer9.setOe76OutOrdOtherOrdI(1);
		Oe76OutOrdBuffer9.setOe76OutOrdPlnAvlD("1");
		Oe76OutOrdBuffer9.setOe76OutOrdPlnAvlDow("DOW");
		Oe76OutOrdBuffer9.setOe76OutOrdPlnAvlH("2000");
		Oe76OutOrdBuffer9.setOe76OutOrdPlnDrpD("FG");
		Oe76OutOrdBuffer9.setOe76OutOrdPlnDrpDow("FGH");
		Oe76OutOrdBuffer9.setOe76OutOrdPlnDrpH("2000");
		Oe76OutOrdBuffer9.setOe76OutOrdPrjC("JBHNEXT");
		Oe76OutOrdBuffer9.setOe76OutOrdPrlTrlF("Y");
		Oe76OutOrdBuffer9.setOe76OutOrdProtectFldsFlg("N");
		Oe76OutOrdBuffer9.setOe76OutOrdPsuDstRamp("R");
		Oe76OutOrdBuffer9.setOe76OutOrdPsuDstRampDate("2015-08-08");
		Oe76OutOrdBuffer9.setOe76OutOrdPsuDstRampH("0800");
		Oe76OutOrdBuffer9.setOe76OutOrdPsuOrgRamp("R");
		Oe76OutOrdBuffer9.setOe76OutOrdPsuOrgRampDate("2015-08-08");
		Oe76OutOrdBuffer9.setOe76OutOrdPsuOrgRampH("0800");
		Oe76OutOrdBuffer9.setOe76OutOrdRefNbrLstUpdS("2015/5/5");
		Oe76OutOrdBuffer9.setOe76OutOrdRmpOvrAlwF("N");
		Oe76OutOrdBuffer9.setOe76OutOrdSchFrtLnI(1);
		Oe76OutOrdBuffer9.setOe76OutOrdSdiIdx((short) 1);
		Oe76OutOrdBuffer9.setOe76OutOrdShipId("1");
		Oe76OutOrdBuffer9.setOe76OutOrdShpLstUpdS("2015/5/5");
		Oe76OutOrdBuffer9.setOe76OutOrdSubstituteSrvF("N");
		Oe76OutOrdBuffer9.setOe76OutOrdSvcLvl("O");
		Oe76OutOrdBuffer9.setOe76OutOrdUnderTrainDsp("DSP");
		Oe76OutOrdBuffer9.setOe76OutOrdUtlSttC("CCC");
		Oe76OutOrdBuffer9.setOe76OutOrgRmpAdrLn01("EDD");
		Oe76OutOrgRmpAdrLn02 oe76OutOrdDstRmpAdrLn0 = new Oe76OutOrgRmpAdrLn02();
		oe76OutOrdDstRmpAdrLn0.setOe76OutOrgRmpCtyNm("CHN");
		oe76OutOrdDstRmpAdrLn0.setOe76OutOrgRmpStC("TN");
		Oe76OutOrdBuffer9.setOe76OutOrgRmpAdrLn02(oe76OutOrdDstRmpAdrLn0);
		Oe76OutOrdBuffer9.setOe76OutOrgRmpC("RCODE");
		return Oe76OutOrdBuffer9;
	}
	
	private List<Oe76OutNonstpLine> prepareOe7OutNonstpBuffer12() {
		 
		List<Oe76OutNonstpLine> oe76OutNonstpLineList=new ArrayList<Oe76OutNonstpLine>();
	        Oe76OutNonstpLine oe76OutNonstpLine = new Oe76OutNonstpLine();
	        oe76OutNonstpLine.setOe76OutNonstpAction("");
	        oe76OutNonstpLine.setOe76OutNonstpAdrI(1);
	        oe76OutNonstpLine.setOe76OutNonstpAdrLn01("ABC");
	        oe76OutNonstpLine.setOe76OutNonstpAdrLn02("XYZ");
	        oe76OutNonstpLine.setOe76OutNonstpAprSttC("ABC");
	        oe76OutNonstpLine.setOe76OutNonstpBusLocI(1);
	        oe76OutNonstpLine.setOe76OutNonstpBusLocNm("ABC");
	        oe76OutNonstpLine.setOe76OutNonstpBusSitI(1);
	        oe76OutNonstpLine.setOe76OutNonstpConFrsNm("ABC");
	        oe76OutNonstpLine.setOe76OutNonstpConI(1);
	        oe76OutNonstpLine.setOe76OutNonstpConLstNm("XYZ");
	        oe76OutNonstpLine.setOe76OutNonstpContact("MOBILE");
	        oe76OutNonstpLine.setOe76OutNonstpCrdMgrFrsNm("ABC");
	        oe76OutNonstpLine.setOe76OutNonstpCrdMgrLstNm("DCF");
	        oe76OutNonstpLine.setOe76OutNonstpCrdMgrUid("RCON509");
	        oe76OutNonstpLine.setOe76OutNonstpCrdSttC("AB");
	        oe76OutNonstpLine.setOe76OutNonstpCryC("ABXC");
	        oe76OutNonstpLine.setOe76OutNonstpCtyC("XY");
	        oe76OutNonstpLine.setOe76OutNonstpCtyNm("JAIPUR");
	        oe76OutNonstpLine.setOe76OutNonstpCtystC("RJ");
	        oe76OutNonstpLine.setOe76OutNonstpCusC("ABC");
	        oe76OutNonstpLine.setOe76OutNonstpDptC("DEP");
	        oe76OutNonstpLine.setOe76OutNonstpFormatPhn("12345");
	        oe76OutNonstpLine.setOe76OutNonstpFormatZip("600097");
	        oe76OutNonstpLine.setOe76OutNonstpLstUpdS("2017/07/12");
	        oe76OutNonstpLine.setOe76OutNonstpPhnArC("CHN");
	        oe76OutNonstpLine.setOe76OutNonstpPhnExt("44");
	        oe76OutNonstpLine.setOe76OutNonstpPhnI(1);
	        oe76OutNonstpLine.setOe76OutNonstpPhnNbr("123456");
	        oe76OutNonstpLine.setOe76OutNonstpPhnPfx("00");
	        oe76OutNonstpLine.setOe76OutNonstpPst1C("CHN");
	        oe76OutNonstpLine.setOe76OutNonstpPst2C("THO");
	        oe76OutNonstpLine.setOe76OutNonstpPstExtC("H");
	        oe76OutNonstpLine.setOe76OutNonstpSolOutsrAlF("WEDD");
	        oe76OutNonstpLine.setOe76OutNonstpStC("CODE");
	        
	        oe76OutNonstpLineList.add(oe76OutNonstpLine);
	        return oe76OutNonstpLineList;
	       
	}
	private List<Oe76OutStpLine> prepareOe76OutStpBuffer13() {
		List<Oe76OutStpLine> oe76OutStpLineList=new ArrayList<Oe76OutStpLine>();
		Oe76OutStpLine oe76OutStpLine = new Oe76OutStpLine();

	        oe76OutStpLine.setOe76OutStpSuggEndTime("2015/05/05");
	        oe76OutStpLine.setOe76OutStpPstExtC("CHN");
	        oe76OutStpLine.setOe76OutStpPhnExt("44");
	        oe76OutStpLine.setOe76OutStpWeight(BigDecimal.ONE);
	        oe76OutStpLine.setOe76OutStpTypeC("DFG");
	        oe76OutStpLine.setOe76OutStpSuggDate("2017/2/2");
	        oe76OutStpLine.setOe76OutStpSuggBegTime("05:00");
	        oe76OutStpLine.setOe76OutStpStC("T");
	        oe76OutStpLine.setOe76OutStpStatus("A");
	        oe76OutStpLine.setOe76OutStpSbtskLstUpdS("2017/1/1");
	        oe76OutStpLine.setOe76OutStpApptRsnCd("PICKUP");
	        oe76OutStpLine.setOe76OutStpRefNbrLstUpdS("2017/1/1");
	        oe76OutStpLine.setOe76OutStpQty((short) 1);
	        oe76OutStpLine.setOe76OutStpPstExtC("NO");
	        oe76OutStpLine.setOe76OutStpPst2C("DFG");
	        oe76OutStpLine.setOe76OutStpPst1C("ABC");
	        oe76OutStpLine.setOe76OutStpPreF("N");
	        oe76OutStpLine.setOe76OutStpPoolInd("A");
	        oe76OutStpLine.setOe76OutStpPhnPfx("C");
	        oe76OutStpLine.setOe76OutStpPhnNbr("123");
	        oe76OutStpLine.setOe76OutStpPhnI(123456);
	        oe76OutStpLine.setOe76OutStpPhnExt("91");
	        oe76OutStpLine.setOe76OutStpPhnCryC("IND");
	        oe76OutStpLine.setOe76OutStpPhnArC("91");
	        oe76OutStpLine.setOe76OutStpOfrStpSeqNbr(1);
	        oe76OutStpLine.setOe76OutStpNewSeq("2");
	        oe76OutStpLine.setOe76OutStpLstUpdS("2017/1/1");
	        oe76OutStpLine.setOe76OutStpLoader("LOAD");
	        oe76OutStpLine.setOe76OutStpLoadedOn("TRUCK");
	        oe76OutStpLine.setOe76OutStpLnItmSeqNbr((short) 1);
	        oe76OutStpLine.setOe76OutStpJbhedisS("ZXC");
	        oe76OutStpLine.setOe76OutStpHazardous("N");
	        oe76OutStpLine.setOe76OutStpFrsOfrH("11:00");
	        oe76OutStpLine.setOe76OutStpFrsOfrD("2");
	        oe76OutStpLine.setOe76OutStpForPc1("A");
	        oe76OutStpLine.setOe76OutStpForPc("Z");
	        oe76OutStpLine.setOe76OutStpFormatZip("123");
	        oe76OutStpLine.setOe76OutStpFormatPhn("123456");
	        oe76OutStpLine.setOe76OutStpFormatAddr("ASD");
	        oe76OutStpLine.setOe76OutStpExeNewSeq("1");
	        oe76OutStpLine.setOe76OutStpEqpAct("ACT");
	        oe76OutStpLine.setOe76OutStpDrvrLdOvrF("N");
	        oe76OutStpLine.setOe76OutStpDriverCount("1");
	        oe76OutStpLine.setOe76OutStpDptC("CODE");
	        oe76OutStpLine.setOe76OutStpCusC("CODE");
	        oe76OutStpLine.setOe76OutStpCurSchWinEndH("2017/2/2");
	        oe76OutStpLine.setOe76OutStpCurSchWinBegH("08:00");
	        oe76OutStpLine.setOe76OutStpCurSchWinBegD("21");
	        oe76OutStpLine.setOe76OutStpCtystC("CODE");
	        oe76OutStpLine.setOe76OutStpCtyNm("CODE");
	        oe76OutStpLine.setOe76OutStpCtyC("CODE");
	        oe76OutStpLine.setOe76OutStpCryC("CODE");
	        oe76OutStpLine.setOe76OutStpContact("CODE");
	        oe76OutStpLine.setOe76OutStpConLstNm("CODE");
	        oe76OutStpLine.setOe76OutStpConI(1);
	        oe76OutStpLine.setOe76OutStpConFrsNm("CODE");
	        oe76OutStpLine.setOe76OutStpCmdC("CODE");
	        oe76OutStpLine.setOe76OutStpBusSitI(1);
	        oe76OutStpLine.setOe76OutStpBusLocNm("CODE");
	        oe76OutStpLine.setOe76OutStpBusLocI(1);
	        oe76OutStpLine.setOe76OutStpApptRsnCd("PICKUP");
	        oe76OutStpLine.setOe76OutStpApptNewRsnCd("PICKUP");
	        oe76OutStpLine.setOe76OutStpApptNbr("1");
	        oe76OutStpLine.setOe76OutStpAdrLn02("NN");
	        oe76OutStpLine.setOe76OutStpAdrLn01("AA");
	        oe76OutStpLine.setOe76OutStpAdrI(1);
	        oe76OutStpLine.setOe76OutStpAction("NO");
	        oe76OutStpLine.setOe76OutStpOfrStpSeqNbr(1);
	        oe76OutStpLineList.add(oe76OutStpLine);
		return oe76OutStpLineList;

	}
	private List<Oe76OutOrdclssLine> prepareOe76OutOrdclssBuffer11() {
		List<Oe76OutOrdclssLine> oe76OutOrdclssLineList=new ArrayList<Oe76OutOrdclssLine>();
		Oe76OutOrdclssLine oe76OutOrdclssLine = new Oe76OutOrdclssLine();

        oe76OutOrdclssLine.setOe76OutOrdclssRqmClsTypC("PYMTMETHOD");
        oe76OutOrdclssLine.setOe76OutOrdclssRqmClsC("COLLECT");
        oe76OutOrdclssLineList.add(oe76OutOrdclssLine);
		return oe76OutOrdclssLineList;

		}
}