package com.jbhunt.loadplannig.integration.backfill.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.ArrivalCheckCallEditService;
import com.jbhunt.loadplannig.integration.backfill.services.LoadedUnloadedCheckCallEditService;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class CheckCallEditController extends BackfillBaseController{

	private final ArrivalCheckCallEditService arrivalCheckCallEditService;
	private final LoadedUnloadedCheckCallEditService loadedUnloadedCheckCallEditService;
	
	@PatchMapping("/checkcalls/arrival")
	public ResponseEntity<BackfillServiceResponse> updateArrivalCheckCall(@RequestBody OperationalPlanDTO operationalPlanDTO){
		log.info("save arrival check call");
		arrivalCheckCallEditService.updateArrivalCheckCall(operationalPlanDTO);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
	
	@PatchMapping("/checkcalls/loaded")
	public ResponseEntity<BackfillServiceResponse> updateLoadedCheckCall(@RequestBody OperationalPlanDTO operationalPlanDTO){
		log.info("save loaded check call");
		loadedUnloadedCheckCallEditService.editLoadedCheckCall(operationalPlanDTO);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
	
	@PatchMapping("/checkcalls/unloaded")
	public ResponseEntity<BackfillServiceResponse> updateUnloadedCheckCall(@RequestBody OperationalPlanDTO operationalPlanDTO){
		log.info("save unloaded check call service");
		loadedUnloadedCheckCallEditService.editUnLoadedCheckCall(operationalPlanDTO);
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
	
}