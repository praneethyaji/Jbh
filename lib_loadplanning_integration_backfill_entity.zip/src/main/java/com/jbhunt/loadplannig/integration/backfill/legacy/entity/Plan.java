package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@Entity
@Table(name = "BKFIL_RSC_PLAN", schema = "ALI")
public class Plan implements Serializable {
    @Id
    @Column(name = "BKFIL_RSC_PLAN_I")
    private Integer resourcePlanId;

    @Column(name = "NEXT_ORD_I")
    private Integer nextOrderId;

    @Column(name = "NEXT_LD_I")
    private Integer nextLoadId;

    @Column(name = "NEXT_LD_NUM")
    private String nextLoadNum;

    @Column(name = "NEXT_LD_SEQ_NUM")
    private Integer legacyOrderId;

    @Column(name = "EQP_I")
    private Integer equipmentId;

    @Column(name = "RSC_RSV_I")
    private Integer resourceReservationId;

    @Column(name = "CRR_RSV_I")
    private Integer carrierReservationId;

    @Column(name = "JOB_I")
    private Integer jobId;

    @Column(name = "TOUR_F")
    private Character tourPlanning ;

    @Column(name = "DSP_NBR")
    private Integer dipatchNumberLegacy;

    @Column(name ="PREPLAN_TYPE")
    private String preplanType;

    @Column(name = "PRG_STT_C")
    private Character programStatusCode;

    @Column(name="ORD_SYS_C")
    private String orderSystem;

}
