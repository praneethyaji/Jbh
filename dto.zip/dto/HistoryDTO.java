package com.jbhunt.loadplannig.integration.backfill.dto;

import lombok.Data;

@Data
public class HistoryDTO {

	private Integer resourceCommunicationLogId;

	private Short legacyCallSequenceNumber;

	private Integer jobId;

	private String driverCode1;

	private String driverCode2;

	private String rate1;

	private String saveRate1;

	private String perDiem1;

	private String savePerDiem1;
	
	private String rate2;

	private String saveRate2;

	private String perDiem2;

	private String savePerDiem2;
	
	private String callTakerInits;
	
	private Integer startHub;
	
	private Integer endHub;

}
