package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "STOP_COMMENT", schema = "ALI")
public class StopComment implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6559116504612828512L;

	@Column(name = "OFR_STP_SEQ_NBR")
    private Integer stopSequenceNumber;

    @Column(name = "CMM")
    private String comment;

    @Id
    @Column(name = "ORD_I")
    private Integer orderId;
    
    @Column(name = "DSP_NBR")
    private Integer dispatchNumber;

    @Column(name = "CMM_SEQ_NBR")
    private Integer commentSequenceNumber;

    @Column(name = "CMM_TYP")
    private String commentType;

    @Column(name = "EXT_CMM_TXT")
    private String extCommentText;

    @Column(name = "CMM_TXT")
    private String commentText;
    
    @Column(name = "CRT_S")
    private OffsetDateTime createTimeStamp;

    @Column(name = "CRT_UID")
    private String createUserId;

    @Column(name = "CRT_PGM_C")
    private String createProgramName;

    @Column(name = "LST_UPD_S")
    private OffsetDateTime lastUpdatedTimeStamp;

    @Column(name = "LST_UPD_UID")
    private String lastUpdateUserId;

    @Column(name = "LST_UPD_PGM_C")
    private String lastUpdateProgramName;

}
