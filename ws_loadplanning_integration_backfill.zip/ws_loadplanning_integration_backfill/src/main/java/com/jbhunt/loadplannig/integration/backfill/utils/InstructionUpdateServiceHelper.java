package com.jbhunt.loadplannig.integration.backfill.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderCommentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.StopCommentRepository;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InCommentsLine;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class InstructionUpdateServiceHelper {

	private final OrderCommentRepository orderCommentRepository;
	private final StopCommentRepository stopCommentRepository;
	private final InstructionUpdateEnricher instructionUpdateEnricher;
	
	 private final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
	 private final DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");


	public Oee5InputChannelData populateComments(OperationalPlanEvent orderUpdateEvent, OrderLoadSync loadDetails,
			Oee5InputChannelData input, int stopSeqNo)  {
		List<Object[]> orderCommentList = orderCommentRepository.findCommentDetailsByOrdId(loadDetails.getLegacyOrderID());
		List<Object[]> stopCommentList = stopCommentRepository.findStopDetailsByOrdId(loadDetails.getLegacyOrderID());
		int stopSequenceNumber = stopSeqNo;
		
        input.getOee5InCommentsBuffer3().clear();
        
        List<Oee5InCommentsLine> commentList = instructionUpdateEnricher.setInComments(orderUpdateEvent);
        
        if (null != orderCommentList) {
			for (Object[] orderComment : orderCommentList) {
				try {
					commentList.add(setOrderComments(orderComment));
				} catch (ParseException e) {
					 log.error("Error while processCommentUpdate" + e);
			         throw new JBHuntRuntimeException("Error while insertRecordsForEDIBackfill" + e);
				}
			}
		}
        
        if (null != stopCommentList) {
			for (Object[] stopComment : stopCommentList) {
				try {
					commentList.add(setStopComments(stopComment, stopSequenceNumber));
				} catch (ParseException e) {
					 log.error("Error while processCommentUpdate" + e);
			         throw new JBHuntRuntimeException("Error while insertRecordsForEDIBackfill" + e);
				}
				++stopSequenceNumber;
			}
		}
        
		
        int dspNbr = 0;
        input.getOee5InputBuffer1().setOee5InputCommentsChgF("Y");
        input.getOee5InputBuffer1().setOee5InputNbrOfComments((short) commentList.size());
        input.getOee5InCommentsBuffer3().addAll(commentList);
        for (Oee5InCommentsLine oee5InCommentsLine : input.getOee5InCommentsBuffer3()) {
            oee5InCommentsLine.setOee5InCommentsSeqNbr((short) ++dspNbr);
        }
        return input;
	}
	
	public void deleteOrderComments(OrderLoadSync loadDetails) {
		
		Integer orderCommentDeleted = null;
        orderCommentDeleted = orderCommentRepository.deleteOrderComments(loadDetails.getLegacyOrderID());
        log.info("orderCommentDeleted" + orderCommentDeleted);
	}
	
	public void deleteStopComments(OrderLoadSync loadDetails) {
		
		Integer deleteStopComments = null;
		deleteStopComments = stopCommentRepository.deleteStopComments(loadDetails.getLegacyOrderID());
        log.info("stopCommentDeleted" + deleteStopComments);
	}
	
	
	private Oee5InCommentsLine setStopComments(Object[] stopComment, int stopSeqNo) throws ParseException {
        int sequenceNumber = stopSeqNo;
        Oee5InCommentsLine oee5InCommentsLine = new Oee5InCommentsLine();
        oee5InCommentsLine.setOee5InCommentsCmm(stopComment[7].toString().trim());
        oee5InCommentsLine.setOee5InCommentsJbhsoacS("");
        oee5InCommentsLine.setOee5InCommentsSeqNbr(Short.parseShort(stopComment[4].toString()));
        short stopSequenceNbr = (short)++ sequenceNumber;
        oee5InCommentsLine.setOee5InCommentsStopSeqNbr(stopSequenceNbr);
        oee5InCommentsLine.setOee5InCommentsCrtPgmId(stopComment[3].toString().trim());
        Date date = inputFormat.parse(stopComment[9].toString());
        oee5InCommentsLine.setOee5InCommentsCrtTimestamp(df.format(date));
        oee5InCommentsLine.setOee5InCommentsCrtUsrId(stopComment[10].toString().trim());
        oee5InCommentsLine.setOee5InCommentsCmmTypC(stopComment[5].toString().trim());
        return oee5InCommentsLine;
        
    }
	
	private Oee5InCommentsLine setOrderComments(Object[] orderComment) throws ParseException {
		Oee5InCommentsLine oee5InCommentsLine = new Oee5InCommentsLine();
		oee5InCommentsLine.setOee5InCommentsCmm(orderComment[6].toString().trim());
		oee5InCommentsLine.setOee5InCommentsJbhsoacS("");
		oee5InCommentsLine.setOee5InCommentsSeqNbr(Short.parseShort(orderComment[3].toString()));
		oee5InCommentsLine.setOee5InCommentsCrtPgmId(orderComment[2].toString().trim());
		Date date = inputFormat.parse(orderComment[7].toString());
        oee5InCommentsLine.setOee5InCommentsCrtTimestamp(df.format(date));
		oee5InCommentsLine.setOee5InCommentsCrtUsrId(orderComment[8].toString().trim());
		oee5InCommentsLine.setOee5InCommentsCmmTypC(orderComment[4].toString().trim());
		return oee5InCommentsLine;

	}
	
}
