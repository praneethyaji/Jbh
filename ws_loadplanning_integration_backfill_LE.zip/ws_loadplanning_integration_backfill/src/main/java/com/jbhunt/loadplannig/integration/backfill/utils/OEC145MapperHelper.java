package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.ordermanagement.order.entity.BulkOrderUploadDetail;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InNonstpLine;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InStpLine;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutNonstpLine;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData.Oe76OutStpLine;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class OEC145MapperHelper {
	
	public List<Oee5InNonstpLine> mapNonStopBuffer(Oe76OutputChannelData orderDetails) {

		List<Oee5InNonstpLine> nonStopBuffer = new ArrayList<>();

		for (Oe76OutNonstpLine oe76OutNonstpLine : orderDetails.getOe76OutNonstpBuffer12()) {
			Oee5InNonstpLine oee5InNonstpLine = new Oee5InNonstpLine();
			oee5InNonstpLine.setOee5InNonstpAdrI(oe76OutNonstpLine.getOe76OutNonstpAdrI());
			oee5InNonstpLine.setOee5InNonstpAdrLn01(oe76OutNonstpLine.getOe76OutNonstpAdrLn01());
			oee5InNonstpLine.setOee5InNonstpAdrLn02(oe76OutNonstpLine.getOe76OutNonstpAdrLn02());
			oee5InNonstpLine.setOee5InNonstpBusLocI(oe76OutNonstpLine.getOe76OutNonstpBusLocI());
			oee5InNonstpLine.setOee5InNonstpBusLocNm(oe76OutNonstpLine.getOe76OutNonstpBusLocNm());
			oee5InNonstpLine.setOee5InNonstpBusSitI(oe76OutNonstpLine.getOe76OutNonstpBusSitI());
			oee5InNonstpLine.setOee5InNonstpConFrsNm(oe76OutNonstpLine.getOe76OutNonstpConFrsNm());
			oee5InNonstpLine.setOee5InNonstpConI(oe76OutNonstpLine.getOe76OutNonstpConI());
			oee5InNonstpLine.setOee5InNonstpConLstNm(oe76OutNonstpLine.getOe76OutNonstpConLstNm());
			oee5InNonstpLine.setOee5InNonstpCryC(oe76OutNonstpLine.getOe76OutNonstpCryC());
			oee5InNonstpLine.setOee5InNonstpCtyC(oe76OutNonstpLine.getOe76OutNonstpCtyC());
			oee5InNonstpLine.setOee5InNonstpCtyNm(oe76OutNonstpLine.getOe76OutNonstpCtyNm());
			oee5InNonstpLine.setOee5InNonstpCusC(oe76OutNonstpLine.getOe76OutNonstpCusC());
			oee5InNonstpLine.setOee5InNonstpDptC(oe76OutNonstpLine.getOe76OutNonstpDptC());
			oee5InNonstpLine.setOee5InNonstpPhnArC(oe76OutNonstpLine.getOe76OutNonstpPhnArC());
			oee5InNonstpLine.setOee5InNonstpPhnExt(oe76OutNonstpLine.getOe76OutNonstpPhnExt());
			oee5InNonstpLine.setOee5InNonstpPhnI(oe76OutNonstpLine.getOe76OutNonstpPhnI());
			oee5InNonstpLine.setOee5InNonstpPhnNbr(oe76OutNonstpLine.getOe76OutNonstpPhnNbr());
			oee5InNonstpLine.setOee5InNonstpPhnPfx(oe76OutNonstpLine.getOe76OutNonstpPhnPfx());
			oee5InNonstpLine.setOee5InNonstpPst1C(oe76OutNonstpLine.getOe76OutNonstpPst1C());
			oee5InNonstpLine.setOee5InNonstpPst2C(oe76OutNonstpLine.getOe76OutNonstpPst2C());
			oee5InNonstpLine.setOee5InNonstpPstExtC(oe76OutNonstpLine.getOe76OutNonstpPstExtC());
			oee5InNonstpLine.setOee5InNonstpStC(oe76OutNonstpLine.getOe76OutNonstpStC());
			oee5InNonstpLine.setOee5InNonstpLstUpdS(oe76OutNonstpLine.getOe76OutNonstpLstUpdS());
			nonStopBuffer.add(oee5InNonstpLine);
		}

		return nonStopBuffer;
	}

	public List<Oee5InStpLine> mapStopBuffer(Oe76OutputChannelData orderDetails) {
        List<Oee5InStpLine> stopBuffer = new ArrayList<>();
		for (Oe76OutStpLine oe76OutStpLine : orderDetails.getOe76OutStpBuffer13()) {
			Oee5InStpLine oee5InStpLine = new Oee5InStpLine();
			oee5InStpLine.setOee5InStpSuggEndTime(oe76OutStpLine.getOe76OutStpSuggEndTime());
			oee5InStpLine.setOee5InStpPstExtC(oe76OutStpLine.getOe76OutStpPstExtC());
			oee5InStpLine.setOee5InStpPhnExt(oe76OutStpLine.getOe76OutStpPhnExt());
			oee5InStpLine.setOee5InStpWgt(oe76OutStpLine.getOe76OutStpWeight());
			oee5InStpLine.setOee5InStpTypeC(oe76OutStpLine.getOe76OutStpTypeC());
			oee5InStpLine.setOee5InStpSuggDate(oe76OutStpLine.getOe76OutStpSuggDate());
			oee5InStpLine.setOee5InStpSuggBegTime(oe76OutStpLine.getOe76OutStpSuggBegTime());
			oee5InStpLine.setOee5InStpStC(oe76OutStpLine.getOe76OutStpStC());
			oee5InStpLine.setOee5InStpStatus(oe76OutStpLine.getOe76OutStpStatus());
			oee5InStpLine.setOee5InStpSbtskLstUpdS(oe76OutStpLine.getOe76OutStpSbtskLstUpdS());
			oee5InStpLine.setOee5InStpApptRsnCd(oe76OutStpLine.getOe76OutStpApptRsnCd());
			oee5InStpLine.setOee5InStpRefNbrLstUpdS(oe76OutStpLine.getOe76OutStpRefNbrLstUpdS());
			oee5InStpLine.setOee5InStpQty(oe76OutStpLine.getOe76OutStpQty());
			oee5InStpLine.setOee5InStpPstExtC(oe76OutStpLine.getOe76OutStpPstExtC());
			oee5InStpLine.setOee5InStpPst2C(oe76OutStpLine.getOe76OutStpPst2C());
			oee5InStpLine.setOee5InStpPst1C(oe76OutStpLine.getOe76OutStpPst1C());
			oee5InStpLine.setOee5InStpPreF(oe76OutStpLine.getOe76OutStpPreF());
			oee5InStpLine.setOee5InStpPoolInd(oe76OutStpLine.getOe76OutStpPoolInd());
			oee5InStpLine.setOee5InStpPhnPfx(oe76OutStpLine.getOe76OutStpPhnPfx());
			oee5InStpLine.setOee5InStpPhnNbr(oe76OutStpLine.getOe76OutStpPhnNbr());
			oee5InStpLine.setOee5InStpPhnI(oe76OutStpLine.getOe76OutStpPhnI());
			oee5InStpLine.setOee5InStpPhnExt(oe76OutStpLine.getOe76OutStpPhnExt());
			oee5InStpLine.setOee5InStpPhnCryC(oe76OutStpLine.getOe76OutStpPhnCryC());
			oee5InStpLine.setOee5InStpPhnArC(oe76OutStpLine.getOe76OutStpPhnArC());
			oee5InStpLine.setOee5InStpoOfrStpSeqNbr(oe76OutStpLine.getOe76OutStpOfrStpSeqNbr());
			oee5InStpLine.setOee5InStpNewSeq(oe76OutStpLine.getOe76OutStpNewSeq());
			oee5InStpLine.setOee5InStpLstUpdS(oe76OutStpLine.getOe76OutStpLstUpdS());
			oee5InStpLine.setOee5InStpLoader(oe76OutStpLine.getOe76OutStpLoader());
			oee5InStpLine.setOee5InStpLoadedOn(oe76OutStpLine.getOe76OutStpLoadedOn());
			oee5InStpLine.setOee5InStpLnItmSeqNbr(oe76OutStpLine.getOe76OutStpLnItmSeqNbr());
			oee5InStpLine.setOee5InStpJbhedisS(oe76OutStpLine.getOe76OutStpJbhedisS());
			oee5InStpLine.setOee5InStpHazardous(oe76OutStpLine.getOe76OutStpHazardous());
			oee5InStpLine.setOee5InStpFrsOfrH(oe76OutStpLine.getOe76OutStpFrsOfrH());
			oee5InStpLine.setOee5InStpFrsOfrD(oe76OutStpLine.getOe76OutStpFrsOfrD());
			oee5InStpLine.setOee5InStpForPc1(oe76OutStpLine.getOe76OutStpForPc1());
			oee5InStpLine.setOee5InStpForPc(oe76OutStpLine.getOe76OutStpForPc());
			oee5InStpLine.setOee5InStpFormatZip(oe76OutStpLine.getOe76OutStpFormatZip());
			oee5InStpLine.setOee5InStpFormatPhn(oe76OutStpLine.getOe76OutStpFormatPhn());
			oee5InStpLine.setOee5InStpFormatAddr(oe76OutStpLine.getOe76OutStpFormatAddr());
			oee5InStpLine.setOee5InStpExeNewSeq(oe76OutStpLine.getOe76OutStpExeNewSeq());
			oee5InStpLine.setOee5InStpEqpAct(oe76OutStpLine.getOe76OutStpEqpAct());
			oee5InStpLine.setOee5InStpDrvrLdOvrF(oe76OutStpLine.getOe76OutStpDrvrLdOvrF());
			oee5InStpLine.setOee5InStpDriverCount(oe76OutStpLine.getOe76OutStpDriverCount());
			oee5InStpLine.setOee5InStpDptC(oe76OutStpLine.getOe76OutStpDptC());
			oee5InStpLine.setOee5InStpCusC(oe76OutStpLine.getOe76OutStpCusC());
			oee5InStpLine.setOee5InStpCurSchWinEndH(oe76OutStpLine.getOe76OutStpCurSchWinEndH());
			oee5InStpLine.setOee5InStpCurSchWinBegH(oe76OutStpLine.getOe76OutStpCurSchWinBegH());
			oee5InStpLine.setOee5InStpCurSchWinBegD(oe76OutStpLine.getOe76OutStpCurSchWinBegD());
			oee5InStpLine.setOee5InStpCtystC(oe76OutStpLine.getOe76OutStpCtystC());
			oee5InStpLine.setOee5InStpCtyNm(oe76OutStpLine.getOe76OutStpCtyNm());
			oee5InStpLine.setOee5InStpCtyC(oe76OutStpLine.getOe76OutStpCtyC());
			oee5InStpLine.setOee5InStpCryC(oe76OutStpLine.getOe76OutStpCryC());
			oee5InStpLine.setOee5InStpContact(oe76OutStpLine.getOe76OutStpContact());
			oee5InStpLine.setOee5InStpConLstNm(oe76OutStpLine.getOe76OutStpConLstNm());
			oee5InStpLine.setOee5InStpConI(oe76OutStpLine.getOe76OutStpConI());
			oee5InStpLine.setOee5InStpConFrsNm(oe76OutStpLine.getOe76OutStpConFrsNm());
			oee5InStpLine.setOee5InStpCmdC(oe76OutStpLine.getOe76OutStpCmdC());
			oee5InStpLine.setOee5InStpBusSitI(oe76OutStpLine.getOe76OutStpBusSitI());
			oee5InStpLine.setOee5InStpBusLocNm(oe76OutStpLine.getOe76OutStpBusLocNm());
			oee5InStpLine.setOee5InStpBusLocI(oe76OutStpLine.getOe76OutStpBusLocI());
			oee5InStpLine.setOee5InStpApptRsnCd(oe76OutStpLine.getOe76OutStpApptRsnCd());
			oee5InStpLine.setOee5InStpApptNewRsnCd(oe76OutStpLine.getOe76OutStpApptNewRsnCd());
			oee5InStpLine.setOee5InStpApptNbr(oe76OutStpLine.getOe76OutStpApptNbr());
			oee5InStpLine.setOee5InStpAdrLn02(oe76OutStpLine.getOe76OutStpAdrLn02());
			oee5InStpLine.setOee5InStpAdrLn01(oe76OutStpLine.getOe76OutStpAdrLn01());
			oee5InStpLine.setOee5InStpAdrI(oe76OutStpLine.getOe76OutStpAdrI());
            setDefaultValues(oe76OutStpLine, oee5InStpLine);
			oee5InStpLine.setOee5InStpAction(oe76OutStpLine.getOe76OutStpAction());
			oee5InStpLine.setOee5InStpPcsQBasC("    ");
			oee5InStpLine.setOee5InStpWgtBasC("");
			Integer itemVolume = 0;
			oee5InStpLine.setOee5InStpVol(itemVolume);
			oee5InStpLine.setOee5InStpVolBasC("");
			oee5InStpLine.setOee5InStpPreF("Y");
			stopBuffer.add(oee5InStpLine);
		}

		return stopBuffer;
	}

    private Oe76OutStpLine setDefaultValues(Oe76OutStpLine oe76OutStpLine, Oee5InStpLine oee5InStpLine) {
        oee5InStpLine.setOee5InApptAdrI(
                oe76OutStpLine.getOe76OutStpAdrI() == 0 ? 0 : oe76OutStpLine.getOe76OutStpAdrI());
        oee5InStpLine.setOee5InApptBusSitI(
                oe76OutStpLine.getOe76OutStpBusSitI() == 0 ? 0 : oe76OutStpLine.getOe76OutStpBusSitI());
        oee5InStpLine.setOee5InApptCusC(StringUtils.defaultIfEmpty(oe76OutStpLine.getOe76OutStpCusC(), ""));
        return oe76OutStpLine;
    }
}
