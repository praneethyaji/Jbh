package com.jbhunt.loadplannig.integration.backfill.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.springframework.stereotype.Service;

import com.google.common.base.Splitter;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanAdditionalInstructionDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanEquipmentRequirementDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.masterdata.location.client.LocationClient;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InCommentsLine;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class InstructionUpdateEnricher {

	private final LocationClient locationClient;

	private final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
	private final DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");

	public List<Oee5InCommentsLine> setInComments(OperationalPlanEvent operationalPlanEvent) {

		List<Oee5InCommentsLine> instructionList = new ArrayList<>();

		if (operationalPlanEvent != null) {
			List<OperationalPlanAdditionalInstructionDTO> additionalInstructionDTOs = operationalPlanEvent
					.getOperationalPlanDTO().getOperationalPlanAdditionalInstructions();
			additionalInstructionDTOs.forEach(additionalInstructionDTO -> {
				if (StringUtils.equals(additionalInstructionDTO.getSourceApplicationCode(), CommonConstants.OPEX)) {
					Oee5InCommentsLine oee5InCommentsLine = new Oee5InCommentsLine();
					oee5InCommentsLine.setOee5InCommentsCmm(
							additionalInstructionDTO.getAdditionalInstructionText().toUpperCase().trim());
					oee5InCommentsLine.setOee5InCommentsCmmTypC("GENERAL");
					oee5InCommentsLine.setOee5InCommentsJbhsoacS("");
					oee5InCommentsLine.setOee5InCommentsSeqNbr((short) 0);
					oee5InCommentsLine.setOee5InCommentsCrtUsrId(
							operationalPlanEvent.getOperationalPlanDTO().getCreateUserId().trim());
					oee5InCommentsLine.setOee5InCommentsCrtPgmId(
							Optional.ofNullable(operationalPlanEvent.getOperationalPlanDTO().getCreateProgramName())
									.map(String::trim).map(id -> (id.length() > 8) ? id.substring(0, 8) : id)
									.orElse("PROCESID"));
					log.info("Create Time Stamp >>>>>>>>>>>>>>>>>>>> {} ",
							operationalPlanEvent.getOperationalPlanDTO().getCreateTimestamp().toString());
					try {
						oee5InCommentsLine.setOee5InCommentsCrtTimestamp(df.format(inputFormat.parse(
								operationalPlanEvent.getOperationalPlanDTO().getCreateTimestamp().toString().trim())));
						instructionList.add(oee5InCommentsLine);
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}
			});

			// set driver comments
			setDriverComments(operationalPlanEvent, instructionList);

			// set equipment comments
			setEquipmentComments(operationalPlanEvent, instructionList);
		}
		return instructionList;
	}

	private void setDriverComments(OperationalPlanEvent operationalPlanEvent,
			List<Oee5InCommentsLine> instructionList) {
		int stopSeqNbr = 1;
		for (OperationalPlanStopDTO stopDTO : operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops()) {
			for (OperationalPlanAdditionalInstructionDTO stopInstruction : stopDTO
					.getOperationalPlanAdditionalInstructions()) {
				if (StringUtils.equals(stopInstruction.getSourceApplicationCode(), CommonConstants.OPEX)) {
					populateInstructionList(stopInstruction, stopDTO, operationalPlanEvent, stopSeqNbr,
							instructionList);
				}
			}
			++stopSeqNbr;
		}
	}

	private void populateInstructionList(OperationalPlanAdditionalInstructionDTO stopInstruction,
			OperationalPlanStopDTO stopDTO, OperationalPlanEvent operationalPlanEvent, int stopSeqNbr,
			List<Oee5InCommentsLine> instructionList) {
		for (final String commtxt : Splitter.fixedLength(45)
				.split(stopInstruction.getAdditionalInstructionText().trim())) {
			log.info(commtxt);
			Oee5InCommentsLine oee5InCommentsLine = new Oee5InCommentsLine();
			try {
				oee5InCommentsLine.setOee5InCommentsCmm(commtxt.toUpperCase().trim());
				oee5InCommentsLine.setOee5InCommentsCmmTypC("DRIVER");
				oee5InCommentsLine.setOee5InCommentsJbhsoacS(
						locationClient.findLocationProfilebyLocationCode(stopDTO.getLocationId())
								.getLocationProfileDTO().getLocationCode());
				oee5InCommentsLine.setOee5InCommentsStopSeqNbr(
						(operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops().size() == stopSeqNbr)
								? (short) 99
								: (short) stopSeqNbr);
			} catch (JSONException e) {
				throw new JBHuntRuntimeException(e.getMessage());
			}
			instructionList.add(oee5InCommentsLine);
		}

	}

	private void setEquipmentComments(OperationalPlanEvent operationalPlanEvent,
			List<Oee5InCommentsLine> instructionList) {
		for (OperationalPlanEquipmentRequirementDTO operationPlanEquipmentRequirementDTO : operationalPlanEvent
				.getOperationalPlanDTO().getOperationalPlanEquipmentRequirements()) {
			for (OperationalPlanAdditionalInstructionDTO EquipmentRequirementAdditionalInstruction : operationPlanEquipmentRequirementDTO
					.getOperationalPlanAdditionalInstructions()) {
				if (StringUtils.equals(EquipmentRequirementAdditionalInstruction.getSourceApplicationCode(),
						CommonConstants.OPEX)) {
					for (final String commtxt : Splitter.fixedLength(45)
							.split(EquipmentRequirementAdditionalInstruction.getAdditionalInstructionText().trim())) {
						Oee5InCommentsLine oee5InCommentsLine = new Oee5InCommentsLine();
						oee5InCommentsLine.setOee5InCommentsCmm(commtxt.toUpperCase().trim());
						oee5InCommentsLine.setOee5InCommentsCmmTypC("DRIVER");
						oee5InCommentsLine.setOee5InCommentsJbhsoacS("");
						instructionList.add(oee5InCommentsLine);
					}
				}
			}
		}
	}
}
