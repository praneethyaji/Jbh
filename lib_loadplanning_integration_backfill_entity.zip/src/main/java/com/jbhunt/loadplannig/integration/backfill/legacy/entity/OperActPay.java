package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "OPR_ACT_PAY", schema = "ALI")
public class OperActPay implements Serializable {

	private static final long serialVersionUID = -407696220899411731L;

	@EmbeddedId
    private SourceId id;

	@Column(name = "JOB_ID")
	private Integer jobId;

	@Column(name = "ORD_I")
	private Integer orderId;

	@Column(name = "RAT_A")
	private String rate1;

	@Column(name = "ACT_TYP")
	private String activityType;

	@Column(name = "OPR_POS")
	private Short position;

	@Column(name = "SRC_NM")
	private String sourceName;

}
