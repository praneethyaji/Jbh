package com.jbhunt.loadplannig.integration.backfill.exception;

public class Mainframe404Exception extends RuntimeException {
    public Mainframe404Exception(String message){
        super(message);
    }
}
