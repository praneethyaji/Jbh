package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.*;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.*;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.relaxedRequestFields;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.document;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.*;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.*;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.mdm.dto.LocationProfileDTO;
import com.lmc363i.lmc363.LMC363Port;
import com.request.lmc363i.lmc363.ProgramInterface;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc341i.lmc341.LMC341Port;
import com.lmc342i.lmc342.LMC342Port;
import com.lmc361i.lmc361.LMC361Port;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea;
import com.request.lmc341i.lmc341.ProgramInterface.Lmc341CommArea.Lmc341InputArea;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables;
import com.request.lmc361i.lmc361.ProgramInterface.Lmc361IRecord;
import com.response.lmc341i.lmc341.ProgramInterface.Lmc341OutputArea;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava.Wo42ErrorVariables;
import com.response.lmc361i.lmc361.ProgramInterface.Lmc361ORecord;

import javax.xml.ws.Holder;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class OperationsexecutionLoadplanintegrationbackfillControllerIT {

	@MockBean
	PIDCredentials pidCredentials;
	
	@MockBean
	LocationProfileDTOs locationProfileDTOs;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http")
			.host("operationsexecutionswitchplan.jbhunt.com").removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public static final String userName = "user";

	public static final String password = "pass";

	public static final String CREATE_SWITCH_REQUEST = "/json/CreateSwitchRequestWithEquipment.json";

	public static final String CREATE_SWITCH_REQUEST_SECOND_RESOURCE_PERSON = "/json/CreateSwitchRequestWithPerson.json";

	private static final String SEND_OPERATIONAL_PLAN_JSON_PATH = "/json/OperationalPlanEvent.json";

	private static final String SEND_OPERATIONAL_PLAN_JSON_CANCELL = "/json/OperationalPlanEventCancell.json";

	private static final String SEND_OPERATIONAL_PLAN_JSON_DRIVER = "/json/DriverTruckPairing.json";

	private static final String SEND_OPERATIONAL_PLAN_JSON_DRIVER_CANCELL = "/json/DriverSendPlanCancell.json";
	
	private static final String SEND_OPERATIONAL_PLAN_JSON_DISPATCH = "/json/DispatchOperationalSendPlan.json";
	
	private static final String INBOUND_CREATE_DRIVER_PREPLAN_JSON = "/json/InboundToYardCreate.json";
	private static final String INBOUND_CREATE_DRIVER_TRUCK_PREPLAN_JSON = "/json/InboundToYardEquipmentCreate.json";
	private static final String INBOUND_UPDATE_DRIVER_PREPLAN_JSON = "/json/InboundToYardUpdate.json";
	private static final String INBOUND_UPDATE_DRIVER_TRUCK_PREPLAN_JSON = "/json/InboundToYardUpdateEquipment.json";
	
	
	

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private LMC341Port lmc341Port;

	@MockBean
	private LMC342Port lmc342Port;
	
	@MockBean
	private LMC361Port lMC361Port;

	@MockBean
	private LMC363Port lmc363Port;

	private Lmc361ORecord lmc361ORecord;

	private Lmc341OutputArea output;

	private Lmc341CommArea finalInput;

	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;
	
	@MockBean 
	private  EquipmentRepository equipmentRepository;

	@MockBean
	private OrderLoadRepository orderLoadRepository;

	@MockBean
	private SubTaskRepository subTaskRepository;

	@MockBean
	private TaskRepository taskRepository;

	@MockBean
	private RsvrscRepository rsvrscRepository;

	@MockBean
	private TpndJobAsnRepository tpndJobAsnRepository;


	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void testSendPlan() throws Exception {

		testSendPlanCancellOrAssign(SEND_OPERATIONAL_PLAN_JSON_PATH);
	}

	@Test
	public void testSendPlanCancell() throws Exception {

		testSendPlanCancellOrAssign(SEND_OPERATIONAL_PLAN_JSON_CANCELL);
	}

	@Test
	public void testSendDriverPrePlan() throws Exception {
		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[7885243]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		TEquipment equipment= new TEquipment();
		equipment.setTrailerNumber("353086");
		equipment.setCurrentEstimateTimeArrivelDate("2019-7-15");
		equipment.setCurrentEstimateTimeArrivelHour("12.45.05");
		equipment.setLastDispatchOrderNumber("RA97938");
		when(equipmentRepository.getLastDispatchOrderDetails("353086")).thenReturn(equipment);

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(1010479);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

		when(orderLoadRepository.findLoadDetailsByOrderID(Mockito.anyInt())).thenReturn(tOrder);
		

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/DriverSendPlan.json")),
				OperationalPlanEvent.class);

		output = new Lmc341OutputArea();
		output.setLmc341ErrorMessage("Mock");
		output.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output);


		Wo42ComReturnToJava output = new Wo42ComReturnToJava();

		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		output.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		System.out.println("response ---- >>> " + response.asString());

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void testSendDriverPrePlanError() throws Exception {
		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");
		when(orderLoadRepository.findLoadDetailsByOrderID(Mockito.anyInt())).thenReturn(tOrder);

		TSubtask1 tSubtask1 = new TSubtask1();
		tSubtask1.setJobId(122);
		tSubtask1.setPreferanceSequenceNumber(1002);
		tSubtask1.setCurrentAppointmnetBegHour("2019-05-31 11:03:51.604942");
		tSubtask1.setCurrentAppointmnetBegDate("2019-05-31 11:03:51.604942");
		tSubtask1.setCurrentApointmentEndHour("2019-05-31 11:03:51.604942");
		tSubtask1.setBusinessId(34);
		tSubtask1.setCityId("FDOD7");
		tSubtask1.setSubTaskID(5);
		tSubtask1.setCustomerCode("YO");
		tSubtask1.setRequestTyId("4");


		List<TSubtask1> listSubTasks =new ArrayList<>();
		listSubTasks.add(tSubtask1);
		when(subTaskRepository.findSubTaskDetailsByTaskId(Mockito.anyInt())).thenReturn(listSubTasks);

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[7885243]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/DriverSendPlan.json")),
				OperationalPlanEvent.class);

		output = new Lmc341OutputArea();
		output.setLmc341ErrorMessage("Mock");
		output.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenThrow(new RuntimeException(getError()));


		Wo42ComReturnToJava output = new Wo42ComReturnToJava();

		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		output.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
	}

	public void testSendPlanCancellOrAssign(String filePathJson) throws Exception {

		// ARRANGE
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");
		when(orderLoadRepository.findLoadDetailsByOrderID(Mockito.anyInt())).thenReturn(tOrder);

		when(taskRepository.findLastUpdatedTimeStampBytaskId(Mockito.anyInt())).thenReturn("66777");

		TPndJobAsn tPndJobAsn = new TPndJobAsn();
		tPndJobAsn.setLasUpdateTimeStamp("2019-05-31 11:03:51.604942");
		when(tpndJobAsnRepository.findTPNJobDetailsByTaskId(Mockito.anyInt())).thenReturn(tPndJobAsn);
		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[7885243]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(filePathJson)), OperationalPlanEvent.class);

		Lmc341InputArea inputArea = null;
		finalInput = new Lmc341CommArea();
		finalInput.setLmc341InputArea(inputArea);

		output = new Lmc341OutputArea();
		output.setLmc341ErrorMessage("Mock");
		output.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output);
		Wo42ComReturnToJava output = new Wo42ComReturnToJava();
		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ErrorKey1("");
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		Wo42ErrorVariables.setWo42Message("");
		Wo42ErrorVariables.setWo42CicsReturnCode(399);
		Wo42ErrorVariables.setWo42ErrorKey2("");

		output.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		System.out.println("response ---- >>> " + response.asString());

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void testSendDriverPrePlanCancell() throws Exception {

		sendPreplanassignOrCancel(SEND_OPERATIONAL_PLAN_JSON_DRIVER_CANCELL);

	}

	public void sendPreplanassignOrCancel(String jsonPath) throws Exception {

		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[7885243]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");
		when(orderLoadRepository.findLoadDetailsByOrderID(Mockito.anyInt())).thenReturn(tOrder);
		
		TSubtask1 tSubtask1 = new TSubtask1();
		tSubtask1.setJobId(122);
		tSubtask1.setPreferanceSequenceNumber(1002);
		tSubtask1.setCurrentAppointmnetBegHour("2019-05-31 11:03:51.604942");
		tSubtask1.setCurrentAppointmnetBegDate("2019-05-31 11:03:51.604942");
		tSubtask1.setCurrentApointmentEndHour("2019-05-31 11:03:51.604942");
		tSubtask1.setBusinessId(34);
		tSubtask1.setCityId("FDOD7");
		tSubtask1.setSubTaskID(5);
		tSubtask1.setCustomerCode("YO");
		tSubtask1.setRequestTyId("4");


		List<TSubtask1> listSubTasks =new ArrayList<>();
		listSubTasks.add(tSubtask1);
		when(subTaskRepository.findSubTaskDetailsByTaskId(Mockito.anyInt())).thenReturn(listSubTasks);
		Reservation reservation= new Reservation();
		reservation.setLastUpdateTimeStamp("2019-05-31 11:03:51.604942");
		reservation.setReservationId(1010479);
		when(rsvrscRepository.getrsvDetailsofDriver(Mockito.anyInt())).thenReturn(reservation);

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(jsonPath)),
				OperationalPlanEvent.class);


		output = new Lmc341OutputArea();
		output.setLmc341ErrorMessage("Mock");
		output.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output);



		Wo42ComReturnToJava output = new Wo42ComReturnToJava();

		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		output.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		System.out.println("response ---- >>> " + response.asString());

		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void sendPreplanArrivalCheckCall() throws Exception {

		testCheckcall();
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/ArrivalCheckCall.json")),
				OperationalPlanEvent.class);

		Response response = given(this.requestSpecification).log().all().auth().basic(userName, password)
				.filter(document("ProcessOperationalPlans",preprocessRequest(uriOverride,prettyPrint()),
						preprocessResponse(prettyPrint()),relaxedRequestFields(processCheckCallsRequest())))
				.accept(ContentType.JSON).contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");

		System.out.println("response ---- >>> " + response.asString());
		Mockito.verify(lmc363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void sendPreplanLoadedCheckCall() throws Exception {

		testCheckcall();
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/LoadedCheckCall.json")),
				OperationalPlanEvent.class);
		TEquipment trailerEquipment = new TEquipment();
		trailerEquipment.setEquipmentId(65);
		trailerEquipment.setTrailerPrefix("543434");
		trailerEquipment.setTrailerNumber("333423");
		when(equipmentRepository.getTrailerContainerByEquipmentId(Mockito.any())).thenReturn(trailerEquipment);

		Response response = given(this.requestSpecification).log().all().auth().basic(userName, password)
				.filter(document("ProcessOperationalPlans",preprocessRequest(uriOverride,prettyPrint()),
				preprocessResponse(prettyPrint()),relaxedRequestFields(processCheckCallsRequest())))
				.accept(ContentType.JSON).contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");

		System.out.println("response ---- >>> " + response.asString());
		Mockito.verify(lmc363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}
	@Test
	public void sendPreplanUnloadedCheckCall() throws Exception {

		testCheckcall();
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream("/json/UnloadedCheckCall.json")),
				OperationalPlanEvent.class);
		TEquipment trailerEquipment = new TEquipment();
		trailerEquipment.setEquipmentId(65);
		trailerEquipment.setTrailerPrefix("543434");
		trailerEquipment.setTrailerNumber("333423");
		when(equipmentRepository.getTrailerContainerByEquipmentId(Mockito.any())).thenReturn(trailerEquipment);

		Response response = given(this.requestSpecification).log().all().auth().basic(userName, password)
				.filter(document("ProcessOperationalPlans",preprocessRequest(uriOverride,prettyPrint()),
						preprocessResponse(prettyPrint()),relaxedRequestFields(processCheckCallsRequest())))
				.accept(ContentType.JSON).contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");

		System.out.println("response ---- >>> " + response.asString());
		Mockito.verify(lmc363Port,times(1)).lmc363Operation(Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord.class),Mockito.any(com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava.class),Mockito.anyString(),Mockito.anyObject(),Mockito.anyObject(),Mockito.anyObject());

		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}

	@Test
	public void testDispatchcall() throws Exception {

		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));
		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

        wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(1010479);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

		when(orderLoadRepository.findLoadDetailsByOrderID(Mockito.anyInt())).thenReturn(tOrder);
        
        TEquipment tEquipment = new TEquipment(); 
        
        tEquipment.setTrailerNumber("356789");
        tEquipment.setTrailerPrefix("AMZN");
        tEquipment.setCurrentEstimateTimeArrivelDate("2018-05-01");
        tEquipment.setCurrentEstimateTimeArrivelHour("01.50.00");
        tEquipment.setEquipmentId(9737742);
        when(equipmentRepository.getTrailerDetails("353086")).thenReturn(tEquipment);
        
        when(equipmentRepository.fetchEqpDetailsByEqpId("9737742")).thenReturn(tEquipment);
        
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(SEND_OPERATIONAL_PLAN_JSON_DISPATCH)),
				OperationalPlanEvent.class);

		lmc361ORecord = new Lmc361ORecord();
		lmc361ORecord.setLmc361OIoErrorDesc(""); 

		when(lMC361Port.lmc361Operation(Mockito.any(Lmc361IRecord.class))).thenReturn(lmc361ORecord);


		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password)
				.filter(document("ProcessDispatch", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processDispatchRequest())))
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		System.out.println("response ---- >>> " + response.asString());

		assertThat(response.statusCode(), is(HttpStatus.SC_OK));

	}
	
	
	
	
	
	@Test
    public void testCreateInboundYardForDriverPreplan()throws Exception{
		testInboundYardForDriverPreplan(INBOUND_CREATE_DRIVER_PREPLAN_JSON);
    }

    @Test
    public void testUpdateInboundYardForDriverPreplan()throws Exception{
    	testInboundYardForDriverPreplan(INBOUND_UPDATE_DRIVER_PREPLAN_JSON);
    }
    
    
    @Test
    public void testCreateInboundYardForTractorDriverPreplan()throws Exception{
    	testInboundBoundYard(INBOUND_CREATE_DRIVER_TRUCK_PREPLAN_JSON);
    }
    
    @Test
    public void testUpdateInboundYardForTractorDriverPreplan()throws Exception{
    	testInboundBoundYard(INBOUND_UPDATE_DRIVER_TRUCK_PREPLAN_JSON);
    }

    private void testCheckcall()throws Exception {
		wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/EquipmentDetailsResponse.json"));
		String responseMasterDataLocation = IOUtils.toString(this.getClass().getResourceAsStream("/json/locationProfile.json"));

		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[193764]"))
				.willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		wireMockServer.stubFor(get(urlEqualTo("/masterdatalocationservices/locations/search/findbylocation/26551")).
				willReturn(aResponse()
						.withHeader("Content-type","application/json").withBody(responseMasterDataLocation).withStatus(200)));

		TEquipment tEquipment = new TEquipment();
		tEquipment.setTrailerNumber("357376");
		tEquipment.setTrailerPrefix("JBHZ");
		tEquipment.setLastLocation("WESOK");
		tEquipment.setEquipmentId(12774949);
		tEquipment.setLastLocation("ABCD");
		when(equipmentRepository.fetchEqpDetailsByEqpId("12774949")).thenReturn(tEquipment);
		when(equipmentRepository.getLastLocationForLoadedCheckcall("357376")).thenReturn(tEquipment);

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

		when(orderLoadRepository.findLoadDetailsByOrderID(20012455)).thenReturn(tOrder);
		Integer[][] jobIdAndstopSequenceNumbersArray={{6682,99003}};
		when(subTaskRepository.getStopSeqNumberByOrderId(20012455)).thenReturn(jobIdAndstopSequenceNumbersArray);
		when(subTaskRepository.getLocationForArrivalUnloaded(Long.valueOf(20012455) , 99003)).thenReturn("9999");
	}

    private void testInboundYardForDriverPreplan(String jsonPath) throws Exception{
		
		// ARRANGE
        wireMockServer.resetAll();
        MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

        String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
                + "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
                + "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
                + "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
                + "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
                + "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
                + "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
                + "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
                + "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
                + "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
                + "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

        // ACT
        wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

        String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));

		TOrder tOrder = new TOrder();
		tOrder.setOrderId(1010479);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");

		when(orderLoadRepository.findLoadDetailsByOrderID(Mockito.anyInt())).thenReturn(tOrder);

		TSubtask1 tSubtask1 = new TSubtask1();
		tSubtask1.setJobId(122);
		tSubtask1.setCurrentAppointmnetBegHour("2019-05-31 11:03:51.604942");
		tSubtask1.setCurrentAppointmnetBegDate("2019-05-31 11:03:51.604942");
		tSubtask1.setCurrentApointmentEndHour("2019-05-31 11:03:51.604942");
		tSubtask1.setBusinessId(34);
		tSubtask1.setPreferanceSequenceNumber(1002);
		tSubtask1.setCityId("FDOD7");
		tSubtask1.setSubTaskID(5);
		tSubtask1.setCustomerCode("YO");
		tSubtask1.setRequestTyId("4");

 		List<TSubtask1> listSubTasks =new ArrayList<>();
		listSubTasks.add(tSubtask1);
		when(subTaskRepository.findSubTaskDetailsByTaskId(Mockito.anyInt())).thenReturn(listSubTasks);
		Reservation reservation= new Reservation();
		reservation.setLastUpdateTimeStamp("2019-05-31 11:03:51.604942");
		reservation.setReservationId(1010479);
		when(rsvrscRepository.getrsvDetailsofDriver(Mockito.anyInt())).thenReturn(reservation);

        wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
                .withRequestBody(WireMock.equalTo("[142691]")).willReturn(aResponse()
                        .withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
        
        wireMockServer.stubFor(
                WireMock.get(WireMock.urlPathEqualTo("/masterdatalocationservices/locations/search/findbylocation/10868"))
                        .willReturn(WireMock.aResponse().withHeader("Content-Type", "application/json")
                                .withBody("{ \"locationProfileDTO\": { \"id\": 10868, \"facilityOperationDTO\": [], \"facilityOverviewRequirementCodeDTO\": [], \"contactDTO\": [], \"addressDTO\": { \"id\": 235523, \"addressLine1\": \"1874 Iron Bridge Rd\", \"addressLine2\": \"\", \"state\": \"KY\", \"city\": \"Bowling Green\", \"cityAliasName\": \"Bowling Green\", \"zipcode\": \"421039757\", \"country\": \"USA\", \"countyName\": \"Warren\", \"latitude\": 36.937973, \"longitude\": -86.254737 }, \"hazmatDTO\": null, \"disallowedEquipmentDTO\": [], \"customerDirections\": null, \"generalInstructions\": null, \"locationCode\": \"IRBO18\", \"locationName\": \"Iron Bridge SOD\" }, \"timezone\": \"America/Chicago\" }")
                                .withStatus(200)));

        OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(jsonPath)),
                OperationalPlanEvent.class);

        output = new Lmc341OutputArea();
        output.setLmc341ErrorMessage("Mock");
        output.setLmc341ReturnFlag("S");

        when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output);


        Wo42ComReturnToJava output = new Wo42ComReturnToJava();

        Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
        Wo42ErrorVariables.setWo42ReturnFlag("S");
        output.setWo42ErrorVariables(Wo42ErrorVariables);

        when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output);

        // ACT
        Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
                .contentType(ContentType.JSON).body(operationalPlanEvent)
                .patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
        System.out.println("response ---- >>> " + response.asString());

        // ASSERT
        assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}
    
    private void testInboundBoundYard(String jsonPath) throws Exception{
    	wireMockServer.resetAll();
		MockJBHSecurity.addSecurityForUser(mockUser(userName, password).withAuthLevels(UPDATE));

		String expectedResponse = "{\r\n" + "    \"certifications\": null,\r\n" + "    \"fleet\": null,\r\n"
				+ "    \"serviceFailures\": null,\r\n" + "    \"type\": [\r\n" + "        \"REG\"\r\n" + "    ],\r\n"
				+ "    \"payType\": [\r\n" + "        \"UNITALLOWANCE\",\r\n" + "        \"HOURLY\"\r\n" + "    ],\r\n"
				+ "    \"utilization\": null,\r\n" + "    \"timeOff\": null,\r\n" + "    \"timeOfLocation\": null,\r\n"
				+ "    \"driveHours\": 0,\r\n" + "    \"workHours\": 0,\r\n" + "    \"onDutyHours\": 0,\r\n"
				+ "    \"aobrStatusDurationHours\": 1534168392000,\r\n" + "    \"aobrStatus\": \"Sleeper\",\r\n"
				+ "    \"expirationDate\": \"2022-01-29\",\r\n" + "    \"physicalExpirationDate\": \"2019-06-12\",\r\n"
				+ "    \"dotReviewDate\": \"2019-05-17\",\r\n" + "    \"personId\": \"253282\",\r\n"
				+ "    \"resourceName\": \"JOSEPH  LAVEY\",\r\n" + "    \"firstName\": \"JOSEPH\",\r\n"
				+ "    \"middleName\": \"\",\r\n" + "    \"lastName\": \"LAVEY\",\r\n"
				+ "    \"alphaCode\": \"LAVJ7\"\r\n" + "}";

		// ACT
		wireMockServer.stubFor(get(urlEqualTo("/personnelpeople/people/251915")).willReturn(
				aResponse().withHeader("Content-Type", "application/json").withBody(expectedResponse).withStatus(200)));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		TOrder tOrder = new TOrder();
		tOrder.setOrderId(20012455);
		tOrder.setOrdrNumber("RC45013");
		tOrder.setOrderCreatedTimeStamp("2019-05-31 11:03:51.604942");
		when(orderLoadRepository.findLoadDetailsByOrderID(Mockito.anyInt())).thenReturn(tOrder);

		when(taskRepository.findLastUpdatedTimeStampBytaskId(Mockito.anyInt())).thenReturn("66777");
		wireMockServer.stubFor(post(urlEqualTo("/masterdataasset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[142691]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		wireMockServer.stubFor(
                WireMock.get(WireMock.urlPathEqualTo("/masterdatalocationservices/locations/search/findbylocation/10868"))
                        .willReturn(WireMock.aResponse().withHeader("Content-Type", "application/json")
                                .withBody("{ \"locationProfileDTO\": { \"id\": 10868, \"facilityOperationDTO\": [], \"facilityOverviewRequirementCodeDTO\": [], \"contactDTO\": [], \"addressDTO\": { \"id\": 235523, \"addressLine1\": \"1874 Iron Bridge Rd\", \"addressLine2\": \"\", \"state\": \"KY\", \"city\": \"Bowling Green\", \"cityAliasName\": \"Bowling Green\", \"zipcode\": \"421039757\", \"country\": \"USA\", \"countyName\": \"Warren\", \"latitude\": 36.937973, \"longitude\": -86.254737 }, \"hazmatDTO\": null, \"disallowedEquipmentDTO\": [], \"customerDirections\": null, \"generalInstructions\": null, \"locationCode\": \"IRBO18\", \"locationName\": \"Iron Bridge SOD\" }, \"timezone\": \"America/Chicago\" }")
                                .withStatus(200)));

		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
                IOUtils.toString(this.getClass().getResourceAsStream(jsonPath)),
                OperationalPlanEvent.class);

		Lmc341InputArea inputArea = null;
		finalInput = new Lmc341CommArea();
		finalInput.setLmc341InputArea(inputArea);

		output = new Lmc341OutputArea();
		output.setLmc341ErrorMessage("Mock");
		output.setLmc341ReturnFlag("S");

		when(lmc341Port.lmc341Operation(Mockito.any(Lmc341CommArea.class))).thenReturn(output);
		Wo42ComReturnToJava output = new Wo42ComReturnToJava();
		Wo42ErrorVariables Wo42ErrorVariables = new Wo42ErrorVariables();
		Wo42ErrorVariables.setWo42ErrorKey1("");
		Wo42ErrorVariables.setWo42ReturnFlag("S");
		Wo42ErrorVariables.setWo42Message("");
		Wo42ErrorVariables.setWo42CicsReturnCode(399);
		Wo42ErrorVariables.setWo42ErrorKey2("");

		output.setWo42ErrorVariables(Wo42ErrorVariables);

		when(lmc342Port.lmc342Operation(Mockito.any(Wo42ComJavaSentVariables.class))).thenReturn(output);

		// ACT
		Response response = given(this.requestSpecification).auth().basic(userName, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		System.out.println("response ---- >>> " + response.asString());

		// ASSERT
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
    }

	private String getError(){
		StringBuffer stringBuffer = new StringBuffer();
		for(int i=0 ;i<400;i++){
			stringBuffer.append("test");
		}
		return stringBuffer.toString();
	}

	private static FieldDescriptor[] processCheckCallsRequest() {
		return new FieldDescriptor[] {
				fieldWithPath("operationalPlanEventSubTypes[]").description("operationalPlanEventSubTypes of the checkCall"),
				fieldWithPath("operationalPlanEventType")
						.description("operational Plan Event Type code, it can be operational Plan Event Type"),
				fieldWithPath("operationalPlanDTO").description("operational Plan DTO, store operational Plan DTO event"),
				fieldWithPath("operationalPlanDTO.operationalPlanId")
						.description("Represent the operationalPlanDTO belongs to which operational plan"),
				fieldWithPath("operationalPlanDTO.operationalPlanNumber").description(
						"Represent the operational Plan Number details, load number id "),
				fieldWithPath("operationalPlanDTO.operationalPlanResourceAssignmentAssociationList[]").description("Represent the List of asociation of driver and truck details"),
				fieldWithPath("operationalPlanDTO.operationalPlanResourceAssignmentAssociationList[].resourceAssignmentPlan.equipmentAssignments").description("Represent the equipment")
						.optional().type(String.class) };
	}
	
	private static FieldDescriptor[] processDispatchRequest() {
		return new FieldDescriptor[] {
			fieldWithPath("operationalPlanDTO.orderOperationalPlanAssociations[].operationalPlanOrder.orderId").description("Order ids to be dispatched").type(String.class),
			fieldWithPath("operationalPlanDTO.operationalPlanResourceAssignmentAssociationList[].resourceAssignmentPlan.equipmentAssignments.equipmentId").description("Equipment id of truck with which order is dispatched").type(String.class),	
			fieldWithPath("operationalPlanDTO.operationalPlanStops[].operationalPlanStopAppointment.appointmentStartTimestamp").description("ETA time of the dispatch").type(String.class),
			fieldWithPath("operationalPlanDTO.operationalPlanStops[].cityId").description("city ids of the stop locations").type(String.class),
			fieldWithPath("operationalPlanDTO.operationalPlanStops[].locationId").description("city ids of the stop locations").type(String.class),
			fieldWithPath("operationalPlanDTO.lastUpdateTimestamp").description("city ids of the stop locations").type(String.class),
			fieldWithPath("operationalPlanDTO.operationalPlanEquipmentRequirements[].trailerPreloadedIndicator").description("Business code which tells the finance unit of equipment").type(String.class),
			fieldWithPath("operationalPlanDTO.operationalPlanEquipmentRequirements[].trailingEquipmentId").description("Business code which tells the finance unit of equipment").type(String.class),
			fieldWithPath("operationalPlanDTO.lastUpdateUserId").description("user id who initiated the deadhead/bobtail").type(String.class)
		};
	}

}
