package com.jbhunt.loadplannig.integration.backfill.utils;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InLoadSyncData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InRateBuffer8;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InTrlgEqpBuffer11;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InTrlgEqpBuffer11.Oee5InTrlgEqpSpecData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InTrlgEqpBuffer11.Oee5InTrlgEqpTemData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InputBuffer1;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData;

@Service
public class OrderUpdateMapperHelper {

    public Oee5InRateBuffer8 mapRateBuffer() {
        Oee5InRateBuffer8 oee5InRateBuffer8 = new Oee5InRateBuffer8();
        oee5InRateBuffer8.setOee5InRatMkrItmC("");
        return oee5InRateBuffer8;
    }

    public Oee5InTrlgEqpBuffer11 mapTrailingEquipmentBuffer(Oe76OutputChannelData orderDetails) {

        Oee5InTrlgEqpBuffer11 trailingEquipmentBuffer = new Oee5InTrlgEqpBuffer11();

        Oee5InTrlgEqpTemData oee5InTrlgEqpTemData = new Oee5InTrlgEqpTemData();
        Oee5InTrlgEqpSpecData oee5InTrlgEqpSpecData = new Oee5InTrlgEqpSpecData();
        oee5InTrlgEqpTemData.setOee5InMinTem(new BigDecimal(0));
        oee5InTrlgEqpTemData.setOee5InMaxTem(new BigDecimal(0));
        // Need to change the below value
        oee5InTrlgEqpSpecData.setOee5InTrlgEqpSpecAscI(orderDetails.getOe76OutOrdBuffer9().getOe76OutOrdAgrLnI());
        trailingEquipmentBuffer.getOee5InEqpTemBuffer11B().add(oee5InTrlgEqpTemData);
        trailingEquipmentBuffer.getOee5InEqpSpecBuffer11A().add(oee5InTrlgEqpSpecData);
        return trailingEquipmentBuffer;

    }

    public Oee5InLoadSyncData mapLoadSyncBuffer(OrderLoadSync loadDetails) {
        Oee5InLoadSyncData oee5InLoadSyncBuffer12 = new Oee5InLoadSyncData();
        oee5InLoadSyncBuffer12.setOee5InScmOrdI(loadDetails.getScmOrderID());
        oee5InLoadSyncBuffer12.setOee5InOrdTrakNbr(StringUtils.defaultIfEmpty(loadDetails.getOrderTrackNumber(), "").trim());
        oee5InLoadSyncBuffer12
                .setOee5InPrmRefNbrTypC(StringUtils.defaultIfEmpty(loadDetails.getReferenceNumberTypeCode(), ""));
        oee5InLoadSyncBuffer12.setOee5InPrmRefNbrVal(StringUtils.defaultIfEmpty(loadDetails.getRefNbrValue(), ""));
        return oee5InLoadSyncBuffer12;
    }

    public Oee5InputBuffer1 mapInputBuffer(Oe76OutputChannelData orderDetails) {
        Oee5InputBuffer1 oee5InputBuffer1 = new Oee5InputBuffer1();
        oee5InputBuffer1.setOee5InputDcpAftRailTran(BigDecimal.valueOf(1.00));
        oee5InputBuffer1
                .setOee5InputNbrOfStops((short) orderDetails.getOe76OutStpBuffer13().size());
        oee5InputBuffer1.setOee5InputTransitMiles(0);
		oee5InputBuffer1.setOee5InputUsrC("");
        oee5InputBuffer1.setOee5InApptOverrideFlag("Y");
        return oee5InputBuffer1;
    }

}
