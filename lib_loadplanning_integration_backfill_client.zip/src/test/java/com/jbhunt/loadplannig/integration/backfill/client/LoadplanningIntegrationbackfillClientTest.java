package com.jbhunt.loadplannig.integration.backfill.client;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.dto.LegacyOrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplannig.integration.backfill.properties.LoadplanningIntegrationbackfillProperties;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.loadplanning.owo.dto.event.OperationalWorkOrderEvent;
import com.jbhunt.operations.admin.operationalgroup.dto.event.OperationalGroupEvent;
import com.jbhunt.operations.drivertruckassignment.dto.ResourceESDTO;
import com.jbhunt.operations.equipmentgroup.dto.EquipmentGroupESDTO;
import com.jbhunt.operations.equipmentgroup.dto.OpexEquipmentLocationUpdateDTO;
import com.jbhunt.operations.equipmentgroup.dto.RemoveEquipmentFromGroupBackFillDTO;
import com.jbhunt.operations.trackandtrace.dto.CheckCallESDTO;

public class LoadplanningIntegrationbackfillClientTest {

	private RestTemplate restTemplate;
	private MockRestServiceServer mockServer;
	private LoadplanningIntegrationbackfillProperties loadplanningIntegrationbackfillProperties;
	private LoadplanningIntegrationbackfillClient loadplanningIntegrationbackfillClient;
	private String contextURL;

	private static final int HTTP_REQUEST_TIMEOUT = 20000;

	@Before
	public void setUp() {
		restTemplate = new RestTemplate();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setConnectTimeout(HTTP_REQUEST_TIMEOUT);
		requestFactory.setReadTimeout(HTTP_REQUEST_TIMEOUT);
		restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor("testuser", "test123"));
		restTemplate.setRequestFactory(requestFactory);
		mockServer = MockRestServiceServer.createServer(restTemplate);
		loadplanningIntegrationbackfillProperties = new LoadplanningIntegrationbackfillProperties();
		loadplanningIntegrationbackfillProperties.setBaseURL("http://localhost:8088/loadplanningintegrationBackfill/");
		loadplanningIntegrationbackfillClient = new LoadplanningIntegrationbackfillClient(
				loadplanningIntegrationbackfillProperties, restTemplate);
		contextURL = "http://localhost:8088/loadplanningintegrationBackfill";
	}

	@Test
	public void testcreateLoad() throws Exception {
		OperationalPlanEvent operationalPlanEvent = new OperationalPlanEvent(null, null, new OperationalPlanDTO());
		mockServer.expect(requestTo(contextURL + "/backfill/operationalplans")).andExpect(method(HttpMethod.POST))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.loadCreate(operationalPlanEvent);
		Assert.assertNotNull(response);
		Assert.assertEquals("success", response.getStatusMessage());
	}

	@Test
	public void testUpdateLoad() throws Exception {
		OperationalPlanEvent operationalPlanEvent = new OperationalPlanEvent(null, null, new OperationalPlanDTO());
		mockServer.expect(requestTo(contextURL + "/backfill/operationalplans")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.loadUpdate(operationalPlanEvent);
		Assert.assertNotNull(response);
	}

	@Test

	public void testDriverTruckAssignments() throws Exception {
		ResourceESDTO assignResourceESDTO = new ResourceESDTO();
		mockServer.expect(requestTo(contextURL + "/backfill/drivertruckassignments")).andExpect(method(HttpMethod.POST))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient
				.driverTruckPairing(assignResourceESDTO);
		Assert.assertNotNull(response);
	}

	@Test
	public void testCreateOWO() {
		mockServer.expect(requestTo(contextURL + "/backfill/operationalworkorders")).andExpect(method(HttpMethod.POST))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		OperationalWorkOrderEvent operationalWorkOrderEvent = new OperationalWorkOrderEvent();
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.createOWO(operationalWorkOrderEvent);
		Assert.assertNotNull(response);
	}

	
	  
	 @Test
	    public void testAddCommenCall() {
	    	CheckCallESDTO   checkCallESDTO=new CheckCallESDTO();
	    	 mockServer.expect(requestTo(contextURL + "/backfill/commentcalls")).andExpect(method(HttpMethod.PATCH))
	         .andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
	 BackfillServiceResponse response = loadplanningIntegrationbackfillClient.addCommenCall(checkCallESDTO);
	 Assert.assertNotNull(response);
	    }
	@Test(expected = JBHuntRuntimeException.class)
	public void testCreateOWOException() {
		mockServer.expect(requestTo(contextURL + "/backfill/operationalworkorders")).andExpect(method(HttpMethod.POST))
				.andRespond(withSuccess(asString(new BackfillServiceResponse("500", "ERROR", false)),
						MediaType.APPLICATION_JSON));
		OperationalWorkOrderEvent operationalWorkOrderEvent = new OperationalWorkOrderEvent();
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.createOWO(operationalWorkOrderEvent);
	}

	@Test
	public void testUpdateOWO() {
		mockServer.expect(requestTo(contextURL + "/backfill/operationalworkorders")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		OperationalWorkOrderEvent operationalWorkOrderEvent = new OperationalWorkOrderEvent();
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.updateOWO(operationalWorkOrderEvent);
		Assert.assertNotNull(response);
	}

	@Test(expected = JBHuntRuntimeException.class)
	public void testUpdateOWOException() {
		mockServer.expect(requestTo(contextURL + "/backfill/operationalworkorders")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(asString(new BackfillServiceResponse("500", "ERROR", false)),
						MediaType.APPLICATION_JSON));
		OperationalWorkOrderEvent operationalWorkOrderEvent = new OperationalWorkOrderEvent();
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.updateOWO(operationalWorkOrderEvent);
	}

	@Test
	public void testFetchLegacyOrderDetails() {
		mockServer.expect(requestTo(contextURL + "/backfill/legacyorders/operationalplanid/12345"))
				.andExpect(method(HttpMethod.GET))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		Integer operationalPlanId = 12345;
		LegacyOrderOperationalPlanAssociationDTO response = loadplanningIntegrationbackfillClient
				.fetchLegacyOrderDetails(operationalPlanId);
		Assert.assertNotNull(response);
	}

	@Test
	public void testFetchOperationalPlanIdByOrderId() {
		mockServer.expect(requestTo(contextURL + "/backfill/legacyorders/operationalplans/legacyorderid/124567789"))
				.andExpect(method(HttpMethod.GET)).andRespond(withSuccess("[{}]", MediaType.APPLICATION_JSON));
		Integer legacyorderid = 124567789;
		List<LegacyOrderOperationalPlanAssociationDTO> response = loadplanningIntegrationbackfillClient.fetchOperationalPlanIdsByOrderId(legacyorderid);
		Assert.assertNotNull(response);
	}

	@Test
	public void testFetchOperationalPlanIdByOrderIdAndJobId() {
		mockServer
				.expect(requestTo(
						contextURL + "/backfill/legacyorders/operationalplans/legacyorderid/124567789?legacyjobid=1"))
				.andExpect(method(HttpMethod.GET)).andRespond(withSuccess("12345", MediaType.APPLICATION_JSON));
		Integer legacyorderid = 124567789;
		Integer legacyjobid = 1;
		Integer legacyresourcereservationid = null;
		Integer response = loadplanningIntegrationbackfillClient.fetchOperationalPlanId(legacyorderid, legacyjobid, legacyresourcereservationid);
		Assert.assertNotNull(response);
	}

	@Test
	public void testFetchOperationalPlanIdByOrderIdAndReservationId() {
		mockServer.expect(requestTo(contextURL
				+ "/backfill/legacyorders/operationalplans/legacyorderid/124567789?legacyresourcereservationid=1"))
				.andExpect(method(HttpMethod.GET)).andRespond(withSuccess("12345", MediaType.APPLICATION_JSON));
		Integer legacyorderid = 124567789;
		Integer legacyjobid = null;
		Integer legacyresourcereservationid = 1;
		Integer response = loadplanningIntegrationbackfillClient
				.fetchOperationalPlanId(legacyorderid, legacyjobid, legacyresourcereservationid);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testFetchOperationalPlanIdByBothJobIdAndReservationId() {
		mockServer.expect(requestTo(contextURL
				+ "/backfill/legacyorders/operationalplans/legacyorderid/124567789?legacyjobid=1&legacyresourcereservationid=1"))
				.andExpect(method(HttpMethod.GET)).andRespond(withSuccess("12345", MediaType.APPLICATION_JSON));
		Integer legacyorderid = 124567789;
		Integer legacyjobid = 1;
		Integer legacyresourcereservationid = 1;
		Integer response = loadplanningIntegrationbackfillClient
				.fetchOperationalPlanId(legacyorderid, legacyjobid, legacyresourcereservationid);
		Assert.assertNotNull(response);
	}

	private String getBackfillServiceResponse() {
		return asString(new BackfillServiceResponse("200", "success", false));
	}

	public static String asString(Object o) {
		if (o != null) {
			ObjectMapper objectMapper = new ObjectMapper();
			try {
				return objectMapper.writeValueAsString(o);
			} catch (JsonProcessingException e) {
				// todo
			}
		}
		return "null";
	}

	@Test
	public void testBeaming() {
		mockServer.expect(requestTo(contextURL + "/backfill/equipments/locations")).andExpect(method(HttpMethod.POST))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		OpexEquipmentLocationUpdateDTO equipmentLocationUpdateDTO = new OpexEquipmentLocationUpdateDTO();
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.beaming(equipmentLocationUpdateDTO);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testEquipmentAssignment() {
		mockServer.expect(requestTo(contextURL + "/backfill/equipmentgroup")).andExpect(method(HttpMethod.POST))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		EquipmentGroupESDTO equipmentGroupESDTO = new EquipmentGroupESDTO();
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.equipmentAssignment(equipmentGroupESDTO);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testEquipmentUnassignment() {
		mockServer.expect(requestTo(contextURL + "/backfill/equipmentgroup")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		RemoveEquipmentFromGroupBackFillDTO removeEquipment = new RemoveEquipmentFromGroupBackFillDTO();
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.equipmentUnassignment(removeEquipment);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testDeadhead() {
		final OperationalPlanDTO operationalPlanDTO = new OperationalPlanDTO();
		mockServer.expect(requestTo(contextURL + "/backfill/operationalplans/123456/deadhead")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		operationalPlanDTO.setOperationalPlanNumber("123456");
		operationalPlanDTO.setOperationalPlanId(123456);
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.deadhead(operationalPlanDTO);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testBobtail() {
		final OperationalPlanDTO operationalPlanDTO = new OperationalPlanDTO();
		mockServer.expect(requestTo(contextURL + "/backfill/operationalplans/123456/bobtail")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		operationalPlanDTO.setOperationalPlanNumber("123456");
		operationalPlanDTO.setOperationalPlanId(123456);
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.bobtail(operationalPlanDTO);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testResourceAssignment() {
		final OperationalPlanDTO operationalPlanDTO = new OperationalPlanDTO();
		mockServer.expect(requestTo(contextURL + "/backfill/operationalplans/123456/resourceassignments")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		operationalPlanDTO.setOperationalPlanNumber("123456");
		operationalPlanDTO.setOperationalPlanId(123456);
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.resourceAssignment(operationalPlanDTO);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testCreatePayRoute() {
		final OperationalPlanDTO operationalPlanDTO = new OperationalPlanDTO();
		mockServer.expect(requestTo(contextURL + "/backfill/operationalplans/123456/createpayroute")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		operationalPlanDTO.setOperationalPlanNumber("123456");
		operationalPlanDTO.setOperationalPlanId(123456);
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.createPayRoute(operationalPlanDTO);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testUpdatePayRoute() {
		final OperationalPlanDTO operationalPlanDTO = new OperationalPlanDTO();
		mockServer.expect(requestTo(contextURL + "/backfill/operationalplans/123456/updatepayroute")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		operationalPlanDTO.setOperationalPlanNumber("123456");
		operationalPlanDTO.setOperationalPlanId(123456);
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.updatePayRoute(operationalPlanDTO);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testCancelResourceAssignment() {
		final OperationalPlanDTO operationalPlanDTO = new OperationalPlanDTO();
		mockServer.expect(requestTo(contextURL + "/backfill/operationalplans/123456/resourceassignments/cancel")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		operationalPlanDTO.setOperationalPlanNumber("123456");
		operationalPlanDTO.setOperationalPlanId(123456);
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.cancelResourceAssignment(operationalPlanDTO);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testCreateInboundToYard() {
		final OperationalPlanDTO operationalPlanDTO = new OperationalPlanDTO();
		mockServer.expect(requestTo(contextURL + "/backfill/operationalplans/123456/inboundtoyard")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		operationalPlanDTO.setOperationalPlanNumber("123456");
		operationalPlanDTO.setOperationalPlanId(123456);
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.createInboundToYard(operationalPlanDTO);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void testCreateFleet() {
		mockServer.expect(requestTo(contextURL + "/backfill/operationalevents")).andExpect(method(HttpMethod.POST))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		OperationalGroupEvent operationalGroupEvent = new OperationalGroupEvent();
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.createFleet(operationalGroupEvent);
		Assert.assertNotNull(response);
	}
	
	
	@Test
	public void testUpdateFleet() {
		mockServer.expect(requestTo(contextURL + "/backfill/operationalevents")).andExpect(method(HttpMethod.PATCH))
				.andRespond(withSuccess(getBackfillServiceResponse(), MediaType.APPLICATION_JSON));
		OperationalGroupEvent operationalGroupEvent = new OperationalGroupEvent();
		BackfillServiceResponse response = loadplanningIntegrationbackfillClient.updateFleet(operationalGroupEvent);
		Assert.assertNotNull(response);
	}
	
	
}