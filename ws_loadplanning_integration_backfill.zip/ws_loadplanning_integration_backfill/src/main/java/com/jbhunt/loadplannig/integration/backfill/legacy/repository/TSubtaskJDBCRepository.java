package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class TSubtaskJDBCRepository {

	TSubtaskJDBCRepository(@Qualifier("dataSourceDB2") JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private final JdbcTemplate jdbcTemplate;

	public void updateTSubtask(final String arrivalDate, final String arrivalTime, final Integer subTaskId) {
		final String query = "UPDATE ALI.TSUBTASK1 TS SET TS.ACL_ARV_D = ?, TS.ACL_ARV_H = ? WHERE TS.STSK_ID = ?";
		jdbcTemplate.update(query, arrivalDate, arrivalTime, subTaskId);
	}
}
