package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class TAppointmentJDBCRepository {

	TAppointmentJDBCRepository(@Qualifier("dataSourceDB2") JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private final JdbcTemplate jdbcTemplate;

	public void updateTAppointment(final String arrivalTimeDeviationTypeCode, final String comment, final Integer subTaskId) {

		final String query = "UPDATE ALI.TAPPOINTMENT A SET A.LT_ARV_RSN_C = ?, A.CMM = ? WHERE A.STSK_ID = ? AND A.REC_STT_F = ?" ;
		jdbcTemplate.update(query, arrivalTimeDeviationTypeCode, comment, subTaskId, "A");
	}

}
