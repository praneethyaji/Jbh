package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TTask;

@RepositoryRestResource
public interface TaskRepository extends JpaRepository<TTask, Integer> {

	@Query(value = "select  CHAR(LST_UPDT_TMSTP_S) from ALI.TTASK where TASK_ID=:taskId WITH UR ", nativeQuery = true)
	String findLastUpdatedTimeStampBytaskId(@Param("taskId") Integer taskId);
	
	/*@Query(value = "SELECT B.PRF_SEQ_N, A.REQ_TYP_C, D.ORD_NBR_CH, A.TASK_ID, C.ATY_TY_ID FROM ALI.TTASK A, ALI.TSUBTASK1 B Left OUTER join ALI.TACTIVITY C ON C.SRCE_ID = B.STSK_ID AND " + 
			"C.PROG_STT_C IN ('A', 'S', 'W', 'C','X'), ALI.TORDER D WHERE D.ORD_NBR_CH =:ordNbrCh AND A.TASK_ID = D.ORD_I AND A.REQ_TYP_C = 'EQUIPMENT' AND B.TASK_ID = A.TASK_ID AND " + 
			"D.ORD_I = A.TASK_ID AND B.PRF_SEQ_N >= 1000 ORDER BY B.PRF_SEQ_N WITH UR", nativeQuery = true)
	List<Object[]> findOrdDetailsByOrdNbrCh(@Param("ordNbrCh") String ordNbrCh);*/
	
	@Query(value = "SELECT A.REQ_TYP_C, A.UTL_STT_C, D.ORD_NBR_CH, B.BSST_ALIAS, B.CITY_ID, C.ATY_TY_ID, A.TASK_ID, B.PROG_STT_C, "
			+ "B.PRF_SEQ_N, CHAR (B.CURR_APT_BEG_D, ISO) \"APPT_BEG_DATE\", CHAR (B.CURR_APT_BEG_H, ISO) \"APPT_BEG_TIME\", A.FLT_C, "
			+ "B.STSK_ID, CHAR (B.CURR_APT_END_D, ISO) \"APPT_END_DATE\", CHAR (B.CURR_APT_END_H, ISO) \"APPT_END_TIME\", "
			+ "B.job_id, A.DIV_ID, A.LST_UPDT_TMSTP_S FROM ALI.TTASK A, ALI.TSUBTASK1 B Left OUTER join "
			+ "ALI.TACTIVITY C ON  C.SRCE_ID = B.STSK_ID AND C.PROG_STT_C IN ('A', 'S', 'W', 'C','X') , ALI.TORDER D WHERE  "
			+ "D.ORD_NBR_CH =:ordNbrCh AND A.TASK_ID = D.ORD_I  AND B.TASK_ID = A.TASK_ID AND "
			+ "D.ORD_I = A.TASK_ID AND B.PRF_SEQ_N >= 1000 ORDER BY B.PRF_SEQ_N WITH UR", nativeQuery = true)
	List<Object[]> findOrdDetailsByOrdNbrCh(@Param("ordNbrCh") String ordNbrCh);

	@Query(value = " SELECT ORD.ORD_I, ORD.ORD_NBR_CH, RSC.REQ_FR_ETY_KEY_CH, CHAR (SUB.LST_UPDT_TMSTP_S) AS LST_UPDT_TMSTP_S, RSC.RSC_RSV_I, CHAR(RSC.LST_UPD_S) AS LST_UPD_S, SUB.STSK_ID,SUB.PRF_SEQ_N,SUB.BSST_ID, SUB.RQ_TY_ID, SUB.CITY_ID "
			+ " FROM  ALI.TORDER ORD, ALI.RSC_RSV RSC,ALI.TSUBTASK1 SUB "
			+ " WHERE ORD.ORD_I = SUB.TASK_ID  and RSC.REC_STT ='A' AND SUB.RSC_RSV_I = RSC.RSC_RSV_I AND RSC.REQ_FR_ETY_KEY_CH =:alphaCode AND SUB.TASK_ID=:ordId WITH UR",nativeQuery = true)
	List<Object[]> findOrderStopForTransfer(@Param("alphaCode") String alphaCode, @Param("ordId") Integer ordId);

}







