package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TAppointment;

@RepositoryRestResource
public interface TAppointmentRepository extends JpaRepository<TAppointment, Integer>{

	
	@Query(value = "SELECT A.STSK_ID, A.SEQ_NO_N, A.PROG_STT_C, A.CRTN_TMSTP_S, A.CRTN_UID_N, A.LST_UPDT_PRGM_ID, A.LST_UPDT_UID_N, A.LST_UPDT_TMSTP_S, A.LT_ARV_RSN_C, A.RESP_OPR_ID, A.CRT_PGM_C, A.APT_CHN_RSN_TY_ID, A.REC_STT_F  FROM ALI.TAPPOINTMENT A, ALI.TSUBTASK1 B WHERE A.STSK_ID =:subTaskId AND A.STSK_ID=B.STSK_ID AND A.REC_STT_F='A' WITH UR", nativeQuery = true)
	TAppointment fetchAppointmentDetailsBySubTaskId(@Param("subTaskId") Integer subTaskId);
	
}
