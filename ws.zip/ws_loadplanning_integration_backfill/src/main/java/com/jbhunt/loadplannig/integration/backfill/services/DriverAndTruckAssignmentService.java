package com.jbhunt.loadplannig.integration.backfill.services;

import static com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants.STANDARD_PLAN;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.EntityManager;

import org.apache.commons.collections4.CollectionUtils;
import org.json.JSONException;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.Reservation;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TOrder;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TSubtask1;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.BkfilOrdLdAscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.BkfilOwoJaAscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadSyncRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.RsvrscRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.SubTaskRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.TaskRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.LegacyOrderOperationalPlanAssociationRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.BkfilOwoJaAscResponse;
import com.jbhunt.loadplannig.integration.backfill.utils.CommonUtils;
import com.jbhunt.loadplannig.integration.backfill.utils.PairingTruckAndDriverHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.SendPlanHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.TractorAndDriverSendplanHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanOrderDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanResourceAssignmentAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanWorkOrderAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.jbhunt.personnel.people.dto.PeopleDetailsDTO;
import com.lmc342i.lmc342.LMC342Port;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable;
import com.request.lmc342i.lmc342.ProgramInterface.Wo42ComJavaSentVariables.Wo42ComRequiredData.Wo42OrdDtlTable.Wo42OrdStopInfo;
import com.response.lmc342i.lmc342.ProgramInterface.Wo42ComReturnToJava;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class DriverAndTruckAssignmentService {

	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final OrderLoadSyncRepository orderLoadSyncRepository;
	private final SendPlanHelper sendPlanHelper;
	private final OrderLoadRepository orderLoadRepository;
	private final TaskRepository taskRepository;
	private final RsvrscRepository rsvrscRepository;
	private final SubTaskRepository subTaskRepository;
	private final TractorAndDriverSendplanHelper tractorAndDriverSendplanHelp;
	private final BkfilOrdLdAscRepository bkfilOrdLdAscRepository;
	private final LMC342Port lmc342Port;
	private final DriverAssignmentService driverAssignmentService;
	private final DriverAndTruckPairingService driverAndTruckPairingService;
	private final PairingTruckAndDriverHelper pairingTruckAndDriverHelper;
	private final LegacyOrderOperationalPlanAssociationRepository legacyOrderOperationalPlanAssociationRepository;
	private EntityManager entityManager;
	private final LoadplanningIntegrationOWObackfillService loadplanningIntegrationOWObackfillService;
	private final BkfilOwoJaAscRepository bkfilOwoJaAscRepository;

	/**
	 * @param operationalPlanDTO
	 * @param actionFlag
	 * @param operationalFlag
	 * @param eventSubType
	 * @throws Exception
	 */
	public void driverAndTruckAssignment(final OperationalPlanDTO operationalPlanDTO, final String actionFlag,
			final String operationalFlag, final String eventSubType) throws Exception {
		final List<OperationalPlanResourceAssignmentAssociationDTO> operationalPlanResourceAssignmentAssociationList = operationalPlanDTO
				.getOperationalPlanResourceAssignmentAssociationList();
		if (CollectionUtils.isEmpty(operationalPlanResourceAssignmentAssociationList)) {
			final String errorMessage = "Preplan failed: Resource list is empty";
			log.info(errorMessage);
			backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.FAILED.name(),
					eventSubType, errorMessage);
			return;
		}

		final OperationalPlanResourceAssignmentAssociationDTO resourceAssignmentAssociation = Collections
				.max(operationalPlanResourceAssignmentAssociationList, Comparator.comparing(
						OperationalPlanResourceAssignmentAssociationDTO::getOperationalPlanResourceAssignmentAssociationId));
		final ResourceAssignmentPlanDTO resourceAssignmentPlanDTO = resourceAssignmentAssociation
				.getResourceAssignmentPlan();

		final String isTruePlan = STANDARD_PLAN.equalsIgnoreCase(
				resourceAssignmentPlanDTO.getResourceAssignmentPlanType().getResourceAssignmentPlanTypeCode()) ? "N"
						: "Y";
		log.info("getEquipmentAssignments: " + resourceAssignmentPlanDTO.getEquipmentAssignments());
		if (resourceAssignmentPlanDTO.getEquipmentAssignments() != null) {

			log.info("preplan by tractor");
			resourceAssignment(operationalPlanDTO, actionFlag, operationalFlag, resourceAssignmentPlanDTO, isTruePlan,
					eventSubType);

		} else if (resourceAssignmentPlanDTO.getDriverAssignment() != null) {

			final String operationFlag = OperationalPlanEventSubType.RESOURCEPLAN_CANCEL.name()
					.equalsIgnoreCase(eventSubType) ? operationalFlag : CommonConstants.TRACTOR_AND_DRIVER_SAVEPLAN;

			log.info("preplan by driver - operationFlag ", operationFlag);
			driverAssignmentService.driverAssignment(operationalPlanDTO, operationFlag, resourceAssignmentPlanDTO,
					isTruePlan, eventSubType);
		}

		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
		updateLegacyOrderOperationalPlanAssociation(operationalPlanDTO);
	}

	private void updateLegacyOrderOperationalPlanAssociation(OperationalPlanDTO operationalPlanDTO) {
		log.info("saving job id and rsc id in LegacyOrderOperationalPlanAssociation");
		if ("owo".equalsIgnoreCase(operationalPlanDTO.getOperationalPlanType().getOperationalPlanTypeCode())) {
			operationalPlanDTO.getOperationalPlanWorkOrderAssociations().forEach(operationalWorkOrderAssociation -> {
				BkfilOwoJaAscResponse bkfilOwoJaAscResponse = loadplanningIntegrationOWObackfillService
						.findOrdDetailsBynxtOwoNum("W" + operationalWorkOrderAssociation.getOperationalWorkOrderId());
				if (bkfilOwoJaAscResponse == null) {
					throw new JBHuntRuntimeException(
							"OWO Order " + operationalWorkOrderAssociation.getOperationalWorkOrderId()
									+ " doesn't exist and It's mandatory for Resource Assignment.");
				}
				getTaskDetailsAndUpdateRecordInLegacyAssociation(bkfilOwoJaAscResponse.getOrdI());
			});

		} else {
			operationalPlanDTO.getOrderOperationalPlanAssociations().stream()
					.forEach(orderOperationalPlanAssociation -> {
						final TOrder orderSync = Optional
								.ofNullable(orderLoadRepository.findLoadDetailsByOrderID(
										orderOperationalPlanAssociation.getOperationalPlanOrder().getOrderId()))
								.orElseGet(() -> orderLoadRepository.findLoadDetailsByOrderIDWarehouse(
										orderOperationalPlanAssociation.getOperationalPlanOrder().getOrderId()));
						if (orderSync == null) {
							throw new JBHuntRuntimeException(
									"Order Id " + orderOperationalPlanAssociation.getOperationalPlanOrder().getOrderId()
											+ " doesn't exist and It's mandatory for Resource Assignment.");
						}
						getTaskDetailsAndUpdateRecordInLegacyAssociation(orderSync.getOrderId());
					});
		}
	}

	private void getTaskDetailsAndUpdateRecordInLegacyAssociation(Integer legacyOrderId) {
		entityManager.clear();
		List<TSubtask1> subTaskDetails = subTaskRepository.getJobandRSCId(legacyOrderId);
		if (!CollectionUtils.isEmpty(subTaskDetails)) {
			legacyOrderOperationalPlanAssociationRepository.updateLegacyOrderOperationalPlanAssociation(
					subTaskDetails.get(0).getJobId(), subTaskDetails.get(0).getReservationId(), legacyOrderId);
		}
	}

	/**
	 * @param operationalPlanDTO
	 * @param actionFlag
	 * @param operationalFlag
	 * @param resourceAssignmentPlanDTO
	 * @param isTruePlan
	 */
	public void resourceAssignment(final OperationalPlanDTO operationalPlanDTO, final String actionFlag,
			String operationalFlag, final ResourceAssignmentPlanDTO resourceAssignmentPlanDTO, final String isTruePlan,
			final String eventSubType) {
		final EquipmentDetailsDTO equipmentDetails = sendPlanHelper.populateEquipment(resourceAssignmentPlanDTO);
		final PeopleDetailsDTO driverDetails = resourceAssignmentPlanDTO.getDriverAssignment() != null
				? sendPlanHelper.populateDriverDetails(resourceAssignmentPlanDTO)
				: new PeopleDetailsDTO();
		if (OperationalPlanEventSubType.RESOURCEASSIGNMENT.name().equalsIgnoreCase(eventSubType)) {
			Optional.ofNullable(driverDetails.getAlphaCode()).ifPresent(alphaCode -> {
				if (!pairingTruckAndDriverHelper.isAlreadyPaired(equipmentDetails.getLegacyEquipmentId(), alphaCode,
						CommonConstants.ISBOTHPAIRED)) {
					if (pairingTruckAndDriverHelper.isAlreadyPaired(equipmentDetails.getLegacyEquipmentId(), null,
							CommonConstants.ISTRUCKALREADYPAIRED)) {
						log.info("Truck Already paired With Some Other driver: {} ",
								equipmentDetails.getLegacyEquipmentId());
						throw new JBHuntRuntimeException("Truck Already paired With Some Other driver");
					} else if (pairingTruckAndDriverHelper.isAlreadyPaired(null, alphaCode,
							CommonConstants.ISDRIVERALREADYPAIRED)) {
						log.info("Driver Already paired With Some Other Truck: {} ", alphaCode);
						throw new JBHuntRuntimeException("Driver Already paired With Some Other Truck");
					} else {
						try {
							driverAndTruckPairingService.pairingofTruckAndDriver(
									pairingTruckAndDriverHelper.formResourceESDTO(resourceAssignmentPlanDTO));
						} catch (Exception e) {
							log.info(e.getMessage());
							throw new JBHuntRuntimeException("Driver and Truck is not paired: " + e.getMessage());
						}
					}
				}
			});
		}

		List<Integer> orderIds = new ArrayList<Integer>();

		final List<Integer> oldPlannedOrdersDetails = new ArrayList<>();

		List<Integer> normalLoads = orderLoadSyncRepository
				.getPlannedNewOrderIdsBylegacyEquipmentId((equipmentDetails.getEquipmentNumber()));

		List<Integer> owoLoads = bkfilOwoJaAscRepository
				.getPlannedNewOwoOrderIdsBylegacyEquipmentId((equipmentDetails.getEquipmentNumber()));

		oldPlannedOrdersDetails.addAll(normalLoads);
		oldPlannedOrdersDetails.addAll(owoLoads);

		switch (operationalPlanDTO.getOperationalPlanType().getOperationalPlanTypeCode()) {
		case "Freight":
			orderIds = operationalPlanDTO.getOrderOperationalPlanAssociations().stream()
					.map(OrderOperationalPlanAssociationDTO::getOperationalPlanOrder)
					.map(OperationalPlanOrderDTO::getOrderId).collect(Collectors.toList());
			break;
		case "OWO":
			orderIds = operationalPlanDTO.getOperationalPlanWorkOrderAssociations().stream()
					.map(OperationalPlanWorkOrderAssociationDTO::getOperationalWorkOrderId)
					.collect(Collectors.toList());
			break;
		default:
			break;
		}

		List<Integer> oldPlannedOrdersDetailsForUpdate = new ArrayList<Integer>();
		if ((OperationalPlanEventSubType.RESOURCEASSIGNMENT.name().equalsIgnoreCase(eventSubType))) {
			oldPlannedOrdersDetailsForUpdate = orderIds.stream().filter(r -> oldPlannedOrdersDetails.contains(r))
					.collect(Collectors.toList());
			orderIds.removeIf(e -> oldPlannedOrdersDetails.contains(e));
		}
		final List<Integer> planedIds = Stream.of(oldPlannedOrdersDetails, orderIds).flatMap(x -> x.stream())
				.collect(Collectors.toList());

		final List<Wo42OrdDtlTable> listOfOrderDetails = new ArrayList<>();
		log.info("size of listoldplanOrders " + planedIds.size());
		for (int i = 0; i < planedIds.size(); i++) {
			try {
				prepareWo42OrdDtlTable(actionFlag, operationalFlag, resourceAssignmentPlanDTO, oldPlannedOrdersDetails,
						i + 1, listOfOrderDetails, planedIds.get(i), eventSubType, operationalPlanDTO,
						oldPlannedOrdersDetailsForUpdate);
			} catch (JSONException e) {
				throw new JBHuntRuntimeException(e.getMessage());
			}

		}

		final Wo42ComRequiredData inputOfLMC342 = tractorAndDriverSendplanHelp.populateWo42ComJavaSentVariables(
				listOfOrderDetails, actionFlag, equipmentDetails, driverDetails, operationalPlanDTO.getCreateUserId(),
				isTruePlan);

		final Wo42ComJavaSentVariables inputLMC342 = new Wo42ComJavaSentVariables();
		inputLMC342.setWo42ComRequiredData(inputOfLMC342);
		final Wo42ComReturnToJava output = CommonUtils.soapCall((i) -> lmc342Port.lmc342Operation(i), inputLMC342);
		final String responseString = CommonUtils.asString(output);
		if (!("S".equalsIgnoreCase(output.getWo42ErrorVariables().getWo42ReturnFlag())
				|| "A".equalsIgnoreCase(output.getWo42ErrorVariables().getWo42ReturnFlag()))) {
			throw new JBHuntRuntimeException(responseString);
		}
	}

	/**
	 * @param actionFlag
	 * @param operationalFlag
	 * @param resourceAssignmentPlanDTO
	 * @param oldPlannedOrdersDetails
	 * @param seqNumber
	 * @param listOfOrderDetails
	 * @param newOrderID
	 * @throws JSONException
	 */
	private void prepareWo42OrdDtlTable(final String actionFlag, String operationalFlag,
			final ResourceAssignmentPlanDTO resourceAssignmentPlanDTO, final List<Integer> oldPlannedOrdersDetails,
			Integer seqNumber, final List<Wo42OrdDtlTable> listOfOrderDetails, Integer newOrderID,
			final String eventSubType, final OperationalPlanDTO operationalPlanDTO,
			List<Integer> oldPlannedOrdersDetailsForUpdate) throws JSONException {
		
		boolean isOWO = false;

		OperationalPlanWorkOrderAssociationDTO operationalPlanWorkOrderAssociationDTO = new OperationalPlanWorkOrderAssociationDTO();

		if (!CollectionUtils.isEmpty(operationalPlanDTO.getOperationalPlanWorkOrderAssociations())) {
			Optional<OperationalPlanWorkOrderAssociationDTO> owoAssOptional = operationalPlanDTO
					.getOperationalPlanWorkOrderAssociations().stream()
					.filter(owoAssociationDTO -> owoAssociationDTO.getOperationalWorkOrderId().equals(newOrderID))
					.findAny();
			if (owoAssOptional.isPresent()) {
				operationalPlanWorkOrderAssociationDTO = owoAssOptional.get();
				isOWO = true;
			}
		}

		Integer nextLoadId = null;
		if ("owo".equalsIgnoreCase(operationalPlanDTO.getOperationalPlanType().getOperationalPlanTypeCode()) && isOWO) {
			BkfilOwoJaAscResponse bkfilOwoJaAscResponse = loadplanningIntegrationOWObackfillService
					.findOrdDetailsBynxtOwoNum(
							"W" + operationalPlanWorkOrderAssociationDTO.getOperationalWorkOrderId());
			nextLoadId = Optional
					.ofNullable(bkfilOrdLdAscRepository
							.getNextLoadIdbyOwoId(operationalPlanWorkOrderAssociationDTO.getOperationalWorkOrderId()))
					.orElseThrow(
							() -> new JBHuntRuntimeException("NextLoadId is not found in BKFIL_ORD_LD_ASC table"));
			getWo42OrdDtlTableList(actionFlag, operationalFlag, resourceAssignmentPlanDTO, oldPlannedOrdersDetails,
					seqNumber, listOfOrderDetails, newOrderID, eventSubType, operationalPlanDTO,
					oldPlannedOrdersDetailsForUpdate, bkfilOwoJaAscResponse.getOrdI(),
					bkfilOwoJaAscResponse.getOrdNbrch(), isOWO, nextLoadId);

		} else {
			final TOrder orderSync = Optional.ofNullable(orderLoadRepository.findLoadDetailsByOrderID(newOrderID))
					.orElseGet(() -> orderLoadRepository.findLoadDetailsByOrderIDWarehouse(newOrderID));
			if (orderSync == null) {
				throw new JBHuntRuntimeException(
						"Order Id " + newOrderID + " doesn't exist and It's mandatory for Resource Assignment.");
			}
			nextLoadId = Optional.ofNullable(bkfilOrdLdAscRepository.getNextLoadIdbyNewOrderId(newOrderID))
			.orElseThrow(() -> new JBHuntRuntimeException("NextLoad is not found in Bkfil_Ord_LdAsc"));
			getWo42OrdDtlTableList(actionFlag, operationalFlag, resourceAssignmentPlanDTO, oldPlannedOrdersDetails,
					seqNumber, listOfOrderDetails, newOrderID, eventSubType, operationalPlanDTO,
					oldPlannedOrdersDetailsForUpdate, orderSync.getOrderId(), orderSync.getOrdrNumber(), isOWO, nextLoadId);
		}
	}

	private void getWo42OrdDtlTableList(final String actionFlag, String operationalFlag,
			final ResourceAssignmentPlanDTO resourceAssignmentPlanDTO, final List<Integer> oldPlannedOrdersDetails,
			Integer seqNumber, final List<Wo42OrdDtlTable> listOfOrderDetails, Integer newOrderID,
			final String eventSubType, final OperationalPlanDTO operationalPlanDTO,
			List<Integer> oldPlannedOrdersDetailsForUpdate, Integer legacyOrderId, String legacyOrderNumber,
			final boolean isOWO, Integer nextLoadId) throws JSONException {
		final String timeStampByTaskID = taskRepository.findLastUpdatedTimeStampBytaskId(legacyOrderId);

		Reservation reservationDetails = null;
		List<TSubtask1> listSubTasks;
		boolean isOldplannedOrder = false;

		if (seqNumber <= oldPlannedOrdersDetails.size()
				&& !eventSubType.equalsIgnoreCase(OperationalPlanEventSubType.UNASSIGN_TRUCK.name())) {
			operationalFlag = "U";
			isOldplannedOrder = true;
		}
		log.info("seqNumber and newOrderID and actionflag and operationalFlag " + seqNumber + " " + newOrderID + " "
				+ actionFlag + " " + operationalFlag);
		if (("D".equalsIgnoreCase(actionFlag) || "T".equalsIgnoreCase(actionFlag))
				&& resourceAssignmentPlanDTO.getDriverAssignment() != null || "U".equalsIgnoreCase(operationalFlag)) {
			reservationDetails = rsvrscRepository.getrsvDetailsofDriver(legacyOrderId);
			listSubTasks = subTaskRepository.getSubtaskDetailsForDeleted(legacyOrderId);
		} else {
			listSubTasks = Optional.ofNullable(subTaskRepository.findSubTaskDetailsByTaskId(legacyOrderId))
					.filter(r -> !CollectionUtils.isEmpty(r)).map(r -> r)
					.orElseGet(() -> subTaskRepository.findSubTaskDetailsByTaskIdPlannedLoads(legacyOrderId));
		}
		String locationCode = null;

		if (OperationalPlanEventSubType.INBOUND_TO_YARD.name().equalsIgnoreCase(eventSubType)) {

			final Integer stopSequenceNumber = operationalPlanDTO.getOperationalPlanStops().stream()
					.max(Comparator.comparing(OperationalPlanStopDTO::getOperationalPlanStopSequenceNumber))
					.map(OperationalPlanStopDTO::getOperationalPlanStopSequenceNumber).orElse(null);

			final TSubtask1 subTask = listSubTasks.stream()
					.filter(stop -> stop.getPreferanceSequenceNumber().equals(stopSequenceNumber)).findAny()
					.orElse(null);
			listSubTasks.remove(subTask);

			locationCode = sendPlanHelper.getLocationCode(operationalPlanDTO);
		}
		List<Wo42OrdStopInfo> wo42OrdStopInfoList = tractorAndDriverSendplanHelp.populateStopDetails(listSubTasks);
		Wo42OrdDtlTable ordDtlDetail = tractorAndDriverSendplanHelp.populateOrderDetails(newOrderID, nextLoadId,
				legacyOrderId, wo42OrdStopInfoList, actionFlag, operationalFlag, timeStampByTaskID, reservationDetails,
				resourceAssignmentPlanDTO, seqNumber, locationCode, isOldplannedOrder, oldPlannedOrdersDetailsForUpdate,
				legacyOrderNumber, isOWO);
		log.info("after populate orderDetails seqNumber" + seqNumber);

		listOfOrderDetails.add(ordDtlDetail);
	}

}
