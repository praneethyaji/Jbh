package com.jbhunt.loadplannig.integration.backfill.enums;

import java.util.HashMap;
import java.util.Map;

public enum JAStatusType {

	AVAILABLE(1, "Available"), COMPLETED(2, "Completed"), CANCELED(3, "Canceled");

	Integer typeId;

	String typeName;
	private static Map<String, String> mapValues = new HashMap<>();

	static{
		mapValues.put("Available", "A");
		mapValues.put("Completed", "S");
		mapValues.put("Canceled", "X");
	}

	private JAStatusType(Integer typeId, String name) {
		this.typeId = typeId;
		this.typeName = name;
	}

	public String getTypeName() {
		return typeName;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public static String getCode(String value){
		return mapValues.get(value);
	}

}
