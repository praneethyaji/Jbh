package com.jbhunt.loadplannig.integration.backfill.dto;

import java.util.HashMap;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CheckcallDTO {
    private String userId="";
    private String orderNumber="";
    private long ordI;
    private long jobId;
    private String project="";
    private String carrier="";
    private long eqpId;
    private String tractorNbr="";
    private String tractorRqdFlg;
    private int nextStopSeqNbr;
    private String nextCustomerCode="";
    private String callType="";
    private String stopCustomerCode="";
    private String checkCallVars="";
    private String dataState = "";
    private String locationCityState="";
    private String LoadUnloadDate="";
    private String LoadUnloadtime="";
    private String comments="";
    private String carrierFlg="";
    private String arrivalDate="";
    private String arrivalTime="";
    private String comment="";
    private String TrailerContainerNumber="";
    private String TrailerContainerPrefix="";
    private String poNumber="";
    private String seal="";
    private String bolNumber="";
    private String proNumber="";
    private long quantity=0;
    private long weight=0;
    private String beamTrailerOrder="";
    private long invertOrder = 0;
    private String createUserId= "" ;
    private String orderTimeStamp = ""; 
    private String beamCustomerCode = "";
    private String tcallCustomerCode = ""; 
    private String ccallLocation = ""; 
    private String ccallTrailerChasisFlag = "";
    private SpotDBCallDTO spotCallDTO;
    private PCallDTO pCallDTO;
    private String locationTimeZone;
    private Map<String,String> routeDetails = new HashMap<>();
}
