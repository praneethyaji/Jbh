package com.jbhunt.loadplannig.integration.backfill.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TerminateCallDTO {
	
	
    private String pickupArea;
    
    private String dropTrailerFlag;
    
    private String truckCityState;
    
    private String customerCode;
    
    private String cityState;
    
    private Integer endHubMiles;

}
