/*package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.TEquipment;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.EquipmentRepository;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadSyncRepository;
import com.jbhunt.loadplannig.integration.backfill.services.DispatchLoadPlanService;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanAdditionalInstructionDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanEquipmentRequirementDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanEquipmentRequirementSpecificationAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.masterdata.dto.EquipmentDetailsDTO;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InCommentsLine;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOrdBuffer2;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOrdBuffer2.Oee5InOrdEqpUntC;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InTrlgEqpBuffer11;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InTrlgEqpBuffer11.Oee5InTrlgEqpCmmData;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class LoadEquipmentUpdateServiceHelper {
	
	private final InstructionUpdateServiceHelper instructionUpdateServiceHelper;
	private final OrderLoadSyncRepository orderLoadSyncRepository;
	private final EquipmentRepository equipmentRepository;
	private final DispatchLoadPlanService dispatchLoadPlanService;
	
	public Oee5InputChannelData extractCommentList(Oee5InputChannelData input, Integer stopSeqNo) throws JBHuntRuntimeException {
		List<OrderLoadSync> loadDetails;
		try {
			loadDetails = orderLoadSyncRepository.findOrderLoadSyncDTODetailsByOrderID(input.getOee5InLoadSyncBuffer12().get(0).getOee5InScmOrdI());
		} catch (JBHuntRuntimeException e) {
			log.info("Error calling XRef Service"+e);
			throw new JBHuntRuntimeException(e.getLocalizedMessage());
		}
		instructionUpdateServiceHelper.populateComments(null, loadDetails.get(0), input, stopSeqNo);
		return input;
	}
	
	public Oee5InOrdBuffer2 populateEquipmentDetails(Oee5InputChannelData input,
			OperationalPlanEvent operationalPlanEvent) {
		log.info("populateEquipmentDetails calling >>>>>>>>>>>>>>>>>>>>>>>");
		Oee5InOrdBuffer2 oee5InOrdBuffer2 = input.getOee5InOrdBuffer2();
		
		EquipmentDetailsDTO equipmentDetailsDTO = dispatchLoadPlanService.getTractorDetails(operationalPlanEvent.getOperationalPlanDTO());
		TEquipment equipmentDetails = equipmentRepository.getTrailerDetails(equipmentDetailsDTO.getEquipmentNumber());
		
		String equipmentNbr = equipmentDetails.getTrailerNumber();
		
		oee5InOrdBuffer2.setOee5InOrdEqpUntPfx(equipmentDetails.getTrailerPrefix());
		input.getOee5InOthOrdBuffer9()
				.setOee5InOrdOrgTrlNbr(equipmentDetails.getTrailerNumber());
		Oee5InOrdEqpUntC ordEqpUntC = new Oee5InOrdEqpUntC();
		if (StringUtils.isNotEmpty(equipmentNbr)) {
			if (equipmentNbr.trim().length() < 6) {
				equipmentNbr = StringUtils.leftPad(equipmentNbr.trim(), 6, "0");
			}
			ordEqpUntC.setOee5InOrdFiller1(equipmentNbr.substring(0, 1));
			if (equipmentNbr.length() >= CommonConstants.MAX_EQP_LENGTH_10) {
				ordEqpUntC.setOee5InOrdFiller2(equipmentNbr.substring(1, CommonConstants.MAX_EQP_LENGTH_10));
			} else {
				ordEqpUntC.setOee5InOrdFiller2(equipmentNbr.substring(1));
			}
		} else {
			ordEqpUntC.setOee5InOrdFiller1(" ");
			ordEqpUntC.setOee5InOrdFiller2("         ");
		}
		oee5InOrdBuffer2.setOee5InOrdEqpUntC(ordEqpUntC);
		String eqpReqTypC = "";
		oee5InOrdBuffer2.setOee5InOrdEqpTypC(eqpReqTypC);
		return oee5InOrdBuffer2;
	}
	
	
	public void populateOtherEquipInformation(OperationalPlanEquipmentRequirementDTO orderEquipmentRequirementDTO,
			Oee5InOrdBuffer2 oee5InOrdBuffer2, Oee5InputChannelData input, OperationalPlanEvent operationalPlanEvent)
			throws JBHuntRuntimeException {
		
		log.info("populateOtherEquipInformation calling >>>>>>>>>>>>>>>>>>>>>>>");

		oee5InOrdBuffer2.setOee5InOrdEqpLenRqdF(orderEquipmentRequirementDTO.getEquipmentLengthRequiredIndicator());

		populateDriverComments("", input, "DRIVER");
		String oee5InOrdEqpSubClsC = ""; 
		oee5InOrdBuffer2.setOee5InOrdEqpSubClsC(oee5InOrdEqpSubClsC);
		oee5InOrdBuffer2.setOee5InOrdPrlTrlF(orderEquipmentRequirementDTO.getTrailerPreloadedIndicator());

		oee5InOrdBuffer2.setOee5InOrdEqpSubClsRqdF(orderEquipmentRequirementDTO.getEquipmentTypeRequiredIndicator());
		oee5InOrdBuffer2.setOee5InOrdEqpTypRqdF(orderEquipmentRequirementDTO.getEquipmentTypeRequiredIndicator());

	}
	
	public void populateDriverComments(String equipmentSpecificationType, Oee5InputChannelData input, String commentType) throws JBHuntRuntimeException {
		Oee5InCommentsLine comment = new Oee5InCommentsLine();
		comment.setOee5InCommentsCmmTypC(commentType);
		comment.setOee5InCommentsCmm(StringUtils.upperCase(equipmentSpecificationType + " REQUIRED"));
		comment.setOee5InCommentsSeqNbr((short) (input.getOee5InCommentsBuffer3().size() + 1));
		Map<String, List<Oee5InCommentsLine>> mapcomment = input.getOee5InCommentsBuffer3().stream()
				.collect(Collectors.groupingBy(Oee5InCommentsLine::getOee5InCommentsCmm));
		if (!mapcomment.containsKey(StringUtils.upperCase(equipmentSpecificationType + " REQUIRED"))) {
			input.getOee5InCommentsBuffer3().add(comment);
		}
		input.getOee5InputBuffer1().setOee5InputNbrOfComments((short) input.getOee5InCommentsBuffer3().size());
	}
	
	public void populateEquipmentComments(Oee5InTrlgEqpCmmData oee5InTrlgEqpCmmData,
			OperationalPlanEquipmentRequirementDTO orderEquipmentRequirementDTO,
			OperationalPlanEquipmentRequirementSpecificationAssociationDTO orderEquipmentRequirementSpecificationDetail, Oee5InTrlgEqpBuffer11 oee5InTrlgEqpBuffer11) {
		
		log.info("populateEquipmentComments calling >>>>>>>>>>>>>>>>>>>>>>>");
		if (null != orderEquipmentRequirementDTO
				&& null != orderEquipmentRequirementDTO.getOperationalPlanAdditionalInstructions()
				&& CollectionUtils.isNotEmpty(
						orderEquipmentRequirementDTO.getOperationalPlanAdditionalInstructions())) {
			String comm = "";
			for (OperationalPlanAdditionalInstructionDTO addcomment : orderEquipmentRequirementDTO.getOperationalPlanAdditionalInstructions()) {
				comm = "precool temperature" + "-" + orderEquipmentRequirementSpecificationDetail.getOperationalPlanEquipmentRequirementSpecificationAssociationId() + "-" + addcomment.getAdditionalInstructionText();
			}
			oee5InTrlgEqpCmmData.setOee5InCmmTxt(comm);
			oee5InTrlgEqpBuffer11.getOee5InEqpCmmBuffer11C().add(oee5InTrlgEqpCmmData);
			oee5InTrlgEqpBuffer11.setOee5InEqpCmmChanged("Y");
		}
	}

}
*/