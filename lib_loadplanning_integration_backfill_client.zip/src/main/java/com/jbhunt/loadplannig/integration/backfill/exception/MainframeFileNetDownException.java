package com.jbhunt.loadplannig.integration.backfill.exception;

public class MainframeFileNetDownException extends RuntimeException {
    public MainframeFileNetDownException(String message){
        super(message);
    }
}
