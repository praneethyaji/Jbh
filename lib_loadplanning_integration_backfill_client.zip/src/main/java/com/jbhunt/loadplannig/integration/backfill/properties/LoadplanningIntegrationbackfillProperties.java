package com.jbhunt.loadplannig.integration.backfill.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@Data
@ConfigurationProperties("loadplanningIntegrationbackfill")
public class LoadplanningIntegrationbackfillProperties {

    private String baseURL;
}