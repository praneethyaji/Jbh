/*package com.jbhunt.loadplannig.integration.backfill.services;

import java.math.BigDecimal;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.utils.LoadEquipmentUpdateServiceHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanEquipmentRequirementDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanEquipmentRequirementSpecificationAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOrdBuffer2;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InTrlgEqpBuffer11;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InTrlgEqpBuffer11.Oee5InTrlgEqpCmmData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InTrlgEqpBuffer11.Oee5InTrlgEqpSpecData;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InTrlgEqpBuffer11.Oee5InTrlgEqpTemData;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class LoadEquipmentInstructionUpdateService {

	private final LoadEquipmentUpdateServiceHelper loadEquipmentUpdateServiceHelper;

	public Oee5InputChannelData processEquipmentUpdate(OperationalPlanEvent operationaPlanEvent,
			Oee5InputChannelData input) throws JBHuntRuntimeException {
		log.info("createTrlngEqpBuffer11");
		input = loadEquipmentUpdateServiceHelper.extractCommentList(input, 0);
		Oee5InTrlgEqpBuffer11 oee5InTrlgEqpBuffer11 = new Oee5InTrlgEqpBuffer11();

		if (CollectionUtils
				.isNotEmpty(operationaPlanEvent.getOperationalPlanDTO().getOperationalPlanEquipmentRequirements())) {

			populateTrlngEqpBuffer11(operationaPlanEvent, input, oee5InTrlgEqpBuffer11);

			input.getOee5InputBuffer1().setOee5InputOrderChgF("Y");
		}
		input.setOee5InTrlgEqpBuffer11(oee5InTrlgEqpBuffer11);

		return input;
	}

	public void populateTrlngEqpBuffer11(OperationalPlanEvent operationaPlanEvent, Oee5InputChannelData input,
			Oee5InTrlgEqpBuffer11 oee5InTrlgEqpBuffer11) throws JBHuntRuntimeException {
		
		log.info("populateTrlngEqpBuffer11 calling  >>>>>>>>>>>>>>>>>>>>>>>>");

		Oee5InTrlgEqpCmmData oee5InTrlgEqpCmmData = null;
		
		Oee5InOrdBuffer2 oee5InOrdBuffer2 = loadEquipmentUpdateServiceHelper.populateEquipmentDetails(input,
				operationaPlanEvent);

		for (OperationalPlanEquipmentRequirementDTO orderEquipmentRequirementDTO : operationaPlanEvent
				.getOperationalPlanDTO().getOperationalPlanEquipmentRequirements()) {

			loadEquipmentUpdateServiceHelper.populateOtherEquipInformation(orderEquipmentRequirementDTO,
					oee5InOrdBuffer2, input, operationaPlanEvent);
			
			
			Oee5InTrlgEqpSpecData oee5InTrlgEqpSpecData = new Oee5InTrlgEqpSpecData();
			oee5InTrlgEqpSpecData.setOee5InEqpSpecMsrBas("");
			oee5InTrlgEqpSpecData.setOee5InEqpSpecMsrVal((short) 0.00);
			oee5InTrlgEqpSpecData.setOee5InTrlgEqpSpecAscI(0);
			oee5InTrlgEqpBuffer11.getOee5InEqpSpecBuffer11A().add(oee5InTrlgEqpSpecData);
			oee5InTrlgEqpBuffer11.setOee5InEqpSpecChanged("Y");
			
			Oee5InTrlgEqpTemData oee5InTrlgEqpTemData = new Oee5InTrlgEqpTemData();

			oee5InTrlgEqpTemData.setOee5InZoneSeqNbr((short) 0.00);
			oee5InTrlgEqpTemData.setOee5InMinTem(BigDecimal.valueOf(0.00));
			oee5InTrlgEqpTemData.setOee5InMaxTem(BigDecimal.valueOf(0.00));
			oee5InTrlgEqpBuffer11.getOee5InEqpTemBuffer11B().add(oee5InTrlgEqpTemData);
			

			if (CollectionUtils.isNotEmpty(
					orderEquipmentRequirementDTO.getOperationalPlanEquipmentRequirementSpecificationAssociations())) {
				
				oee5InTrlgEqpCmmData = new Oee5InTrlgEqpCmmData();

				for (OperationalPlanEquipmentRequirementSpecificationAssociationDTO orderEquipmentRequirementSpecificationAssociations : orderEquipmentRequirementDTO
						.getOperationalPlanEquipmentRequirementSpecificationAssociations()) {

					loadEquipmentUpdateServiceHelper.populateEquipmentComments(oee5InTrlgEqpCmmData, orderEquipmentRequirementDTO, orderEquipmentRequirementSpecificationAssociations, oee5InTrlgEqpBuffer11);
				}
			}
			
			input.setOee5InOrdBuffer2(oee5InOrdBuffer2);
		}
	}

}
*/