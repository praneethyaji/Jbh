package com.jbhunt.loadplannig.integration.backfill.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import com.jbhunt.security.boot.autoconfig.enterprisesecurity.AuthorizationConfiguration;
import com.jbhunt.security.boot.autoconfig.enterprisesecurity.filter.AuthorizationFilter;

@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    private AuthorizationConfiguration authorizationConfiguration;

    public SecurityConfiguration(AuthorizationConfiguration authorizationConfiguration) {
        this.authorizationConfiguration = authorizationConfiguration;

    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable();
        http.httpBasic();
        http.authorizeRequests().anyRequest().authenticated();
        //To be  configured later with required URL authorization.
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        http.addFilterAfter(authorizationConfiguration.getAuthorizationFilter(), BasicAuthenticationFilter.class);
        http.addFilterAfter(authorizationConfiguration.getSwitchUserFilter(), AuthorizationFilter.class);
    }
}