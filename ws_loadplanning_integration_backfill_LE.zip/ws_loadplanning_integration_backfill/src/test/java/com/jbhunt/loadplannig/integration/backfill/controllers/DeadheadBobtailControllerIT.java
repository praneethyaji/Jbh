package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.relaxedRequestFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.pathParameters;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.document;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.restassured.operation.preprocess.RestAssuredPreprocessors.modifyUris;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.restdocs.request.ParameterDescriptor;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.SocketUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.mdm.dto.LocationProfileDTOs;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc363i.lmc363.LMC363Port;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class DeadheadBobtailControllerIT {

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@LocalServerPort
	private int port;

	public static WireMockServer wireMockServer;

	public static final int WIREMOCK_PORT = SocketUtils.findAvailableTcpPort();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	protected OperationPreprocessor uriOverride = modifyUris().scheme("http")
			.host("loadplanning-test.jbhunt.com").removePort();

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	@MockBean
	private LMC363Port lmc363Port;

	public static final String username = "user";

	public static final String password = "pass";

	public static final String DEADHEAD_JSON = "/json/DeadheadCheckCall.json";

	public static final String BOBTAIL_JSON = "/json/BobtailCheckCall.json";

	public static final String NO_EQUIPMENT_BOBTAIL_JSON = "/json/NoEquipmentDetails.json";

	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;

	@MockBean
	LocationProfileDTOs locationProfileDTOs;

	@Autowired
	private ObjectMapper objectMapper;

	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void setupClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
		System.setProperty("runtime.environment", "QA");
		System.setProperty("WIREMOCK_PORT", String.valueOf(WIREMOCK_PORT));
		System.setProperty("runtime.environment", "QA");
		wireMockServer = new WireMockServer(WIREMOCK_PORT);
		wireMockServer.start();
	}

	@Test
	public void testDeadheadCheckCall() throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[1859748]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[142691]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));
		
		String crossReferenceResponse = "[{\"cciNextCCICrossReferenceID\":5025429,\"cciEntityName\":\"TCITY\",\"cciEntityFirstColumnName\":\"PNT_I\",\"cciEntityFirstColumnValue\":19764,\"cciEntitySecondColumnName\":null,\"cciEntitySecondColumnValue\":null,\"nextEntityName\":\"City\",\"nextEntityFirstColumnName\":\"CityID\",\"nextEntityFirstColumnValue\":9999,\"effectiveTimestamp\":\"1992-01-06T19:07:16-06:00\",\"expirationTimestamp\":\"2099-12-31T17:59:59.454-06:00\"}]";

        wireMockServer.stubFor(get(urlEqualTo("/masterdatacrossreferenceservices/crossreference/fetchcrossreferences/City/CityID/9999")).willReturn(
                aResponse().withHeader("Content-Type", "application/json").withBody(crossReferenceResponse).withStatus(200)));

		final OperationalPlanDTO operationalPlanDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(DEADHEAD_JSON)), OperationalPlanDTO.class);

		Response response = given(this.requestSpecification).auth().basic(username, password)
				.filter(document("ProcessDeadHead", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processDeadheadBobtail())))
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanDTO)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/{operationalPlanId}/deadhead",
						4866);
		Assert.assertEquals(response.statusCode(), response.statusCode());
	}

	@Test
	public void testBobtailCheckCall() throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[1859748]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[142691]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		final OperationalPlanDTO operationalPlanDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(BOBTAIL_JSON)), OperationalPlanDTO.class);

		Response response = given(this.requestSpecification).auth().basic(username, password)
				.filter(document("ProcessBobtail", preprocessRequest(uriOverride, prettyPrint()),
						preprocessResponse(prettyPrint()), relaxedRequestFields(processDeadheadBobtail())))
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanDTO)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/{operationalPlanId}/bobtail",
						4866);
		Assert.assertEquals(response.statusCode(), response.statusCode());
	}

	@Test
	public void testNoEquipmentForCheckCall() throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));

		String responseMasterData = IOUtils.toString(this.getClass().getResourceAsStream("/json/MasterDataAsset.json"));
		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[1859748]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		wireMockServer.stubFor(post(urlEqualTo("/ws_masterdata_asset/equipments/details"))
				.withRequestBody(WireMock.equalTo("[142691]")).willReturn(aResponse()
						.withHeader("Content-Type", "application/json").withBody(responseMasterData).withStatus(200)));

		OperationalPlanDTO operationalPlanDTO = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(NO_EQUIPMENT_BOBTAIL_JSON)),
				OperationalPlanDTO.class);

		Response response = given(this.requestSpecification).auth().basic(username, password)
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanDTO)
				.patch("/ws_loadplanning_integration_backfill/backfill/operationalplans/{operationalPlanId}/bobtail",
						4866);
		Assert.assertEquals(response.statusCode(), response.statusCode());
	}
	
	/*private ParameterDescriptor[] operationalPlanParams() {
		return new ParameterDescriptor[] { parameterWithName("operationalPlanId").description("operational Plan Id") };
	}*/
	
	private static FieldDescriptor[] processDeadheadBobtail() {
		return new FieldDescriptor[] {
			fieldWithPath("createUserId").description("User id who create the plan").type(String.class),
			fieldWithPath("lastUpdateUserId").description("user id who initiated the deadhead/bobtail").type(String.class),
			fieldWithPath("operationalPlanFinanceBusinessUnitCode").description("Business code which tells the finance unit of equipment").type(String.class),
			
			fieldWithPath("operationalPlanResourceAssignmentAssociationList[].resourceAssignmentPlan.equipmentAssignments.equipmentId").description("Equipment id of deadehead/bobtail").type(String.class),
			fieldWithPath("operationalPlanStops[].cityId").description("city ids of the stop locations").type(String.class),
			fieldWithPath("operationalPlanStops[].stopReasonCode").description("reason for stop locations").type(String.class),
			fieldWithPath("operationalPlanComments[].commentText").description("comment given by user while deadhead/bobtail").type(String.class)
		};
	}

}
