package com.jbhunt.loadplannig.integration.backfill.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@RefreshScope
@Component
@ConfigurationProperties("mainframeendpoints")
public class MainframeEndpointProperties {

	private String lmc341URL;
	private String lmc342URL;
	private String lmc345URL;
	private String lmc360URL;
	private String lmc359URL;
	private String lmc363URL;
	private String lmc361URL;
	private String lmc362URL;
	private String lmc366URL;
	private String lmc364URL;
	private String lmc365URL;
	private String lmc367URL;
	private String oec145URL;
	private String oec076URL;

}

