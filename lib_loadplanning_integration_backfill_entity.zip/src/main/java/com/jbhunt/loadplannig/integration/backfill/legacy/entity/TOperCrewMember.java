package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "TOPER_CREW_MEMBER", schema = "ALI")
public class TOperCrewMember {

	@Id
	@Column(name = "OPR_CREW_MBR_ID")
	private int oprCrewMbrId;

	@Column(name = "OPR_ROLE_C")
	private String operationRole;

	@Column(name = "REC_STT_F")
	private String recordStatus;

	@Column(name = "OPR_ID")
	private Integer operatorId;
	
	@OneToOne
    @JoinColumn(name = "OPR_CREW_MBR_ID")
    @MapsId
    private OperPowAssoc operPowAssoc;
	

}
