package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "TBUSINESS_SITE", schema = "ALI")
public class BusinessSite implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@Column(name = "BSST_ID")
	private Integer bsstID;
	
	@Column(name = "BUS_ID")
	private Integer busID;
	
	@Column(name = "BUS_LOC_ID")
	private Integer busLocID;
	
	@Column(name = "DIV_ID")
	private String divID;
	
	@Column(name = "BUS_NAME_I")
	private String busNameI;
	
	@Column(name = "REC_STT_F")
	private String recSitF;
	
	
	
	
	
	
}
