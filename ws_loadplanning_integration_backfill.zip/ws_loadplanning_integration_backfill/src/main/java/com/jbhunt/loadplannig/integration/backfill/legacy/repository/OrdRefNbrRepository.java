package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrdRefNbr;

@Repository
public interface OrdRefNbrRepository extends JpaRepository<OrdRefNbr, String> {
	
	List<OrdRefNbr> findOrdRefNbrDetailsByOrderId(@Param("orderId") int orderId);
	
	@Modifying
	@Transactional
	@Query(value = "DELETE FROM ALI.TORD_REF_NBR where CRT_UID = 'PIDLDPN' AND ORD_I=:orderId", nativeQuery = true)
	Integer deleteReferenceNumbers(@Param("orderId") Integer orderId);

}
