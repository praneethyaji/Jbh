package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TORDER", schema = "ALI")
public class TOrder implements Serializable { 

	private static final long serialVersionUID = 3931372509084744183L;

	@Id
	@Column(name = "ORD_I")
	private Integer orderId; 

	@Column(name = "ORD_NBR_CH")
	private String ordrNumber;

	@Column(name = "CRT_S")
	private String orderCreatedTimeStamp;

	@Column(name = "LST_UPD_S")
	private String lastUpdateTimeStamp;
	
	@Column(name = "LST_DSP_NBR")
	private Short dispatchNumber;
	
}
