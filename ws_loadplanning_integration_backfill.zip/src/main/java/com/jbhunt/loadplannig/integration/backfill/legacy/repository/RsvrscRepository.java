package com.jbhunt.loadplannig.integration.backfill.legacy.repository;

import com.jbhunt.loadplannig.integration.backfill.legacy.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;


@RepositoryRestResource
public interface RsvrscRepository extends JpaRepository<Reservation, Integer> {
	@Query(value = "SELECT RSC_RSV_I, CHAR(LST_UPD_S) AS LST_UPD_S,REQ_TO_ETY_KEY_I,REC_STT from ALI.RSC_RSV WHERE REQ_TO_ETY_KEY_I=:taskId  AND REC_STT = 'A' WITH UR", nativeQuery = true)
	Reservation getrsvDetailsofDriver(@Param("taskId") Integer taskId);

	@Query(value = " SELECT RSC.RSC_RSV_I, BRP.LGC_ORD_I from ALI.RSC_RSV RSC, ALI.BKFIL_RSC_PLAN BRP  WHERE REQ_FR_ETY_KEY_CH =:alphaCode AND BRP.RSC_RSV_I = RSC.RSC_RSV_I WITH UR ", nativeQuery = true)
	List<Object[]> fetchResourcePlanByDriverAlphaCode(@Param("alphaCode") String alphaCode);
}
