package com.jbhunt.loadplannig.integration.backfill.services;

import static com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants.AVAILABLE;
import static com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants.PLANNED;
import static com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants.DISPATCHED;

import org.springframework.stereotype.Service;

import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class InboundYardService {

	private DriverAndTruckAssignmentService driverAndTruckAssignmentService;
	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private InboundYardAfterDispatchService inboundYardAfterDispatchService;

	public void createInboundToYard(final OperationalPlanDTO operationalPlanDTO) throws Exception {
		backFillEventTrackingRepository.saveBackTrackingDetails(operationalPlanDTO, EventStatusEnum.PENDING.name(),
				OperationalPlanEventSubType.INBOUND_TO_YARD.name(), "");
		createInboundYard(operationalPlanDTO, CommonConstants.TRACTOR_AND_DRIVER_SAVEPLAN,
				CommonConstants.TRACTOR_AND_DRIVER_SAVEPLAN, OperationalPlanEventSubType.INBOUND_TO_YARD.name());
	}

	public void createInboundYard(final OperationalPlanDTO operationalPlanDTO, final String actionFlag,
			final String operationalFlag, final String eventSubType) throws Exception {

		switch (operationalPlanDTO.getOperationalPlanStatus().getOperationalPlanStatusCode()) {
		case AVAILABLE:
			log.info("InboundYard :" + AVAILABLE);
			break;
		case PLANNED:
			log.info("InboundYard :" + PLANNED);
			driverAndTruckAssignmentService.driverAndTruckAssignment(operationalPlanDTO, actionFlag, operationalFlag,
					eventSubType);
			break;
		case DISPATCHED:
			log.info("InboundYard :" + DISPATCHED);
			inboundYardAfterDispatchService.inboundYardAfterDispatch(operationalPlanDTO);
			break;
		default:
			break;

		}

	}

}
