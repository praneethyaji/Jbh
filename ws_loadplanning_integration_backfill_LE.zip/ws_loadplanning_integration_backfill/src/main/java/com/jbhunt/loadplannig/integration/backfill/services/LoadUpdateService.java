package com.jbhunt.loadplannig.integration.backfill.services;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.stereotype.Service;

import com.jbhunt.biz.refNumber.dao.ws.buffers.ReferenceNumbersLinkBuffers;
import com.jbhunt.biz.refNumber.vo.AddNewReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.DeletedReferenceNumberVO;
import com.jbhunt.biz.refNumber.vo.UpdatedReferenceNumberVO;
import com.jbhunt.biz.securepid.PIDCredentials;
import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.legacy.entity.OrderLoadSync;
import com.jbhunt.loadplannig.integration.backfill.legacy.repository.OrderLoadSyncRepository;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CommonUtils;
import com.jbhunt.loadplannig.integration.backfill.utils.InstructionUpdateServiceHelper;
import com.jbhunt.loadplannig.integration.backfill.utils.ReferenceUpdateServiceHelper;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanReferenceNumberDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.oec076i.oec076.OEC076Port;
import com.request.oec076i.oec076.ProgramInterface;
import com.request.oec076i.oec076.ProgramInterface.Oe76InputChannelData;
import com.request.oec076i.oec076.ProgramInterface.Oe76InputChannelData.Oe76InHeadingBuffer1;
import com.request.oec076i.oec076.ProgramInterface.Oe76InputChannelData.Oe76InOrdBuffer3;
import com.request.oec076i.oec076.ProgramInterface.Oe76InputChannelData.Oe76InXmlStringBuffer16;
import com.request.oec076i.oec076.ProgramInterface.Oe76InputChannelData.Oe76InputBuffer2;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData;
import com.response.oec076i.oec076.ProgramInterface.Oe76OutputChannelData;
import com.response.oec145i.oec145.ProgramInterface.Oee5OutputChannelData;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class LoadUpdateService {

	private final BackFillEventTrackingRepository backFillEventTrackingRepository;
	private final LegacyOrderLoadCrossReferenceService legacyOrderLoadCrossReferenceService;
	private final InstructionUpdateServiceHelper instructionUpdateServiceHelper;
	private final ReferenceUpdateServiceHelper referenceUpdateServiceHelper;
	private final OrderLoadSyncRepository orderLoadSyncRepository;
	private final OEC145MapperService oEC145MapperService;
	private final PIDCredentials pidCredentials;
	private final OEC076Port oec076Port;

	public void processInstructionUpdate(OperationalPlanEvent operationalPlanEvent) {
		log.info("processInstructionUpdate calling ..... ");
		
		for(OrderOperationalPlanAssociationDTO orderOperationalPlanAssociationDTO : operationalPlanEvent.getOperationalPlanDTO().getOrderOperationalPlanAssociations()) {
			
			int orderId = orderOperationalPlanAssociationDTO.getOperationalPlanOrder().getOrderId();
			List<OrderLoadSync> loadDetails = getLoadDetails(orderId);

			Oee5InputChannelData oee5input = new Oee5InputChannelData();
			Oee5OutputChannelData oee5OutputChannelData = null;
			
			oee5input = prepareLoadObj(oee5input, loadDetails);

			instructionUpdateServiceHelper.deleteOrderComments(loadDetails.get(0));
			instructionUpdateServiceHelper.deleteStopComments(loadDetails.get(0));
			instructionUpdateServiceHelper.populateComments(operationalPlanEvent, loadDetails.get(0), oee5input, 0);

			//loadEquipmentInstructionUpdateService.processEquipmentUpdate(operationalPlanEvent, oee5input);

			oee5OutputChannelData = oEC145MapperService.callOEC145UpdateService(oee5input);
			log.info("oee5OutputChannelData >>>>>>>>>>>>>>>>>>>>>>>>> {}",CommonUtils.asString(oee5OutputChannelData));
			backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanEvent.getOperationalPlanDTO(),
					EventStatusEnum.COMPLETED.name(), "");
		}
	}
	
	public void processReferenceNumberUpdate(OperationalPlanEvent operationalPlanEvent) {
		
		log.info("processReferenceUpdate calling ..... ");
		
		Oee5InputChannelData oee5input = new Oee5InputChannelData();
		int legacyOrderID = legacyOrderLoadCrossReferenceService.getLegacyOrderDetails(operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanId()).getLegacyOrderId();
		List<OrderLoadSync> loadDetails = orderLoadSyncRepository.findOrderLoadSyncDTODetailsByLegacyOrderID(legacyOrderID);
		oee5input = prepareLoadObj(oee5input, loadDetails);
		String userId = operationalPlanEvent.getOperationalPlanDTO().getCreateUserId();
        String programName = CommonConstants.OPEX_BKFL;
        
        List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
        List<AddNewReferenceNumberVO> crtRefNbrList = new ArrayList<>();
        List<DeletedReferenceNumberVO> delRefNbrList = new ArrayList<>();
        List<String> actionList = new ArrayList<>();
        
        //actionList.add("NewObject");
        
        actionList.add("ValueChange");
        
		ReferenceNumbersLinkBuffers ordRefNbrBuffers = referenceUpdateServiceHelper.linkOEC070InSelectMode(legacyOrderID,
				userId, programName, "jcnt531", "getlow08");
		OperationalPlanReferenceNumberDTO referenceNumberDTO = new OperationalPlanReferenceNumberDTO();

		List<OperationalPlanReferenceNumberDTO> inputReferenceNumberDTOs = new ArrayList<>();
		
		
		if (null != operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanReferenceNumbers()) {
			inputReferenceNumberDTOs
					.addAll(operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanReferenceNumbers());
			for (OperationalPlanReferenceNumberDTO referenceNumber : operationalPlanEvent.getOperationalPlanDTO()
					.getOperationalPlanReferenceNumbers()) {
				if(StringUtils.equals(referenceNumber.getSourceApplicationCode(), CommonConstants.OPEX)) {
					referenceNumberDTO = referenceNumber;
					log.info("referenceNumberDTO >>>>>>>>>>>>>>>>>>>>>>>> {}",referenceNumberDTO);
					break;
				}
			}
		}
		
		String callMode = "REFNBR";
		
		if((CommonConstants.LTL).equalsIgnoreCase(operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanServiceOfferingCode())){
			callMode = "LINEITEM";
		}
		
		String entity = "OrderReferenceNumber";
		
		if (actionList.contains("ObjectRemoved")) {
			delRefNbrList = referenceUpdateServiceHelper.fetchDeleteReferenceNumberVO(delRefNbrList, ordRefNbrBuffers,
					referenceNumberDTO);
		} else if (actionList.contains("NewObject")) {
			crtRefNbrList = referenceUpdateServiceHelper.fetchCreateReferenceNumberVO(operationalPlanEvent,
					inputReferenceNumberDTOs, oee5input, entity, referenceNumberDTO);
		} else if (actionList.contains("ValueChange")) {
			updRefNbrList = referenceUpdateServiceHelper.fetchUpdateReferenceNumberVO(operationalPlanEvent,
					inputReferenceNumberDTOs, ordRefNbrBuffers, oee5input, referenceNumberDTO, entity);
		}
		
		referenceUpdateServiceHelper.defaultLineItemValuesForRefMode(updRefNbrList, crtRefNbrList, delRefNbrList, callMode);
		
		List<UpdatedReferenceNumberVO> finalUpdRefNbrList = new ArrayList<>();
		finalUpdRefNbrList.add(updRefNbrList.get(0));
		
		String response  =  referenceUpdateServiceHelper.linkOEC070InUpdateMode(ordRefNbrBuffers, finalUpdRefNbrList, crtRefNbrList, delRefNbrList, loadDetails.get(0),
                "jcnt531::getlow08", callMode, CommonConstants.OEC070_UPDATE);
		
		log.info("Reference Update Response  - Load >>>>>>>>>>>>>>>>>>>>>>> {}",response);
		
		//processReferenceNumberUpdateForStopItem(operationalPlanEvent, loadDetails.get(0), oee5input);
		
		backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanEvent.getOperationalPlanDTO(),
				EventStatusEnum.COMPLETED.name(), "");
		 
	}
	
	/*public String processReferenceNumberUpdateForStopItem(OperationalPlanEvent operationalPlanEvent, OrderLoadSync loadDetails, Oee5InputChannelData oee5input) {
		
		log.info("processReferenceUpdateForStopItem calling ..... ");
		
		
		int legacyOrderID = loadDetails.getLegacyOrderID();
		String userId = operationalPlanEvent.getOperationalPlanDTO().getCreateUserId();
        String programName = CommonConstants.OPEX_BKFL;
        
        List<UpdatedReferenceNumberVO> updRefNbrList = new ArrayList<>();
        List<AddNewReferenceNumberVO> crtRefNbrList = new ArrayList<>();
        List<DeletedReferenceNumberVO> delRefNbrList = new ArrayList<>();
        
		ReferenceNumbersLinkBuffers ordRefNbrBuffers = referenceUpdateServiceHelper.linkOEC070InSelectMode(legacyOrderID,
				userId, programName, "jcnt531", "getlow08");
		
		//Only One Stop per event possible so getting first index alone
		OperationalPlanStopDTO stopDTO  = operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops().get(0);
			
			int stopItemId = stopDTO.getOperationalPlanStopId();
			OperationalPlanStopItemDTO stopItem = itemReferenceNumberHelper.getStopItemByID(stopDTO, stopItemId);
			
            List<OperationalPlanReferenceNumberDTO> stopReferenceNumbersToUpdateForStopItem = stopDTO.getOperationalPlanReferenceNumbers();
            
            List<OperationalPlanReferenceNumberDTO> referenceNumberDTOsToUpdate = itemReferenceNumberHelper.getReferenceNumberDTOsForStopReferenceNumbers(stopDTO,
                    stopReferenceNumbersToUpdateForStopItem);
	                    

			String callMode = "REFNBR";

			if((CommonConstants.LTL).equalsIgnoreCase(operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanServiceOfferingCode())){
				callMode = "LINEITEM";
			}
			
			updRefNbrList = referenceUpdateServiceHelper.processReferenceNumberUpdateForStopItem(ordRefNbrBuffers,
					referenceNumberDTOsToUpdate, stopItem, operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanStops().size(), stopDTO.getOperationalPlanStopSequenceNumber());
			referenceUpdateServiceHelper.defaultLineItemValuesForRefMode(updRefNbrList, crtRefNbrList, delRefNbrList, callMode);

			String response  = referenceUpdateServiceHelper.linkOEC070InUpdateMode(ordRefNbrBuffers, updRefNbrList,
					crtRefNbrList, delRefNbrList, loadDetails, "jcnt531::getlow08", callMode, CommonConstants.OEC070_UPDATE);
			
			log.info("Reference Update Response - Stop >>>>>>>>>>>>>>>>>>>>>>> {}",response);
			return response;
		
	}*/
	
	private Oe76InXmlStringBuffer16 createXmlSecurity(String securityString) {

		Oe76InXmlStringBuffer16 inXmlStringBuffer16 = new Oe76InXmlStringBuffer16();

		if (null == securityString || "".equalsIgnoreCase(securityString.trim())) {
			inXmlStringBuffer16.setOe76InXmlString(String.format("%-10000s", ""));

		} else {
			inXmlStringBuffer16.setOe76InXmlString(String.format("%-10000s", securityString));
			inXmlStringBuffer16.setOe76InXmlStringLen(securityString.length());
		}

		inXmlStringBuffer16.setOe76InXmlFiller(String.format("%-20000s", ""));

		return inXmlStringBuffer16;
	}

	private Oe76InHeadingBuffer1 createHeader(String callMode) {
		Oe76InHeadingBuffer1 headingBuff = new Oe76InHeadingBuffer1();
		headingBuff.setOe76InFunction(callMode);
		headingBuff.setOe76InProgramToStart("PROGRAM");
		return headingBuff;
	}

	private Oe76InputBuffer2 createInputBuffer2(String callMode, String prgId, String userId, Integer orderId) {
		Oe76InputBuffer2 inpbuff = new Oe76InputBuffer2();
		inpbuff.setOe76InputFunction(callMode);
		inpbuff.setOe76InputPcPrgId(prgId);
		inpbuff.setOe76InputUsrC(userId);
		inpbuff.setOe76InputOrdTy(" ");
		inpbuff.setOe76InputOverrideFlag("");
		inpbuff.setOe76InputOvrdCount((short) 0);
		if (orderId != null) {
			inpbuff.setOe76InputOrdI(orderId);
		}

		return inpbuff;
	}
	
	private List<OrderLoadSync> getLoadDetails(int orderId){
		
		List<OrderLoadSync> loadDetails = new ArrayList<OrderLoadSync>();
		/*int orderId = operationalPlanEvent.getOperationalPlanDTO().getOrderOperationalPlanAssociations().get(0)
				.getOperationalPlanOrder().getOrderId();*/
		loadDetails = orderLoadSyncRepository.findOrderLoadSyncDTODetailsByOrderID(orderId);
		return loadDetails;
	}
	
	private Oee5InputChannelData prepareLoadObj(Oee5InputChannelData oee5input, List<OrderLoadSync> loadDetails) {
		
		int legacyOrdId = loadDetails.get(0).getLegacyOrderID();

		final Properties configProp = new Properties();
		InputStream in = OrderDetailsExtractionService.class.getClassLoader()
				.getResourceAsStream("OEC076Parameters.properties");
		try {
			configProp.load(in);
		} catch (IOException e) {
			log.error("IOException error" + e);
			throw new JBHuntRuntimeException("ERROR READING OEC76 Property :" + e.getLocalizedMessage());
		}

		String xmlSecurityString = configProp.getProperty("securityString");

		Oe76InXmlStringBuffer16 oe76InXmlStringBuffer16 = createXmlSecurity(xmlSecurityString);

		Oe76InHeadingBuffer1 headerBuffer = createHeader("SELECT");

		String userId = pidCredentials.getUsername();
		Oe76InputBuffer2 inputBuffer = createInputBuffer2("SELECT", "OPEX", userId,
				legacyOrdId);

		Oe76InOrdBuffer3 orderBuffer = new Oe76InOrdBuffer3();
		orderBuffer.setOe76InOrdOrdI(legacyOrdId);

		Oe76InputChannelData oe76input = new Oe76InputChannelData();
		oe76input.setOe76InXmlStringBuffer16(oe76InXmlStringBuffer16);
		oe76input.setOe76InHeadingBuffer1(headerBuffer);
		oe76input.setOe76InputBuffer2(inputBuffer);
		oe76input.setOe76InOrdBuffer3(orderBuffer);
		
		ProgramInterface programInterface = new ProgramInterface();
		programInterface.setOe76InputChannelData(oe76input);

		Oe76OutputChannelData oe76OutputChannelData = oec076Port.oec076Operation(oe76input);

		// log.info("oe76OutputChannelData >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> {}",CommonUtils.asString(oe76OutputChannelData));
		
		

		oee5input = oEC145MapperService.getInputChannelDataForOec145(oe76OutputChannelData, loadDetails.get(0));
		
		return oee5input;
		
	}

}
