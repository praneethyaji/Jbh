package com.jbhunt.loadplannig.integration.backfill.legacy.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "JOB_SEGMENT", schema = "ALI")
public class JobSegment implements Serializable {

	private static final long serialVersionUID = 5449099857507298883L;

	@Id
	@Column(name = "JOB_SEG_I")
	private Integer jobSegmentId;

	@Column(name = "JOB_I")
	private Integer jobId;

	@Column(name = "MIL_TYP_C")
	private String mileageType;

	@Column(name = "SEQ_NO")
	private Short sequenceNumber;

	@Column(name = "BEG_HUB_MIL_Q")
	private Integer beginHubMiles;

	@Column(name = "END_HUB_MIL_Q")
	private Integer endHubMiles;

	@Column(name = "INC_JOB_SEG_F")
	private String jobSegmentFlag;

}
