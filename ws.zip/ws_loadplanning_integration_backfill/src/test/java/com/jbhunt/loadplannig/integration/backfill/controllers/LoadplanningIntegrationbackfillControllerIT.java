package com.jbhunt.loadplannig.integration.backfill.controllers;

import static com.jayway.restassured.RestAssured.given;
import static com.jbhunt.security.mock.builder.MockUserBuilder.mockUser;
import static com.jbhunt.security.mock.model.JBHAuthorizationAccessLevel.UPDATE;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeMatchingHeaders;
import static org.springframework.restdocs.restassured.RestAssuredRestDocumentation.documentationConfiguration;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.restdocs.JUnitRestDocumentation;
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jbhunt.loadplannig.integration.backfill.configuration.MainframePortConfiguration;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.security.mock.MockJBHSecurity;
import com.jbhunt.security.mock.junit.rule.MockJBHSecurityRule;
import com.lmc341i.lmc341.LMC341Port;
import com.lmc342i.lmc342.LMC342Port;
import com.lmc360i.lmc360.LMC360Port;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ImportAutoConfiguration(exclude = MainframePortConfiguration.class)
public class LoadplanningIntegrationbackfillControllerIT {

	@MockBean
	private LMC341Port lmc341Port;

	@MockBean
	private LMC342Port lmc342Port;

	@MockBean
	private LMC360Port lmc360Port;

	@ClassRule
	public static MockJBHSecurityRule mockJBHSecurityRule = new MockJBHSecurityRule();

	@Rule
	public final JUnitRestDocumentation restDocumentation = new JUnitRestDocumentation("target/generated-snippets");

	protected RequestSpecification requestSpecification;

	public static final String username = "user";

	public static final String password = "pass";

	protected OperationPreprocessor removeAllHeadersExceptContentType = removeMatchingHeaders("^(?!Content-Type).*$");

	public final String OPERATIONAL_PLAN_JSON_PATH = "/operationalplan.json";

	public final String OPERATIONAL_PLAN_WORK_ORDER_JSON_PATH = "/operationalplan_workOrder.json";

	public final String OPERATIONAL_PLAN_UPDATE_JSON_PATH = "/operationalplan_update.json";

	public final String OPERATIONAL_PLAN_WORK_ORDER_UPDATE_JSON_PATH = "/operationalplan_workOrder_update.json";
	

	@MockBean
	private JdbcTemplate sqlServerjdbcTemplate;

	@Autowired
	private ObjectMapper objectMapper;

	@LocalServerPort
	private int port;

	@Before
	public void setup() {
		RestAssured.port = port;
		this.requestSpecification = new RequestSpecBuilder()
				.addFilter(documentationConfiguration(this.restDocumentation)).build();

	}

	@BeforeClass
	public static void beforeClass() throws IOException {
		MockJBHSecurity.initialize();
		System.setProperty("runtime.environment", "MOCK");
		System.setProperty("com.jbhunt.biz.securepid.OverridePath", "src/test/resources/pid");
		System.setProperty("DOMAIN_PID", "");
		System.setProperty("DOMAIN_PASSWORD", "");
	}

	@Test
	public void testLoadCreateForFrieght() throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_JSON_PATH)),
				OperationalPlanEvent.class);
		Response response = given(this.requestSpecification).auth().basic(username, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

	@Test
	public void testLoadCreateForOWO() throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_WORK_ORDER_JSON_PATH)),
				OperationalPlanEvent.class);
		Response response = given(this.requestSpecification).auth().basic(username, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

	@Test
	public void testLoadUpdateForFrieght() throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_UPDATE_JSON_PATH)),
				OperationalPlanEvent.class);
		Response response = given(this.requestSpecification).auth().basic(username, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

	@Test
	public void testLoadUpdateForOWO() throws Exception {
		MockJBHSecurity.addSecurityForUser(mockUser(username, password).withAuthLevels(UPDATE));
		OperationalPlanEvent operationalPlanEvent = objectMapper.readValue(
				IOUtils.toString(this.getClass().getResourceAsStream(OPERATIONAL_PLAN_WORK_ORDER_UPDATE_JSON_PATH)),
				OperationalPlanEvent.class);
		Response response = given(this.requestSpecification).auth().basic(username, password).accept(ContentType.JSON)
				.contentType(ContentType.JSON).body(operationalPlanEvent)
				.post("/ws_loadplanning_integration_backfill/backfill/operationalplans");
		assertThat(response.statusCode(), is(HttpStatus.SC_OK));
	}

}
