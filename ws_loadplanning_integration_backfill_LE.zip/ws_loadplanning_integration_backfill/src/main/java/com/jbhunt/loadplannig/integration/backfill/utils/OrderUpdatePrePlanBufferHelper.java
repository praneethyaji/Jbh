package com.jbhunt.loadplannig.integration.backfill.utils;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOthOrdBuffer7;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOthOrdBuffer7.Oee5InBondInfo;
import com.request.oec145i.oec145.ProgramInterface.Oee5InputChannelData.Oee5InOthOrdBuffer7.Oee5InCustomBrokerData;

@Service
public class OrderUpdatePrePlanBufferHelper {

	public Oee5InOthOrdBuffer7 mapPrePlanBuffer() {
        Oee5InOthOrdBuffer7 oee5InPreplanBuffer7 = new Oee5InOthOrdBuffer7();
        Oee5InBondInfo bondInformation = new Oee5InBondInfo();
        List<Oee5InCustomBrokerData> customBrokerDataList = new ArrayList<>();
        oee5InPreplanBuffer7.setOee5InBondInfo(bondInformation);
        oee5InPreplanBuffer7.setOee5InCustBrkBuffer7A(customBrokerDataList);
        return oee5InPreplanBuffer7;
    }

}
