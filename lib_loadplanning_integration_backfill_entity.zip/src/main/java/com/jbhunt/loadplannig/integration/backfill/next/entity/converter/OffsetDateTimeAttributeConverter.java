package com.jbhunt.loadplannig.integration.backfill.next.entity.converter;

import com.jbhunt.loadplannig.integration.backfill.next.entity.constants.LoadplanningIntegrationbackfillConstants;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class OffsetDateTimeAttributeConverter implements AttributeConverter<OffsetDateTime, String> {

    @Override
    public String convertToDatabaseColumn(OffsetDateTime offsetDateTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(LoadplanningIntegrationbackfillConstants.DATE_TIME_OFFSET_FORMATTER_PATTERN);
        return offsetDateTime.format(formatter);
    }

    @Override
    public OffsetDateTime convertToEntityAttribute(String dateTimeString) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(LoadplanningIntegrationbackfillConstants.DATE_TIME_OFFSET_FORMATTER_PATTERN);
        return OffsetDateTime.parse(dateTimeString, formatter);
    }

}