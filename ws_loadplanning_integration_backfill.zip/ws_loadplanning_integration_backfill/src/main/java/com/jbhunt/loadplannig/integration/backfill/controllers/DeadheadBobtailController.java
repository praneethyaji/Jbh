package com.jbhunt.loadplannig.integration.backfill.controllers;

import java.net.URISyntaxException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.services.DeadheadBobtailService;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEventSubType;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class DeadheadBobtailController extends BackfillBaseController {

	private final DeadheadBobtailService deadheadBobtailService;

	@PatchMapping("/operationalplans/{operationalPlanId}/deadhead")
	public ResponseEntity<BackfillServiceResponse> deadhead(
			@RequestBody final OperationalPlanDTO operationalPlanDTO) throws URISyntaxException {
		log.info("Triggered - /backfill/deadheadbobtail");
		deadheadBobtailService.deadHeadBobTail(operationalPlanDTO, OperationalPlanEventSubType.DEADHEAD_CHECKCALL.name());
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
	
	@PatchMapping("/operationalplans/{operationalPlanId}/bobtail")
	public ResponseEntity<BackfillServiceResponse> bobtail(
			@RequestBody final OperationalPlanDTO operationalPlanDTO) throws URISyntaxException {
		log.info("Triggered - /backfill/deadheadbobtail");
		deadheadBobtailService.deadHeadBobTail(operationalPlanDTO,OperationalPlanEventSubType.BOBTAIL_CHECKCALL.name());
		return ResponseEntity.ok(getBackfillServiceSuccessResponse());
	}
}
