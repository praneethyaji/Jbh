package com.jbhunt.loadplannig.integration.backfill.client;

import static com.jbhunt.loadplannig.integration.backfill.constants.ApplicationConstants.OPERATIONAL_PLAN_ID;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.dto.BackfillServiceResponse;
import com.jbhunt.loadplannig.integration.backfill.dto.LegacyOrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplannig.integration.backfill.exception.Mainframe404Exception;
import com.jbhunt.loadplannig.integration.backfill.exception.Mainframe904Exception;
import com.jbhunt.loadplannig.integration.backfill.exception.Mainframe911Exception;
import com.jbhunt.loadplannig.integration.backfill.exception.Mainframe913Exception;
import com.jbhunt.loadplannig.integration.backfill.exception.MainframeCICSWebServiceDownException;
import com.jbhunt.loadplannig.integration.backfill.exception.MainframeFileNetDownException;
import com.jbhunt.loadplannig.integration.backfill.properties.LoadplanningIntegrationbackfillProperties;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.event.OperationalPlanEvent;
import com.jbhunt.loadplanning.owo.dto.event.OperationalWorkOrderEvent;
import com.jbhunt.operations.admin.operationalgroup.dto.event.OperationalGroupEvent;
import com.jbhunt.operations.drivertruckassignment.dto.ResourceESDTO;
import com.jbhunt.operations.equipmentgroup.dto.EquipmentGroupESDTO;
import com.jbhunt.operations.equipmentgroup.dto.OpexEquipmentLocationUpdateDTO;
import com.jbhunt.operations.equipmentgroup.dto.RemoveEquipmentFromGroupBackFillDTO;
import com.jbhunt.operations.trackandtrace.dto.CheckCallESDTO;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@AllArgsConstructor
public class LoadplanningIntegrationbackfillClient {

	private final LoadplanningIntegrationbackfillProperties loadplanningIntegrationbackfillProperties;
	private final RestTemplate loadplanningIntegrationbackfillRestTemplate;

	@HystrixCommand
	public BackfillServiceResponse loadCreate(OperationalPlanEvent operationalPlanEvent) {
		log.info("Load create for Operational plan number: {}",
				operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanNumber());
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/operationalplans", HttpMethod.POST,
				new HttpEntity<>(operationalPlanEvent), BackfillServiceResponse.class));
	}

	@HystrixCommand
	public BackfillServiceResponse loadUpdate(OperationalPlanEvent operationalPlanEvent) {
		log.info("Load update for Operational plan number: {}",
				operationalPlanEvent.getOperationalPlanDTO().getOperationalPlanNumber());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/operationalplans", HttpMethod.PATCH,
				new HttpEntity<>(operationalPlanEvent), BackfillServiceResponse.class));
	}

	@HystrixCommand
	public BackfillServiceResponse deadhead(final OperationalPlanDTO operationalPlanDTO) {
		log.info("Deadhead for Operational plan number: {}", operationalPlanDTO.getOperationalPlanNumber());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		final Map<String, Object> parameter = new HashMap<>();
		parameter.put(OPERATIONAL_PLAN_ID, operationalPlanDTO.getOperationalPlanNumber());
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL()
						+ "/backfill/operationalplans/{operationalPlanId}/deadhead",
				HttpMethod.PATCH, new HttpEntity<>(operationalPlanDTO), BackfillServiceResponse.class, parameter));
	}

	@HystrixCommand
	public BackfillServiceResponse bobtail(final OperationalPlanDTO operationalPlanDTO) {
		log.info("Bobtail for Operational plan number: {}", operationalPlanDTO.getOperationalPlanNumber());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		final Map<String, Object> parameter = new HashMap<>();
		parameter.put(OPERATIONAL_PLAN_ID, operationalPlanDTO.getOperationalPlanNumber());
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL()
						+ "/backfill/operationalplans/{operationalPlanId}/bobtail",
				HttpMethod.PATCH, new HttpEntity<>(operationalPlanDTO), BackfillServiceResponse.class, parameter));
	}

	@HystrixCommand
	public BackfillServiceResponse resourceAssignment(final OperationalPlanDTO operationalPlanDTO) {
		log.info("Resource Assignment for Operational plan number: {}", operationalPlanDTO.getOperationalPlanNumber());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		final Map<String, Object> parameter = new HashMap<>();
		parameter.put(OPERATIONAL_PLAN_ID, operationalPlanDTO.getOperationalPlanId());
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL()
						+ "/backfill/operationalplans/{operationalPlanId}/resourceassignments",
				HttpMethod.PATCH, new HttpEntity<>(operationalPlanDTO), BackfillServiceResponse.class, parameter));
	}

	@HystrixCommand
	public BackfillServiceResponse cancelResourceAssignment(final OperationalPlanDTO operationalPlanDTO) {
		log.info("Cancel Resource Assignment for Operational plan number: {}", operationalPlanDTO.getOperationalPlanNumber());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		final Map<String, Object> parameter = new HashMap<>();
		parameter.put(OPERATIONAL_PLAN_ID, operationalPlanDTO.getOperationalPlanId());
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL()
						+ "/backfill/operationalplans/{operationalPlanId}/resourceassignments/cancel",
				HttpMethod.PATCH, new HttpEntity<>(operationalPlanDTO), BackfillServiceResponse.class, parameter));
	}
	
	@HystrixCommand
	public BackfillServiceResponse createPayRoute(final OperationalPlanDTO operationalPlanDTO) {
		log.info("Create PayRoute for Operational plan number: {}", operationalPlanDTO.getOperationalPlanNumber());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		final Map<String, Object> parameter = new HashMap<>();
		parameter.put(OPERATIONAL_PLAN_ID, operationalPlanDTO.getOperationalPlanId());
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL()
						+ "/backfill/operationalplans/{operationalPlanId}/createpayroute",
				HttpMethod.PATCH, new HttpEntity<>(operationalPlanDTO), BackfillServiceResponse.class, parameter));
	}
	
	@HystrixCommand
	public BackfillServiceResponse updatePayRoute(final OperationalPlanDTO operationalPlanDTO) {
		log.info("Update PayRoute for Operational plan number: {}", operationalPlanDTO.getOperationalPlanNumber());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		final Map<String, Object> parameter = new HashMap<>();
		parameter.put(OPERATIONAL_PLAN_ID, operationalPlanDTO.getOperationalPlanId());
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL()
						+ "/backfill/operationalplans/{operationalPlanId}/updatepayroute",
				HttpMethod.PATCH, new HttpEntity<>(operationalPlanDTO), BackfillServiceResponse.class, parameter));
	}

	@HystrixCommand
	public BackfillServiceResponse createInboundToYard(final OperationalPlanDTO operationalPlanDTO) {
		log.info("Inbound to yard for Operational plan number: {}", operationalPlanDTO.getOperationalPlanNumber());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		final Map<String, Object> parameter = new HashMap<>();
		parameter.put(OPERATIONAL_PLAN_ID, operationalPlanDTO.getOperationalPlanId());
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL()
						+ "/backfill/operationalplans/{operationalPlanId}/inboundtoyard",
				HttpMethod.PATCH, new HttpEntity<>(operationalPlanDTO), BackfillServiceResponse.class, parameter));
	}

	@HystrixCommand
	public BackfillServiceResponse driverTruckPairing(ResourceESDTO assignResourceESDTO) {
		log.info("driver and truck pairing client started, driverId:{},equipmentId: {}",
				assignResourceESDTO.getPerson(), assignResourceESDTO.getEquipmentId());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/drivertruckassignments",
				HttpMethod.POST, new HttpEntity<>(assignResourceESDTO), BackfillServiceResponse.class));
	}

	@HystrixCommand
	public BackfillServiceResponse createOWO(OperationalWorkOrderEvent operationalWorkOrderEvent) {
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		log.info("Create OWO from client ........ ");
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/operationalworkorders",
				HttpMethod.POST, new HttpEntity<>(operationalWorkOrderEvent), BackfillServiceResponse.class));
	}

	@HystrixCommand
	public BackfillServiceResponse updateOWO(OperationalWorkOrderEvent operationalWorkOrderEvent) {
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		log.info("Update OWO from client ........ ");
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/operationalworkorders",
				HttpMethod.PATCH, new HttpEntity<>(operationalWorkOrderEvent), BackfillServiceResponse.class));
	}

	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "10000") })
	public LegacyOrderOperationalPlanAssociationDTO fetchLegacyOrderDetails(Integer operationalplanid) {
		Map<String, Object> parameter = new HashMap<>();
		parameter.put("operationalplanid", operationalplanid);
		ResponseEntity<LegacyOrderOperationalPlanAssociationDTO> response = loadplanningIntegrationbackfillRestTemplate
				.exchange(
						loadplanningIntegrationbackfillProperties.getBaseURL()
								+ "/backfill/legacyorders/operationalplanid/{operationalplanid}",
						HttpMethod.GET, null,
						new ParameterizedTypeReference<LegacyOrderOperationalPlanAssociationDTO>() {
						}, parameter);
		return getResponseBody(response);
	}

	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "10000") })
	public List<LegacyOrderOperationalPlanAssociationDTO> fetchOperationalPlanIdsByOrderId(Integer legacyorderid) {
		Map<String, Object> parameter = new HashMap<>();
		parameter.put("legacyorderid", legacyorderid);
		ResponseEntity<List<LegacyOrderOperationalPlanAssociationDTO>> response = loadplanningIntegrationbackfillRestTemplate
				.exchange(
						loadplanningIntegrationbackfillProperties.getBaseURL()
								+ "/backfill/legacyorders/operationalplans/legacyorderid/{legacyorderid}",
						HttpMethod.GET, null,
						new ParameterizedTypeReference<List<LegacyOrderOperationalPlanAssociationDTO>>() {
						}, parameter);
		return getResponseBody(response);
	}

	@HystrixCommand
	public BackfillServiceResponse addCommenCall(CheckCallESDTO CheckCallESDTO) {
		log.info("add comment for tacall : {}", CheckCallESDTO.getOperationalPlanCheckCallId());
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/commentcalls", HttpMethod.PATCH,
				new HttpEntity<>(CheckCallESDTO), BackfillServiceResponse.class));
	}

	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "10000") })
	public Integer fetchOperationalPlanId(Integer legacyorderid, Integer legacyjobid,
			Integer legacyresourcereservationid) {
		Map<String, Object> parameter = new HashMap<>();
		parameter.put("legacyorderid", legacyorderid);
		parameter.put("legacyjobid", legacyjobid);
		parameter.put("legacyresourcereservationid", legacyresourcereservationid);
		ResponseEntity<Integer> response = loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL()
						+ prepareCrossServiceReferenceUrl(legacyjobid, legacyresourcereservationid),
				HttpMethod.GET, null, new ParameterizedTypeReference<Integer>() {
				}, parameter);
		return getResponseBody(response);
	}

	private BackfillServiceResponse validateResponse(
			ResponseEntity<BackfillServiceResponse> backfillServiceResponseEntity) {
		BackfillServiceResponse backfillServiceResponse = getResponseBody(backfillServiceResponseEntity);
		if (backfillServiceResponse != null && backfillServiceResponse.getStatusCode() != null) {
			switch (backfillServiceResponse.getStatusCode()) {
			case "904":
				throw new Mainframe904Exception(backfillServiceResponse.getStatusMessage());
			case "911":
				throw new Mainframe911Exception(backfillServiceResponse.getStatusMessage());
			case "913":
				throw new Mainframe913Exception(backfillServiceResponse.getStatusMessage());
			case "404":
				throw new Mainframe404Exception(backfillServiceResponse.getStatusMessage());
			case "CICS Web service is down":
				throw new MainframeCICSWebServiceDownException(backfillServiceResponse.getStatusMessage());
			case "FineNext is down":
				throw new MainframeFileNetDownException(backfillServiceResponse.getStatusMessage());
			case "500":
				throw new JBHuntRuntimeException(backfillServiceResponse.getStatusMessage());
			default:
				log.info("response code: {}, message: {}", backfillServiceResponse.getStatusCode(),
						backfillServiceResponse.getStatusMessage());

			}
		}
		return backfillServiceResponse;
	}

	private <T> T getResponseBody(ResponseEntity<T> responseEntity) {
		if (HttpStatus.NOT_FOUND.equals(responseEntity.getStatusCode())
				|| HttpStatus.SERVICE_UNAVAILABLE.equals(responseEntity.getStatusCode())) {
			throw new JBHuntRuntimeException(responseEntity.getStatusCode().name());
		}
		return Optional.ofNullable(responseEntity).map(ResponseEntity::getBody).orElse(null);
	}

	@HystrixCommand
	public BackfillServiceResponse beaming(OpexEquipmentLocationUpdateDTO equipmentLocationUpdateDTO) {
		log.info("beam process equipment and location client started, equipmentId:{}, locationId:{} ",
				equipmentLocationUpdateDTO.getEquipmentId(), equipmentLocationUpdateDTO.getLocationId());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/equipments/locations",
				HttpMethod.POST, new HttpEntity<>(equipmentLocationUpdateDTO), BackfillServiceResponse.class));
	}

	@HystrixCommand
	public BackfillServiceResponse equipmentAssignment(EquipmentGroupESDTO equipmentGroupESDTO) {
		log.info("Equipment Assignment");
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/equipmentgroup", HttpMethod.POST,
				new HttpEntity<>(equipmentGroupESDTO), BackfillServiceResponse.class));
	}

	@HystrixCommand
	public BackfillServiceResponse equipmentUnassignment(RemoveEquipmentFromGroupBackFillDTO removeEquipment) {
		log.info("Equipment Unassignment");
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/equipmentgroup", HttpMethod.PATCH,
				new HttpEntity<>(removeEquipment), BackfillServiceResponse.class));
	}
	
	@HystrixCommand
	public BackfillServiceResponse createFleet(OperationalGroupEvent operationalGroupEvent) {
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		log.info("Create Fleet from client ........ ");
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/operationalevents",
				HttpMethod.POST, new HttpEntity<>(operationalGroupEvent), BackfillServiceResponse.class));
	}
	
	@HystrixCommand
	public BackfillServiceResponse updateFleet(OperationalGroupEvent operationalGroupEvent) {
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		log.info("Update Fleet from client ........ ");
		return validateResponse(loadplanningIntegrationbackfillRestTemplate.exchange(
				loadplanningIntegrationbackfillProperties.getBaseURL() + "/backfill/operationalevents",
				HttpMethod.PATCH, new HttpEntity<>(operationalGroupEvent), BackfillServiceResponse.class));
	}

	private String prepareCrossServiceReferenceUrl(Integer legacyjobid, Integer legacyresourcereservationid) {
		StringBuilder sb = new StringBuilder();
		sb.append("/backfill/legacyorders/operationalplans/legacyorderid/{legacyorderid}");
		if (legacyjobid != null && legacyresourcereservationid == null) {
			sb.append("?legacyjobid={legacyjobid}");
		} else if (legacyresourcereservationid != null && legacyjobid == null) {
			sb.append("?legacyresourcereservationid={legacyresourcereservationid}");
		} else {
			sb.append("?legacyjobid={legacyjobid}&legacyresourcereservationid={legacyresourcereservationid}");
		}
		return sb.toString();
	}

}