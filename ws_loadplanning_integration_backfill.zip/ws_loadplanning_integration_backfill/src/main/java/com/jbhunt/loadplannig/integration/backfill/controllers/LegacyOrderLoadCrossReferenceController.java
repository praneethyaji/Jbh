package com.jbhunt.loadplannig.integration.backfill.controllers;

import java.util.Optional;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbhunt.infrastructure.exception.JBHValidationException;
import com.jbhunt.loadplannig.integration.backfill.dto.LegacyOrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplannig.integration.backfill.services.LegacyOrderLoadCrossReferenceService;

import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@RequestMapping("/backfill")
public class LegacyOrderLoadCrossReferenceController {

	@Autowired
	private final LegacyOrderLoadCrossReferenceService crossReferenceService;

	@GetMapping(value = "/legacyorders/operationalplanid/{operationalplanid}")
	public ResponseEntity<LegacyOrderOperationalPlanAssociationDTO> getLegacyOrderDetails(@PathVariable("operationalplanid") Integer operationalplanid) {
		LegacyOrderOperationalPlanAssociationDTO legacyOrderOperationalPlanAssociationDTO = crossReferenceService
				.getLegacyOrderDetails(operationalplanid);

		return Optional.ofNullable(legacyOrderOperationalPlanAssociationDTO).isPresent()
				? new ResponseEntity<>(legacyOrderOperationalPlanAssociationDTO, HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@GetMapping(value = "/legacyorders/operationalplans/legacyorderid/{legacyorderid}")
	public ResponseEntity<Object> getOperationalPlanId(@PathVariable("legacyorderid") Integer legacyorderid,
			@QueryParam("legacyjobid") Integer legacyjobid,
			@QueryParam("legacyresourcereservationid") Integer legacyresourcereservationid) {
		try {
			return ResponseEntity.ok(legacyjobid == null && legacyresourcereservationid == null
					? crossReferenceService.getOperationalPlansByOrderId(legacyorderid)
					: crossReferenceService.getOperationalPlanIdByJoborReservationId(legacyorderid, legacyjobid,
							legacyresourcereservationid));
		} catch (JBHValidationException ex) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

	}

}
