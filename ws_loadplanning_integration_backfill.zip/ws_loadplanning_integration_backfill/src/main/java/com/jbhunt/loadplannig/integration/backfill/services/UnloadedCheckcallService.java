package com.jbhunt.loadplannig.integration.backfill.services;

import java.net.URISyntaxException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.ws.Holder;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jbhunt.infrastructure.exception.JBHuntRuntimeException;
import com.jbhunt.loadplannig.integration.backfill.constants.CommonConstants;
import com.jbhunt.loadplannig.integration.backfill.dto.CheckcallDTO;
import com.jbhunt.loadplannig.integration.backfill.enums.EventStatusEnum;
import com.jbhunt.loadplannig.integration.backfill.next.repository.BackFillEventTrackingRepository;
import com.jbhunt.loadplannig.integration.backfill.utils.CheckCallHelper;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanCheckCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanStopActivityCheckCallDTO;
import com.jbhunt.loadplanning.operationalplan.dto.checkcall.OperationalPlanStopActivityCheckCallReferenceNumberDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OperationalPlanStopDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.OrderOperationalPlanAssociationDTO;
import com.jbhunt.loadplanning.operationalplan.dto.core.ResourceAssignmentPlanDTO;
import com.lmc363i.lmc363.LMC363Port;
import com.request.lmc363i.lmc363.ProgramInterface.Lm36ComCommareaRecord;
import com.response.lmc363i.lmc363.ProgramInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class UnloadedCheckcallService  extends CheckCallBackfillService{

    private final CheckCallHelpService checkCallHelpService;
    private final LMC363Port lmc363Port;
    private final BackFillEventTrackingRepository backFillEventTrackingRepository;
    private final CheckCallHelper checkCallHelper;
    private final TimeZoneUtilityService timeZoneUtilityService;

    public void unloaded(OperationalPlanDTO operationalPlanDTO) throws URISyntaxException {
        log.info("UnLoaded CheckCall");
        ResourceAssignmentPlanDTO resourceAssignmentPlan=checkCallHelpService.getResourceAssignmentPlan(operationalPlanDTO);
        CheckcallDTO checkcallDTO= new CheckcallDTO();
        Map<String,String> checkCallElementValuesMap= new HashMap<>();

        OperationalPlanCheckCallDTO operationalPlanCheckCallDTO =operationalPlanDTO.getOperationalPlanCheckCallList().stream().filter(operationalPlanCheckCall->
                operationalPlanCheckCall.getCheckCallType().getCheckCallTypeCode().equalsIgnoreCase("Unloaded")
        ).findAny().orElseThrow(()-> new JBHuntRuntimeException("Unloaded Checkcall not found."));
        OperationalPlanStopDTO operationalPlanStopDTO = operationalPlanDTO.getOperationalPlanStops().stream()
                .filter(operationalPlanStop -> operationalPlanStop.getOperationalPlanStopId()
                        .equals(operationalPlanCheckCallDTO.getOperationalPlanStopId()))
                .findFirst().orElseThrow(() -> new JBHuntRuntimeException(
                        "Stop Id " + operationalPlanCheckCallDTO.getOperationalPlanStopId() + " is not found"));
        Optional<List<OrderOperationalPlanAssociationDTO>> orderOperationalPlanAssociationDTOList = Optional
				.ofNullable(operationalPlanDTO).map(OperationalPlanDTO::getOrderOperationalPlanAssociations);
		if (orderOperationalPlanAssociationDTOList.isPresent()) {
			OrderOperationalPlanAssociationDTO orderOperationalPlanAssociationDTO = orderOperationalPlanAssociationDTOList
					.get().stream().findFirst()
					.orElseThrow(() -> new JBHuntRuntimeException("orderOperational Plan Association is required."));
			checkCallHelpService.populateCheckcallWithOrderInformation(orderOperationalPlanAssociationDTO, checkcallDTO);
		}

        checkCallHelpService.populateCheckcallWithEquipmentInformation(resourceAssignmentPlan,checkcallDTO);
        if (org.apache.commons.lang.StringUtils.isBlank(checkcallDTO.getTrailerContainerNumber())){
            throw new JBHuntRuntimeException("Container not found in TEquipment and required for Unloaded");
        }
        checkcallDTO.setComment(Optional.ofNullable(operationalPlanCheckCallDTO.getCheckCallComment()).orElse(""));

        checkcallDTO.setDataState(CommonConstants.DATA_STATE_B);
        checkcallDTO.setUserId(operationalPlanDTO.getCreateUserId());

        checkcallDTO.setTractorRqdFlg(CommonConstants.TRACTOR_RQD_FLAG);
        if (StringUtils.isEmpty(checkcallDTO.getCarrier())){
            checkcallDTO.setCarrierFlg("I");
        }
        checkcallDTO.setLocationTimeZone(timeZoneUtilityService.getTimeBasedOnLocation(operationalPlanStopDTO.getLocationId()));

        DateTimeFormatter sdfDate = DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT);
        DateTimeFormatter sdfTime = DateTimeFormatter.ofPattern(CommonConstants.TIME_FORMAT);

        checkcallDTO.setCallType(CommonConstants.UNLOADED_CALL_TYPE);
        Optional.ofNullable(operationalPlanCheckCallDTO.getArrivalCall()).ifPresent(arrivalCall -> {
            checkCallHelpService.populateArrivalInformation(operationalPlanDTO.getOperationalPlanCheckCallList(), arrivalCall, checkcallDTO);
        });

        ZonedDateTime stopActivityTimestamp =operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getStopActivityTimestamp().atZoneSameInstant(ZoneId.of(checkcallDTO.getLocationTimeZone()));

        checkcallDTO.setLoadUnloadDate(stopActivityTimestamp.format(sdfDate));
        checkcallDTO.setLoadUnloadtime(stopActivityTimestamp.format(sdfTime));

        Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall())
                .map(OperationalPlanStopActivityCheckCallDTO::getStopActivityWeight)
                .ifPresent(v ->{
                    checkcallDTO.setWeight(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getStopActivityWeight().longValue());
                    checkCallElementValuesMap.put("LMB4COM-UCALL-WGT-RQD-SW","Y");
                });
        Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall())
                .map(OperationalPlanStopActivityCheckCallDTO::getStopActivityQuantity)
                .ifPresent(v -> {
                    checkcallDTO.setQuantity(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getStopActivityQuantity());
                    checkCallElementValuesMap.put("LMB4COM-UCALL-QTY-RQD-SW","Y");
                });
        Character hazMatFlag=Optional.ofNullable(operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getHazardousMaterialIndicator()).orElse('N');

        checkCallElementValuesMap.put("LMB4COM-UCALL-ADATE-RQD-SW","Y");
        checkCallElementValuesMap.put("LMB4COM-UCALL-DATE-RQD-SW","Y");
        checkCallElementValuesMap.put("LMB4COM-UCALL-HAZMAT-FLG",hazMatFlag.toString());
        checkCallElementValuesMap.put("LMB4COM-UCALL-OWGT-OVR-FLG","Y");
        checkCallHelpService.populateCheckcallWithLocationCityState(checkcallDTO);

        checkCallElementValuesMap.put("LMB4COM-UCALL-DRV-CNT-FLG","N");
        operationalPlanCheckCallDTO.getOperationalPlanStopCheckCallServices().
                stream().filter(planStopService -> planStopService.getOperationalPlanServiceTypeCode().
                equalsIgnoreCase(CommonConstants.DRIVER_UNLOADED)).findFirst().
                ifPresent(x->checkCallElementValuesMap.put("LMB4COM-UCALL-DRV-CNT-FLG","Y"));

        checkCallElementValuesMap.put("LMB4COM-UCALL-RCV-UNL-FLG","N");
        checkCallElementValuesMap.put("LMB4COM-UCALL-LUMP-UNL-FLG","N");
        checkCallElementValuesMap.put("LMB4COM-UCALL-DRV-PULPAL-FLG","N");
        checkCallElementValuesMap.put("LMB4COM-UCALL-DRV-THRPAL-FLG","N");
        checkCallElementValuesMap.put("LMB4COM-UCALL-DRV-RMBRC-FLG","N");

        checkCallElementValuesMap.put("LMB4COM-PROT-UCALL-BOL-SW","Y");
        checkCallElementValuesMap.put("LMB4COM-PROT-UCALL-HAZMAT-SW","Y");
        checkCallElementValuesMap.put("LMB4COM-PROT-UCALL-DRVCNT-SW","Y");
        checkCallElementValuesMap.put("LMB4COM-UCALL-MIL-OVR-FLG","3");

        checkCallHelpService.populateHubForUnloaded(checkcallDTO,checkCallElementValuesMap);
        checkCallElementValuesMap.put("LMB4COM-UCALL-HUB-RQD-SW","Y");
        operationalPlanCheckCallDTO.getOperationalPlanStopActivityCheckCall().getOperationalPlanStopActivityCheckCallReferenceNumbers().forEach(referenceNumber->
            populateReferenceNumber(referenceNumber,checkCallElementValuesMap,checkcallDTO)
        );
        String checkcallVars= getCheckCallVarsValues(checkCallElementValuesMap,checkCallHelper.getCheckcallUnloadedElements());
        checkcallDTO.setCheckCallVars(checkcallVars);
        log.info("checkcallVars {}", checkcallVars);
        log.info("checkcallVars.lenght {}", checkcallVars.length());

        Lm36ComCommareaRecord lm36ComCommareaRecord =checkCallHelper.createLm36ComCommareaRecord(checkcallDTO);
        com.request.lmc363i.lmc363.ProgramInterface.Lm36ComReturnToJava lm36ComReturnToJava =checkCallHelper.getLm36ComReturnToJava(checkcallDTO);

        javax.xml.ws.Holder<ProgramInterface.Lm36ComReturnToJavaOutput> lm36ComReturnToJavaOutputHolder = new Holder<>();
        javax.xml.ws.Holder<String> lm36ComFillerOutputHolder = new Holder<>();

        log.info(" sending checkcallDTO {}",checkcallDTO);
        lmc363Port.lmc363Operation(lm36ComCommareaRecord, lm36ComReturnToJava, "", new Holder<>(), lm36ComReturnToJavaOutputHolder, lm36ComFillerOutputHolder);

        checkCallHelper.loggingCheckcallResponse( lm36ComReturnToJavaOutputHolder);
        log.info("Result of the Unloaded operation from the mainframe: {} ",lm36ComFillerOutputHolder.value);
        backFillEventTrackingRepository.updateBackTrackingDetails(operationalPlanDTO, EventStatusEnum.COMPLETED.name(),
				"");
    }
    private void populateReferenceNumber(OperationalPlanStopActivityCheckCallReferenceNumberDTO referenceNumber, Map<String,String> checkCallElementValuesMap, CheckcallDTO checkcallDTO){
        switch (referenceNumber.getReferenceNumberTypeCode()){
            case CommonConstants.BOL :
                checkcallDTO.setBolNumber(referenceNumber.getReferenceNumberValue());
                checkCallElementValuesMap.put("LMB4COM-UCALL-BOL-RQD-SW","Y");
                break;
            case CommonConstants.SEAL:
                checkCallElementValuesMap.put("LMB4COM-UCALL-SEAL-RQD-SW","Y");
                checkcallDTO.setSeal(referenceNumber.getReferenceNumberValue());
                break;
            case CommonConstants.PO_NBR:
                checkCallElementValuesMap.put("LMB4COM-UCALL-PO-NBR",referenceNumber.getReferenceNumberValue());
                checkCallElementValuesMap.put("LMB4COM-PROT-UCALL-PO-NBR-SW","Y");
                break;
                default:
                    break;
        }
    }
}
